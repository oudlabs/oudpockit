#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

# Install squid web proxy
sudo -n yum -y install squid httpd-tools
rc=$?

# Configure squid web proxy
sudo tee /etc/squid/squid.conf <<EOF

auth_param basic program /usr/lib64/squid/basic_ncsa_auth /etc/squid/passwords
auth_param basic realm proxy
acl authenticated proxy_auth REQUIRED
http_access allow authenticated
EOF

# Add web proxy user
#sudo htpasswd -c /etc/squid/passwords webproxy <<EOF
#${bPW}
#EOF

htpasswd -ci /etc/squid/passwords webproxy >> ${logdir}/squid-setup-${now}.log 2>&1 <<EOF
${bPW}
EOF

# Open up squid web proxy port in local firewall
sudo -n firewall-cmd --add-port=3128/tcp --permanent
rc=$?
sudo -n firewall-cmd --reload
rc=$?
sudo -n systemctl restart firewalld.service
rc=$?

# Enable and start squid web proxy
sudo -n systemctl enable squid
rc=$?
sudo -n systemctl start squid

