#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Show Usage
###############################################################################
showUsage() {
   echo "${cmd} [supplier|secondary] [options]"
   echo "  --pnum <n>"
   echo "  --supplier <supplierHost>:<adminPort>:<replPort>"
   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            pnum) myPnum="$1";shift;;
            suffix) suffix="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            swdir) swdir="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -n "${myPnum}" ];then pnum=${myPnum};else pnum=10;fi
if [ -z "${oudSupplier}" ];then oudSupplier="${localHost}:${pnum}444:${pnum}989";fi
jPW="${cfgdir}/...pw"

# Generate sslv3 and TNS data
echo "DEMO --> Generate tns and sslv3 data"
#${curdir}/manage_data.sh gendata -n tns   -N 1     --suffix "${suffix}" --rm
${curdir}/manage_data.sh gendata -n sslv3 -N 20000 --suffix "${suffix}" --rm

# Setup first OUD instance
echo "DEMO --> Setup first OUD instance for TNS"
${curdir}/demo_tns.sh --pnum 10 -N 1 --suffix "${suffix}" -j "${jPW}"

# Apply batch config to oud10
echo "DEMO --> Apply sslv3 batch config to first OUD instance"
${oudmwdir}/oud10/OUD/bin/dsconfig -h ${localHost} -X -p 10444 -D "${bDN}" -j "${jPW}" --no-prompt --batchFilePath ${cfgdir}/sslv3.batch >> ${logdir}/oud-cfg-${now}.log 2>&1


# Add admin user
echo "DEMO --> Setup admin and data user to first OUD instance"
${curdir}/manage_muser.sh add --port 10444 --dstype oud --utype admin -j "${jPW}" --mpw "${jPW}"

# Add data user
${curdir}/manage_muser.sh add --port 10636 --dstype oud --utype data --suffix "${suffix}" -j "${jPW}" --mpw "${jPW}"

# Add sslv3 data
echo "DEMO --> Load users"
${oudmwdir}/oud10/OUD/bin/ldapmodify -h ${localHost} -Z -X -p 10636 -D "${bDN}" -j "${jPW}" -a -c -f ${cfgdir}/sslv3.ldif > ${logdir}/load-sslv3-${now}.log 2>&1

#echo "DEMO --> Load databases"
#${oudmwdir}/oud10/OUD/bin/ldapmodify -h ${localHost} -Z -X -p 10636 -D "${bDN}" -j "${jPW}" -a -c -f ${cfgdir}/tns.ldif > ${logdir}/load-tns-${now}.log 2>&1

# Add second OUD instance
echo "DEMO --> Setup second OUD instance for TNS"
set -x
${curdir}/manage_eus.sh extend -n sslv3 --pnum 20 --supplier ${oudSupplier}
rc=$?
set +x

# Add admin user
echo "DEMO --> Setup admin user to second OUD instance"
${curdir}/manage_muser.sh add --port 20444 --dstype oud --utype admin -j "${jPW}" --mpw "${jPW}"

# Apply batch config to oud20
echo "DEMO --> Apply sslv3 batch config to second OUD instance"
${oudmwdir}/oud20/OUD/bin/dsconfig -h ${localHost} -X -p 20444 -D "${bDN}" -j "${jPW}" --no-prompt --batchFilePath ${cfgdir}/sslv3.batch >> ${logdir}/oud-cfg-${now}.log 2>&1

# Add third OUD instance
echo "DEMO --> Setup third OUD instance for TNS"
set -x
${curdir}/manage_eus.sh extend -n sslv3 --pnum 30 --supplier ${oudSupplier}
rc=$?
set +x

# Add admin user
echo "DEMO --> Setup admin user to third OUD instance"
${curdir}/manage_muser.sh add --port 30444 --dstype oud --utype admin -j "${jPW}" --mpw "${jPW}"

# Apply batch config to oud30
echo "DEMO --> Apply sslv3 batch config to third OUD instance"
${oudmwdir}/oud30/OUD/bin/dsconfig -h ${localHost} -X -p 30444 -D "${bDN}" -j "${jPW}" --no-prompt --batchFilePath ${cfgdir}/sslv3.batch >> ${logdir}/oud-cfg-${now}.log 2>&1

# Restart oud1 and oud2 with relaxed cryptography
echo "DEMO --> Restart first two OUD instances with relaxed cryptography enabled"
export OPENDS_JAVA_ARGS="-Djava.security.properties=${samples}/sslv3-java.security -Dcustom.config.location=${samples}/tlsconfig-sslv3.properties"
${oudmwdir}/oud10/OUD/bin/stop-ds > /dev/null
${oudmwdir}/oud10/OUD/bin/start-ds > /dev/null

${oudmwdir}/oud20/OUD/bin/stop-ds > /dev/null
${oudmwdir}/oud20/OUD/bin/start-ds > /dev/null
