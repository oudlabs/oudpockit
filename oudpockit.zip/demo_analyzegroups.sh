#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive 
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} --ldif <file>

DESCRIPTION
     Sample script to analyze group data of LDIF export

     Note when exporting the LDIF file, be sure to disable line wrapping
     with export-ldif --width=0.

OPTIONS
     The following options are supported:

         --ldif <file>       LDIF export from OUD

         --top <n>           Show top <n>
                             Default: 20
                             If set to 0, will show all entries with memberships

EOF

   exit 1

}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            ldif) ldifFile="$1";shift;;
            top) topN="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Validate inputs
###############################################################################
if [ -z "${topN}" ];then topN=20;fi
if [ ${topN} -eq 0 ];then topN=9999999999999;fi
if [ -z "${ldifFile}" ]
then
   echo "ERROR: Must specify --ldif <file>"
   exit 1
fi

if [ -e "${ldifFile}" ]
then
   true
else
   echo "ERROR: LDIF file (${ldifFile}) does not exist"
   exit 1
fi

###############################################################################
# Analyze group data
###############################################################################
objvar=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)

analyze_groups() {
   readarray -t objects < <(egrep -ih "^dn: |^objectClass: group|^objectClass: posixGroup|^member:|^uniqueMember:" ${ldifFile} \
      | sed -e "s/objectClass: //gi" \
            -e "s/^member.*/m/gi" \
            -e "s/^uniqueMember.*/m/gi" \
            -e "s/^dn: /object${objvar}/gi" \
            -e "s/ /_/g" \
            -e "s/	/_/g" \
            -e "s/,.*//g" \
            -e "s/$/|/g" \
      | tr -d '[\n\r]' \
      | sed -e "s/object${objvar}/\nobject:/gi" \
   )

   for (( x=0; x< ${#objects[*]}; x++ ))
   do
      if [[ "${objects[${x}]}" == *\|group* ]]
      then
         group_name=$(echo ${objects[${x}]}|cut -d'|' -f1|sed -e "s/^object://g")
         group_count=$(echo ${objects[${x}]}|cut -d'|' -f3-|sed -e "s/|/ /g"|wc -w)
         printf "%-20s%-10s\n" "${group_count}" "${group_name}"
      fi
   done
}

analyze_users() {
   readarray -t objects < <(egrep -ih "^dn: |^objectClass: person|^objectClass: organizationalPerson|^objectClass: inetOrgPerson|^memberof:|^ismemberof:" ${ldifFile} \
      | sed -e "s/objectClass: person/person/gi" \
            -e "s/objectClass: organizationalPerson/person/gi" \
            -e "s/objectClass: inetOrgPerson/person/gi" \
            -e "s/^memberof.*/m/gi" \
            -e "s/^ismemberof.*/m/gi" \
            -e "s/^dn: /object${objvar}/gi" \
            -e "s/ /_/g" \
            -e "s/	/_/g" \
            -e "s/,.*//g" \
            -e "s/$/|/g" \
      | tr -d '[\n\r]' \
      | sed -e "s/object${objvar}/\nobject:/gi" \
            -e "s/|person|person|/|person|/g" \
            -e "s/|person|person|/|person|/g" \
            -e "s/|person|person|/|person|/g" \
            -e "s/|person|person|/|person|/g" \
   )

   for (( x=0; x< ${#objects[*]}; x++ ))
   do
      if [[ "${objects[${x}]}" == *\|person* ]]
      then
         user_name=$(echo ${objects[${x}]}|cut -d'|' -f1|sed -e "s/^object://g")
         memberof_count=$(echo ${objects[${x}]}|cut -d'|' -f3-|sed -e "s/|/ /g"|wc -w)
         printf "%-20s%-10s\n" "${memberof_count}" "${user_name}"
      fi
   done
}

echo "Analyzing groups..."
printf "%-20s%-10s\n" "Member" "Group"
printf "%-20s%-10s\n" "Count" "Name"
printf "%-20s%-10s\n" "-------------------" "-------------------"
analyze_groups|sort -nr|grep -v "^0 "|head -${topN}

echo -e "\nAnalyzing users..."
printf "%-20s%-10s\n" "MemberOf" "User"
printf "%-20s%-10s\n" "Count" "Name"
printf "%-20s%-10s\n" "-------------------" "-------------------"
analyze_users|sort -nr|grep -v "^0 "|head -${topN}
