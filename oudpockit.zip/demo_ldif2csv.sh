#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

useSSL=''
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            csv) csvFile=$1;shift;;
            ldif) ldifFile=$1;shift;;
            oc) objectClass=$1;shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -z "${objectClass}" ];then objectClass='inetOrgPerson';fi

if [ -z "${ldifFile}" ]
then
   echo "Usage: ${0} --ldif <ldif_file> --csv <csv_file> [--oc <objectClass> ] "
   exit 1
elif [ -e "${ldifFile}" ]
then
   true
else
   echo "ERROR: LDIF file ${ldifFile} does not exist"
   exit 1
fi

if [ -z "${csvFile}" ];then csvFile=$(echo ${ldifFile}|sed -e "s/.ldif//gi" -e "s/$/.csv/g");fi

csnTmpFile="${csvFile}n.tmp"
csvTmpFile="${csvFile}v.tmp"

###############################################################################
# Process LDIF file
###############################################################################
nl=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
dnvar=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
spcvar=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
tabvar=$(head -$((RANDOM % 20000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)

echo "DEMO --> Show Convert LDIF file to CSV file for objectClass ${objectClss}."
echo "   Input CSV File: ${csvFile}"
echo "   Output LDIF File: ${ldifFile}"
echo -e "   Progress: .\c"


# Make tmp file of all attribute names
cat ${ldifFile} \
   |sed -e "s/^dn: /${nl}/g" \
        -e "s/^/|/g" \
        -e "s/objectClass: /|oc/gi" \
        -e "s/: .*/|/gi" \
   |tr -d '[\n\r]' \
   |sed -e "s/${nl}/\n/g" \
        -e "s/||/|/g" \
        -e "s/||/|/g" \
   >> ${csnTmpFile}

# Make tmp file of all attribute values
grep -v objectclass: ${ldifFile} \
   |sed -e "s/: /:/" \
        -e "s/^dn:/${nl}${dnvar}/g" \
        -e "s/^/|/g" \
        -e "s/^.*: /|/gi" \
        -e "s/ /${spcvar}/g" \
        -e "s/	/${tabvar}/g" \
   |tr -d '[\n\r]' \
   |sed -e "s/${nl}/\n/g" \
        -e "s/${dnvar}/dn:/g" \
        -e "s/||/|/g" \
        -e "s/||/|/g" \
   >> ${csvTmpFile}

###############################################################################
# Get the full list of attribute names
###############################################################################
readarray -t attrNames < <(cat ${csnTmpFile}|grep -i "${objectClass}"|sed 's/^[^|]*|//'|sed -e "s/|/\n/g"|sort -u|grep -vi "^objectclass$")
headder="rdn"
for (( n=0; n< ${#attrNames[*]}; n++ ))
do
   if [ -z "${attrNames[${n}]}" ];then attrNames[${n}]='dn';fi
   ckoc=$(echo "${attrNames[${n}]}"|grep "^oc")
   if [ -z "${ckoc}" ]
   then
      headder="${headder}|${attrNames[${n}]}"
   fi
done

###############################################################################
# Get all of the attribute name:value pairs
###############################################################################
readarray -t csvEntries < <(cat ${csvTmpFile}|grep -i "${objectClass}")

###############################################################################
# Construct new array of attribute values based on attrNames array
###############################################################################
newEntries=( )
for (( v=0; v< ${#csvEntries[*]}; v++ ))
do
   echo -e ".\c"
   dnValue=$(echo ${csvEntries[${v}]}|cut -d'|' -f1|cut -d':' -f2)
   rdnValue=$(echo "${dnValue},"|cut -d'=' -f2|cut -d',' -f1)
   newEntries[${v}]="${rdnValue}|${dnValue}"
   newEntries[${v}]="${rdnValue}"
   readarray -t entryLine < <(echo ${csvEntries[${v}]}|sed -e "s/|/\n/g")
   for (( a=0; a< ${#attrNames[*]}; a++ ))
   do
      attrMatch='false'
      for (( e=0; e< ${#entryLine[*]}; e++ ))
      do
         attrName=$(echo "${entryLine[${e}]}:"|cut -d':' -f1)
         attrValue=$(echo "${entryLine[${e}]}"|cut -d':' -f2-|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")

         if [ "${attrName}" == "${attrNames[${a}]}" ]
         then
            newEntries[${v}]="${newEntries[${v}]}|${attrValue}"
            attrMatch='true'
         fi
      done
      if [ -n "${attrValue}" ] && [ "${attrMatch}" == 'false' ]
      then
          newEntries[${v}]="${newEntries[${v}]}|"
      fi
   done
done
echo -e ".done"

echo "${headder}" > ${csvFile}
for (( e=0; e< ${#newEntries[*]}; e++ ))
do
   echo "${newEntries[${e}]}" >> ${csvFile}
done

# Remove the temporary csv file
rm -f "${csnTmpFile}" "${csvTmpFile}"
