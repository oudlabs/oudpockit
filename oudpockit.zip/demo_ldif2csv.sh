#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

useSSL=''
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            csv) csvFile=$1;shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -z "${csvFile}" ]
then
   csvFile="${cfgdir}/e2.csv"
fi

csvTmpFile="${csvFile}.tmp"

###############################################################################
# Generate data
###############################################################################
if [ -e "${cfgdir}/e2.dn" ]
then
   true
else
   echo -e "\nDEMO --> Generate data with e2 template"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_data.sh genall -n e2 -N 100 --rm
   rc=$?;set +x
fi


###############################################################################
# Setup OUD instance
###############################################################################
if [ -e "${oudmwdir}/oud1/OUD/bin/start-ds" ]
then
   true
else
   echo -e "\nDEMO --> Setup OUD instance with e2 template"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oud.sh setup --pnum 1 -n e2 --schema "${samples}/e2.schema"
   rc=$?;set +x
fi

###############################################################################
# Apply some data munging
###############################################################################
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
${lmod} -h ${localHost} -Z -X -p 1636 -D "${bDN}" -j "${jPW}" <<EOF
dn: uid=user10,ou=People,${suffix}
changeType: modify
delete: mobile
-
delete: employeeNumber
-
add: employeeNumber
employeeNumber: 1218818282
EOF

###############################################################################
# Run demo
###############################################################################
nl=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
attr=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
echo "DEMO --> Show data pipeline to convert LDIF to CSV for specific attributes:"
echo "dn|mail|departmentNumber|employeeNumber|mobile|sn|cn|uid" > ${csvFile}

${lsrch} -h ${localHost} ${useSSL} -p ${ldapPort} -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub "objectClass=corpuser" --simplePageSize 250 employeeNumber uid cn sn mobile mail departmentNumber \
   |sed \
      -e "s/^$/${nl}/g" \
      -e "s/^/|/g" \
      -e "s/^|dn: /${attr}1000:/gi" \
      -e "s/^|mobile: /|${attr}1001:/gi" \
      -e "s/^|sn: /|${attr}1002:/gi" \
      -e "s/^|cn: /|${attr}1003:/gi" \
      -e "s/^|mail: /|${attr}1004:/gi" \
      -e "s/^|uid: /|${attr}1005:/gi" \
      -e "s/^|departmentNumber: /|${attr}1006:/gi" \
      -e "s/^|employeeNumber: /|${attr}1007:/gi" \
   |tr -d '[\n\r]' \
   |sed \
      -e "s/${nl}/\n/g" \
   >> ${csvTmpFile}

###############################################################################
# Iterate through the temporary file and sort and populating missing values
###############################################################################
readarray -t csvEntries < <(cat ${csvTmpFile})

# Remove the temporary csv file
rm -f "${csvTmpFile}"

for (( x=0; x< ${#csvEntries[*]}; x++ ))
do
   a1000=$(echo "${csvEntries[$x]}"|cut -d'|' -f1|cut -d':' -f2-)
   a1001=$(echo "${csvEntries[$x]}"|cut -d'|' -f2|cut -d':' -f2-)
   a1002=$(echo "${csvEntries[$x]}"|cut -d'|' -f3|cut -d':' -f2-)
   a1003=$(echo "${csvEntries[$x]}"|cut -d'|' -f4|cut -d':' -f2-)
   a1004=$(echo "${csvEntries[$x]}"|cut -d'|' -f5|cut -d':' -f2-)
   a1005=$(echo "${csvEntries[$x]}"|cut -d'|' -f6|cut -d':' -f2-)
   a1006=$(echo "${csvEntries[$x]}"|cut -d'|' -f7|cut -d':' -f2-)
   a1007=$(echo "${csvEntries[$x]}"|cut -d'|' -f8|cut -d':' -f2-)

   echo "${a1000}|${a1001}|${a1002}|${a1003}|${a1004}|${a1005}|${a1006}|${a1007}|" | tee -a ${csvFile}
done
