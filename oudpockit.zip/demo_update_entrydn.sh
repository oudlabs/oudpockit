#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Purpose
###############################################################################
echo "The purpose of this demo is to populate the entryDN virtual entry"
echo "for customers that want to perform indexed searches on entryDN"

###############################################################################
# Define key variables
###############################################################################
adminDN="uid=admin1,ou=Admins,${suffix}"
adminDN="${bDN}"
dnFile="${cfgdir}/dn.list"
entryDnFile="${cfgdir}/entrydn.ldif"
logFile="${logdir}/entrydn-${now}.log"
steps=0

# Start with a fresh entryDN ldif file
if [ -e "${dnFile}" ];then rm -f "${dnFile}" 2> /dev/null;fi
if [ -e "${entryDnFile}" ];then rm -f "${entryDnFile}" 2> /dev/null;fi

# Dump all entries from the directory at page size of 250 per result set
let steps++
echo "Step ${steps}: Build entryDN candidate list"
${oudmwdir}/oud/bin/ldapsearch -T --simplePageSize 250 -h ${localHost} -Z -X -p ${ldapsPort} -D "${adminDN}" -j "${jPW}" -b "${suffix}" -s sub '(objectClass=top)' dn entryDN 2> /dev/null \
    |egrep -i "^dn: |^entryDN" \
    |sed \
       -e "s/^entryDN: /|/gi" \
       -e "s/^dn: /${bolvar}/gi" \
       -e "s/ /${spcvar}/g" \
       -e "s/	/${spcvar}/g" \
    |tr -d '[\n\r]' \
    |sed \
        -e "s/${bolvar}/|\n/g" \
    |grep -v "^|$" \
    > ${dnFile}
if [ -s "${dnFile}" ]
then
   true
else
   echo "ERROR: Directory server ${localHost}:${ldapsPort} is not available"
   exit 1
fi

# Iterate through the dn list and identify all entries with entryDN that
# does not match dn.
dnCnt=$(wc -l ${dnFile}|awk '{ print $1 }'|sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')
let steps++
echo "Step ${steps}: Determine which of ${dnCnt} entries need to be updated"
readarray -t dnList <<< $(cat ${dnFile})

for (( x=0; x< ${#dnList[*]}; x++ ))
do
   dn=$(echo "${dnList[${x}]}"|cut -d'|' -f1)
   entryDN=$(echo "${dnList[${x}]}"|cut -d'|' -f2)
   if [ "${entryDN,,}" != "${dn,,}" ]
   then
      echo "Queuing up dn=${dn}"
      echo -e "dn: ${dn}\nchangeType: modify\nreplace: entryDN\nentryDN: ${dn}\n" >> ${entryDnFile}
   fi
done

# Apply entryDN updates
entryDnCnt=$(grep -c "^dn: " ${entryDnFile} 2> /dev/null|sed -e "s/ //g" -e ':a;s/\B[0-9]\{3\}\>/,&/;ta')
if [ -z "${entryDnCnt}" ];then entryDnCnt=0;fi
let steps++
echo "Step ${steps}: Update ${entryDnCnt} entryDN values of ${dnCnt} entries"
if [ -e "${entryDnFile}" ]
then
   ${oudmwdir}/oud/bin/ldapmodify -h ${localHost} -Z -X -p ${ldapsPort} -D "${adminDN}" -j "${jPW}" -c -f "${entryDnFile}" > ${logFile} 2>&1
fi

# Purge dn file
let steps++
echo "Step ${steps}: Clean up temporary files"
if [ -e "${dnFile}" ];then rm -f "${dnFile}" 2> /dev/null;fi
if [ -e "${entryDnFile}" ];then rm -f "${entryDnFile}" 2> /dev/null;fi
echo "entryDN update complete"
