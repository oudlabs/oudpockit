#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
subsubcmd=$2
curdir=$(cd ${curdir}; pwd)
cd

mypid="$$"
###############################################################################
# The purpose of this script is to enable Prometheus compliant exportor
# for OUD product.
# Note that Prometheus only supports numeric metric values.  Find any non-
# numeric values with
# curl -s https://localhost:1888/metrics/|grep -v "[0-9]$"|sed -e "s/^/#/g"
#
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

   findpager
   cat << EOU | ${pgcmd}
NAME
     ${cmd} [subcommand] [options]

IMPORTANT NOTE
     sudo privilege may be required to setup and use the emitter

SYNOPSIS
     Setup exporter
        ${cmd} setup --name <resourceName>  --instName <oud_instance_name> --type <oud|proxy> --compartment <ocid> --oracleHome <oracleHome> --adminPort <port> --ldap <port> --ldaps <port> --metricPort <port> -D <monitor_user> -j "/<dir>/<monitor_password_file>" [options]

     Start exporter
        ${cmd} start [--name <name>]

     Stop exporter
        ${cmd} stop [--name <name>]

     Show status of exporter services
        ${cmd} status [--name <name>]

     Deinstall exporter
        ${cmd} deinstall [--name <name>]

     Query OUD instance
        ${cmd} query [--name <name>]

     Enable exporter to restart on OS reboot
        ${cmd} enable

     Disable exporter to restart on OS reboot
        ${cmd} disable

     Update monitor user credential
        ${cmd} uc --name <resource_name> -D <monitor_user> -j /<dir>/<password_file>

     Update proxy user credential
        ${cmd} uc --name <resource_name> --proxyuser <proxy_user> -x /<dir>/<password_file>

     Add minimally privileged monitor user to OUD administrative config
 
        ${cmd} adduser --port <ldaps_port> --dstype <oud|proxy> --utype <admin|data> -j <priv_user_pw_file> --mpw <mon_user_pw> [-D <monitor_user>] [--rootdn <dn>]

     Delete monitor user from OUD administrative config

        ${cmd} deleteuser --dstype <oud|proxy> --utype <admin|data> -j <priv_user_pw_file> --mpw <mon_user_pw> [-D <monitor_user>] [--rootdn <dn>]

     Change password of monitor user

        ${cmd} moduserpw --dstype <oud|proxy> --utype <admin|data> -j <priv_user_pw_file> --mpw <mon_user_pw> [-D <monitor_user>] [--rootdn <dn>]

     See if admin user exists

        ${cmd} showuser --dstype <oud|proxy> --utype admin -j <priv_user_pw_file> [-D <monitor_user>] [--rootdn <dn>]

     See if data user(s) exists

        ${cmd} showuser --dstype <oud|proxy> --utype data --suffix "<suffix>" -j <priv_user_pw_file> --mpw <mon_user_pw> [-D <monitor_user>] [--rootdn <dn>]

     Show OUD instance state 

        ${cmd} showstate --port 1444 --dstype <oud|proxy> -j <priv_user_pw_file> [--rootdn <dn>]

     Set OUD instance state to UP or MAINT

        ${cmd} modstate <UP|MAINT> --port 1444 --dstype <oud|proxy> -j <priv_user_pw_file> [--rootdn <dn>]

DESCRIPTION
     Sample to demonstrate how to export cn=monitor data for consumption
     by monitoring services like Oracle Observability and Management and
     open source projects like Promethus.

OPTIONS
     The following options are supported:

         --type <option>         Product type
                                 Default: oud
                                 Available types: oud, proxy or replgw

         --compartment <ocid>    OCID of the compartment

         --name <resource_name>  Name of the directory server instance (resource)
                                 Default: <host>-asinst_1

         --resName <name>        Same as --name
                                 Default: <host>-asinst_1

         --instName <name>       OUD instance name
                                 Default: asinst_1

         --oracleHome <path>     Path to where the Oracle Home is

         --javaHome <path>       Path to where the Java Home is


         --adminPort <port>      Secure port to query metric data
                                 Defaults by type:
                                    1444 for OUD
                                    1445 for OUD Proxy
                                    1446 for OUD Replication Gateway

         --ldap <port>           Non-encrypted LDAP port
                                 Default: 1389

         --ldaps <port>          Encrypted LDAP port
                                 Default: 1636

         --metricPort <n>        Metric listener port number
                                 Default: 1888

         --adir <dir>            Management Agent instance directory
                                 Defaults:
                                    OCI: /var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst
                                    Non-OCI: /opt/oracle/mgmt_agent/agent_inst

         --auser <dir>           Management Agent user
                                    OCI: oracle-cloud-agent
                                    Non-OCI: mgmt_agent
                                    Default: mgmt_agent

         --usetls                Encrypt listener

         --cert                  Listener PEM certificate file

         --key                   Listener PEM key file

         --truststore            Listener JKS truststore file
                                 Default: ${certdir}/CA/truststore

         -D <user>               OUD Monitor user
                                 Default: muser

         -luser <user_dn>        Listener user
                                 Default: exporter

         -t <file>               Truststore password file (including full path)

WEB PROXY OPTIONS
         --proxyproto <http|https> Web proxy protocol
                                   Default: http
         --proxyhost "<host>"      Web proxy host
                                   Default: 8080
         --proxyport "<port>"      Web proxy port
                                   Default: 8080
         --proxyuser "<user>"      Web proxy user
                                   Default: proxy
         -x "<file>"               File containing web proxy user's password
         --proxyrealm "<realm>"    Web Proxy realm
                                   Default: proxy
         --proxyuri "<uri>"        Web proxy URI
                                   Default: http://localhost:8080

MONITOR USER MANAGEMENT OPTIONS

         --dstype [oud|dsee]       Directory service product
                                   Default: oud
                                 
         --utype [admin|data]      Administrative or data/suffix user

         --host <host>             Host on which DS runs
                                   Default: ${localHost}

         --port <port>             Secure LDAP or Admin port of DS instance
                                   Default: ${portAdmin}

         -D <dn>                   Privileged user used for managing the
                                   monitor user
                                   Default: cn=Directory Manager

         -j <file>                 Password file of privileged user


         --rootdn <dn>             Privileged user used for managing the
                                   Default: cn=Directory Manager

         --muser <name>            Monitor user
                                   Default: muser

         --suffix <dn>             Base suffix for the data user
                                   Default: ${suffix}

         --mpw <file>              File containing password of monitor user.

         --eus                     Add if needing to add monitor user to the
                                   following suffixes:
                                      cn=OracleContext
                                      cn=OracleContext,<suffix>

EOU
}

# Set LANG preferences for international env
export LANG="en_US.UTF-8" LC_ALL="en_US.UTF-8" LC_CTYPE="en_US.UTF-8"

oudprefix="oud"
proxyprefix="proxy"

PATH=/usr/lib/amd64/gettext:/usr/gnu/bin:/usr/xpg4/bin:/usr/xpg6/bin:$PATH:/usr/sbin:/sbin:.
cfgdir="${curdir}/cfg"
logdir="${curdir}/logs"
tmpdir="${curdir}/tmp"
libdir="${cfgdir}/lib"
swdir="${curdir}/sw"
#oudmwdir="/home/oracle/poc/mw_oud12c"
oudsmmwdir="${curdir}/mw_oudsm12c"
oidmwdir="${curdir}/mw_oid12c"
samples="${curdir}/samples"
perfdir="${swdir}/LDAPPerfTools"
certdir="${cfgdir}/certs"

me=$(whoami)
myg=$(id -gn)
now=$(date +'%Y%m%d%H%M%S')
today=$(echo ${now}|cut -c1-8)

pylog="${logdir}/pycmd-${today}.log"
localHost=$(hostname -f 2> /dev/null|grep "\.")
if [ -z "${localHost}" ]
then
   iface=$(ifconfig -a|grep RUNNING|grep -v SLAVE|cut -d: -f1|head -1)
   ifaceip=$(ifconfig ${iface} 2>&1|egrep -v "canonical name|server can't find"|grep "inet "|awk '{ print $2 }')
   localHost=$(nslookup ${ifaceip}|grep -i arpa|awk '{ print $4 }'|sed -e "s/=//g" -e "s/\.$//g" -e "s/^M//g" -e "s/\/n//g" |egrep -vi "localhost|localhost.localdomain|^$")
fi   
if [ -z "${localHost}" ]
then
   echo "ERROR: Cannot determine full qualified host name"
   exit 1
fi
localH=$(echo ${localHost}|cut -d'.' -f1)
if [ "${localHost}" == "${localH}" ]
then
   localHost=$(getent hosts ${localHost} 2> /dev/null|awk '{ print $2 }'|sort|uniq)
   localH=$(echo "${localHost}."|cut -d'.' -f1)
   if [ "${localHost}" == "${localH}" ]
   then
      localHost=$(getent hosts ${localHost} 2> /dev/null|awk '{ print $3 }'|sort|uniq)
      localH=$(echo "${localHost}."|cut -d'.' -f1)
      if [ "${localHost}" == "${localH}" ]
      then
         echo "Error: Local host name is not fully qualified."
         exit 1
      fi
   fi
fi

hostValidity=3650 
intValidity=$((${hostValidity}*10))
caValidity=$((${hostValidity}*20))

spcvar=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
tabvar=$(head -$((RANDOM % 20000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)

###############################################################################
# Create requisite directories and response files
###############################################################################
mkdir -p "${cfgdir}" "${logdir}" "${swdir}" "${tmpdir}" "${libdir}" 2> /dev/null

###############################################################################
# Custom Variables
###############################################################################
if [ -z "${bDN}" ];then bDN='cn=Directory Manager';fi

##############################################################################
# Test LDAP port
##############################################################################
test_port() {
   if [ -n "${oudSupplier}" ] || [ "${subcmd}" == 'query' ]
   then
      testhost="$1"
      testport="$2"
      /usr/bin/python - <<EOPY
import time,socket
host="${testhost}"
port="${testport}"

def checkPort(host, port):
   s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   s.settimeout(1)
   try:
      s.connect((host, int(port)))
      s.shutdown(socket.SHUT_RDWR)
      return True
   except:
      return False
   s.close()

if checkPort(host, port):
   print ("UP")
else:
   print ("DOWN")
EOPY
   rc=$?
   fi
}

##############################################################################
# Check for sudo error message
##############################################################################
ckSudo() {
   sudolog="$1"
   sudomsg="$2"

   if [ -z "${sudomsg}" ]
   then
      sudomsg="sudo command failed"
   fi

   if [ -s "${sudolog}" ]
   then
      cksudoerr=$(grep "^sudo: a password is required" ${sudolog})
      if [ -n "${cksudoerr}" ]
      then
         echo "ERROR: ${sudomsg}"
         return 1
      else
         return 0
      fi
   fi
}

##############################################################################
# Lookup OS
##############################################################################
lookupos() {
   # Determine Operating System
   os=$(uname -s 2> /dev/null)
   osv=$(uname -r 2> /dev/null)
   arch=$(uname -i 2> /dev/null)
   osn=''
   olv=''

   # Set osVersion
   case ${os} in
      'Linux') omc_host_type='omc_host_linux';agentOsName='linux.x64'
               osn='linux'
               if [ -n "$(grep -i Tikanga /etc/redhat-release 2> /dev/null)" ]
               then
                  osVersion="OEL5"
                  olv=5
                  if [ "${sub_cmd}" == 'setup' ];then ipv4=$(getent ahostsv4 ${agentHost}|grep STREAM | awk '{ print $1 }');fi
               elif [ -n "$(grep -i Santiago /etc/redhat-release 2> /dev/null)" ]
               then
                  osVersion="OL6"
                  olv=6
                  if [ "${sub_cmd}" == 'setup' ];then ipv4=$(getent ahostsv4 ${agentHost}|grep STREAM | awk '{ print $1 }');fi
               elif [ -n "$(grep -i Maipo /etc/redhat-release 2> /dev/null)" ]
               then
                  osVersion="OL7"
                  olv=7
                  if [ "${sub_cmd}" == 'setup' ];then ipv4=$(getent ahostsv4 ${agentHost}|grep STREAM | awk '{ print $1 }');fi
               elif [ -n "$(grep -i Ootpa /etc/redhat-release 2> /dev/null)" ]
               then
                  osVersion="OL8"
                  olv=8
                  if [ "${sub_cmd}" == 'setup' ];then ipv4=$(getent ahostsv4 ${agentHost}|grep STREAM | awk '{ print $1 }');fi
               elif [ -n "$(grep -i "Fedora release 31" /etc/redhat-release 2> /dev/null)" ]
               then
                  osVersion="Fedora31"
                  olv=f31
                  if [ "${sub_cmd}" == 'setup' ];then ipv4=$(getent ahostsv4 ${agentHost}|grep STREAM | awk '{ print $1 }');fi
               fi
               ;;
      'SunOS') omc_host_type='omc_host_solaris';agentOsName='solaris.x64'
               osn='solaris'
               ;;
   esac
}

##############################################################################
# Find pager
##############################################################################
findpager() {
   #
   # Set the page command
   #
   pgcmd='cat - '
   ck4less=`which less 2>&1 | grep -v "no less"`
   if [ -n "${ck4less}" ]
   then
      pgcmd='less'
   else
      ck4more=`which more 2>&1 | grep -v "no more"`
      if [ -n "${ck4more}" ]
      then
         pgcmd='more'
      fi
   fi

   if [ "${cmd}" == 'cathelp' ];then pgcmd='cat - ';fi
}

##############################################################################
# Determine which python command to use according to operating system
##############################################################################
getPyCmd() {
   lookupos
   reqck=''
   case ${os} in
      'Linux') case ${olv} in
               5) pycmd="python";echo "RedHat/Oracle Linux version 5 is not supported.";exit 1;;
               6) pycmd="python"
                  ckssl=$(rpm -q openssl|grep openssl-|cut -d'-' -f2-|grep "^1")
                  ckpy=$(rpm -q python|grep python-|cut -d'-' -f2-|grep "^2.[6-9]")
                  ;;
               7) pycmd="python"
                  ckssl=$(rpm -q openssl|grep openssl-|cut -d'-' -f2-|grep "^1")
                  ckpy=$(rpm -q python|grep python-|cut -d'-' -f2-|grep "^2.[6-9]")
                  ;;
               '8'|'9') pycmd="python3"
                  cknsl=$(rpm -q libnsl|grep libnsl-)
                  ckssl=$(rpm -q openssl|grep openssl-|cut -d'-' -f2-|grep "^1")
                  ckpy=$(rpm -qa|grep "^python3")
                  ;;
               esac
               ;;
   esac

   if [ "${olv}" == "8" ] && [ -z "${cknsl}" ];then reqck='fail';echo "ERROR: Requisite failure: libnsl is not installed";fi
   if [ "${olv}" == "9" ] && [ -z "${cknsl}" ];then reqck='fail';echo "ERROR: Requisite failure: libnsl is not installed";fi
   if [ -z "${ckssl}" ];then reqck='fail';echo "ERROR: Requisite failure: openssl v1 or newer is not installed";fi
   if [ -z "${ckpy}" ];then reqck='fail';echo "ERROR: Requisite failure: python is not installed";fi
   if [ -n "${reqck}" ];then exit 1;fi
}

##############################################################################
# Determine which python command to use according to operating system
##############################################################################
checkPyLdap() {
   lookupos
   reqck=''
   case ${os} in
      'Linux') case ${olv} in
               5) pycmd="python";echo "RedHat/Oracle Linux version 5 is not supported.";exit 1;;
               6) pycmd="python"
                  ckpyldp=$(rpm -q python-ldap|grep python-ldap|cut -d'-' -f3-)
                  ;;
               7) pycmd="python"
                  ckpyldp=$(rpm -q python-ldap|grep python-ldap|cut -d'-' -f3-)
                  ;;
               '8'|'9') pycmd="python3"
                  ckpyldp=$(rpm -q python3-ldap|grep python3-ldap|cut -d'-' -f3-)
                  ;;
               esac
               ;;
   esac

   if [ -z "${ckpyldp}" ];then reqck='fail';echo "ERROR: Requisite failure: python ldap is not installed.";fi
   if [ -n "${reqck}" ];then exit 1;fi
}

##############################################################################
# Perform ldapsearch via ${pycmd}
##############################################################################
pyLdapSearch() {
   ldpProto="$1"
   ldpHost="$2"
   ldpPort="$3"
   ldpDN="$4"
   ldpBase="$5"
   ldpScope="$6"
   ldpFilter="$7"
   ldpPW="${bPW}"
 
   getPyCmd
   checkPyLdap
 
   case ${ldpScope} in
    'base') pyLdpScope='ldap.SCOPE_BASE';;
     'one') pyLdpScope='ldap.SCOPE_ONE';;
     'sub') pyLdpScope='ldap.SCOPE_SUBTREE';;
   esac
 
   getPyCmd
   ${pycmd} - 2>> ${pylog} <<EOPY
import sys,ldap,ldif

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${ldpDN}"
pw = "${ldpPW}"
basedn = "${ldpBase}"
searchFilter = "${ldpFilter}"
searchAttribute = ["*"]
searchScope = ${pyLdpScope}
lw=ldif.LDIFWriter(sys.stdout,cols=100000)

# Connect to directory server
try:
   l = ldap.initialize("${ldpProto}://${ldpHost}:${ldpPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Perform search operation
try:
    ldap_result_id = l.search(basedn, searchScope, searchFilter, searchAttribute)
    result_set = []
    while 1:
        result_type, result_data = l.result(ldap_result_id, 0)
        if (result_data == []):
            break
        else:
            if result_type == ldap.RES_SEARCH_ENTRY:
                result_set.append(result_data)

            ldn=result_data[0][0]
            lc=result_data[0][1]
            lw.unparse(ldn,lc)

except ldap.LDAPError as e:
    print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ]
   then
      echo "ERROR: LDAP search failed with error ${pyRC}" >> ${pylog}
      echo "       URL: ${ldpProto}://${ldpHost}:${ldpPort}" >> ${pylog}
      echo "       BindDN: ${ldpDN}" >> ${pylog}
      echo "       Base: ${ldpBase}" >> ${pylog}
      echo "       Scope: ${ldpScope}" >> ${pylog}
      echo "       Filter: ${ldpFilter}" >> ${pylog}
   fi

   # If python log is empty, remove it
   if [ -s "${pylog}" ]
   then
      true
   else
      rm -f "${pylog}" 2> /dev/null
   fi
}


##############################################################################
# Generate Certificate Authority
##############################################################################
setup_ca() {
   unset JAVA_TOOL_OPTIONS

   if [ -e "${cadir}/root-ca.jks" ]
   then
      true
   else
      msg=''

      let steps++
      echo "Step: ${steps} - Setup root and intermediate Certificate Authorities"| tee -a  ${logdir}/certs-${now}.log

      if [ "${dbg}" == 'true' ];then set -x;fi
      # Make requisite directories
      mkdir -p "${certdir}" "${cadir}" "${icadir}" > /dev/null 2>&1
      rc=$?

      cd "${cadir}"
      mkdir -p certs crl csr newcerts private > /dev/null 2>&1
      rc=$?

      cd "${icadir}"
      mkdir -p certs crl csr newcerts private > /dev/null 2>&1
      rc=$?
      set +x

      chmod -R 0750 ${certdir}

      # Create self-signed certificate for the root CA
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -genkeypair -keystore ${cadir}/root-ca.jks -storepass "${jkspw}" -keypass "${jkspw}" -alias root-ca-cert -dname "cn=Root CA" -keysize 2048 -keyalg "RSA" -sigalg SHA256withRSA -validity ${caValidity} -ext bc:c >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to generate self-signed cert for root CA";fi

      # Export root CA certificate
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -storepass "${jkspw}" -keystore ${cadir}/root-ca.jks -alias root-ca-cert -exportcert -rfc -file ${cadir}/certs/ca-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export root CA certificate";fi

      # Generate cert and key store for intermediate CA
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -genkeypair -keystore ${icadir}/ca.jks -storepass "${jkspw}" -keypass "${jkspw}" -alias ca-cert -dname "cn=Intermediate CA" -keysize 2048 -keyalg "RSA" -sigalg SHA256withRSA -validity ${intValidity} -ext bc:c >> ${logdir}/certs-${now}.log 2>&1

      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to generate cert and key store for intermediate CA";fi

      # Request cert for intermediate CA and sign by root CA
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -certreq -storepass "${jkspw}" -keystore ${icadir}/ca.jks -keypass "${jkspw}" -alias ca-cert -file  ${icadir}/csr/ca.csr >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to generate cert request for intermediate CA";fi

      # Sign intermediate CA's cert by root CA
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -gencert -storepass "${jkspw}" -keystore ${cadir}/root-ca.jks -alias root-ca-cert -ext BC=0 -rfc -validity ${intValidity} -infile ${icadir}/csr/ca.csr -outfile ${icadir}/certs/ica-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to sign the intermediate CA's cert";fi

      # Import Root CA cert into intermediate CA's keystore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -trustcacerts -storepass "${jkspw}" -keystore ${icadir}/ca.jks -alias root-ca-cert -file  ${cadir}/certs/ca-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Root CA cert into Intermediat CA keystore";fi

      # Import Intermediate CA cert into intermediate CA's keystore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert               -storepass "${jkspw}" -keystore ${icadir}/ca.jks -alias ca-cert -file  ${icadir}/certs/ica-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Intermediate CA cert into Intermediat CA keystore";fi

      # Create Intermediate CA truststore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -trustcacerts -storepass "${jkspw}" -keystore "${caTrustStore}" -alias root-ca-cert -file  ${cadir}/certs/ca-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to create Intermediate CA truststore";fi

      # Import Intermediate CA cert into Intermediate CA truststore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -trustcacerts -storepass "${jkspw}" -keystore "${caTrustStore}" -alias ca-cert -file  ${icadir}/certs/ica-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Intermediate CA cert into Intermediate truststore";fi

      # Create combined Root CA and Intermediate CA chain cert file
      if [ "${dbg}" == 'true' ];then set -x;fi
      touch ${icadir}/certs/ca-chain-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?
      chmod 0640 ${icadir}/certs/ca-chain-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?
      cat ${icadir}/certs/ica-cert.pem ${cadir}/certs/ca-cert.pem > ${icadir}/certs/ca-chain-cert.pem 2> /dev/null
      rc=$?;set +x
      chmod 0440 ${icadir}/certs/ca-chain-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Intermediate CA cert into Intermediate truststore";fi

      # Show errors
      if [ -n "${msg}" ];then echo -e "${msg}";exit 1;fi
   fi
}

##############################################################################
# Generate Host Certificate
##############################################################################
gen_host_cert() {
   unset JAVA_TOOL_OPTIONS

   msg=''

   # Make sure CA is setup
   setup_ca

   # Setup requisite directory for host cert
   mkdir -p "${certdir}/${myHost}"
   rc=$?

   cd "${certdir}/${myHost}"
   mkdir -p certs crl csr newcerts private > /dev/null 2>&1
   rc=$?

   # Set pin file
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -e "${certdir}/${myHost}/${myHost}.pin" ]
   then
      true
   else
      echo "${jkspw}" > "${certdir}/${myHost}/${myHost}.pin"
   fi

   if [ -e "${certdir}/${myHost}/${myHost}.jks" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate and sign host cert ${myHost}"| tee -a  ${logdir}/certs-${now}.log

      # Set permissions
      chmod 0640 "${certdir}/${myHost}/*" 2> /dev/null

      # Create host server keystore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -genkeypair -keystore ${certdir}/${myHost}/${myHost}.jks -storepass "${jkspw}" -keypass "${jkspw}" -alias server-cert -dname "cn=${myHost}" -keysize 2048 -keyalg "RSA" -sigalg SHA256withRSA -validity ${hostValidity} >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to host keystore";fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -certreq -storepass "${jkspw}" -keystore ${certdir}/${myHost}/${myHost}.jks -keypass "${jkspw}" -alias server-cert -file  ${certdir}/${myHost}/csr/${myHost}.csr >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to create host cert request";fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -gencert -storepass "${jkspw}" -keystore ${icadir}/ca.jks -alias ca-cert -ext BC=0 -rfc -validity ${hostValidity} -infile ${certdir}/${myHost}/csr/${myHost}.csr -outfile ${certdir}/${myHost}.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to sign host cert by Intermediate CA";fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -storepass "${jkspw}" -keystore ${certdir}/${myHost}/${myHost}.jks -alias server-cert -file  ${certdir}/${myHost}.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import host cert into host keystore";fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -storepass "${jkspw}" -keystore ${certdir}/${myHost}/${myHost}.jks -alias root-ca-chain -file ${icadir}/certs/ca-chain-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import CA chain cert into host keystore";fi

      # Create PKCS12 Version of server keystore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importkeystore -srckeystore ${certdir}/${myHost}/${myHost}.jks -destkeystore ${certdir}/${myHost}/${myHost}.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${jkspw}" -deststorepass "${jkspw}" -srcalias server-cert -destalias server-cert >> ${logdir}/certs-${now}.log 2>&1 <<EOF
yes
EOF
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS keystore to PKCS12 keystore";fi

      # Create PKCS12 Version of server truststore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importkeystore -srckeystore ${certdir}/CA/truststore -destkeystore ${certdir}/truststore.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${jkspw}" -deststorepass "${jkspw}" -srcalias ca-cert -destalias ca-cert >> ${logdir}/certs-${now}.log 2>&1 <<EOF
yes
EOF
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS truststore to PKCS12 keystore";fi

      # Create PKCS12 Version of server truststore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importkeystore -srckeystore ${certdir}/CA/truststore -destkeystore ${certdir}/truststore.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${jkspw}" -deststorepass "${jkspw}" -srcalias root-ca-cert -destalias root-ca-cert >> ${logdir}/certs-${now}.log 2>&1 <<EOF
yes
EOF
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS truststore to PKCS12 keystore";fi


      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importkeystore -srckeystore ${certdir}/${myHost}/${myHost}.jks -destkeystore ${certdir}/${myHost}/dsee.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${jkspw}" -deststorepass "${jkspw}" -srcalias server-cert -destalias dsee-cert >> ${logdir}/certs-${now}.log 2>&1 <<EOF
yes
EOF
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS keystore to PKCS12 keystore for DSEE";fi


      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -list -keystore ${certdir}/${myHost}/${myHost}.p12 -storetype PKCS12  -storepass "${jkspw}" -v >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to list contents of PKCS12 keystore";fi


      # Address compatibility with existing implementation
      if [ "${dbg}" == 'true' ];then set -x;fi
      #cp "${certdir}/${myHost}.p12" "${certdir}/${myHost}/keystore.p12" >> ${logdir}/certs-${now}.log 2>&1
      #cp "${certdir}/dsee.p12" "${certdir}/${myHost}/dsee.p12" >> ${logdir}/certs-${now}.log 2>&1
      #cp "${certdir}/${myHost}.jks" "${certdir}/${myHost}/keystore" >> ${logdir}/certs-${now}.log 2>&1
      set +x

      # Show errors
      if [ -n "${msg}" ];then echo -e "${msg}";exit 1;fi
   fi

}

##############################################################################
# Retrieve host cert and trust store from CA host
##############################################################################
get_cert() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   rsync --progress -vvtre "ssh -h ${caHost} -p ${sshport} -i \"${sshprivkey}\" -o StrictHostKeyChecking=no" "${me}@${caHost}:${certdir}/." "${certdir}/."
   rc=$?;set +x
}

##############################################################################
# Re-generate CA Certificate
##############################################################################
regen_ca_cert() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   rm -f ${cadir}/root-ca.jks ${icadir}/ca.jks ${caTrustStore} 2> /dev/null
   rc=$?;set +x
   setup_ca
}    
        
##############################################################################
# Re-generate Host Certificate
##############################################################################
regen_host_cert() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   rm -f ${certdir}/${myHost}/${myHost}.jks 2> /dev/null
   rc=$?;set +x
   gen_host_cert

   # Extract private key
   if [ -e "${certdir}/pylocalhost.pem" ];then rm -f "${certdir}/pylocalhost.pem";fi
   openssl pkcs12 -in ${certdir}/localhost/localhost.p12 -out ${certdir}/pylocalhost.pem -nodes -passin "pass:${jkspw}"
   rc=$?;set +x
}    

##############################################################################
# Summarize keystore contents
##############################################################################
summarize_keystore() {
   # Summarize certs
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= Summarize Host certs:"
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${ktool} -list -v -keystore "${keystore}" -storetype ${storeType} -storepass "${jkspw}"|egrep -i "^Certificate|^Owner:|^Issuer:|^Valid from:"|grep -v "Certificate fingerprints"
   rc=$?;set +x
        
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= Summarize CA cert chain:"
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${ktool} -list -v -keystore "${certdir}/truststore.p12" -storetype ${storeType} -storepass "${jkspw}"|egrep -i "^Certificate|^Owner:|^Issuer:|^Valid from:"|grep -v "Certificate fingerprints"
   rc=$?;set +x
}

##############################################################################
# List keystore contents in RFC format
##############################################################################
list_rfc_keystore() {
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= List certs in RFC format:"
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${ktool} -list -rfc -keystore "${keystore}" -storetype ${storeType}  -storepass "${jkspw}"
}

###############################################################################
# Find Wallet Libraries
###############################################################################
ckWalletLibs() {
   pkilib="${libdir}/oraclepki.jar"
   corelib="${libdir}/osdt_core.jar"
   certlib="${libdir}/osdt_cert.jar"
   set +x
   if [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ]
   then
      true
   else
      if [ -e "${oracleHome}/oracle_common/" ]
      then
         cp ${oracleHome}/oracle_common/modules/oracle.pki/oraclepki.jar ${libdir} 2> /dev/null
         cp ${oracleHome}/oracle_common/modules/oracle.osdt/osdt_core.jar ${libdir} 2> /dev/null
         cp ${oracleHome}/oracle_common/modules/oracle.osdt/osdt_cert.jar ${libdir} 2> /dev/null
      else
         echo "ERROR: Wallet Libraries missing."
         exit 1
      fi
   fi
}

###############################################################################
# Create wallet if it doesn't already exit
###############################################################################
mkWallet() {
   set +x
   ckWalletLibs
   if [ -n "$JAVA_HOME" ]
   then
      if [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ] && [ -e "${cfgdir}/ewallet.p12" ]
      then
         true
      elif [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ]
      then
         # Generate random 64 character string for vault password
         vaultpw=$(head /dev/urandom | tr -dc 'a-zA-Z0-9' | cut -c1-64)
         $JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -create >> ${logdir}/wallet-${now} 2>&1 <<EOF
$vaultpw
$vaultpw
EOF
         rc=$?
         $JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -createALO >> ${logdir}/wallet-${now} 2>&1
         rc=$?
      fi
   fi
}

###############################################################################
# Update Credentials
###############################################################################
updateCreds() {
   set +x
   if [ -n "$JAVA_HOME" ] && [ "$USE_WALLET" == 'true' ]
   then
      # Create wallet if it doesn't already exist
      mkWallet

      #########################################################################
      # Update Monitor User
      #########################################################################
      uTag="mUser-${resName}"
      if [ -n "${myMuser}" ] && [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ] && [ -e "${cfgdir}/ewallet.p12" ]
      then
         ckBdn=$($JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -listCredential | grep "${uTag}")
         if [ -n "${ckBdn}" ]
         then
            $JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -modifyCredential ${uTag}  "${muserDN}" "${bPW}"
            rc=$?
         else
            $JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -createCredential ${uTag}  "${muserDN}" "${bPW}"
            rc=$?
         fi
      fi

      #########################################################################
      # Update Web Proxy User
      #########################################################################
      uTag="pUser"
      if [ -n "${my_proxyUser}" ] && [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ] && [ -e "${cfgdir}/ewallet.p12" ]
      then
         ckBdn=$($JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -listCredential | grep "${uTag}")
         if [ -n "${ckBdn}" ]
         then
            $JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -modifyCredential ${uTag}  "${proxyUser}" "${proxyPW}"
            rc=$?
         else
            $JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -createCredential ${uTag}  "${proxyUser}" "${proxyPW}"
            rc=$?
         fi
      fi
   fi
}

###############################################################################
# Get Credentials
###############################################################################
getCreds() {
   ckWalletLibs
   if [ -n "$JAVA_HOME" ] && [ "$USE_WALLET" == 'true' ]
   then
      #########################################################################
      # Update Monitor User
      #########################################################################
      uTag="mUser-${resName}"
      if [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ] && [ -e "${cfgdir}/ewallet.p12" ]
      then
         userEntry=$($JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -listCredential | grep "${uTag} ")
         userIndex=$(echo "${userEntry}"|cut -d':' -f1)
         if [ -n "${userIndex}" ]
         then
            muserDN=$(echo ${userEntry}|cut -d':' -f2|sed -e "s/^.* ${uTag} //g")
            bPW=$($JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -viewEntry oracle.security.client.password${userIndex}|grep oracle.security.client|cut -d'=' -f2-|sed -e "s/^ //g")
         fi
      fi

      #########################################################################
      # Update Web Proxy User
      #########################################################################
      uTag="pUser"
      if [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ] && [ -e "${cfgdir}/ewallet.p12" ]
      then
         userEntry=$($JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -listCredential | grep "${uTag} ")
         userIndex=$(echo "${userEntry}"|cut -d':' -f1)
         if [ -n "${userIndex}" ]
         then
            proxyUser=$(echo ${userEntry}|cut -d':' -f2|sed -e "s/^.* ${uTag} //g")
            proxyPW=$($JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -viewEntry oracle.security.client.password${userIndex}|grep oracle.security.client|cut -d'=' -f2-|sed -e "s/^ //g")
         fi
      fi
   fi
}

##############################################################################
# List keystore contents
##############################################################################
list_keystore() {
   getCreds

   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= List certs:"
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${ktool} -list -keystore "${keystore}" -storetype ${storeType} -storepass "${jkspw}"
}

###############################################################################
# Show Credentials
###############################################################################
showMgmtAgentCreds() {
   let steps++
   echo -e "\nStep ${steps} - List instances with prometheus endpoint agent credentials"
   if [ -z "${adir}" ]
   then
      adir=$(grep "^adir=" ${cfgdir}/*/exporter.config 2> /dev/null|sed -e "s/^.*adir=//g"|sort -u)
   fi
   if [ -z "${agentUser}" ]
   then
      agentUser=$(grep "^agentUser=" ${cfgdir}/*/exporter.config 2> /dev/null|sed -e "s/^.*agentUser=//g"|sort -u)
   fi

   if [ -n "${adir}" ] && [ -n "${agentUser}" ]
   then
       if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
       then
          if [ "${dbg}" == 'true' ];then set -x;fi
          ${adir}/bin/credential_mgmt.sh -o listCredentials -s Agent|grep RestCreds
          rc=$?;set +x
       else
          if [ "${dbg}" == 'true' ];then set -x;fi
          sudo -u ${agentUser} /bin/sh ${adir}/bin/credential_mgmt.sh -o listCredentials -s Agent|grep RestCreds
          rc=$?;set +x
       fi
   fi
}

###############################################################################
# Show Credentials
###############################################################################
showCreds() {
   ckWalletLibs

   if [ -n "$JAVA_HOME" ] && [ "$USE_WALLET" == 'true' ]
   then
      let steps++
      echo "Step ${steps} - List instances with wallet credentials"
      if [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ] && [ -e "${cfgdir}/ewallet.p12" ]
      then
         creds=$($JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -listCredential)
         idList=$(echo "${creds}"|grep "^[0-9]:"|cut -d':' -f1|sort -n)

         tagLen=$(echo "${creds}"|grep "^[0-9]:"|cut -d' ' -f2|awk '{ print length }'|sort -rn|head -1)
	 tagLen=$((${tagLen}+6))
         userLen=$(echo "${creds}"|grep "^[0-9]:"|cut -d' ' -f3-|awk '{ print length }'|sort -rn|head -1)

         printf "%-10s%-${tagLen}s %-${userLen}s  %-30s\n" "Entry" "Tag" "User" "Password"
         printf "%-10s%-${tagLen}s %-${userLen}s  %-30s\n" "--------" "--------" "-----------" "-----------"
         for n in ${idList}
         do
            tag=$(echo "${creds}"|grep "^${n}:"|cut -d' ' -f2|sed -e "s/^ //g")
            user=$(echo "${creds}"|grep "^${n}:"|cut -d' ' -f3-|sed -e "s/^ //g")
            upw=$($JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -viewEntry oracle.security.client.password${n} 2>&1|grep -v 'No entry found'|sed -e "s/^.*client.password${n} = //g")
	    maskupw=$(echo ${upw}|sed -e "s/[][a-zA-Z0-9!@#$%^&*()-=+_<>~\`\.,?;:'\\\/\"{}\|]/*/g")
            printf "%-10s%-${tagLen}s %-${userLen}s  %-30s\n" "User${n}" "${tag}" "${user}" "${maskupw}"
         done
      else
         echo "ERROR: Requisite PKI libraries are not installed"
         exit 1
      fi
   fi
}

###############################################################################
# Delete Credentials
###############################################################################
delCred() {
   ckWalletLibs

   if [ -n "$JAVA_HOME" ] && [ "$USE_WALLET" == 'true' ]
   then
      #########################################################################
      # Update Monitor User
      #########################################################################
      uTag="mUser-${resName}"
      if [ -n "${myMuser}" ] && [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ] && [ -e "${cfgdir}/ewallet.p12" ]
      then
         $JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -deleteCredential "${uTag}" >> ${logdir}/wallet-${now}
         rc=$?
      fi

      #########################################################################
      # Update Web Proxy User
      #########################################################################
      uTag="pUser"
      if [ -n "${my_proxyUser}" ] && [ -e "${pkilib}" ] && [ -e "${corelib}" ] && [ -e "${certlib}" ] && [ -e "${cfgdir}/ewallet.p12" ]
      then
         $JAVA_HOME/bin/java -cp "$pkilib:$corelib:$certlib" oracle.security.pki.OracleSecretStoreTextUI -nologo -wrl "${cfgdir}" -deleteCredential "${uTag}" >> ${logdir}/wallet-${now}
         rc=$?
      fi
   fi
}

###############################################################################
# Check requisites for running the emmitter
###############################################################################
check_requisites() {
   if [ "${subcmd}" == 'summary' ] || [ "${subcmd}" == 'gencert' ] || [ "${subcmd}" == 'regencert' ] || [ "${subcmd}" == 'regenca' ] || [ "${subcmd}" == 'modstate' ]
   then
      true
   else
      rc=0

      # Make sure htpasswd is installed
      ckpkg=$(rpm -q httpd-tools|grep 'is not installed')
      if [ -n "${ckpkg}" ]
      then
         echo "ERROR: Exporter requires httpd-tools package.  Please install requisite package"
         echo " Linux: sudo yum install -y httpd-tools libnsl python3-ldap"
         rc=1
      fi

      # Make sure openssl is installed
      ckpkg=$(rpm -q openssl|grep 'is not installed')
      if [ -n "${ckpkg}" ]
      then
         echo "ERROR: Exporter requires openssl package.  Please install requisite package"
         echo " Linux: sudo yum install -y openssl"
         rc=1
      fi

      if [ ${rc} -eq 1 ];then exit 1;fi
   fi
}

###############################################################################
# Update Exporter config (or create if it doesn't exist)
###############################################################################
updateConfigs() {
   # Make sure metrics directory exists
   if [ -d "${exporterDir}" ]
   then
      true
   else
      if [ "${subcmd}" == 'setup' ]
      then
         mkdir -p "${exporterDir}" 2> /dev/null
      fi
   fi

   if [ "${subcmd}" == 'setup' ]
   then
      # Make sure Monitoring user is set
      if [ -z "${monitorUser}" ] && [ "${subcmd}" == 'setup' ]
      then
         echo "ERROR: Must specify Monitoring User with -D <userName>"
         exit 1
      fi

      # Make sure oracle home is set
      if [ -z "${oracleHome}" ] && [ "${subcmd}" == 'setup' ]
      then
         echo "ERROR: Must specify Oracle Home with --oracleHome <path>"
         exit 1
      fi

      # Make sure Java home is set
      if [ -z "${javaHome}" ] && [ "${subcmd}" == 'setup' ]
      then
         echo "ERROR: Must specify Java Home with --javaHome <path>"
         exit 1
      fi

      # Make sure Resource Name is set
      if [ -z "${resName}" ] && [ "${subcmd}" == 'setup' ]
      then
         echo "ERROR: Must specify Resource Name with --resName <Resource Name>"
         exit 1
      fi

      # Make sure Metric port is set
      if [ -z "${metricPort}" ] && [ "${subcmd}" == 'setup' ]
      then
         echo "ERROR: Must specify Metric Port with --metricPort <port>"
         exit 1
      fi

      # Make sure Admin port is set
      if [ -z "${monAdminlPort}" ] && [ "${subcmd}" == 'setup' ]
      then
         echo "ERROR: Must specify Admin Port with --adminPort <port>"
         exit 1
      fi

      # Make sure compartment is set
      if [ "${subcmd}" == 'help' ] && [ -z "${compartmentId}" ]
      then
         echo "ERROR: Must specify compartment ID with --compartment <ocid>"
         exit 1
      fi
    fi

    cat > ${commonConfig}.new <<EOF
###############################################################################
# OCI Compartment ID
compartmentId=${compartmentId}

################################################################################
oracleHome=${oracleHome}
adir=${adir}
agentUser=${agentUser}
javaHome=${javaHome}
EOF

    if [ -s "${commonConfig}" ]
    then
       ckdiff=$(diff  ${commonConfig}.new ${commonConfig} 2>&1)
       if [ -n "${ckdiff}" ]
       then
          cp ${commonConfig} ${commonConfig}.${now}
          mv ${commonConfig}.new ${commonConfig}
       fi
    else
       mv ${commonConfig}.new ${commonConfig}
    fi

   if [ "${subcmd}" == 'setup' ] || [ "${subcmd}" == 'updatecfg' ]
   then
      case ${targetType} in
   'oud') # OUD Export Config File
          if [ -e "${exporterConfig}" ]
          then
             cp ${exporterConfig} ${exporterConfig}.${now}
          fi
             
          cat > ${exporterConfig} <<EOF
###############################################################################
# Directory Server Type
targetType=${targetType}

###############################################################################
# Directory Server Instance name
instName=${instName}

###############################################################################
# Exporter listener config
metricPort=${metricPort}
listenerUser=${listenerUser}

###############################################################################
# Monitor user for admin, replication, and data suffixes
monitorUser=${monitorUser}

###############################################################################
# OUD instance ports to monitor
# A value of 0 indicates to not monitor port
monAdminlPort=${monAdminlPort}
monAdminhPort=0
monLdapPort=${monLdapPort}
monLdapsPort=${monLdapsPort}
monHttpPort=0
monHttpsPort=${monHttpsPort}

###############################################################################
# Tags used for dashboard scoping
# All double quotes (") must be escaped with backslash
tags="{hostname=\"${localHost}\"}"

###############################################################################
# Each of the customer defined suffixes
#  suffix<n>       - Base suffix of the OUD backend
#  backend<n>      - Backend of base suffix
#  metricalias<n>  - Metric alias used for suffix/backend
suffix1="dc=example,dc=com"
backend1=userRoot
metricalias1=suffix1

################################################################################
resourceName=${resName}
EOF
             ;;
   'proxy'|'replgw') # OUD Proxy/ReplGW Export Config File
          if [ -e "${exporterConfig}" ]
          then
             cp ${exporterConfig} ${exporterConfig}.${now}
          fi

          cat > ${exporterConfig} <<EOF
###############################################################################
# Directory Server Type
targetType=${targetType}

###############################################################################
# Directory Server Instance name
instName=${instName}

###############################################################################
# Exporter listener config
metricPort=${metricPort}
listenerUser=${listenerUser}

###############################################################################
# Monitor user for admin, replication, and data suffixes
monitorUser=${monitorUser}

###############################################################################
# OUD instance ports to monitor
# A value of 0 indicates to not monitor port
monAdminlPort=${monAdminlPort}
monAdminhPort=0
monLdapPort=${monLdapPort}
monLdapsPort=${monLdapsPort}
monHttpPort=0
monHttpsPort=${monHttpsPort}

###############################################################################
# Tags used for dashboard scoping
# All double quotes (") must be escaped with backslash
tags="{hostname=\"${localHost}\"}"

###############################################################################
# Each of the customer defined suffixes
#  suffix<n>       - Base suffix of the OUD backend
#  backend<n>      - Backend of base suffix
#  metricalias<n>  - Metric alias used for suffix/backend
#suffix1="dc=example,dc=com"
#backend1=userRoot
#metricalias1=suffix1

################################################################################
resourceName=${resName}
EOF
          ;;
      'oam'|'oim'|'wl') # Export Config File for WebLogic services
          if [ -e "${exporterConfig}" ]
          then
             cp ${exporterConfig} ${exporterConfig}.${now}
          fi

          cat > ${exporterConfig} <<EOF
###############################################################################
# Directory Server Type
targetType=${targetType}

###############################################################################
# Directory Server Instance name
instName=${instName}

###############################################################################
# Exporter listener config
metricPort=${metricPort}
listenerUser=${listenerUser}

###############################################################################
# Monitor user for admin, replication, and data suffixes
monitorUser=${monitorUser}

###############################################################################
# Exporter listener configuration
metricPort=${metricPort}

###############################################################################
# OAM Configuration
wlst="${wlst}"
monWlsPort=${monWlsPort}

###############################################################################
# Tags used for dashboard scoping
# All double quotes (") must be escaped with backslash
tags="{hostname=\"${localHost}\"}"
EOF

       # Make sure that wlst is defined
       if [ -z "${wlst}" ]
       then
          echo "ERROR: No wlst.sh found. Specify --wlst /<path>/wlst.sh"
          exit 1
       fi
       ;;
      esac
   fi

}

###############################################################################
# Read configs
###############################################################################
readConfigs() {
   # Load common config if present
   if [ -e "${commonConfig}" ]
   then
      . ${commonConfig}
   fi

   # Load exporter config if present
   if [ -e "${exporterConfig}" ]
   then
      . ${exporterConfig}
   fi
}


###############################################################################
# Parse arguments
###############################################################################
inclueStrings='false'
useTLS='false'
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            metricPort) myMetricPort="$1";shift;;
            admin|adminPort) myAdminlPort="$1";shift;;
            adminh) myAdminhPort="$1";shift;;
            ldap) myLdapPort="$1";shift;;
            ldaps) myLdapsPort="$1";shift;;
            wl) myWlsPort="$1";shift;;
            wlst) myWlst="$1";shift;;
            wuser) myWlsUser="$1";shift;;
            type) targetType="$1";shift;;
            interval) interval="$1";shift;;
            adir) adir="$1";shift;;
            compartment) myCompartmentId="$1";shift;;
            auser) myAgentUser="$1";shift;;
            strings) includeStrings='true';;
            name) myName="$1";shift;;
            resName) myResourceName="$1";shift;;
            instName) myInstName="$1";shift;;
            step) steps="$1";shift;;
            luser) listenerUser="$1";shift;;
            usetls) useTLS="true";;
            cert) cert="$1";shift;;
            key) key="$1";shift;;
            truststore) truststore="$1";shift;;
            oracleHome) myOracleHome="$1";shift;;
            javaHome) javaHome="$1";shift;;
            proxyproto) my_proxyProto="$1";shift;;
            proxyhost) my_proxyHost="$1";shift;;
            proxyport) my_proxyPort="$1";shift;;
            proxyuser) my_proxyUser="$1";shift;;
            proxyrealm) proxyRealm="$1";shift;;
            proxyuri) my_proxyUri="$1";shift;;
            cahost) caHost="$1";shift;;
            sshkey) sshkey="$1";shift;;
            keystore) myKeyStore="$1";shift;;
            storetype) storeType="$1";shift;;
            help) showUsage;;
            utype) uType="$1";shift;;
            dstype) dsType="$1";shift;;
            host) myHost="$1";shift;;
            port) myPort="$1";shift;;
            muser) myMonitorUser="$1";shift;;
            rootdn) bDN="$1";shift;;
            mpw) myPwFile="$1";shift;;
            eus) eus='true';shift;;
            suffix) mySuffix="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            D) myMuser="$1";shift;;
            j) jpw=$1;shift;;
            l) lpwf="$1";shift;;
            t) tpwf="$1";shift;;
            x) ppwf="$1";shift;;
            n) myTemplate=$1;shift;;
            h) myHost=$1;shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set default values
###############################################################################
USE_WALLET='true'
if [ -n "${myMuser}" ];then monitorUser="${myMuser}";fi
if [ -z "${monitorUser}" ];then monitorUser='muser';fi

if [ -z "${targetType}" ];then targetType='oud';fi
case ${targetType} in
   'oud') true;;
   'proxy') true;;
   'replgw') true;;
   *) echo "ERROR: Valid target types are oud, proxy, replgw";exit 1;;
esac

if [ -n "${myWlst}" ];then wlst="${myWlst}";fi
if [ -z "${wlst}" ];then wlst=$(find ${curdir} -name wlst.sh|grep "oracle_common/common/bin/wlst.sh"|head);fi

if [ -n "${jpw}" ]
then
   if [ -s "${jpw}" ]
   then
      jPW="${jpw}"
      bPW=$(cat ${jpw})
   else
      echo "ERROR: Monitor user password file is empty"
      exit 1
   fi
else
   if [ "${subcmd}" == 'setup' ]
   then
      echo -e "Enter monitor user's password: \c"
      while IFS= read -r -s -n1 char
      do
        [[ -z $char ]] && { printf '\n'; break; }
        if [[ $char == $'\x7f' ]]
        then
            [[ -n $bPW ]] && bPW=${bPW%?}
            printf '\b \b'
        else
          bPW+=$char
          printf '*'
        fi
      done
   fi
fi


if [ -z "${jPW}" ];then jPW="${cfgdir}/...pw";fi

if [ -n "${myName}" ];then myResourceName="${myName}";resName="${myName}";fi
if [ -n "${myResourceName}" ];then resName="${myResourceName}";fi

if [ -z "${uType}" ];then uType='admin';fi
if [ -z "${dsType}" ];then dsType='oud';fi

dsHost=${localHost}
if [ "${subcmd}" == 'adduser' ] || [ "${subcmd}" == 'moduser' ] || [ "${subcmd}" == 'deleteuser' ]
then
   case ${dsType} in
       'oud') if [ "${uType}" == 'admin' ];then suffix="cn=config";fi;;
     'proxy') if [ "${uType}" == 'admin' ];then suffix="cn=config";fi;;
    'replgw') if [ "${uType}" == 'admin' ];then suffix="cn=config";fi;;
      'dsee') if [ "${uType}" == 'admin' ];then suffix="cn=Administrators,cn=config";fi;;
           *) showUsage;;
   esac
fi

if [ -n "${myMonitorUser}" ];then monitorUser="${myMonitorUser}";fi
if [ -z "${monitorUser}" ];then monitorUser='muser';fi

if [ -n "${myHost}" ];then dsHost="${myHost}";fi
if [ -n "${myPort}" ];then dsPort="${myPort}";fi
if [ -n "${myPwFile}" ];then pwFile=${myPwFile};fi
if [ "${uType}" == 'data' ]
then
   if [ -n "${mySuffix}" ]
   then
      suffix=${mySuffix}
   else
      unset suffix
   fi
elif [ "${uType}" == 'admin' ]
then
   case ${dsType} in
         'oud') muserDN="cn=${monitorUser},cn=config";;
   esac
else
      case ${dsType} in
      'oud') muserDN="cn=${monitorUser},${suffix}";;
   esac
fi

if [ "${subcmd}" == 'adduser' ]
then
   if [ -e "${pwFile}" ]
   then
      mPW=$(cat ${pwFile} 2> /dev/null)
   fi

   if [ -z "${mPW}" ]
   then
      showUsage "ERROR: Monitor user password must be provided by --mpw <pwfile>"
      exit 1
   fi

   if [ -z "${bPW}" ]
   then
      showUsage "ERROR: Monitor privileged user password must be provided by -j <pwfile>"
      exit 1
   fi
fi

###############################################################################
# Handle Proxy Args
###############################################################################
proxyProto=''
proxyHost=''
proxyPort=''
proxyUser=''
proxyPW=''
proxyRealm=''
proxyUri=''
export proxyProto proxyHost proxyPort proxyUser proxyPW proxyRealm proxyUri
if [ -n "${my_proxyUri}" ]
then
   ckproto=$(echo ${my_proxyUri}|grep -i "^http")
   if [ -n "${ckproto}" ]
   then
      proxyProto=$(echo ${my_proxyUri}|cut -d':' -f1)
      proxyHost=$(echo ${my_proxyUri}|cut -d':' -f2|sed -e "s/\/\///g")
      proxyPort=$(echo ${my_proxyUri}|cut -d':' -f3)
   else
      echo "ERROR: proxy uri must include protocol (http:// or https://)"
      exit 1
   fi
fi
if [ -z "${proxyProto}" ];then proxyProto='http';fi
if [ -n "${my_proxyUser}" ];then proxyUser="${my_proxyUser}";fi
if [ -n "${my_proxyProto}" ];then proxyProto="${my_proxyProto}";fi
if [ -n "${my_proxyHost}" ];then proxyHost="${my_proxyHost}";fi
if [ -n "${my_proxyPort}" ];then proxyPort="${my_proxyPort}";fi
if [ -n "${proxyUser}" ] && [ "${subcmd}" != 'dc' ]
then
   if [ -n "${ppwf}" ]
   then
      if [ -e "${ppwf}" ];then proxyPW=$(cat "${ppwf}");rm -f "${ppwf}";fi
   fi
   if [ -z "${proxyPW}" ]
   then
      echo -e "Enter proxy user's password: \c"
      while IFS= read -r -s -n1 char
      do
        [[ -z $char ]] && { printf '\n'; break; }
        if [[ $char == $'\x7f' ]]
        then
            [[ -n $proxyPW ]] && proxyPW=${proxyPW%?}
            printf '\b \b'
        else
          proxyPW+=$char
          printf '*'
        fi
      done
      # Store proxy user's credential in wallet
      #addCreds
   fi
   if [ "${sub_cmd}" == 'setup' ] && [ -z "${proxyRealm}" ]
   then
      echo -e "Does your proxy require a realm? [Default: no] \c"
      read needRealm
      if [ -z "${needRealm}" ];then needRealm=no;fi
      needRealm=$(echo ${needRealm}|tr '[:upper:]' '[:lower:]')
      if [ "${needRealm}" == "yes" ]
      then
         echo -e "Proxy Realm: [Default: proxy] \c"
         read proxyRealm
         if [ -z "${proxyRealm}" ];then proxyRealm=proxy;fi
      fi
   fi
fi
if [ -n "${proxyProto}" ] && [ -n "${proxyHost}" ] && [ -n "${proxyPort}" ]
then
   proxyUri="${proxyProto}://${proxyHost}:${proxyPort}"
fi
if [ -n "${proxyProto}" ] && [ -n "${proxyHost}" ] && [ -n "${proxyPort}" ] && [ -n "${proxyUser}" ] && [ -n "${proxyPW}" ]
then
   proxyUri="${proxyProto}://${proxyUser}:${proxyPW}@${proxyHost}:${proxyPort}"
fi

case ${targetType} in
      'oud') monAdminhPort=0; monLdapPort=0; monLdapsPort=0; monHttpPort=0; monHttpsPort=0;metricPort=1888;;
    'proxy') monAdminhPort=0; monLdapPort=0; monLdapsPort=0; monHttpPort=0; monHttpsPort=0;metricPort=1887;;
   'replgw') monAdminhPort=0; monLdapPort=0; monLdapsPort=0; monHttpPort=0; monHttpsPort=0;metricPort=1886;;
          *) showUsage;;
esac

if [ -n "${myMetricPort}" ];then metricPort=${myMetricPort};fi

if [ -z "${listenerUser}" ];then listenerUser="exporter";fi

if [ -n "${myInstName}" ]
then
   instName="${myInstName}"
else
   if [ -n "${myResourceName}" ] || [ -n "${myName}" ]
   then
      instName=$(echo ${resName}-|cut -d'-' -f2)
   fi
fi
if [ -z "${instName}" ];then instName="asinst_1";fi
if [ -z "${resName}" ];then resName="${localH}-${instName}";fi
if [ -z "${commonConfig}" ];then commonConfig="${cfgdir}/common.config";fi
exporterDir="${cfgdir}/${resName}"
metricsDir="${exporterDir}/exporter/metrics"
if [ -z "${exporterConfig}" ];then exporterConfig="${exporterDir}/exporter.config";fi

if [ -n "${myCompartmentId}" ];then compartmentId="${myCompartmentId}";fi
if [ -n "${myOracleHome}" ];then oracleHome="${myOracleHome}";fi
if [ -n "${myAdminlPort}" ];then monAdminlPort="${myAdminlPort}";fi
if [ -n "${myAgentUser}" ];then agentUser="${myAgentUser}";fi

readConfigs

if [ -n "${javaHome}" ];then JAVA_HOME=${javaHome};fi
if [ -z "$JAVA_HOME" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
export OPENDS_JAVA_HOME="$JAVA_HOME"
if [ -n "${oracleHome}" ];then lsrch="${oracleHome}/oud/bin/ldapsearch";drepl="${oracleHome}/oud/bin/dsreplication";fi

if [ -n "$JAVA_HOME" ]
then
   ktool="$JAVA_HOME/bin/keytool"
else
   if [ "${subcmd}" == 'setup' ] || [ "${subcmd}" == 'regenca' ] || [ "${subcmd}" == 'regencert' ]
   then
      echo "ERROR: JAVA_HOME not set. Specify --javaHome <path>"
      exit 1
   fi
fi

if [ -n "${myMuser}" ];then monitorUser="${myMuser}";fi
if [ -n "${my_proxyUser}" ];then proxyUser="${my_proxyUser}";fi
case ${targetType} in
      'oud') muserDN="cn=${monitorUser},cn=config";resourceGroup="oud_directory";;
    'proxy') muserDN="cn=${monitorUser},cn=config";resourceGroup="oud_proxy";;
   'replgw') muserDN="cn=${monitorUser},cn=config";resourceGroup="oud_gateway";;
esac
muserRDN=$(echo ${muserDN}|cut -d',' -f1)

if [ -n "${myAdminlPort}" ];then monAdminlPort="${myAdminlPort}";fi
if [ -n "${myAdminhPort}" ];then monAdminhPort="${myAdminhPort}";fi
if [ -n "${myLdapPort}" ];then monLdapPort="${myLdapPort}";fi
if [ -n "${myLdapsPort}" ];then monLdapsPort="${myLdapsPort}";fi
if [ -n "${myHttpPort}" ];then monHttpPort="${myHttpPort}";fi
if [ -n "${myHttpsPort}" ];then monHttpsPort="${myHttpsPort}";fi
if [ -n "${myWlsPort}" ];then monWlsPort="${myWlsPort}";fi
if [ -n "${myWlsUser}" ];then wlsUser="${myWlsUser}";fi
if [ -z "${wlsUser}" ];then wlsUser="weblogic";fi

# Determine default management agent user
if [ -z "${adir}" ] && [ -z "${agentUser}" ] && [ "${me}" == 'mgmt_agent' ] 
then
   test -d "/opt/oracle/mgmt_agent/agent_inst"
   rc=$?
   if [ ${rc} -eq 0 ]
   then
      adir="/opt/oracle/mgmt_agent/agent_inst"
      agentUser="mgmt_agent"
   fi
elif [ -z "${adir}" ] && [ -z "${agentUser}" ] && [ "${me}" == 'oracle-cloud-agent' ]
then
   test -d "/var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst"
   rc=$?
   if [ ${rc} -eq 0 ]
   then
      adir="/var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst"
      agentUser="oracle-cloud-agent"
   fi
elif [ -z "${adir}" ] && [ -z "${agentUser}" ]
then
   if [ "${me}" == 'root' ]
   then
      test -d "/opt/oracle/mgmt_agent/agent_inst"
      rc=$?
      if [ ${rc} -eq 0 ]
      then
         adir="/opt/oracle/mgmt_agent/agent_inst"
         agentUser="mgmt_agent"
      else
         test -d "/var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst"
         rc=$?
         if [ ${rc} -eq 0 ]
         then
            adir="/var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst"
            agentUser="oracle-cloud-agent"
         fi
      fi
   elif [ "${subcmd}" == 'summary' ] || [ "${subcmd}" == 'gencert' ] || [ "${subcmd}" == 'regencert' ] || [ "${subcmd}" == 'regenca' ]
   then
      true
   else
      echo "Enabling restart on OS boot requires running this script as root"
      exit 1
   fi
fi

if [ -n "${myAgentUser}" ];then agentUser="${myAgentUser}";fi

case ${agentUser} in
   'oracle-cloud-agent') true;;
   'mgmt_agent') true;;
   '') agentUser='mgmt_agent';;
   *) echo "ERROR: Invalid agent user name";exit 1;;
esac


if [ -n "${lpwf}" ]
then
   if [ -s "${lpwf}" ]
   then
      lPW=$(cat ${lpwf})
   else
      echo "ERROR: Listener password file is empty"
      exit 1
   fi
fi
if [ -z "${lPW}" ];then lPW="${bPW}";fi


if [ "${useTLS}" == 'true' ]
then
   if [ -z "${truststore}" ]; then truststore="${certdir}/CA/truststore";fi
   if [ -z "${cert}" ]; then cert="${certdir}/localhost.pem";fi
   if [ -z "${key}" ]; then key="${certdir}/pylocalhost.pem";fi
   if [ -n "${tpwf}" ]
   then
      if [ -s "${tpwf}" ]
      then
         tPW=$(cat ${tpwf})
      else
         echo "ERROR: Truststore password file is empty"
         exit 1
      fi
   fi
fi
if [ -z "${tPW}" ];then tPW="${bPW}";fi

if [ -z "${interval}" ];then interval=120;fi

if [ -z "${adir}" ];then adir='/opt/oracle/mgmt_agent/agent_inst';fi

if [ -n "${myCompartmentId}" ];then compartmentId="${myCompartmentId}";fi

sshkey="$HOME/.ssh/id_rsa.pub"
cadir="${certdir}/CA"
icadir="${certdir}/intermediate"
csrdir="${certdir}/csr"
caTrustStore="${cadir}/truststore"

# Set random password for keystore
jkspwf="${certdir}/.jks"
if [ -e "${jkspwf}" ]
then
   . ${jkspwf}
else
   jkspw=$(head /dev/urandom | tr -dc 'a-zA-Z0-9' | cut -c1-32)
   mkdir -p "${certdir}" 2> /dev/null
   echo "jkspw=${jkspw}" > ${jkspwf}
fi


if [ "${cadir}" == '/CA' ]
then
   echo "ERROR: Cert dir may not be the root (/) directory"
   exit 1
fi

# Setup CA if it doesn't already exist
if [ -z "${myHost}" ];then myHost="localhost";fi
if [ -n "${myKeyStore}" ];then keystore="${myKeyStore}";fi
if [ -z "${keystore}" ];then keystore="${certdir}/${myHost}/${myHost}.p12";fi

if [ -z "${storeType}" ];then storeType="JKS";fi

sshprivkey=$(echo ${sshkey}|sed -e "s/\.pub$//gi")

if [ "${subcmd}" == 'setup' ] 
then
   updateConfigs
elif [ "${subcmd}" == 'updatecfg' ]
then
   updateConfigs
   exit
fi 

###############################################################################
# Check TCP state of all ports
###############################################################################
tcp_check_oud() {
   if [ "${dbg}" == 'true' ];then set -x;fi

   adminlState=''
   adminhState=''
   ldapState=''
   ldapsState=''
   httpState=''
   httpsState=''

   if [ "${monAdminlPort}" == '0' ];then ckAdminl='NA';adminlState=2;else ckAdminl=$(test_port ${localHost} ${monAdminlPort});fi
   if [ "${monAdminhPort}" == '0' ];then ckAdminh='NA';adminhState=2;else ckAdminh=$(test_port ${localHost} ${monAdminhPort});fi
   if [ "${monLdapPort}"   == '0' ];then ckLdap='NA'  ;ldapState=2;else ckLdap=$(test_port  ${localHost} ${monLdapPort});fi
   if [ "${monLdapsPort}"  == '0' ];then ckLdaps='NA' ;ldapsState=2;else ckLdaps=$(test_port ${localHost} ${monLdapsPort});fi
   if [ "${monHttpPort}"   == '0' ];then ckHttp='NA'  ;httpState=2;else ckHttp=$(test_port  ${localHost} ${monHttpPort});fi
   if [ "${monHttpsPort}"  == '0' ];then ckHttps='NA' ;httpsState=2;else ckHttps=$(test_port ${localHost} ${monHttpsPort});fi

   if [ "${ckAdminl}" == 'UP' ] && [ "${adminlState}" != '2' ];then adminlState=1;elif [ "${ckAdminl}" == 'DOWN' ];then adminlState=0;fi
   if [ "${ckAdminh}" == 'UP' ] && [ "${adminhState}" != '2' ];then adminhState=1;elif [ "${ckAdminh}" == 'DOWN' ];then adminhState=0;fi
   if [ "${ckLdap}"   == 'UP' ] && [ "${ldapState}"   != '2' ];then ldapState=1;elif   [ "${ckLdap}"   == 'DOWN' ];then ldapState=0;fi
   if [ "${ckLdaps}"  == 'UP' ] && [ "${ldapsState}"  != '2' ];then ldapsState=1;elif  [ "${ckLdaps}"  == 'DOWN' ];then ldapsState=0;fi
   if [ "${ckHttp}"   == 'UP' ] && [ "${httpState}"   != '2' ];then httpState=1;elif   [ "${ckHttp}"   == 'DOWN' ];then httpState=0;fi
   if [ "${ckHttps}"  == 'UP' ] && [ "${httpsState}"  != '2' ];then httpsState=1;elif  [ "${ckHttps}"  == 'DOWN' ];then httpsState=0;fi

   tags="{hostname=\"${localHost}\",Type=\"adminl\"}"
   echo "connection_handler_state${tags} ${adminlState}"

   tags="{hostname=\"${localHost}\",Type=\"adminh\"}"
   echo "connection_handler_state${tags} ${adminhState}"

   tags="{hostname=\"${localHost}\",Type=\"ldap\"}"
   echo "connection_handler_state${tags} ${ldapState}"

   tags="{hostname=\"${localHost}\",Type=\"ldaps\"}"
   echo "connection_handler_state${tags} ${ldapsState}"

   tags="{hostname=\"${localHost}\",Type=\"http\"}"
   echo "connection_handler_state${tags} ${httpState}"

   tags="{hostname=\"${localHost}\",Type=\"https\"}"
   echo "connection_handler_state${tags} ${httpsState}"

   set +x
}

###############################################################################
# LDAP/LDAPS Check of admin and each user-defined backend
###############################################################################
ldapCheck() {
   if [ "${monAdminlPort}" == '0' ]
   then
      queryAdminl='UP'
   else
      ldpPW="${bPW}"
      queryAdminl=$(pyLdapSearch ldaps "${localHost}" "${monAdminlPort}" "${muserDN}" "${muserDN}" 'base' "objectClass=top" 2> /dev/null|grep "description: UP")
      if [ -z "${queryAdminl}" ];then queryAdminl='DOWN';fi
   fi

   if [ "${monLdapPort}" == '0' ]
   then
      queryLdap='UP'
   else
      ldpPW="${bPW}"
      queryLdap=$(pyLdapSearch ldap "${localHost}" "${monLdapPort}" "${muserDN}" "${muserDN}" 'base' "objectClass=top" 2> /dev/null|grep "description: UP")
      if [ -z "${queryLdap}" ];then queryLdap='DOWN';fi
   fi

   if [ "${monLdapsPort}" == '0' ]
   then
      queryLdaps='UP'
   else
      ldpPW="${bPW}"
      queryLdaps=$(pyLdapSearch ldaps "${localHost}" "${monLdapsPort}" "${muserDN}" "${muserDN}" 'base' "objectClass=top" 2> /dev/null|grep "description: UP")
      if [ -z "${queryLdaps}" ];then queryLdaps='DOWN';fi
   fi
}

###############################################################################
# HTTP/HTTPS Check of admin and each user-defined backend
###############################################################################
httpCheck() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ "${monAdminhPort}" == '0' ]
   then
      queryAdminh='DOWN'
   else
      queryAdminh=$(curl -sk https://${localHost}:${monAdminhPort}/ 2> /dev/null|grep "Jetty"|sed -e "s/^.*/UP/g")
      if [ -z "${queryAdminh}" ];then queryAdminh='DOWN';fi
   fi

   if [ "${monHttpPort}" == '0' ]
   then
      queryHttp='DOWN'
   else
      queryHttp=$(curl -s http://${localHost}:${monHttpPort}/ 2> /dev/null|grep "Jetty"|sed -e "s/^.*/UP/g")
      if [ -z "${queryHttp}" ];then queryHttp='DOWN';fi
   fi

   if [ "${monHttpsPort}" == '0' ]
   then
      queryHttps='DOWN'
   else
      queryHttps='UP'
      queryHttps=$(curl -sk https://${localHost}:${monHttpsPort}/ 2> /dev/null|grep "Jetty"|sed -e "s/^.*/UP/g")
      if [ -z "${queryHttps}" ];then queryHttps='DOWN';fi
   fi
   set +x
}

###############################################################################
# Replication Check
###############################################################################
repl_check_oud() {
   suffixN="$1"

   n=0
   if [ -z "${suffixN}" ]
   then
      n=1
      suffixN="$(eval "echo \$suffix${n}")"
   fi

   while [ -n "${suffixN}" ]
   do
      if [ ${n} -eq 0 ]
      then
         backendN=$(echo ${suffixN}|sed -e "s/cn=//g" -e "s/ /_/g")
         metricaliasN=$(echo ${suffixN}|sed -e "s/cn=//g" -e "s/ /_/g")
      else
         suffixN=$(eval "echo \$suffix${n}")
         backendN=$(eval "echo \$backend${n}")
         metricaliasN=$(eval "echo \$metricalias${n}")
      fi

      timeout 110 ${drepl} status -s --advanced --dataToDisplay compact-view --hostname ${localHost} --port ${monAdminlPort} --baseDN "${suffixN}" --bindDN "${muserDN}" --trustAll --connectTimeout 1000000 --readTimeout 1000000 2> /dev/null > ${tmpdir}/repl-${resName}-${now}.tmp <<EOF
${bPW}
EOF

      sed -e "s/ //g" ${tmpdir}/repl-${resName}-${now}.tmp > ${tmpdir}/repl-${resName}-${now}.out 2> /dev/null
      if [ "${dbg}" == 'true' ];then true;else rm -f ${tmpdir}/repl-${resName}-${now}.tmp 2> /dev/null;fi

      if [ -e "${tmpdir}/repl-${resName}-${now}.out" ]
      then
         readarray -t replStatus < <(cat ${tmpdir}/repl-${resName}-${now}.out|egrep "^Server|^Entries|^Mis|^Age|^Replication Port|^Status|^Unres"|sed -e "s/^/|/g" -e "s/ //g" -e "s/	//g"|tr -d '[\n\r]'|sed -e "s/^|Server:/\nServer:/g")
         rc=$?
         for (( x=0; x< ${#replStatus[*]}; x++ ))
         do
            if [[ "${replStatus[${x}]}" == *Server:${localHost}* ]] || [[ "${replStatus[${x}]}" == *Server:${localH}* ]]
            then
               replAOMC=$(echo "${replStatus[${x}]}"|sed -e "s/^.*AgeOfOldestMissingChange://g" -e "s/|.*//g"|tr -dc '0-9')
               replMC=$(echo "${replStatus[${x}]}"|sed -e "s/^.*MissingChanges://g" -e "s/|.*//g"|tr -dc '0-9')
               replState=$(echo "${replStatus[${x}]}"|sed -e "s/^.*Status://g" -e "s/|.*//g" -e "s/Normal/1/g"|tr -dc '0-9')
               replUnresolvedConflicts=$(echo "${replStatus[${x}]}"|sed -e "s/^.*UnresolvedReplicationConflicts://g" -e "s/|.*//g"|tr -dc '0-9')

               if [[ "${replAOMC}" != *${localHost}:${monAdminlPort}* ]] && [[ "${replAOMC}" != *${localHost}:${monAdminhPort}* ]]
               then
                  tags="{hostname=\"${localHost}\",Type=\"${metricaliasN}\"}"
                  if [ -n "${replState}" ];then echo "replication_domain_state${tags} ${replState}";fi
                  if [ -n "${replAOMC}" ];then echo "replication_domain_aomc${tags} ${replAOMC}"|sed -e "s/Over100/101/g";fi
                  if [ -n "${replMC}" ];then echo "replication_domain_missing_changes${tags} ${replMC}"|sed -e "s/Over100/101/g";fi
                  if [ -n "${replUnresolvedConflicts}" ];then echo "replication_domain_unresolved_conflicts${tags} ${replUnresolvedConflicts}"|sed -e "s/Over100/101/g";fi
               fi
            fi
         done
      fi
      if [ ${n} -eq 0 ]
      then
         suffixN=''
      else
         let n++
         suffixN=$(eval "echo \$suffix${n}")
      fi

      if [ "${dbg}" == 'true' ];then true;else rm -f ${tmpdir}/repl-${resName}-${now}.out 2> /dev/null;fi
   done
}

###############################################################################
# Query OUD instance
###############################################################################
checkHealth() {
   # Start with an assumption that all services are UP
   dsAdminState='UP'
   dsLdapState='UP'
   dsLdapsState='UP'
   dsHttpState='UP'
   dsHttpsState='UP'

#      ldapCheck
#      httpCheck
#      if [ "${ckLdaps}" == 'UP' ]
#      then
#         repl_check_oud "cn=schema"
#         repl_check_oud "cn=admin data"
#         repl_check_oud
#      fi

   # Check TCP state
   tcp_check_oud

   # Check replication
   repl_check_oud "cn=schema"
   repl_check_oud "cn=admin data"
   repl_check_oud

   # If Admin port is up
   if [ "${adminlState}" == '1' ]
   then
      dsAdmin='LDAPS'
      dsaout="${tmpdir}/$$${now}-${monAdminlPort}-dsa"
      pyLdapSearch ldaps "${localHost}" "${monAdminlPort}" "${muserDN}" "${muserDN}" 'base' "objectClass=top" 2> /dev/null > ${dsaout}
      rc=$?
      if [ ${rc} -eq 0 ];then dsAdminState='UP';fi
   elif [ "${adminhState}" == '1' ]
   then
      dsAdmin='HTTPS'
      rc=0
      queryAdminh=$(curl -sk https://${localHost}:${monAdminhPort}/ 2> /dev/null|grep "Jetty"|sed -e "s/^.*/UP/g")
      if [ -z "${queryAdminh}" ];then rc=1; dsAdminState='DOWN';fi
   else
      dsAdminState='DOWN'
   fi

   # Set state of all other connection handlers based on admin state
   if [ "${dsAdminState}" == 'DOWN' ] || [ ${rc} -eq 1 ] || [ ${rc} -eq 91 ] || [ ${rc} -eq 52 ]
   then
      dsAdminState='DOWN'
      dsLdapState='DOWN'
      dsLdapsState='DOWN'
      dsHttpState='DOWN'
      dsHttpsState='DOWN'
   elif [ ${rc} -eq 32 ] || [ ${rc} -eq 81 ]
   then
      dsAdminState='WARN'
      dsLdapState='WARN'
      dsLdapsState='WARN'
      dsHttpState='WARN'
      dsHttpsState='WARN'
   elif [ ${rc} -eq 0 ]
   then
      # Check to see if muser status in description attribute is up
      ckbase=$(grep -i '^description: instanceIsUp' ${dsaout} 2> /dev/null)
      if [ -z "${ckbase}" ];then dsAdminState='MAINT';fi

      # Check to see if the admin is unavailable
      ckdown=$(grep -i '^LDAP server is unavailable' ${dsaout} 2> /dev/null)
      if [ -n "${ckdown}" ];then dsAdminState='DOWN';dsLdapState='DOWN'; dsLdapsState='DOWN';dsHttpState='DOWN';dsHttpsState='DOWN';fi

      rm -f "${dsaout}" 2> /dev/null

      if [ "${dsAdminState}" != 'DOWN' ]
      then
        if [ "${dsAdmin}" == 'LDAPS' ]
        then
           pyLdapSearch ldaps "${localHost}" "${monAdminlPort}" "${muserDN}" "cn=config" 'sub' 'objectClass=ds-cfg-db-local-backend-workflow-element' 2> /dev/null > ${dsaout}

           read -r -a baseDnCfgList <<< $(grep "^ds-cfg-base-dn: " ${dsaout}|egrep -vi 'cn=virtual'|sed -e "s/^ds-cfg-base-dn: //g" -e "s/ /${spcvar}/g")

           rm -f "${dsaout}" 2> /dev/null
        elif [ "${dsAdmin}" == 'HTTPS' ]
        then
           echo "WARN: REST Admin not supported yet"
        fi
      fi

      # Test each backend via LDAP and LDAPS
      for (( d=0; d< $((${#baseDnCfgList[*]})); d++ ))
      do
         # Get Suffix
         baseDnSuffix=$(echo "${baseDnCfgList[${d}]}"|sed -e "s/${spcvar}/ /g" -e "s/^dn: //g")

         # Test LDAP
         if [ "${baseDnSuffix}" != 'cn=OracleContext' ] && [ "${baseDnSuffix}" != 'cn=OracleSchemaVersion' ]
         then
            if [ ${monLdapPort} -eq 0 ]
            then
               dsLdapState='OFF'
            else
               dslout="${tmpdir}/$$${now}-${monLdapPort}-dsl"
               pyLdapSearch ldap "${localHost}" "${monLdapPort}" "${muserRDN},${baseDnSuffix}" "${muserDN}" 'base' 'objectClass=top' 2>&1 |grep -vi "^userpassword: " > ${dslout}
               rc=$?

               if [ ${rc} -eq 1 ] || [ ${rc} -eq 91 ] || [ ${rc} -eq 52 ] || [ ${rc} -eq 10 ]
               then
                  dsLdapState='DOWN'
               elif [ ${rc} -eq 32 ] || [ ${rc} -eq 81 ]
               then
                  dsLdapState='ERROR'
               elif [ ${rc} -eq 0 ]
               then
                  ckdown=$(grep -i '^LDAP server is unavailable' ${dslout} 2> /dev/null)
                  if [ -n "${ckdown}" ];then dsLdapState='DOWN';fi
                  cknoobj=$(grep -i '^No such object' ${dslout} 2> /dev/null)
                  if [ -n "${cknoobj}" ];then dsLdapState='ERROR';fi
                  ckreferral=$(grep -i '^Referral' ${dslout} 2> /dev/null)
                  if [ -n "${ckreferral}" ];then dsLdapState='DOWN';fi
               fi
               rm -f "${dslout}" 2> /dev/null
            fi

            # Test each backend
            if [ ${monLdapsPort} -eq 0 ]
            then
               dsLdapsState='OFF'
            else
               dslout="${tmpdir}/$$${now}-${monLdapPort}-dsl"
               pyLdapSearch ldaps "${localHost}" "${monLdapsPort}" "${muserRDN},${baseDnSuffix}" "${muserDN}" 'base' 'objectClass=top' 2>&1 |grep -vi "^userpassword: " > ${dslout}
               rc=$?
               if [ ${rc} -eq 1 ] || [ ${rc} -eq 91 ] || [ ${rc} -eq 52 ] || [ ${rc} -eq 10 ]
               then
                  dsLdapsState='DOWN'
               elif [ ${rc} -eq 32 ] || [ ${rc} -eq 81 ]
               then
                  dsLdapsState='ERROR'
               elif [ ${rc} -eq 0 ]
               then
                  ckdown=$(grep -i '^LDAP server is unavailable' ${dslout} 2> /dev/null)
                  if [ -n "${ckdown}" ];then dsLdapsState='DOWN';fi
                  cknoobj=$(grep -i '^No such object' ${dslout} 2> /dev/null)
                  if [ -n "${cknoobj}" ];then dsLdapsState='ERROR';fi
                  ckreferral=$(grep -i '^Referral' ${dslout} 2> /dev/null)
                  if [ -n "${ckreferral}" ];then dsLdapState='DOWN';fi
               fi
               rm -f "${dslout}" 2> /dev/null

               if [ "${dsLdapState}" == 'ERROR' ] || [ "${dsLdapsState}" == 'ERROR' ]
               then
                  echo "INFO: Make sure \"${lDN},${baseDnSuffix}\" user exists in ${localHost}:${portLdaps}" >> ${mon_log}
               fi
            fi
         fi
      done
   fi

   # Apply logic to determine state of service
   # 1. If admin is down, then the instance is down
   # 2. If any are in DOWN state, the instance is a WARN state
   # 3. If any are in MAINT (maintenance) state, the instance is a MAINT state
   dsStatus=0
   if [ "${dsAdminState}" == 'DOWN' ]
   then
      dsStatus=0 # DOWN
   elif [ "${dsAdminState}" == 'UP' ] || [ "${dsAdminState}" == 'MAINT' ]
   then
      if [ "${dsLdapState}" == 'DOWN' ] || [ "${dsLdapsState}" == 'DOWN' ] && [ "${dsHttpState}" == 'DOWN' ] && [ "${dsHttpsState}" == 'DOWN' ]
      then
         dsStatus=3 # WARN
      elif [ "${dsAdminState}" == 'MAINT' ] || [ "${dsLdapState}" == 'MAINT' ] || [ "${dsLdapsState}" == 'MAINT' ] || [ "${dsHttpState}" == 'MAINT' ]
      then
         dsStatus=2 # MAINT
      else
         dsStatus=1 # UP
      fi
   else
      dsStatus=1 # UP
   fi

   tags="{hostname=\"${localHost}\"}"
   echo "oud_base_status${tags} ${dsStatus}"
}

###############################################################################
# Query OUD instance
###############################################################################
query_os() {
   # Supplement with extra extrnal data
   vCPUs=$(lscpu|grep "^CPU(s)"|awk '{ print $2 }')
   if [ -n "${vCPUs}" ];then echo "os_vCPUs${tags} ${vCPUs}";fi

   mem=$(free -m |grep "^Mem:")
   if [ -n "${mem}" ];then tmem=$(echo ${mem}|awk '{print $2}');echo "os_mem_total${tags} ${tmem}";fi
   if [ -n "${mem}" ];then umem=$(echo ${mem}|awk '{print $3}');echo "os_mem_used${tags} ${umem}";fi
   if [ -n "${mem}" ];then fmem=$(echo ${mem}|awk '{print $4}');echo "os_mem_free${tags} ${fmem}";fi
   if [ -n "${mem}" ];then cmem=$(echo ${mem}|awk '{print $6}');echo "os_mem_cache${tags} ${cmem}";fi

   pgout=$(grep "^pgpgout" /proc/vmstat|awk '{ print $2 }')
   if [ "${pgout}" -lt 0  ];then pgout=0;fi
   if [ -n "${pgout}" ];then echo "os_pageout${tags} ${pgout}";fi

   if [ -n "${instName}" ]
   then
      clsz=$(ps -ef|grep config.ldif|grep "/${instName}/"|sed -e "s/^.*configFile //g" -e "s/\/config\/config.*//g" -e "s/$/\/changelogDb/g"|xargs -n1 du -bs 2> /dev/null|awk '{ print $1 }')
      if [ -z "${clsz}" ];then clsz=0;fi
      if [ -n "${clsz}" ];then echo "os_clsz${tags} ${clsz}";fi

      dbsz=$(ps -ef|grep config.ldif|grep "/${instName}/"|sed -e "s/^.*configFile //g" -e "s/\/config\/config.*//g" -e "s/$/\/db/g"|xargs -n1 du -bs 2> /dev/null|awk '{ print $1 }')
      if [ -z "${dbsz}" ];then dbsz=0;fi
      if [ -n "${dbsz}" ];then echo "os_dbsz${tags} ${dbsz}";fi

      if [ ${dbsz} -gt 0 ] && [ ${clsz} -gt 0 ]
      then
         oudsz=$((${dbsz}+${clsz}))
         if [ -n "${oudsz}" ];then echo "os_oudsz${tags} ${oudsz}";fi
      fi
   fi

   # Log top processes with faults
   #d=$(date +'%Y-%m-%dT%H:%M:%S');ps -o minflt -o \|%p -o \|%a -eL|sort -nr|head -100|sed -e "s/^/${d}|/g"|awk -F'|' '{ print "[MinFaults: " $2 "] [Pid: " $3 "] [Command: " $4 "]"}'|sed -e "s/^/[${d}] /g" >> ${logdir}/faults-${today}.log
}

###############################################################################
# Query OUD instance
###############################################################################
query_oud() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   echo -e "# Output:\n# HELP oud_instance OUD instance metrics.\n# TYPE oud_instance counter"

   dnvar=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
   if [ -n "${jpw}" ];then jPW="${jpw}";fi

   # Initialize summarized connection handler metrics
   abandon_sum=0
   add_sum=0
   bind_sum=0
   compare_sum=0
   delete_sum=0
   extended_sum=0
   mod_sum=0
   moddn_sum=0
   search_sum=0
   unbind_sum=0
   searchone_sum=0
   searchsub_sum=0

   abandon_rt_sum=0
   add_rt_sum=0
   bind_rt_sum=0
   compare_rt_sum=0
   delete_rt_sum=0
   extended_rt_sum=0
   mod_rt_sum=0
   moddn_rt_sum=0
   search_rt_sum=0
   unbind_rt_sum=0

   ch_cnt=0

   byte_to_mb=0.000001

   checkHealth

   if [ "${dbg}" == 'true' ];then set -x;fi

   if [ ${monAdminlPort} -ne 0 ] && [ "${ckAdminl}" == 'UP' ]
   then
      timeout 300 ${lsrch} -T -h ${localHost} -p ${monAdminlPort} -X -Z -D "${muserDN}" -s sub -b 'cn=monitor' '(!(cn=JVM Stack Trace))' > ${tmpdir}/srch-${resName}-${now}.tmp 2>&1 <<EOF
${bPW}
EOF
      sed -e "s/ //g" -e "s/.*:dn: cn=monitor/dn: cn=monitor/g"  ${tmpdir}/srch-${resName}-${now}.tmp > ${tmpdir}/srch-${resName}-${now}.out  2> /dev/null

      readarray -t metrics < <(cat ${tmpdir}/srch-${resName}-${now}.out \
         |egrep -vi "^objectClass: |^cn: |^$|^ds-connectionhandler-connection: |^connection: |^ds-mon-outliers: " \
         |sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/^dn:${spcvar}/${dnvar}/g" -e "s/^${dnvar}cn=monitor/base/g" -e "s/${dnvar}cn=/${dnvar}/g" -e "s/$/|/g" \
         |tr -d '[\n\r]' \
         |sed -e "s/,cn=monitor//g" -e "s/${dnvar}/\n/g" -e "s/${spcvar}Backend|/-be|/gi" -e "s/${spcvar}Backend,/-be,/gi" \
         |egrep -v "^base-be|^cn=monitor" \
      )
      if [ "${dbg}" == 'true' ];then true;else rm -f ${tmpdir}/srch-${resName}-${now}.out ${tmpdir}/srch-${resName}-${now}.tmp 2> /dev/null;fi
   elif [ ${monAdminhPort} -ne 0 ]
   then
      # Figure out how to convert JSON to LDIF for common parsing
      echo "ERROR: Metric collection through HTTPS Administration Connection Handler is not supported"
      exit 1
   fi

   # If cannot query cn=monitor, consider this a warning condition
   if [ ${#metrics[*]} -eq 0 ]
   then
      echo "oud_status${tags} 3"
      exit
   fi

   for (( x=0; x< ${#metrics[*]}; x++ ))
   do
      object=$(echo "${metrics[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      tags="{hostname=\"${localHost}\"}"

      # Base Metrics
      if [[ "${object}" == *currentConnections:* ]]
      then
         echo ${object}|sed -e "s/^.*currentConnections: //g" -e "s/|.*//g" -e "s/^/oud_base_current_connections${tags} /g"
         echo ${object}|sed -e "s/^.*maxConnections: //g" -e "s/|.*//g" -e "s/^/oud_base_max_connections${tags} /g"

      # Base System Information
      elif [[ "${object}" == *availableCPUs* ]]
      then
         echo ${object}|sed -e "s/^.*availableCPUs: //g" -e "s/|.*//g" -e "s/^/oud_base_cpus${tags} /g"

         value_bytes=$(echo ${object}|sed -e "s/^.*maxMemory: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_max_memory${tags} ${value_mb}"

         value_bytes=$(echo ${object}|sed -e "s/^.*freeUsedMemory: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_free_memory${tags} ${value_mb}"

         value_bytes=$(echo ${object}|sed -e "s/^.*usedMemory: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_used_memory${tags} ${value_mb}"

      # G1 GC cn=JVM Memory Usage,cn=monitor
      elif [[ "${object}" == *code-cache-bytes-used-after-last-collection* ]] && [[ "${object}" == *g1-old-gen-bytes-used-after-last-collection* ]]
      then

         value_bytes=$(echo ${object}|sed -e "s/^.*g1-survivor-space-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_survivor${tags} ${value_mb}"

         value_bytes=$(echo ${object}|sed -e "s/^.*g1-eden-space-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_eden${tags} ${value_mb}"

         value_bytes=$(echo ${object}|sed -e "s/^.*g1-old-gen-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_oldgen${tags} ${value_mb}"

      # CMS GC cn=JVM Memory Usage,cn=monitor
      elif [[ "${object}" == *code-cache-bytes-used-after-last-collection* ]] && [[ "${object}" == *par-new-average-collection-duration* ]]
      then

         value_bytes=$(echo ${object}|sed -e "s/^.*par-survivor-space-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_survivor${tags} ${value_mb}"

         value_bytes=$(echo ${object}|sed -e "s/^.*par-eden-space-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_eden${tags} ${value_mb}"

         value_bytes=$(echo ${object}|sed -e "s/^.*cms-old-gen-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_oldgen${tags} ${value_mb}"

      # Parallel GC cn=JVM Memory Usage,cn=monitor
      elif [[ "${object}" == *code-cache-bytes-used-after-last-collection* ]] && [[ "${object}" == *ps-mark-sweep-total-collection-duration* ]]
      then

         value_bytes=$(echo ${object}|sed -e "s/^.*ps-survivor-space-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_survivor${tags} ${value_mb}"

         value_bytes=$(echo ${object}|sed -e "s/^.*ps-eden-space-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_eden${tags} ${value_mb}"

         value_bytes=$(echo ${object}|sed -e "s/^.*ps-old-gen-current-bytes-used: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "jvm_oldgen${tags} ${value_mb}"

      # Disk Space Monitor
      elif [[ "${object}" == *disk-state* ]]
      then
         prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/,cn=Disk Space.*//g" -e "s/-be//g")
         tags="{hostname=\"${localHost}\",Category=\"${prefix}\"}"
         value_bytes=$(echo ${object}|sed -e "s/^.*disk-free: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "backend_disk_free${tags} ${value_mb}"

      # Backends
      elif [[ "${object}" == *ds-backend-is-private* ]] && [[ "${object}" != *Disk\ Space\ Monitor* ]] && [[ "${object}" != *Undirect* ]]
      then
         if [[ "${object}" != *Connection\ Handler* ]] && [[ "${object}" != *Connected\ Replica* ]] && [[ "${object}" != *cache* ]] && [[ "${object}" != *load\ balancing* ]]
         then
            # Original
            #prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/-be$//g" -e "s/-/_/g")
            prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/-be$//g")
            tags="{hostname=\"${localHost}\",Category=\"${prefix}\"}"
            echo ${object}|sed -e "s/^.*ds-backend-entry-count: //g" -e "s/|.*//g" -e "s/^/backend_entry_count${tags} /g"
         fi

      # Connection Handlers
      elif [[ "${object}" == *ds-connectionhandler-protocol* ]]
      then
         ch_proto=$(echo ${object}|sed -e "s/^.*ds-connectionhandler-protocol: //g" -e "s/|.*//g"|tr '[:upper:]' '[:lower:]')
         if [[ "${object}" == *HTTP\ Administration\ Connector* ]]
         then
            ch_proto='adminh'
         elif [[ "${object}" == *LDAP\ Administration\ Connector* ]]
         then
            ch_proto='adminl'
         fi
         tags="{hostname=\"${localHost}\",Type=\"${ch_proto}\"}"
         echo ${object}|sed -e "s/^.*ds-connectionhandler-num-connections: //g" -e "s/|.*//g" -e "s/^/connection_handler_connections${tags} /g"

      # Database Environment
      elif [[ "${object}" == *EnvironmentNBatchesManual* ]]
      then
         be=$(echo ${object}|sed -e "s/^cn=//g" -e "s/ Database Environment//g" -e "s/|.*//g")

         # See https://docs.oracle.com/en/middleware/idm/unified-directory/12.2.1.4/oudag/monitoring-oracle-unified-directory.html#GUID-4A8B943D-9A5B-4353-8B30-7672B04DA852
         lnfetch=$(echo ${object}|sed -e "s/^.*EnvironmentNLNsFetch: //g" -e "s/|.*//g")
         lnfetchmiss=$(echo ${object}|sed -e "s/^.*EnvironmentNLNsFetchMiss: //g" -e "s/|.*//g")

         binfetch=$(echo ${object}|sed -e "s/^.*EnvironmentNBINsFetch: //g" -e "s/|.*//g")
         binfetchmiss=$(echo ${object}|sed -e "s/^.*EnvironmentNBINsFetchMiss: //g" -e "s/|.*//g")
         binfetchmissratio=$(echo ${object}|sed -e "s/^.*EnvironmentNBINsFetchMissRatio: //g" -e "s/|.*//g")

         uinfetch=$(echo ${object}|sed -e "s/^.*EnvironmentNUpperINsFetch: //g" -e "s/|.*//g")
         uinfetchmiss=$(echo ${object}|sed -e "s/^.*EnvironmentNUpperINsFetchMiss: //g" -e "s/|.*//g")

         lnratio=$(echo ${lnfetchmiss} ${lnfetch}|awk '{ printf "%.0f", $1/$2*100 }' 2> /dev/null)
         if [ -z "${lnratio}" ];then lnratio=${lnfetch};fi

         binratio=$(echo ${binfetchmiss} ${binfetch}|awk '{ printf "%.0f", $1/$2*100 }' 2> /dev/null)
         if [ -z "${binratio}" ];then binratio=${binfetch};fi

         uinratio=$(echo ${uinfetchmiss} ${uinfetch}|awk '{ printf "%.0f", $1/$2*100 }' 2> /dev/null)
         if [ -z "${uinratio}" ];then uinratio=${uinfetch};fi

         tags="{hostname=\"${localHost}\",Type=\"${be}\"}"

         echo "backend_ln_miss_ratio${tags} ${lnratio}"
         echo "backend_bin_miss_ratio${tags} ${binratio}"
         echo "backend_uin_miss_ratio${tags} ${uinratio}"

         echo ${object}|sed -e "s/^.*EnvironmentNCheckpoints: //g" -e "s/|.*//g" -e "s/^/backend_checkpoints${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentFSyncTime: //g" -e "s/|.*//g" -e "s/^/backend_fsynctime${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentFSyncMaxTime: //g" -e "s/|.*//g" -e "s/^/backend_max_fsynctime${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentNWaiters: //g" -e "s/|.*//g" -e "s/^/backend_num_waiters${tags} /g"
         echo ${object}|sed -e "s/^.*TransactionNAborts: //g" -e "s/|.*//g" -e "s/^/backend_txn_aborts${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentDataBytes: //g" -e "s/|.*//g" -e "s/^/backend_data_bytes${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentCacheTotalBytes: //g" -e "s/|.*//g" -e "s/^/backend_cached_bytes${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentLastCheckpointInterval: //g" -e "s/|.*//g" -e "s/^/backend_checkpoint_interval${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentCleanerBacklog: //g" -e "s/|.*//g" -e "s/^/backend_cleaner_backlog${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentNTotalLocks: //g" -e "s/|.*//g" -e "s/^/backend_num_locks${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentNWriteLocks: //g" -e "s/|.*//g" -e "s/^/backend_write_locks${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentNReadLocks: //g" -e "s/|.*//g" -e "s/^/backend_read_locks${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentNOpenFiles: //g" -e "s/|.*//g" -e "s/^/backend_open_files${tags} /g"
         echo ${object}|sed -e "s/^.*EnvironmentNWaits: //g" -e "s/|.*//g" -e "s/^/backend_waits${tags} /g"
         value_bytes=$(echo ${object}|sed -e "s/^.*EnvironmentTotalLogSize: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "backend_log_size${tags} ${value_mb}"
         echo ${object}|sed -e "s/^.*EnvironmentLastKnownUtilization: //g" -e "s/|.*//g" -e "s/^/backend_utilization${tags} /g"

         # Place holder to do ram to db size ratio

      # Connection Handler
      elif [[ "${object}" == *Connection\ Handler* ]] || [[ "${object}" == *Administration\ Connector* ]]
      then
         if [[ "${object}" == *Statistics* ]]
         then
            # Summarize connection handler metrics
            abandon_metric=$(echo ${object}|sed -e "s/^.*ds-mon-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/ //g"|grep -v Statistics)
            add_metric=$(echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)
            bind_metric=$(echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)
            compare_metric=$(echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)
            delete_metric=$(echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)
            extended_metric=$(echo ${object}|sed -e "s/^.*ds-mon-extended-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)
            mod_metric=$(echo ${object}|sed -e "s/^.*ds-mon-mod-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)
            moddn_metric=$(echo ${object}|sed -e "s/^.*ds-mon-moddn-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)
            search_metric=$(echo ${object}|sed -e "s/^.*ds-mon-search-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)
            unbind_metric=$(echo ${object}|sed -e "s/^.*ds-mon-unbind-operations-total-count: //g" -e "s/|.*//g"|grep -v Statistics)

            if [ -n "${abandon_metric}" ]
            then
               abandon_sum=$((${abandon_sum}+${abandon_metric}))
               add_sum=$((${add_sum}+${add_metric}))
               bind_sum=$((${bind_sum}+${bind_metric}))
               compare_sum=$((${compare_sum}+${compare_metric}))
               delete_sum=$((${delete_sum}+${delete_metric}))
               extended_sum=$((${extended_sum}+${extended_metric}))
               mod_sum=$((${mod_sum}+${mod_metric}))
               moddn_sum=$((${moddn_sum}+${moddn_metric}))
               search_sum=$((${search_sum}+${search_metric}))
               unbind_sum=$((${unbind_sum}+${unbind_metric}))

               if [ "${abandon_sum}"  -lt 0  ];then abandon_sum=0;fi
               if [ "${add_sum}"      -lt 0  ];then add_sum=0;fi
               if [ "${bind_sum}"     -lt 0  ];then bind_sum=0;fi
               if [ "${compare_sum}"  -lt 0  ];then compare_sum=0;fi
               if [ "${delete_sum}"   -lt 0  ];then delete_sum=0;fi
               if [ "${extended_sum}" -lt 0  ];then extended_sum=0;fi
               if [ "${mod_sum}"      -lt 0  ];then mod_sum=0;fi
               if [ "${moddn_sum}"    -lt 0  ];then moddn_sum=0;fi
               if [ "${search_sum}"   -lt 0  ];then search_sum=0;fi
               if [ "${unbind_sum}"   -lt 0  ];then unbind_sum=0;fi

               abandon_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-abandon-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               add_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-add-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               bind_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-bind-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               compare_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-compare-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               delete_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-delete-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               extended_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-extended-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               mod_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-mod-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               moddn_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-moddn-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               search_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-search-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)
               unbind_rt_metric=$(echo ${object}|sed -e "s/^.*ds-mon-resident-time-unbind-operations-total-time: //g" -e "s/|.*//g"|grep -v Statistics)

               if [ -z "${abandon_rt_metric}"   ];then abandon_rt_metric=0;fi
               if [ -z "${add_rt_metric}"       ];then add_rt_metric=0;fi
               if [ -z "${bind_rt_metric}"      ];then bind_rt_metric=0;fi
               if [ -z "${compare_rt_metric}"   ];then compare_rt_metric=0;fi
               if [ -z "${delete_rt_metric}"    ];then delete_rt_metric=0;fi
               if [ -z "${extended_rt_metric}"  ];then extended_rt_metric=0;fi
               if [ -z "${mod_rt_metric}"       ];then mod_rt_metric=0;fi
               if [ -z "${moddn_rt_metric}"     ];then moddn_rt_metric=0;fi
               if [ -z "${search_rt_metric}"    ];then search_rt_metric=0;fi
               if [ -z "${unbind_rt_metric}"    ];then unbind_rt_metric=0;fi

               if [ "${abandon_rt_metric}"  -lt 0  ];then abandon_rt_metric=0;fi
               if [ "${add_rt_metric}"      -lt 0  ];then add_rt_metric=0;fi
               if [ "${bind_rt_metric}"     -lt 0  ];then bind_rt_metric=0;fi
               if [ "${compare_rt_metric}"  -lt 0  ];then compare_rt_metric=0;fi
               if [ "${delete_rt_metric}"   -lt 0  ];then delete_rt_metric=0;fi
               if [ "${extended_rt_metric}" -lt 0  ];then extended_rt_metric=0;fi
               if [ "${mod_rt_metric}"      -lt 0  ];then mod_rt_metric=0;fi
               if [ "${moddn_rt_metric}"    -lt 0  ];then moddn_rt_metric=0;fi
               if [ "${search_rt_metric}"   -lt 0  ];then search_rt_metric=0;fi
               if [ "${unbind_rt_metric}"   -lt 0  ];then unbind_rt_metric=0;fi

               abandon_rt_sum=$((${abandon_rt_sum}+${abandon_rt_metric}))
               add_rt_sum=$((${add_rt_sum}+${add_rt_metric}))
               bind_rt_sum=$((${bind_rt_sum}+${bind_rt_metric}))
               compare_rt_sum=$((${compare_rt_sum}+${compare_rt_metric}))
               delete_rt_sum=$((${delete_rt_sum}+${delete_rt_metric}))
               extended_rt_sum=$((${extended_rt_sum}+${extended_rt_metric}))
               mod_rt_sum=$((${mod_rt_sum}+${mod_rt_metric}))
               moddn_rt_sum=$((${moddn_rt_sum}+${moddn_rt_metric}))
               search_rt_sum=$((${search_rt_sum}+${search_rt_metric}))
               unbind_rt_sum=$((${unbind_rt_sum}+${unbind_rt_metric}))

               let ch_cnt++

            fi

            # Deal with negative tabulation values
            if [ "${abandon_sum}"  -lt 0  ];then abandon_sum=0;fi
            if [ "${add_sum}"      -lt 0  ];then add_sum=0;fi
            if [ "${bind_sum}"     -lt 0  ];then bind_sum=0;fi
            if [ "${compare_sum}"  -lt 0  ];then compare_sum=0;fi
            if [ "${delete_sum}"   -lt 0  ];then delete_sum=0;fi
            if [ "${extended_sum}" -lt 0  ];then extended_sum=0;fi
            if [ "${mod_sum}"      -lt 0  ];then mod_sum=0;fi
            if [ "${moddn_sum}"    -lt 0  ];then moddn_sum=0;fi
            if [ "${search_sum}"   -lt 0  ];then search_sum=0;fi
            if [ "${unbind_sum}"   -lt 0  ];then unbind_sum=0;fi

            if [[ "${object}" == *LDAP\ Connection\ Handler* ]] && [[ "${object}" == *389\ Statistics* ]]
            then
               ch_proto='ldap'
               tags="{hostname=\"${localHost}\",Type=\"${ch_proto}\"}"

               echo ${object}|sed -e "s/^.*operationsInitiated: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_initiated${tags} /g"
               echo ${object}|sed -e "s/^.*operationsCompleted: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_completed${tags} /g"
               echo ${object}|sed -e "s/^.*operationsUnsuccessful: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_unsuccessful${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-unbind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-mod-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-moddn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-failed-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-user-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_user_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-pwd-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_pwd_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-other-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_other_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-no-such-entry-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_no_such_entry_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-authentication-denied-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_authentication_denied_search_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-resident-time-bind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-unbind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-search-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-compare-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-add-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-mod-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-moddn-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-delete-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-extended-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-abandon-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_rt${tags} /g"

            elif [[ "${object}" == *LDAP\ Connection\ Handler* ]] && [[ "${object}" == *636\ Statistics* ]]
            then
               ch_proto='ldaps'
               tags="{hostname=\"${localHost}\",Type=\"${ch_proto}\"}"

               echo ${object}|sed -e "s/^.*operationsInitiated: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_initiated${tags} /g"
               echo ${object}|sed -e "s/^.*operationsCompleted: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_completed${tags} /g"
               echo ${object}|sed -e "s/^.*operationsUnsuccessful: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_unsuccessful${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-unbind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-mod-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-moddn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-failed-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-user-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_user_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-pwd-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_pwd_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-other-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_other_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-no-such-entry-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_no_such_entry_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-authentication-denied-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_authentication_denied_search_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-resident-time-bind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-unbind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-search-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-compare-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-add-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-mod-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-moddn-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-delete-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-extended-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-abandon-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_rt${tags} /g"

            elif [[ "${object}" == *HTTP\ Connection\ Handler* ]] && [[ "${object}" == *Statistics* ]]
            then
               ch_proto='http'
               tags="{hostname=\"${localHost}\",Type=\"${ch_proto}\"}"

               echo ${object}|sed -e "s/^.*operationsInitiated: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_initiated${tags} /g"
               echo ${object}|sed -e "s/^.*httpOperationsInitiated: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_operations_initiated${tags} /g"
               echo ${object}|sed -e "s/^.*operationsCompleted: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_completed${tags} /g"
               echo ${object}|sed -e "s/^.*operationsUnsuccessful: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_unsuccessful${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-unbind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-mod-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-moddn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-http-get-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_get_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-post-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_post_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-put-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_put_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-patch-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_patch_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-delete-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_delete_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-head-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_head_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-trace-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_trace_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-option-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_option_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-failed-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-user-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_user_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-pwd-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_pwd_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-other-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_other_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-no-such-entry-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_no_such_entry_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-authentication-denied-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_authentication_denied_search_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-resident-time-bind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-unbind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-search-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-compare-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-add-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-mod-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-moddn-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-delete-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-extended-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-abandon-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_rt${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-resident-time-post-option-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_post_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-put-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_put_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-patch-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_patch_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-head-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_head_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-delete-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-trace-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_trace_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-option-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_option_rt${tags} /g"
            elif [[ "${object}" == *LDAP\ Administration\ Connector* ]]
            then
               ch_proto='adminl'
               tags="{hostname=\"${localHost}\",Type=\"${ch_proto}\"}"

               echo ${object}|sed -e "s/^.*operationsInitiated: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_initiated${tags} /g"
               echo ${object}|sed -e "s/^.*operationsCompleted: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_completed${tags} /g"
               echo ${object}|sed -e "s/^.*operationsUnsuccessful: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_unsuccessful${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-unbind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-mod-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-moddn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-failed-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-user-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_user_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-pwd-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_pwd_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-other-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_other_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-no-such-entry-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_no_such_entry_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-authentication-denied-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_authentication_denied_search_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-resident-time-bind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-unbind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-search-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-compare-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-add-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-mod-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-moddn-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-delete-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-extended-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-abandon-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_rt${tags} /g"

            elif [[ "${object}" == *HTTP\ Administration\ Connector* ]]
            then
               ch_proto='adminh'
               tags="{hostname=\"${localHost}\",Type=\"${ch_proto}\"}"

               echo ${object}|sed -e "s/^.*operationsInitiated: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_initiated${tags} /g"
               echo ${object}|sed -e "s/^.*httpOperationsInitiated: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_operations_initiated${tags} /g"
               echo ${object}|sed -e "s/^.*operationsCompleted: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_completed${tags} /g"
               echo ${object}|sed -e "s/^.*operationsUnsuccessful: //g" -e "s/|.*//g" -e "s/^/connection_handler_operations_unsuccessful${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-unbind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-mod-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-moddn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-http-get-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_get_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-post-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_post_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-put-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_put_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-patch-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_patch_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-delete-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_delete_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-head-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_head_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-trace-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_trace_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-http-option-methods-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_http_option_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-failed-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-user-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_user_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-wrong-pwd-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_wrong_pwd_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-other-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_other_bind_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-no-such-entry-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_no_such_entry_ops${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-authentication-denied-search-operations-total-count: //g" -e "s/|.*//g" -e "s/^/connection_handler_failed_authentication_denied_search_ops${tags} /g"

               echo ${object}|sed -e "s/^.*ds-mon-resident-time-bind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_bind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-unbind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_unbind_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-search-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_search_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-compare-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_compare_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-add-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_add_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-mod-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_mod_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-moddn-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_moddn_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-delete-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-extended-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_extended_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-abandon-operations-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_abandon_rt${tags} /g"

               # Missing: ds-mon-resident-time-http-get-methods-total-time: 0
               # Missing: ds-mon-resident-time-http-post-methods-total-time: 0

               echo ${object}|sed -e "s/^.*ds-mon-resident-time-post-option-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_post_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-put-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_put_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-patch-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_patch_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-head-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_head_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-delete-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_delete_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-trace-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_trace_rt${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-resident-time-http-option-methods-total-time: //g" -e "s/|.*//g" -e "s/^/connection_handler_option_rt${tags} /g"
            fi
         fi
      # Group Entry Caches
      elif [[ "${object}" == *entryCacheHitsWithGroupMembers* ]]
      then
         prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/ Entry Cache//g" -e "s/ Cache//g" -e "s/ /_/g")
         tags="{hostname=\"${localHost}\",Category=\"${prefix}\"}"

         echo ${object}|sed -e "s/^.*entryCacheTries: //g" -e "s/|.*//g" -e "s/^/entry_cache_tries${tags} /g"
         echo ${object}|sed -e "s/^.*currentEntryCacheCount: //g" -e "s/|.*//g" -e "s/^/entry_cache_current_count${tags} /g"
         echo ${object}|sed -e "s/^.*entryCacheHitsWithGroupMembers: //g" -e "s/|.*//g" -e "s/^/entry_cache_member_hits${tags} /g"
         echo ${object}|sed -e "s/^.*maxEntryCacheCount: //g" -e "s/|.*//g" -e "s/^/entry_cache_max_count${tags} /g"
         echo ${object}|sed -e "s/^.*entryCacheHits: //g" -e "s/|.*//g" -e "s/^/entry_cache_hits${tags} /g"
         echo ${object}|sed -e "s/^.*entryCacheHitRatio: //g" -e "s/|.*//g" -e "s/^/entry_cache_ratio${tags} /g"
         value_bytes=$(echo ${object}|sed -e "s/^.*maxEntryCacheSize: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "entry_cache_max_size${tags} ${value_mb}"
         echo ${object}|sed -e "s/^.*entryCacheTriesWithGroupMembers: //g" -e "s/|.*//g" -e "s/^/entry_cache_member_tries${tags} /g"
         value_bytes=$(echo ${object}|sed -e "s/^.*currentEntryCacheSize: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "entry_cache_current_size${tags} ${value_mb}"

      # User/FIFO Entry Caches
      elif [[ "${object}" == *currentEntryCacheSize* ]]
      then
         prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/ Entry Cache//g" -e "s/ Cache//g" -e "s/ /_/g")
         tags="{hostname=\"${localHost}\",Category=\"${prefix}\"}"

         echo ${object}|sed -e "s/^.*entryCacheTries: //g" -e "s/|.*//g" -e "s/^/entry_cache_tries${tags} /g"
         echo ${object}|sed -e "s/^.*currentEntryCacheCount: //g" -e "s/|.*//g" -e "s/^/entry_cache_current_count${tags} /g"
         echo ${object}|sed -e "s/^.*maxEntryCacheCount: //g" -e "s/|.*//g" -e "s/^/entry_cache_max_count${tags} /g"
         echo ${object}|sed -e "s/^.*entryCacheHits: //g" -e "s/|.*//g" -e "s/^/entry_cache_hits${tags} /g"
         echo ${object}|sed -e "s/^.*entryCacheHitRatio: //g" -e "s/|.*//g" -e "s/^/entry_cache_ratio${tags} /g"
         value_bytes=$(echo ${object}|sed -e "s/^.*maxEntryCacheSize: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "entry_cache_max_size${tags} ${value_mb}"
         value_bytes=$(echo ${object}|sed -e "s/^.*currentEntryCacheSize: //g" -e "s/|.*//g")
         value_mb=$(echo ${value_bytes} ${byte_to_mb}|awk '{ printf "%.2f", $1*$2 }' 2> /dev/null)
         echo "entry_cache_current_size${tags} ${value_mb}"

      # Work Queue
      elif [[ "${object}" == *maxRequestBacklog* ]]
      then
         prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/Work Queue//g" -e "s/ //g")
         tags="{hostname=\"${localHost}\",Category=\"${prefix}\"}"

         echo ${object}|sed -e "s/^.*currentRequestBacklog: //g" -e "s/|.*//g" -e "s/^/work_queue_current_backlog${tags} /g"
         echo ${object}|sed -e "s/^.*averageRequestBacklog: //g" -e "s/|.*//g" -e "s/^/work_queue_average_backlog${tags} /g"
         echo ${object}|sed -e "s/^.*requestsRejectedDueToQueueFull: //g" -e "s/|.*//g" -e "s/^/work_queue_queue_full_rejects${tags} /g"
         echo ${object}|sed -e "s/^.*maxRequestBacklog: //g" -e "s/|.*//g" -e "s/^/work_queue_max_backlog${tags} /g"

      # Network Groups
      elif [[ "${object}" == *ds-mon-failed-referrals-total-count* ]] && [[ "${object}" == *Network\ Group* ]]
      then
         searchone_metric=$(echo ${object}|sed -e "s/^.*ds-mon-searchonelevel-operations-total-count: //g" -e "s/|.*//g")
         searchsub_metric=$(echo ${object}|sed -e "s/^.*ds-mon-searchsubtree-operations-total-count: //g" -e "s/|.*//g")

         searchone_sum=$((${searchone_sum}+${searchone_metric}))
         searchsub_sum=$((${searchsub_sum}+${searchsub_metric}))

      # Replication Domain
      elif [[ "${object}" == *Replication\ Domain* ]] && [[ "${object}" != *cn=schema* ]] && [[ "${object}" != *cn=admin\ data* ]]
      then
         true

      # Replication Server
      elif [[ "${object}" == *replication-server-id* ]]
      then
         prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/,cn=replication//g" -e "s/^.*,cn=//g" -e "s/=/_/g" -e "s/ /_/g")
         tags="{hostname=\"${localHost}\",Type=\"${prefix}\"}"

         echo ${object}|sed -e "s/^.*missing-changes: //g" -e "s/|.*//g" -e "s/^/replication_server_missing_changes${tags} /g"

      # Tombstone Purger
      elif [[ "${object}" == *deltaTombstones* ]] && [[ "${object}" != *virtual\ acis* ]]
      then
         #cn=cn_OracleContext_dc_example_dc_com Tombstone Purger,cn=monitor
         prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/^.*cn=cn_//g" -e "s/Tombstone Purger.*//g" -e "s/=/_/g" -e "s/ /_/g")
         tags="{hostname=\"${localHost}\",Category=\"${prefix}\"}"

         echo ${object}|sed -e "s/^.*purgedTombstones: //g" -e "s/|.*//g" -e "s/^/oud_ts_purged_tombstones${tags} /g"
         echo ${object}|sed -e "s/^.*createdTombstones: //g" -e "s/|.*//g" -e "s/^/oud_ts_created_tombstones${tags} /g"
         echo ${object}|sed -e "s/^.*deltaTombstones: //g" -e "s/|.*//g" -e "s/^/oud_ts_delta_tombstones${tags} /g"

      # LDAP Extension (JDBC)
      elif [[ "${object}" == *ds-jdbc-connections-total-count* ]] && [[ "${object}" == *,cn=JDBC\ Servers* ]]
      then
         true

      # LDAP Extension (Proxy)
      elif [[ "${object}" == *ds-mon-secured-write-connections-total-count* ]] && [[ "${object}" == *,cn=LDAP\ Servers* ]]
      then
         #if [ "${category}" == 'xtn' ] || [ "${category}" == 'all' ]
         #then
            prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/,cn=LDAP Servers.*//g" -e "s/_/=/g" -e "s/ /_/g" -e "s/-/_/g")
            tags="{hostname=\"${localHost}\",Type=\"${prefix}\"}"

            echo ${object}|sed -e "s/^.*ds-mon-secured-write-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_write_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-modifydn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_modifydn_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-modifydn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_modifydn_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-cached-client-bound-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_cached_client_bound_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-psearch-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_psearch_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-delete-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_delete_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_searchsubtree_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_add_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_abandon_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-used-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_used_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-extended-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_extended_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-bind-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_bind_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-write-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_write_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_extended_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_add_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-modify-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_modify_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_extended_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-read-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_read_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-add-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_add_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-modify-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_modify_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-searchonelevel-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_searchonelevel_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_searchsubtree_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_bind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchsubtree-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchsubtree_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-read-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_read_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_searchsubtree_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchsubtree-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchsubtree_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_compare_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-add-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_add_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchonelevel-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchonelevel_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-read-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_read_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-bind-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_bind_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-modify-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_modify_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-compare-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_compare_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_add_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-used-secured-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_used_secured_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-modify-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_modify_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchonelevel-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchonelevel_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-bind-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_bind_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-free-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_free_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-psearch-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_psearch_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-delete-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_delete_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-searchbase-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_searchbase_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-free-secured-retries-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_free_secured_retries_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-cached-proxy-bound-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_cached_proxy_bound_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-client-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_client_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-modifydn-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_modifydn_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchonelevel-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchonelevel_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-compare-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_compare_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-silent-bind-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_silent_bind_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-read-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_read_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-compare-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_compare_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-searchbase-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_searchbase_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-write-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_write_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-bind-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_bind_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-delete-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_delete_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_bind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchsubtree-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchsubtree_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-invalid-secured-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_invalid_secured_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-bind-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_bind_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-modifydn-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_modifydn_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-modifydn-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_modifydn_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-modifydn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_modifydn_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-write-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_write_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-bind-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_bind_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-write-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_write_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-last-down-date: //g" -e "s/|.*//g" -e "s/^/extension_ldap_last_down_date${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_compare_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-client-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_client_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-free-rejected-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_free_rejected_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-read-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_read_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-searchbase-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_searchbase_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_aborted_delete_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-cached-client-bound-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_cached_client_bound_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-free-secured-rejected-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_free_secured_rejected_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-secured-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_secured_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-searchonelevel-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_searchonelevel_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-free-retries-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_free_retries_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-bind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_bind_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-write-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_write_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-add-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_add_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-bind-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_bind_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_bind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-modify-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_modify_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchbase-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchbase_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-searchonelevel-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_searchonelevel_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-modify-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_modify_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-silent-bind-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_silent_bind_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchbase-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchbase_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-cached-proxy-bound-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_cached_proxy_bound_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-read-connections-max-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_read_connections_max_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_extended_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-modifydn-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_modifydn_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-connection-pool-full-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_connection_pool_full_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-searchbase-operations-total-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_searchbase_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-free-secured-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_free_secured_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_delete_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-extended-operations-min-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_extended_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-bind-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_bind_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-invalid-connections-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_invalid_connections_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-responsetime-extended-operations-max-time: //g" -e "s/|.*//g" -e "s/^/extension_ldap_responsetime_extended_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-connection-pool-full-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_connection_pool_full_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-secured-connections-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_secured_connections_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/extension_ldap_failed_delete_operations_total_count${tags} /g"
         #fi

      # LB WFE (Proxy)
      elif [[ "${object}" == *ds-mon-failed-searchbase-operations-total-count* ]] && [[ "${object}" == *cn=load\ balancing* ]]
      then
         #if [ "${category}" == 'wfe' ] || [ "${category}" == 'all' ]
         #then
            prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/,cn=load balancing//g" -e "s/_/=/g" -e "s/ /_/g" -e "s/-/_/g")
            tags="{hostname=\"${localHost}\",Type=\"${prefix}\"}"

            if [ "${includeStrings}" == 'true' ]
            then
               echo ${object}|sed -e "s/^.*ds-mon-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_ds_mon_searchsubtree_operations_total_count${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-followed-referrals-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_ds_mon_followed_referrals_total_count${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-persistent-searchs-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_ds_mon_persistent_searchs_count${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-violations-schema-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_ds_mon_violations_schema_total_count${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-failed-referrals-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_ds_mon_failed_referrals_total_count${tags} /g"
               echo ${object}|sed -e "s/^.*ds-mon-discarded-referrals-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_ds_mon_discarded_referrals_total_count${tags} /g"
            fi
            echo ${object}|sed -e "s/^.*ds-mon-failed-searchbase-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_searchbase_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-modifydn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_modifydn_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-unbind-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_unbind_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-modifydn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_modifydn_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-searchsubtree-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_searchsubtree_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_searchsubtree_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_searchsubtree_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_add_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_abandon_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_bind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-bind-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_bind_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-add-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_add_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-unbind-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_unbind_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_extended_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_add_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-modifydn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_modifydn_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-modify-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_modify_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_extended_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_compare_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-searchbase-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_searchbase_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-extended-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_extended_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-searchonelevel-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_searchonelevel_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-modifydn-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_modifydn_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_delete_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-modify-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_modify_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-modify-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_modify_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-unbind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_unbind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-searchonelevel-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_searchonelevel_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_searchsubtree_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-abandon-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_abandon_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-abandon-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_abandon_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-searchonelevel-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_searchonelevel_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-searchonelevel-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_searchonelevel_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_bind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-modify-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_modify_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_searchsubtree_operations_total_count:${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-modifydn-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_modifydn_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_bind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_compare_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-searchonelevel-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_searchonelevel_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_compare_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-searchsubtree-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_searchsubtree_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-compare-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_compare_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-extended-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_extended_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-searchonelevel-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_searchonelevel_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-searchsubtree-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_searchsubtree_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-extended-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_extended_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-searchbase-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_searchbase_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-unbind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_unbind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-add-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_add_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_add_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-modify-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_modify_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-delete-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_delete_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-unbind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_unbind_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-delete-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_delete_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-modify-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_modify_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_delete_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-unbind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_unbind_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-modifydn-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_modifydn_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-searchbase-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_searchbase_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-bind-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_bind_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_abandon_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-aborted-abandon-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_aborted_abandon_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-extended-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_extended_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-compare-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_compare_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-bind-operations-max-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_bind_operations_max_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-searchbase-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_searchbase_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-abandon-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_abandon_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-delete-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_delete_operations_min_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-failed-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/wfe_lb_failed_delete_operations_total_count${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-compare-operations-total-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_compare_operations_total_time${tags} /g"
            echo ${object}|sed -e "s/^.*ds-mon-residenttime-add-operations-min-time: //g" -e "s/|.*//g" -e "s/^/wfe_lb_residenttime_add_operations_min_time${tags} /g"
         #fi

      # LDAP WFE (Proxy)
      elif [[ "${object}" == *ds-mon-saturation-index* ]] && [[ "${object}" == *,cn=Workflow\ Elements* ]]
      then
         #if [ "${category}" == 'wfe' ] || [ "${category}" == 'all' ]
         #then
            prefix=$(echo ${object}|cut -d'|' -f1|sed -e "s/,cn=Workflow Elements//g" -e "s/_/=/g" -e "s/ /_/g" -e "s/-/_/g")
            tags="{hostname=\"${localHost}\",Type=\"${prefix}\"}"

            echo ${object}|sed -e "s/^.*ds-mon-saturation-index: //g" -e "s/|.*//g" -e "s/^/wfe_ldap_saturation${tags} /g"
         #fi

      # LB Algorithm WFE (Proxy)
      elif [[ "${object}" == *ds-mon-residenttime-max-time* ]] && [[ "${object}" == *,cn=load\ balancing* ]]
      then
         #if [ "${category}" == 'wfe' ] || [ "${category}" == 'all' ]
         #then
            prefix=$(echo ${object}|cut -d',' -f2|sed -e "s/cn=//g" -e "s/ /_/g")
            tags="{hostname=\"${localHost}\",Type=\"${prefix}\"}"

            # echo ${object}|sed -e "s/^.*ds-mon-residenttime-max-time: //g" -e "s/|.*//g" -e "s/^/oud_lb_algorithm_residenttime_max_time${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-residenttime-min-time: //g" -e "s/|.*//g" -e "s/^/oud_lb_algorithm_residenttime_min_time${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-runs-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_algorithm_runs_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-residenttime-total-time: //g" -e "s/|.*//g" -e "s/^/oud_lb_algorithm_residenttime_total_time${tags} /g"
         #fi

      # LB Route WFE (Proxy)
      elif [[ "${object}" == *ds-mon-searchonelevel-operations-total-count* ]] && [[ "${object}" == *cn=routes,cn=algorithm* ]]
      then
         #if [ "${category}" == 'wfe' ] || [ "${category}" == 'all' ]
         #then
            prefix1=$(echo ${object}|cut -d',' -f1|sed -e "s/ /_/g")
            prefix2=$(echo ${object}|cut -d',' -f4|sed -e "s/cn=//g" -e "s/ /_/g")
            tags="{hostname=\"${localHost}\",Type=\"${prefix1}-${prefix2}\"}"
            # echo ${object}|sed -e "s/^.*ds-mon-searchonelevel-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_searchonelevel_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-searchbase-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_searchbase_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-compare-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_compare_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-modifydn-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_modifydn_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_bind_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-bind-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_bind_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-delete-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_delete_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-modify-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_modify_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-add-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_add_operations_total_count${tags} /g"
            # echo ${object}|sed -e "s/^.*ds-mon-searchsubtree-operations-total-count: //g" -e "s/|.*//g" -e "s/^/oud_lb_route_ds_mon_searchsubtree_operations_total_count${tags} /g"
         #fi
      else
         true
         #echo UNDONE - ${object}
      fi
   done
   tags="{hostname=\"${localHost}\",Type=\"Total\"}"

   # Display connection handler aggregations
   echo "connection_handler_abandon_ops${tags} ${abandon_sum}"
   echo "connection_handler_add_ops${tags} ${add_sum}"
   echo "connection_handler_bind_ops${tags} ${bind_sum}"
   echo "connection_handler_compare_ops${tags} ${compare_sum}"
   echo "connection_handler_delete_ops${tags} ${delete_sum}"
   echo "connection_handler_extended_ops${tags} ${extended_sum}"
   echo "connection_handler_mod_ops${tags} ${mod_sum}"
   echo "connection_handler_moddn_ops${tags} ${moddn_sum}"
   echo "connection_handler_search_ops${tags} ${search_sum}"
   echo "connection_handler_unbind_ops${tags} ${unbind_sum}"

   echo "connection_handler_searchone_ops${tags} ${searchone_sum}"
   echo "connection_handler_searchsub_ops${tags} ${searchsub_sum}"

   abandon_rt_avg=$(echo ${abandon_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   add_rt_avg=$(echo ${add_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   bind_rt_avg=$(echo ${bind_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   compare_rt_avg=$(echo ${compare_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   delete_rt_avg=$(echo ${delete_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   extended_rt_avg=$(echo ${extended_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   mod_rt_avg=$(echo ${mod_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   moddn_rt_avg=$(echo ${moddn_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   search_rt_avg=$(echo ${search_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   unbind_rt_avg=$(echo ${unbind_rt_sum} ${ch_cnt}|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)

   if [ -z "${abandon_rt_avg}"   ];then abandon_rt_avg=0;fi
   if [ -z "${add_rt_avg}"       ];then add_rt_avg=0;fi
   if [ -z "${bind_rt_avg}"      ];then bind_rt_avg=0;fi
   if [ -z "${compare_rt_avg}"   ];then compare_rt_avg=0;fi
   if [ -z "${delete_rt_avg}"    ];then delete_rt_avg=0;fi
   if [ -z "${extended_rt_avg}"  ];then extended_rt_avg=0;fi
   if [ -z "${mod_rt_avg}"       ];then mod_rt_avg=0;fi
   if [ -z "${moddn_rt_avg}"     ];then moddn_rt_avg=0;fi
   if [ -z "${search_rt_avg}"    ];then search_rt_avg=0;fi
   if [ -z "${unbind_rt_avg}"    ];then unbind_rt_avg=0;fi

   if [ "${abandon_rt_avg}"  -lt 0  ];then abandon_rt_avg=0;fi
   if [ "${add_rt_avg}"      -lt 0  ];then add_rt_avg=0;fi
   if [ "${bind_rt_avg}"     -lt 0  ];then bind_rt_avg=0;fi
   if [ "${compare_rt_avg}"  -lt 0  ];then compare_rt_avg=0;fi
   if [ "${delete_rt_avg}"   -lt 0  ];then delete_rt_avg=0;fi
   if [ "${extended_rt_avg}" -lt 0  ];then extended_rt_avg=0;fi
   if [ "${mod_rt_avg}"      -lt 0  ];then mod_rt_avg=0;fi
   if [ "${moddn_rt_avg}"    -lt 0  ];then moddn_rt_avg=0;fi
   if [ "${search_rt_avg}"   -lt 0  ];then search_rt_avg=0;fi
   if [ "${unbind_rt_avg}"   -lt 0  ];then unbind_rt_avg=0;fi

   tags="{hostname=\"${localHost}\",Type=\"Average\"}"

   echo "connection_handler_abandon_rt${tags} ${abandon_rt_avg}"
   echo "connection_handler_add_rt${tags} ${add_rt_avg}"
   echo "connection_handler_bind_rt${tags} ${bind_rt_avg}"
   echo "connection_handler_compare_rt${tags} ${compare_rt_avg}"
   echo "connection_handler_delete_rt${tags} ${delete_rt_avg}"
   echo "connection_handler_extended_rt${tags} ${extended_rt_avg}"
   echo "connection_handler_mod_rt${tags} ${mod_rt_avg}"
   echo "connection_handler_moddn_rt${tags} ${moddn_rt_avg}"
   echo "connection_handler_search_rt${tags} ${search_rt_avg}"
   echo "connection_handler_unbind_rt${tags} ${unbind_rt_avg}"

   # APPMGMT-8064
   tmp_sum=$(($add_rt_avg+$delete_rt_avg+$moddn_rt_avg+$mod_rt_avg))
   write_op_avg_elapsed_time_per_op=$(echo ${tmp_sum} 4|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   echo "connection_handler_elapsed_time_per_op_wrt_avg${tags} $write_op_avg_elapsed_time_per_op"

   aggr_op_avg_elapsed_time_per_op=$(($abandon_rt_avg+$add_rt_avg+$bind_rt_avg+$compare_rt_avg+$delete_rt_avg+$extended_rt_avg+$mod_rt_avg+$moddn_rt_avg+$search_rt_avg+$unbind_rt_avg))
   all_aggr_op_avg=$(echo ${aggr_op_avg_elapsed_time_per_op} 10|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   if [ -z "${all_aggr_op_avg}"    ];then all_aggr_op_avg=0;fi
   echo "connection_handler_elapsed_time_per_op_agg_avg${tags} ${all_aggr_op_avg}"


   tags="{hostname=\"${localHost}\"}"

   all_sum=$((${abandon_sum}+${add_sum}+${bind_sum}+${compare_sum}+${delete_sum}+${extended_sum}+${mod_sum}+${moddn_sum}+${search_sum}+${unbind_sum}))
   echo "connection_handler_all_ops${tags} ${all_sum}"

   all_rt=$((${abandon_rt_avg}+${add_rt_avg}+${bind_rt_avg}+${compare_rt_avg}+${delete_rt_avg}+${extended_rt_avg}+${mod_rt_avg}+${moddn_rt_avg}+${search_rt_avg}+${unbind_rt_avg}))
   all_rt_avg=$(echo ${all_rt} 10|awk '{ printf "%.0f", $1/$2 }' 2> /dev/null)
   if [ -z "${all_rt_avg}"    ];then all_rt_avg=0;fi
   echo "connection_handler_all_rt${tags} ${all_rt_avg}"

   psPid=$(ps -ef|grep config.ldif|grep "\/${instName}\/"|grep start-ds|awk '{ print $2 }')
   if [ -n "${psPid}" ]
   then
      psSize=$(ps -h -o size -p ${psPid}|awk '{ printf "%.0f", $1*1000 }')
      #psSize=$((${psSize}*1000))
      echo "os_psSize${tags} ${psSize}"
   fi

   query_os
}

###############################################################################
# Start exporter for Prometheus
###############################################################################
monitor_target() {
   # Update exporter with metric data
   if [ -d "${metricsDir}" ]
   then
      let steps++
      echo "Step ${steps} - Start ${resName} monitor service"
      getPyCmd
      if [ "${dbg}" == 'true' ];then set -x;fi
      cd "${metricsDir}"
      while true
      do
         if [ "${pycmd}" == 'python3' ]
         then
            cTime1=$(${pycmd} -c 'import datetime;print(int((datetime.datetime.now() - datetime.datetime(1970,1,1)).total_seconds()))')
         else
            cTime1=$(${pycmd} -c 'import time;print int(time.time())')
         fi
         case ${targetType} in
             'oud'|'proxy'|'replgw') ${curdir}/${cmd} query --name ${resName} --type ${targetType} > .index
                    if [ -n "$(egrep "oud_base_status|oud_ts_purged_tombstones|LDAP_Connection_Handler" .index 2> /dev/null)" ]
                    then
                       cat .index | sort -u > index.html
                       for p in oud_base backend connection_handler entry_cache jvm os replication_domain replication_server work_queue extension wfe
                       do
                          grep "^${p}" index.html > ${p}.prom
                       done
                       rm -f .index
                    fi
                    ;;
            'dsee') queryDSEE > .index
                    if [ -n "$(egrep "oud_base_status|oud_ts_purged_tombstones|LDAP_Connection_Handler" .index 2> /dev/null)" ]
                    then
                       cat .index | sort -u > index.html
                       cp index.html index.prom
                       rm -f .index
                    fi
                   ;;
             'oam'|'oim'|'wl') ${curdir}/${cmd} query --name ${resName} --type ${targetType} > .index
                    if [ -n "$(grep oam_total_ops .index 2> /dev/null)" ]
                    then
                       cat .index | sort -u > index.html
                       cp index.html index.prom
                       rm -f .index
                    fi
                    ;;
         esac
         if [ "${pycmd}" == 'python3' ]
         then
            cTime2=$(${pycmd} -c 'import datetime;print(int((datetime.datetime.now() - datetime.datetime(1970,1,1)).total_seconds()))')
         else
            cTime2=$(${pycmd} -c 'import time;print int(time.time())')
         fi
         delta=$((${interval} - (${cTime2} - ${cTime1})))

         if [ -z "${delta}" ];then delta=1;fi
         if [ ${delta} -lt 0 ];then delta=0;fi
         if [ "${dbg}" == 'true' ]
         then
            echo "Sample interval: ${interval}; Delta from sample: ${delta}" >> ${logdir}/emitter_${resName}-${today}.log
         fi
         sleep ${delta}
      done
   else
      echo "ERROR: Metrics directory does not exist"
   fi
}

###############################################################################
# Get list of OUD exporters
###############################################################################
get_exporters() {
   exporters=$(ls -1 ${cfgdir}/*/exporter.config 2> /dev/null|sed -e "s/^.*\/cfg\///g" -e "s/\/exporter.config//g")
}

###############################################################################
# List exporters
###############################################################################
list_exporters() {
   get_exporters
   for resName in ${exporters}
   do
      echo "OUD Exporter ${resName}"
   done
}

###############################################################################
# Start Listener for exporter
###############################################################################
start_prometheus_exporter() {
   pid=$(ps -ef|grep "node_exporter"|grep "/${resName}/"|grep -v grep|awk '{print $2}')
   if [ -n "${pid}" ]
   then
      status_prometheus_exporter
   else
      exporterDir="${cfgdir}/${resName}"
      metricsDir="${exporterDir}/exporter/metrics"
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -d "${metricsDir}" ]
      then
         cd "${metricsDir}/.."
      else
         mkdir -p "${metricsDir}" 2> /dev/null
         cd "${metricsDir}"
         touch index.html ../index.html
         cd "${metricsDir}/.."
      fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${cfgdir}/lib/node_exporter" ]
      then
         nohup ${cfgdir}/lib/node_exporter --collector.disable-defaults --web.disable-exporter-metrics --web.listen-address=localhost:${metricPort} --web.config.file="${cfgdir}/${resName}/exporter.yml" --collector.textfile.directory=${cfgdir}/${resName}/exporter/metrics --collector.textfile >> ${logdir}/listener-${resName}-${today}.log 2>&1 &
      else
         echo "ERROR: Prometheus node_exporter not yet installed"
         exit 1
      fi

      status_prometheus_exporter
   fi
   set +x

}

###############################################################################
# Start Prometheus compliant exporter
###############################################################################
start_oud_exporter() {
   pid=$(ps -ef|grep "manage_exporter.sh monitor --name ${resName} --type"|grep -v " ${mypid} "|grep -v grep|awk '{print $2}')
   if [ -n "${pid}" ]
   then
      status_oud_exporter
   else
      getCreds
      if [ "${dbg}" == 'true' ];then set -x;fi
      nohup ${curdir}/manage_exporter.sh monitor --name ${resName} --type ${targetType} >> ${logdir}/exporter-${resName}-${today}.log 2>&1 &
      set +x

      status_oud_exporter
   fi
}

###############################################################################
# Start watchdog for exporter
###############################################################################
start_watchdog() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   pid=$(ps -ef|grep "manage_exporter.sh watch --name ${resName}"|grep -v grep|awk '{ print $2 }')
   if [ -z "${pid}" ]
   then
      nohup ${curdir}/${cmd} watch --name ${resName} >> ${logdir}/watch-${resName}-${today}.log 2>&1 &
   fi
   set +x

   status_watchdog
}

###############################################################################
# Start OUD exporters
###############################################################################
start_all_prometheus_exporters() {
   if [ -n "${myResourceName}" ];then exporters="${myResourceName}";else get_exporters;fi
   for resName in ${exporters}
   do
      exporterDir="${cfgdir}/${resName}"
      exporterConfig="${exporterDir}/exporter.config"
      readConfigs
      start_prometheus_exporter
   done
}

###############################################################################
# Start Exporter, Listener, and Watchdog
###############################################################################
start_all() {
   getCreds
   if [ -n "${myResourceName}" ];then exporters="${myResourceName}";else get_exporters;fi
   for resName in ${exporters}
   do
      exporterDir="${cfgdir}/${resName}"
      exporterConfig="${exporterDir}/exporter.config"
      readConfigs
      start_prometheus_exporter
      start_oud_exporter
      start_watchdog
   done
}

###############################################################################
# Stop listener for exporter
###############################################################################
stop_prometheus_exporter() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   pid=$(ps -ef|grep "node_exporter"|grep "/${resName}/"|grep -v grep|awk '{print $2}')
   if [ -n "${pid}" ];then kill -9 ${pid};fi

   ck4pid=$(ps -ef|egrep "\/${resName}\/exporter.yml"|grep -v grep|awk '{ print $2 }')
   if [ -n "${ck4pid}" ];then kill -9 ${ck4pid};fi
   set +x

   status_prometheus_exporter
}

###############################################################################
# Stop Prometheus compliant exporter for OUD
###############################################################################
stop_oud_exporter() {
   # Stop monitory
   if [ "${dbg}" == 'true' ];then set -x;fi
   pid=$(ps -ef|grep "manage_exporter.sh monitor --name ${resName} --type"|grep -v grep|awk '{ print $2 }')
   if [ -n "${pid}" ];then kill -9 ${pid};fi
   set +x

   # Stop queries that might still be in progress
   if [ "${dbg}" == 'true' ];then set -x;fi
   pid=$(ps -ef|grep "manage_exporter.sh query --name ${resName} --type"|grep -v grep|awk '{ print $2 }')
   if [ -n "${pid}" ];then kill -9 ${pid};fi
   set +x

   status_oud_exporter
}

###############################################################################
# Status all exporter listeners
###############################################################################
status_all() {
   getCreds
   if [ -n "${myResourceName}" ];then exporters="${myResourceName}";else get_exporters;fi
   for resName in ${exporters}
   do
      exporterDir="${cfgdir}/${resName}"
      exporterConfig="${exporterDir}/exporter.config"
      if [ -e "${cfgdir}/${resName}/exporter.yml" ]
      then
         readConfigs
         status_oud_exporter
         status_prometheus_exporter
         status_watchdog
      else
         echo "Exporter ${resName} is not setup"
      fi
   done
   status_oud_exporter_service
}

###############################################################################
# Stop all exporter listeners
###############################################################################
stop_all_prometheus_exporters() {
   if [ -n "${myResourceName}" ];then exporters="${myResourceName}";else get_exporters;fi
   for resName in ${exporters}
   do
      exporterDir="${cfgdir}/${resName}"
      exporterConfig="${exporterDir}/exporter.config"
      readConfigs
      stop_prometheus_exporter

   done
}

###############################################################################
# Stop watchdog for exporter
###############################################################################
stop_watchdog() {
   if [ -n "${myResourceName}" ];then exporters="${myResourceName}";else get_exporters;fi
   ck4pid=$(ps -ef|grep "manage_exporter.sh watch --name ${resName}"|grep -v " ${mypid} "|grep -v grep|awk '{ print $2 }')
   if [ -n "${ck4pid}" ]
   then
      kill -9 ${ck4pid} 2> /dev/null
   fi

   status_watchdog
}

###############################################################################
# Start watchdog for exporter
###############################################################################
stop_all() {
   if [ -n "${myResourceName}" ];then exporters="${myResourceName}";else get_exporters;fi
   for resName in ${exporters}
   do
      exporterDir="${cfgdir}/${resName}"
      exporterConfig="${exporterDir}/exporter.config"
      readConfigs
      stop_prometheus_exporter
      stop_oud_exporter
      stop_watchdog
   done
}

###############################################################################
# Check the status of watchdog service
###############################################################################
status_watchdog() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   pid=$(ps -ef|grep "manage_exporter.sh watch --name ${resName}"|grep -v grep|awk '{ print $2 }'|sed -e "s/$/ /g"|tr -d '[\n\r]')
   if [ -n "${pid}" ]
   then
      echo "[UP]   ${resName} Exporter watchdog (pid ${pid})"
   else
      echo "[DOWN] ${resName} Exporter watchdog"
   fi
}

###############################################################################
# Check the status of OUD exporter 
###############################################################################
status_oud_exporter() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   pid=$(ps -ef|grep "manage_exporter.sh monitor --name ${resName} --type"|grep -v grep|awk '{print $2}'|sed -e "s/$/ /g"|tr -d '[\n\r]')
   if [ -n "${pid}" ]
   then
      echo "[UP]   ${resName} OUD exporter (pid ${pid})"
   else
      echo "[DOWN] ${resName} OUD exporter"
   fi
}

###############################################################################
# Check the status of Prometheus compliant exporter
###############################################################################
status_oud_exporter_service() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   # Check the Linux systemd service status if enabled
   if [ -e "/usr/lib/systemd/system/oud_exporter.service" ]
   then
      systemctl --no-pager status oud_exporter
   fi
   set +x
}

###############################################################################
# Check the status of Prometheus compliant exporter
###############################################################################
status_prometheus_exporter() {
   pid=$(ps -ef|grep "node_exporter"|grep "/${resName}/"|grep -v grep|awk '{print $2}'|sed -e "s/$/ /g"|tr -d '[\n\r]')
   if [ -n "${pid}" ]
   then
      echo "[UP]   ${resName} Prometheus exporter (pid ${pid})"
   else
      echo "[DOWN] ${resName} Prometheus exporter"
   fi

}

###############################################################################
# Download and install latest OUD exporter
###############################################################################
install_oud_exporter() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   sleep 1
   if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
   then
      cat "${latest_dir}/manage_exporter.sh" > "${curdir}/manage_exporter.sh" 2>&1
      rc1=$?

      cd "${curdir}"
      chmod 0700 manage_exporter.sh >> ${logdir}/exporter-update-${now}.log 2>&1
      rc2=$?
   set +x
   else
      sudo -u ${agentUser} cp "${latest_dir}/manage_exporter.sh" "${curdir}/manage_exporter.sh" 2> /dev/null
      rc1=$?

      cd "${curdir}"
      sudo -u ${agentUser} chmod 0700 manage_exporter.sh >> ${logdir}/exporter-update-${now}.log 2>&1
      rc2=$?
   fi
   if [ ${rc1} -eq 0 ] && [ ${rc2} -eq 0 ]
   then
      echo "OUD exporter updated" | tee -a ${logdir}/exporter-update-${now}.log 2>&1
   else
      echo "ERROR: OUD export update failed. See log ${logdir}/exporter-update-${now}.log" | tee -a ${logdir}/exporter-update-${now}.log 2>&1
      exit 1
   fi
}

###############################################################################
# Backup OUD exporter
###############################################################################
backup_oud_exporter() {
   let steps++
   echo "Step ${steps} - Backup OUD exporter" | tee -a ${logdir}/exporter-update-${now}.log 2>&1
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -d "${cfgdir}/backups" ];then true;else mkdir -p "${cfgdir}/backups";fi
   cd ${curdir}
   tar -zcf ${cfgdir}/backups/oud_exporter-${now}.tgz manage_exporter.sh >> ${logdir}/exporter-update-${now}.log 2>&1
   rc=$?;set +x
}

###############################################################################
# Download and install latest node_exporter
###############################################################################
update_oud_exporter() {
   if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
   then
      readarray -t exporter_versions < <(find / -name manage_exporter.sh 2> /dev/null|grep "oud/manage_exporter.sh")
   else
      readarray -t exporter_versions < <(sudo -u ${agentUser} find / -name manage_exporter.sh 2> /dev/null|grep "oud/manage_exporter.sh")
   fi


   if [ "${dbg}" == 'true' ];then set -x;fi
   latest_version=$(echo  ${exporter_versions[*]}|sed -e "s/^.*appmgmt\///g" -e "s/\/scripts.*//g"|sort -nr|head -1)
   latest_file=$(echo  ${exporter_versions[*]}|grep "/${latest_version}/scripts/oud/")
   latest_dir=$(dirname ${latest_file})
   set +x
   ckdiff=$(sudo diff "${curdir}/${cmd}" "${latest_file}")
   if [ -n "${ckdiff}" ]
   then
      backup_oud_exporter
      install_oud_exporter &
   else
      let steps++
      echo "Step ${steps} - OUD exporter is up-to-date" | tee -a ${logdir}/exporter-update-${now}.log 2>&1
   fi
   set +x
}

###############################################################################
# Download and install latest node_exporter
###############################################################################
update_node_exporter() {
   let steps++
   echo "Step ${steps} - Download latest Prometheus node_exporter" | tee -a ${logdir}/exporter-update-${now}.log 2>&1

   # Download and setup node_exporter
   mkdir -p ${cfgdir}/lib 2> /dev/null
   cd ${cfgdir}/lib

   # Lookup latest version
   if [ -n "${proxyUri}" ]
   then
      ver=$(curl -x "${proxyUri}" -s https://github.com/prometheus/node_exporter/releases/ --connect-timeout 10 |grep linux-amd64.tar.gz|sed -e "s/^.*href=\"//g" -e "s/\" .*//g"|grep linux-amd64.tar.gz)
   else
      ver=$(curl -s https://github.com/prometheus/node_exporter/releases/ --connect-timeout 10 |grep linux-amd64.tar.gz|sed -e "s/^.*href=\"//g" -e "s/\" .*//g"|grep linux-amd64.tar.gz)
   fi

   if [ -z "${ver}" ]
   then
      echo "ERROR: Failed to download node_exporter. Please check your connection"
      exit 1
   fi

   # Download node_exporter
   if [ -n "${proxyUri}" ]
   then
      curl -x "${proxyUri}" -s -L -o node_exporter.tgz https://github.com${ver} >> ${logdir}/exporter-update-${now}.log 2>&1
   else
      curl -s -L -o node_exporter.tgz https://github.com${ver} >> ${logdir}/exporter-update-${now}.log 2>&1
   fi

   # Extract node_exporter
   tar -zx --to-stdout -f node_exporter.tgz */node_exporter > node_exporter.new
   rm node_exporter.tgz 2> /dev/null

   orig=$(openssl dgst -md5 ${cfgdir}/lib/node_exporter 2> /dev/null|awk '{ print $2 }')
   new=$(openssl dgst -md5 ${cfgdir}/lib/node_exporter.new|awk '{ print $2 }')

   if [ "${new}" != "${orig}" ]
   then
      if [ -n "${orig}" ]
      then
         stop_all_prometheus_exporters | sed -e "s/^/         STATUS: /g"
      fi

      # Set permissions
      chmod 0700 node_exporter.new

      # Install new node_exporter
      mv node_exporter.new node_exporter

      if [ -n "${orig}" ]
      then
         start_all_prometheus_exporters | sed -e "s/^/         STATUS: /g"
      fi

      let steps++
      echo "Step ${steps} - New prometheus node_exporter version installed" | tee -a ${logdir}/exporter-update-${now}.log 2>&1

   else
      rm -f node_exporter.new > /dev/null 2>&1
      let steps++
      echo "Step ${steps} - Prometheus node_exporter is up-to-date" | tee -a ${logdir}/exporter-update-${now}.log 2>&1
   fi
}

###############################################################################
# Setup Prometheus emitter property file
###############################################################################
setup_emitter() {

   if [ -e "${cfgdir}/${resName}/exporter.yml" ]
   then
      echo "OUD exporter ${resName} already setup" | tee -a ${logdir}/exporter-setup-${now}.log 2>&1
      exit
   fi

   updateCreds

   # Install node_exporter binary
   if [ -e "${cfgdir}/lib/node_exporter" ]
   then
      true
   else
      update_node_exporter
   fi

   # Make sure localhost cert and private key exists
   if [ -e "${certdir}/localhost/localhost.p12" ]
   then
      true
   else
      let steps++
      echo "Step ${steps} - Generate certs for localhost" | tee -a ${logdir}/exporter-setup-${now}.log 2>&1
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_exporter.sh gencert -h localhost --javaHome "${JAVA_HOME}"| sed -e "s/^/         CERT: /g"
      #rc=$?
      if [ ${rc} -ne 0 ];then exit 1;fi

      jkspwf="${certdir}/.jks"
      if [ -e "${jkspwf}" ]
      then
         . ${jkspwf}
      fi

      # Extract private key
      openssl pkcs12 -in ${certdir}/localhost/localhost.p12 -out ${certdir}/pylocalhost.pem -nodes -passin "pass:${jkspw}"
      rc=$?;set +x
   fi

   # Setup individual exporter
   if [ -s "${cfgdir}/${resName}/exporter.yml" ]
   then
      true
   else
      let steps++
      echo "Step ${steps} - Setup node_exporter credential for ${resName} exporter" | tee -a ${logdir}/exporter-setup-${now}.log 2>&1

      if [ "${dbg}" == 'true' ];then set -x;fi
      mkdir -p ${cfgdir}/${resName}/exporter 2> /dev/null
      cd "${cfgdir}/${resName}"

      # Generate password for exporter user
      htpasswd -ciBC 10 .p exporter >> ${logdir}/exporter-setup-${now}.log 2>&1 <<EOF
${bPW}
EOF
      rc=$?
      ePW=$(cat .p|cut -d: -f2-)
      rm -f .p

      # Create exporter.py config file
      touch ${cfgdir}/${resName}/exporter.yml
      rc=$?
      chmod 0600 ${cfgdir}/${resName}/exporter.yml
      rc=$?
      cat > ${cfgdir}/${resName}/exporter.yml <<EOF
tls_server_config:
  cert_file: ${certdir}/localhost.pem
  key_file: ${certdir}/pylocalhost.pem

basic_auth_users:
  exporter: ${ePW}
EOF
   fi

   # Confirm that the emitter directory exists
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
   then
      test -d "${adir}/discovery/PrometheusEmitter"
      rc=$?
   else
      sudo -u ${agentUser} test -d "${adir}/discovery/PrometheusEmitter"
      rc=$?
   fi

#   # If provided emitter directory does not exist, try OCI default
#   if [ ${rc} -ne 0 ]
#   then
#      if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
#      then
#         test -d "/var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst"
#         rc=$?
#      else
#         sudo -u ${agentUser} test -d "/var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst"
#         rc=$?
#      fi
#
#      if [ ${rc} -eq 0 ];then adir="/var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst";fi
#   fi
#
#   # If the first two adir values don't work, try non-OCI default location
#   if [ ${rc} -ne 0 ]
#   then
#      if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
#      then
#         test -d "/opt/oracle/mgmt_agent/agent_inst"
#         rc=$?
#      else
#         sudo -u ${agentUser} test -d "/opt/oracle/mgmt_agent/agent_inst"
#         rc=$?
#      fi
#
#      if [ ${rc} -eq 0 ];then adir="/opt/oracle/mgmt_agent/agent_inst";fi
#   fi

   # Check management agent credential
   if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
   then
      ckcred=$(/bin/sh ${adir}/bin/credential_mgmt.sh -o listCredentials -s Agent|grep RestCreds|grep "PrometheusEmitter.${resName}")
   else
      ckcred=$(sudo -u ${agentUser} /bin/sh ${adir}/bin/credential_mgmt.sh -o listCredentials -s Agent|grep RestCreds|grep "PrometheusEmitter.${resName}")
   fi

   set +x
   if [ -z "${ckcred}" ]
   then
      let steps++
      echo "Step ${steps} - Load node_exporter credential and HTTPS trust store into management" | tee -a ${logdir}/exporter-setup-${now}.log 2>&1
      echo "         agent for ${resName} exporter" | tee -a ${logdir}/exporter-setup-${now}.log 2>&1
      # Load certificate authority certificate chain into Oracle Management Agent wallet
      # Load exporter credential into management agent for connecting to node_exporter
      if [ "${dbg}" == 'true' ];then set -x;fi
      touch ${cfgdir}/${resName}/update_oma.json
      chmod 0600 ${cfgdir}/${resName}/update_oma.json
      cat > ${cfgdir}/${resName}/update_oma.json <<EOF
{
  "source": "PrometheusEmitter.${resName}",
  "name": "RestCreds",
  "type": "HTTPSCreds",
  "description": "These are HTTPS (BasicAuth) credentials.",
  "properties": [
    {
      "name": "HTTPSUserName",
      "value": "${listenerUser}"
    }, {
      "name": "HTTPSPassword",
      "value": "${lPW}"
    }, {
      "name": "ssl_trustStoreType",
      "value": "JKS"
    }, {
      "name": "ssl_trustStorePassword",
      "value": "${jkspw}"
    }, {
      "name": "ssl_trustStoreLocation",
      "value": "${certdir}/CA/truststore"
    }
  ]
}
EOF

      # Load into Oracle Management Agent
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
      then
         cat ${cfgdir}/${resName}/update_oma.json | /bin/sh ${adir}/bin/credential_mgmt.sh -o upsertCredentials -s Agent | tee ${logdir}/exporter-setup-${now}.log 2>&1 | echo > /dev/null
         rc=$?
      else
         cat ${cfgdir}/${resName}/update_oma.json | sudo -u ${agentUser} /bin/sh ${adir}/bin/credential_mgmt.sh -o upsertCredentials -s Agent | tee ${logdir}/exporter-setup-${now}.log 2>&1 | echo > /dev/null
         rc=$?
      fi

      # Remove temporary json file
      if [ "${dbg}" == 'true' ];then true;else rm -f ${cfgdir}/${resName}/update_oma.json;fi
   fi
   set +x

   # Create the OCI Management Agent Prometheus Emitter property file
   if [ ${rc} -eq 0 ]
   then
      let steps++
      echo "Step ${steps} - Setup Management Agent Prometheus emitter file for ${resName} exporter" | tee -a ${logdir}/exporter-setup-${now}.log 2>&1
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
      then
         test -d "${adir}/discovery/PrometheusEmitter/${resName}.properties"
         file_rc=$?
      else
         sudo -u ${agentUser} test -d "${adir}/discovery/PrometheusEmitter/${resName}.properties"
         file_rc=$?
      fi
      set +x
      if [ ${file_rc} -eq 0 ]
      then
         true
      else
         cat > ${cfgdir}/${resName}.properties <<EOF
url=https://localhost:${metricPort}/metrics
namespace=oracle_appmgmt
instance=${instName}
nodeName=${resName}
hostname=${localHost}
allowMetrics=*
compartmentId=${compartmentId}
resourceName=${resName}
resourceGroup=${resourceGroup}
metricDimensions=resourceName
scheduleMins=2
EOF

         if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
         then
            # Move to the prometheus emitter directory
            mv ${cfgdir}/${resName}.properties ${adir}/discovery/PrometheusEmitter/${resName}.properties

            # Set permissions
            chmod 0644 ${adir}/discovery/PrometheusEmitter/${resName}.properties

            # Set ownership
            chown ${agentUser}:${agentUser} ${adir}/discovery/PrometheusEmitter/${resName}.properties
         else
            # Move to the prometheus emitter directory
            sudo -u ${agentUser} mv ${cfgdir}/${resName}.properties ${adir}/discovery/PrometheusEmitter/${resName}.properties

            # Set permissions
            sudo -u ${agentUser} chmod 0644 ${adir}/discovery/PrometheusEmitter/${resName}.properties

            # Set ownership
            sudo -u ${agentUser} chown ${agentUser}:${agentUser} ${adir}/discovery/PrometheusEmitter/${resName}.properties
         fi
      fi
      set +x

      let steps++
      echo "Step ${steps} - Start ${resName} OUD and Prometheus exporters" | tee -a ${logdir}/exporter-setup-${now}.log 2>&1
      start_all | sed -e "s/^/         STATUS: /g"

      # Re-start the Oracle Cloud Agent
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
      then
         test -e "${adir}/discovery/PrometheusEmitter/${resName}.properties"
         rc=$?
      else
         sudo -u ${agentUser} test -e "${adir}/discovery/PrometheusEmitter/${resName}.properties"
         rc=$?
      fi

      if [ ${rc} -eq 0 ]
      then
         let steps++
         echo "Step ${steps} - Restart management agent" | tee -a ${logdir}/exporter-setup-${now}.log 2>&1
         tryrestart=$(systemctl --no-ask-password restart ${agentUser}.service 2>&1 | grep 'Failed to restart')

         if [ -n "${tryrestart}" ]
         then
            echo "Run the following command as root or via sudo to restart the management agent:"
            echo "systemctl restart ${agentUser}.service"
            echo "or"
            echo "sudo systemctl restart ${agentUser}.service"
            exit
         else
            echo "Management agent restart complete."
         fi
      fi
   else
      echo "ERROR: Emitter directory does not exist (${adir}/discovery/PrometheusEmitter)"
   fi

   updateCreds
}

###############################################################################
# Enable exporter to start on OS boot
###############################################################################
enable_exporter() {
   lookupos
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ "${me}" == 'root' ]
   then
      let steps++
      echo "Step ${steps} - Enable OUD exporter to start on OS boot" | tee -a ${logdir}/exporter-enable-${now}.log

      mkdir -p ${cfgdir} 2> /dev/null
      cat > ${cfgdir}/oud_exporter.service <<EOF
[Unit]
Description=OUD Exporter Service
After=local-fs-pre.target network.target syslog.target
ConditionDirectoryNotEmpty=|${cfgdir}

[Service]
Type=forking
User=${agentUser}
Environment=JAVA_HOME=$JAVA_HOME
WorkingDirectory=${curdir}

ExecStart=${curdir}/${cmd} start
ExecStop=${curdir}/${cmd} stop
SuccessExitStatus=0
Restart=always

[Install]
WantedBy=multi-user.target
EOF
      if [ "${dbg}" == 'true' ];then set -x;fi
      case ${os} in
         'SunOS') if [ -h /etc/init.d/oud_exporter   ];then true;else ln -s ${curdir}/${cmd} /etc/init.d/oud_exporter;fi
                  if [ -h /etc/rc2.d/S99oud_exporter ];then true;ln -s ${curdir}/${cmd} /etc/rc2.d/S99oud_exporter;fi
                  if [ -h /etc/rc3.d/S99oud_exporter ];then true;ln -s ${curdir}/${cmd} /etc/rc3.d/S99oud_exporter;fi
                  if [ -h /etc/rc5.d/S99oud_exporter ];then true;ln -s ${curdir}/${cmd} /etc/rc5.d/S99oud_exporter;fi
                  if [ -h /etc/rc6.d/S99oud_exporter ];then true;ln -s ${curdir}/${cmd} /etc/rc6.d/S99oud_exporter;fi
                  if [ -h /etc/rc0.d/K01oud_exporter ];then true;ln -s ${curdir}/${cmd} /etc/rc0.d/K01oud_exporter;fi
                  if [ -h /etc/rc1.d/K01oud_exporter ];then true;ln -s ${curdir}/${cmd} /etc/rc1.d/K01oud_exporter;fi
                  if [ -h /etc/rc6.d/K01oud_exporter ];then true;ln -s ${curdir}/${cmd} /etc/rc6.d/K01oud_exporter;fi
                  ;;
         'Linux') case ${olv} in
                     5) if [ -h /etc/init.d/oud_exporter ];then true;else ln -s ${curdir}/${cmd} /etc/init.d/oud_exporter; chkconfig --add oud_exporter;fi;;
                     6) if [ -h /etc/init.d/oud_exporter ];then true;else ln -s ${curdir}/${cmd} /etc/init.d/oud_exporter; chkconfig --add oud_exporter;fi;;
                   7|8|9) # If OL7, OL8, or OL9 setup
                        s="${cfgdir}/oud_exporter.service"
                        s1="/usr/lib/systemd/system/oud_exporter.service"
                        s2="/etc/systemd/system/multi-user.target.wants/oud_exporter.service"

                        # Create systemd service config
                        if [ -h "${s1}" ]
                        then
                           true
                        else
                           # Remove if already exists
                           if [ -e "${s1}" ];then rm -fr "${s1}" 2> /dev/null;fi
                           if [ -e "${s2}" ];then rm -fr "${s1}" 2> /dev/null;fi

                           # Add to multi-user.target (e.g. init run level 3)
                           # There appears to be a bug with OL8 that does not allow links.  So copying instead.
                           ln -s "${s}" "${s1}" >> ${logdir}/exporter-enable-${now}.log 2>&1
                           ln -s "${s}" "${s2}" >> ${logdir}/exporter-enable-${now}.log 2>&1

                           # Reload service config
                           systemctl daemon-reload >> ${logdir}/exporter-enable-${now}.log 2>&1
                           rc=$?

                           # Enable service config
                           systemctl enable oud_exporter.service >> ${logdir}/exporter-enable-${now}.log 2>&1
                           rc=$?

                           systemctl daemon-reload >> ${logdir}/exporter-enable-${now}.log 2>&1
                           rc=$?

                        fi
                        systemctl start oud_exporter >> ${logdir}/exporter-enable-${now}.log 2>&1

                        # Enable the management agent user to be able to restart the management
                        # agent service
                        cat > /etc/polkit-1/rules.d/50-${agentUser}.rules <<POLKIT
polkit.addRule(function(action, subject) {
    if (action.id == "org.freedesktop.systemd1.manage-units" &&
        action.lookup("unit") == "${agentUser}.service" &&
        subject.user == "${agentUser}") {
        return polkit.Result.YES;
    }
});
POLKIT
                        # Enable the management agent user to be able to restart the exporter
                        # service
                        cat > /etc/polkit-1/rules.d/50-oud_exporter.rules <<POLKIT
polkit.addRule(function(action, subject) {
    if (action.id == "org.freedesktop.systemd1.manage-units" &&
        action.lookup("unit") == "oud_exporter.service" &&
        subject.user == "${agentUser}") {
        return polkit.Result.YES;
    }
});
POLKIT

                        ;;
                  esac
                  ;;
      esac
      set +x
   else

      if [ "${dbg}" == 'true' ];then set -x;fi
      echo "Run \"${curdir}/${cmd} enable\" as root"
   fi
   set +x
}

###############################################################################
# Disable exporter from starting on OS boot
###############################################################################
disable_exporter() {
   true
   lookupos
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ "${me}" == 'root' ]
   then
      let steps++
      echo "Step ${steps} - Disable OUD exporter from starting on OS boot" | tee -a ${logdir}/exporter-disable-${now}.log

      let steps++
      echo "Step ${steps} - Stop OUD exporter" | tee -a ${logdir}/exporter-disable-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      case $os in
         'SunOS') if [ -h /etc/init.d/oud_exporter   ];then rm -f /etc/init.d/oud_exporter;fi
                  if [ -h /etc/rc2.d/S99oud_exporter ];then rm -f /etc/rc2.d/S99oud_exporter;fi
                  if [ -h /etc/rc3.d/S99oud_exporter ];then rm -f /etc/rc3.d/S99oud_exporter;fi
                  if [ -h /etc/rc5.d/S99oud_exporter ];then rm -f /etc/rc5.d/S99oud_exporter;fi
                  if [ -h /etc/rc6.d/S99oud_exporter ];then rm -f /etc/rc6.d/S99oud_exporter;fi
                  if [ -h /etc/rc0.d/K01oud_exporter ];then rm -f /etc/rc0.d/K01oud_exporter;fi
                  if [ -h /etc/rc1.d/K01oud_exporter ];then rm -f /etc/rc1.d/K01oud_exporter;fi
                  if [ -h /etc/rc6.d/K01oud_exporter ];then rm -f /etc/rc6.d/K01oud_exporter;fi
                  ;;
         'Linux') systemctl stop oud_exporter >> ${logdir}/exporter-disable-${now}.log 2>&1
                  case ${olv} in
                     5) if [ -h /etc/init.d/oud_exporter ];then chkconfig --del oud_exporter;rm -f /etc/init.d/oud_exporter;fi;;
                     6) if [ -h /etc/init.d/oud_exporter ];then chkconfig --del oud_exporter;rm -f /etc/init.d/oud_exporter;fi;;
                   7|8|9) # If OL7, OL8, or OL9 setup
                        # Disable and remove
                        systemctl stop oud_exporter.service >> ${logdir}/exporter-disable-${now}.log 2>&1
                        rc=$?
                        systemctl disable oud_exporter.service >> ${logdir}/exporter-disable-${now}.log 2>&1
                        rc=$?
                        rm -f /etc/systemd/system/multi-user.target.wants/oud_exporter.service /usr/lib/systemd/system/oud_exporter.service ${cfgdir}/oud_exporter.service >> ${logdir}/exporter-disable-${now}.log 2>&1
                        rc=$?

                        # Reload service config
                        systemctl daemon-reload >> ${logdir}/exporter-enable-${now}.log 2>&1
                        rc=$?
                        ;;
                  esac
                  ;;
      esac
      set +x
   else
      if [ -z "${steps}" ];then steps=0;fi
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/${cmd} disable --step ${steps} ${dbgFlag}
      rc=$?;set +x
      let steps++
      let steps++
   fi
   set +x
}

###############################################################################
# Remove exporter
###############################################################################
remove_exporter() {
   # Stop Exporter
   let steps++
   echo "Step ${steps} - Stop ${resName} OUD and Prometheus exporters" | tee -a ${logdir}/exporter-deinstall-${now}.log 2>&1
   stop_all | sed -e "s/^/         STATUS: /g"

   # Delete credential
   # Create temporary JSON
   cat > delete_creds.json <<EOF
{"source": "PrometheusEmitter.${resName}","name":"RestCreds"}
EOF

   if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
   then
      cat delete_creds.json | /bin/sh ${adir}/bin/credential_mgmt.sh -o deleteCredentials -s Agent | tee ${logdir}/exporter-deinstall-${now}.log 2>&1 | echo > /dev/null
      rc=$?
   else
      cat delete_creds.json | sudo -u ${agentUser} ${adir}/bin/credential_mgmt.sh -o deleteCredentials -s Agent | tee ${logdir}/exporter-deinstall-${now}.log 2>&1 | echo > /dev/null
      rc=$?
   fi

   # Remove temporary JSON
   rm delete_creds.json


   # Remove Prometheus Emitter property file
   if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
   then
      test -s "${adir}/discovery/PrometheusEmitter/${resName}.properties"
      rc=$?
   else
      sudo -u ${agentUser} -n test -s "${adir}/discovery/PrometheusEmitter/${resName}.properties"
      rc=$?
   fi

   if [ ${rc} -eq 0 ]
   then
      let steps++
      echo "Step ${steps} - Remove ${resName} Prometheus Emitter property file" | tee -a ${logdir}/exporter-deinstall-${now}.log 2>&1
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
      then
         rm "${adir}/discovery/PrometheusEmitter/${resName}.properties"
         rc=$?
      else
         sudo -u ${agentUser} -n rm "${adir}/discovery/PrometheusEmitter/${resName}.properties"
         rc=$?
      fi
      set +x
   fi

   # Remove Prometheus source file
   if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
   then
      resFile=$(find ${adir}/config/sources -name "OCI.Agent.PrometheusEmitter.*.${resName}.json")
   else
      resFile=$(sudo -u ${agentUser} find ${adir}/config/sources -name "OCI.Agent.PrometheusEmitter.*.${resName}.json")
   fi

   if [ -n "${resFile}" ]
   then
      let steps++
      echo "Step ${steps} - Remove ${resName} Prometheus Emitter source file" | tee -a ${logdir}/exporter-deinstall-${now}.log 2>&1
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ "${me}" == 'mgmt_agent' ] || [ "${me}" == 'oracle-cloud-agent' ]
      then
         find ${adir}/config/sources -name "OCI.Agent.PrometheusEmitter.*.${resName}.json" -delete
         rc=$?
         find ${adir}/config/sources -name "OCI.Agent.PrometheusEmitter.*.${resName}.json.bak" -delete
         rc=$?
      else
         sudo -u ${agentUser} find ${adir}/config/sources -name "OCI.Agent.PrometheusEmitter.*.${resName}.json" -delete
         rc=$?
         sudo -u ${agentUser} find ${adir}/config/sources -name "OCI.Agent.PrometheusEmitter.*.${resName}.json.bak" -delete
         rc=$?
      fi
      set +x
   fi

   # Remove node exporter configuration
   if [ -e "${cfgdir}/${resName}/exporter.yml" ]
   then
      let steps++
      echo "Step ${steps} - Remove ${resName} node_exporter config" | tee -a ${logdir}/exporter-deinstall-${now}.log 2>&1
      if [ "${dbg}" == 'true' ];then set -x;fi
      rm "${cfgdir}/${resName}/exporter.yml"
      rc=$?;set +x
   fi

   if [ -e "${exporterConfig}" ]
   then
      let steps++
      echo "Step ${steps} - Remove ${resName} exporter config" | tee -a ${logdir}/exporter-deinstall-${now}.log 2>&1
      if [ "${dbg}" == 'true' ];then set -x;fi
      rm -f "${exporterConfig}"
      rc=$?;set +x
   fi

   if [ -n "${resName}" ] && [ -d "${cfgdir}/${resName}" ]
   then
      rm -fr "${cfgdir}/${resName}"
   fi
}

###############################################################################
# Deinstall exporter
###############################################################################
deinstall_exporter() {
   # Determine if instance exists
   ck=$(ls -1 "${cfgdir}/${resName}/exporter.config" 2> /dev/null)
   if [ -n "${ck}" ]
   then
      true
   else
      echo "${resName} OUD and Prometheus exporters do not exist"
      exit 1
   fi
   set +x
      
   remove_exporter

   # Delete instance credential
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/${cmd} dc --name ${resName} -D ${monitorUser}
   rc=$?;set +x
}


###############################################################################
# Query target
###############################################################################
query_target() {
   getCreds
   case ${targetType} in
        'oud'|'proxy'|'replgw') query_oud;;
   esac
}

###############################################################################
# Purge logs
###############################################################################
purge_logs() {
   if [ -d "${logdir}" ]
   then
      find "${logdir}" -name "*.log" -ctime +14 -exec rm "{}" \;
   fi
}

###############################################################################
# Find Oracle Cloud Agent Emitter directory
###############################################################################
watch_exporter() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   n=0
   while true
   do
      ck4monitor=$(ps -ef|grep "manage_exporter.sh monitor --name ${resName} --type ${targetType}"|grep -v grep)
      if [ -z "${ck4monitor}" ]
      then
         start_oud_exporter
      fi

      ck4listener=$(ps -ef|grep "node_exporter"|grep ${metricPort}|grep -v grep)
      if [ -z "${ck4listener}" ]
      then
         start_prometheus_exporter
      fi

      sleep 1

      # Purge log files that are older than 14 days
      if [ ${n} -gt 86000 ]
      then
         purge_logs
         n=0
      fi
      let n++
   done
   set +x
}

###############################################################################
# Show necessary sudo profile
###############################################################################
showSudoProfile() {
   cat << EOS
Cmnd_Alias expCat    = sudo cat "${latest_dir}/manage_exporter.sh"
Cmnd_Alias expDiff   = sudo diff "${curdir}/${cmd}" "${latest_file}"
Cmnd_Alias expFind1  = sudo find /opt -name manage_exporter.sh
Cmnd_Alias expTest1  = sudo -u ${agentUser} test -d "${adir}/discovery/PrometheusEmitter"
Cmnd_Alias expTest2  = sudo -u ${agentUser} test -d "/var/lib/oracle-cloud-agent/plugins/oci-managementagent/polaris/agent_inst"
Cmnd_Alias expTest3  = sudo -u ${agentUser} test -d "/opt/oracle/mgmt_agent/agent_inst"
Cmnd_Alias expCred1  = sudo -u ${agentUser} /bin/sh ${adir}/bin/credential_mgmt.sh -o listCredentials -s Agent
Cmnd_Alias expCred2  = sudo -u ${agentUser} /bin/sh ${adir}/bin/credential_mgmt.sh -o upsertCredentials -s Agent
Cmnd_Alias expCred3  = sudo -u ${agentUser} ${adir}/bin/credential_mgmt.sh -o deleteCredentials -s Agent 
Cmnd_Alias expCtl1   = sudo systemctl restart ${agentUser}.service
Cmnd_Alias expCtl2   = /usr/bin/sudo -n systemctl daemon-reload
Cmnd_Alias expCtl3   = /usr/bin/sudo -n systemctl enable oud_exporter.service
Cmnd_Alias expCtl4   = sudo systemctl start oud_exporter
Cmnd_Alias expCtl5   = sudo systemctl stop oud_exporter
Cmnd_Alias expCtl6   = /usr/bin/sudo -n systemctl stop oud_exporter.service
Cmnd_Alias expCtl7   = /usr/bin/sudo -n systemctl disable oud_exporter.service
Cmnd_Alias expOther4 = sudo -n ${curdir}/${cmd} enable
EOS

   sudoCmds="expCat, expFind1, expDiff, expTest1, expTest2, expTest3, expCred1, expCred2, expCred3, expCtl1, expCtl2, expCtl3, expCtl4, expCtl5, expCtl6, expCtl7, expOther4"
   get_exporters
   for resName in ${exporters}
   do
      sudoCmds="${sudocmds}, exp${resName}Other5, exp${resName}Other6, exp${resName}Find2, exp${resName}Find3, exp${resName}Test4, exp${resName}Test5, exp${resName}Test6, exp${resName}Other1, exp${resName}Other2, exp${resName}Other3"
      cat << EOS
Cmnd_Alias exp${resName}Other5  = sudo -n ${curdir}/${cmd} disable --step ${steps} ${dbgFlag}
Cmnd_Alias exp${resName}Other6  = sudo -u ${agentUser} -n rm "${adir}/discovery/PrometheusEmitter/${resName}.properties"
Cmnd_Alias exp${resName}Find2   = sudo -u ${agentUser} find ${adir}/config/sources -name "OCI.Agent.PrometheusEmitter.*.${resName}.json"
Cmnd_Alias exp${resName}Find3   = sudo -u ${agentUser} find ${adir}/config/sources -name "OCI.Agent.PrometheusEmitter.*.${resName}.json" -delete
Cmnd_Alias exp${resName}Test4   = sudo -u ${agentUser} test -d "${adir}/discovery/PrometheusEmitter/${resName}.properties"
Cmnd_Alias exp${resName}Test5   = sudo -u ${agentUser} test -e "${adir}/discovery/PrometheusEmitter/${resName}.properties"
Cmnd_Alias exp${resName}Test6   = sudo -u ${agentUser} -n test -s "${adir}/discovery/PrometheusEmitter/${resName}.properties"
Cmnd_Alias exp${resName}Other1  = sudo -u ${agentUser} mv ${cfgdir}/${resName}.properties ${adir}/discovery/PrometheusEmitter/${resName}.properties
Cmnd_Alias exp${resName}Other2  = sudo -u ${agentUser} chmod 0644 ${adir}/discovery/PrometheusEmitter/${resName}.properties
Cmnd_Alias exp${resName}Other3  = sudo -u ${agentUser} chown ${agentUser}:${agentUser} ${adir}/discovery/PrometheusEmitter/${resName}.properties
EOS
   done

      cat << EOS
${agentUser}      ALL=${sudoCmds}       NOPASSWD: ALL"
EOS
}

##############################################################################
# Add global ACI for monitor user
##############################################################################
addGlobalAci() {
   cfgProto='ldaps'
   if [ "${dbg}" == 'true' ];then set -x;fi

   let steps++
   echo -e "Step ${steps} - Add global ACI for monitor user ${monitorUser}."

   muser_log="${logdir}/muser-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

#        ( ldap.MOD_ADD, 'ds-cfg-global-aci', b'(targetattr="*")(version 3.0; acl "dsMonUser"; allow (read,compare,search) userdn = "ldap:///${muserDN}"; )' ),

   getPyCmd
   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${monAdminlPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)
  exit(0)

# Add the global ACI
try:
    mod_aci = [
        ( ldap.MOD_ADD, 'ds-cfg-global-aci', b'(targetattr="*")(targetscope=subtree)(version 3.0; acl "dsMonUser"; allow (read,compare,search) userdn = "ldap:///${muserDN}"; )' ),
        ( ldap.MOD_ADD, 'ds-cfg-global-aci', b'(targetcontrol="1.3.6.1.4.1.26027.1.5.5") (version 3.0; acl "dsMonUser"; allow(read) userdn="ldap:///${muserDN}";)' )
    ]

    # Do the actual modification 
    l.modify_s('cn=Access Control Handler,cn=config',mod_aci)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: Global ACI add failed";fi
   set +x
}

##############################################################################
# Add OUD admin monitor user
##############################################################################
addOudAdminUser() {
   cfgProto='ldaps'
   if [ "${dbg}" == 'true' ];then set -x;fi

   let steps++
   echo -e "Step ${steps} - Add ${uType} monitor user ${monitorUser}."

   muser_log="${logdir}/muser-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   getPyCmd
   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${monAdminlPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)
  exit(0)

# Add muser
try:
    add_muser = [
        ('objectclass', [b'person', b'organizationalPerson', b'inetOrgPerson']),
        ('description', [b"instanceIsUp"] ),
        ('cn', [b"${monitorUser}"] ),
        ('sn', [b"${monitorUser}"] )
    ]

    # Do the actual modification 
    l.add_s("${muserDN}",add_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)

# Update the entry
try:
    mod_muser = [
        ( ldap.MOD_REPLACE, 'userPassword', [b'${mPW}'] ),
        ( ldap.MOD_REPLACE, 'description', b'instanceIsUp' ),
        ( ldap.MOD_REPLACE, 'ds-pwp-password-policy-dn', [b'cn=Root Password Policy,cn=Password Policies,cn=config'] ),
        ( ldap.MOD_REPLACE, 'ds-privilege-name', [b'config-read', b'bypass-lockdown', b'jmx-notify', b'jmx-read', b'unindexed-search', b'subentry-read'] ),
        ( ldap.MOD_REPLACE, 'ds-rlim-lookthrough-limit', b'0' ),
        ( ldap.MOD_REPLACE, 'ds-rlim-size-limit', b'0' ),
        ( ldap.MOD_REPLACE, 'ds-rlim-time-limit', b'0' )
    ]

    # Do the actual modification 
    l.modify_s("${muserDN}",mod_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: User add failed";fi
   set +x
}

##############################################################################
# Add data monitor user
##############################################################################
addDataUser() {
   mySuffix="$1"
   cfgProto='ldaps'

   getPyCmd

   let steps++
   echo -e "Step ${steps} - Add ${uType} monitor user (cn=${monitorUser},${mySuffix})."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   getPyCmd
   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${monLdapPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Add muser
try:
    add_muser = [
        ('objectclass', [b'person', b'organizationalPerson', b'inetOrgPerson']),
        ('cn', [b"${monitorUser}"] ),
        ('description', [b"instanceIsUp"] ),
        ('sn', [b"${monitorUser}"] ),
        ('userPassword', [b"${mPW}"] ),
        ('aci', [b'(targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)'] )
    ]

    # Do the actual modification 
    l.add_s("cn=${monitorUser},${mySuffix}",add_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)

# Update the OUD ACI
#try:
#    mod_aci = [
#        ( ldap.MOD_ADD, 'aci', b'(targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)' ),
#    ]
#
#    # Do the actual modification 
#    l.modify_s("cn=${monitorUser},${mySuffix}",mod_aci)
#
#except ldap.LDAPError as e:
#  if type(e.message) == dict and e.message.has_key('desc'):
#      print(e.message['desc'])
#  else:
#      print(e)
l.unbind_s()
EOPY
   pyRC=$?

   if [ ${pyRC} -ne 0 ];then echo "ERROR: User add failed";cat ${muser_log};fi
   set +x
}

##############################################################################
# Modify DSEE DBMonitor ACI
##############################################################################
addDbAci() {
   cfgProto='ldaps'
   let steps++
   echo -e "Step ${steps} - Add DSEE DB monitor ACI for ${monitorUser})."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   getPyCmd
   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${monAdminlPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Update the DSEE ACI
try:
    mod_aci = [
        ( ldap.MOD_REPLACE, 'aci', b'(target ="ldap:///cn=monitor*")(targetattr != "aci || connection")(version 3.0; acl "dbmonitor"; allow( read, search, compare) userdn = "ldap:///${muserDN}";)' ),
    ]

    # Do the actual modification 
    l.modify_s("cn=ldbm database, cn=plugins, cn=config",mod_aci)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)
l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: Aci add failed";fi
   set +x
}

##############################################################################
# Update admin's password
##############################################################################
updateAdminPassword() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   cfgProto='ldaps'

   case ${dsType} in
       'oud') if [ "${uType}" == 'admin' ];then adminsuffix="cn=config";fi;;
     'proxy') if [ "${uType}" == 'admin' ];then adminsuffix="cn=config";fi;;
    'replgw') if [ "${uType}" == 'admin' ];then adminsuffix="cn=config";fi;;
      'dsee') if [ "${uType}" == 'admin' ];then adminsuffix="cn=Administrators,cn=config";fi;;
           *) showUsage;;
   esac

   let steps++
   echo -e "Step ${steps} - Update password of admin monitor user ${monitorUser}."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   getPyCmd
   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Update the entry
try:
    mod_muser = [
        ( ldap.MOD_REPLACE, 'userPassword', [b"${mPW}"] )
    ]

    # Do the actual modification 
    l.modify_s("cn=${monitorUser},${adminsuffix}",mod_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: Passwod update failed";fi
   set +x
}

##############################################################################
# Update user's password
##############################################################################
updateUserPassword() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   mySuffix="$1"
   cfgProto='ldaps'

   let steps++
   echo -e "Step ${steps} - Update password of ${uType} monitor user ${monitorUser}."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   getPyCmd
   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Update the entry
try:
    mod_muser = [
        ( ldap.MOD_REPLACE, 'userPassword', [b"${mPW}"] )
    ]

    # Do the actual modification 
    l.modify_s("cn=${monitorUser},${mySuffix}",mod_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: Passwod update failed";fi
   set +x
}

##############################################################################
# Delete user
##############################################################################
deleteUser() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   mySuffix="$1"
   cfgProto='ldaps'
   let steps++
   echo -e "Step ${steps} - Delete ${uType} monitor user ${monitorUser}."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   getPyCmd
   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Delete the entry
try:
    # Do the actual modification 
    l.delete_s("cn=${monitorUser},${mySuffix}")

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: User removal failed";fi
   set +x
}

###############################################################################
# Add muser
###############################################################################
addUser() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   case ${dsType} in
       'oud') case ${uType} in
                 'admin') ldpPW="${bPW}"
                          ck4muser=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "${muserDN}" 'base' "objectClass=top" 2>&1|grep "does not exist")
                          if [ -n "${ck4muser}" ]
                          then
                             addOudAdminUser
                          else
                             echo "Admin monitor user ${monitorUser} already exists"
                          fi

                          ck4aci=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "cn=Access Control Handler,cn=config" 'base' "objectClass=top" 2>&1|grep "ds-cfg-global-aci"|grep "dsMonUser")
                          if [ -z "${ck4aci}" ]
                          then
                             addGlobalAci
                          fi
                          ;;
                  'data') ldpPW="${bPW}"
                          ck4muser=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "${muserDN}" 'base' "objectClass=top" 2>&1|grep "does not exist")
                          if [ -n "${ck4muser}" ]
                          then
                             addDataUser "${suffix}"
                             if [ "${eus}" == 'true' ]
                             then
                                addDataUser "cn=OracleContext,${suffix}"
                             fi
                          else
                             echo "Data monitor user ${monitorUser} already exists"
                          fi
                          ;;
                       *) showUsage;;
              esac
              ;;
      'dsee') ldpPW="${bPW}"
              ck4muser=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "${muserDN}" 'base' "objectClass=top" 2>&1|grep "${muserDN} does not exist")
              if [ -z "${ck4muser}" ]
              then
                 case ${uType} in
                    'admin') addDataUser "cn=Administrators,cn=config";addDbAci;;
                     'data') addDataUser "${suffix}";;
                          *) showUsage;;
                 esac
              else
                 case ${uType} in
                    'admin') echo "Admin monitor user ${monitorUser} already exists";;
                     'data') echo "Data monitor user ${monitorUser} already exists";;
                 esac
                 exit 1
              fi
              ;;
           *) showUsage "Invalid DS type"
   esac

   updateCreds
}

##############################################################################
# Update user description to enable/disable maintenance
##############################################################################
showInstanceState() {
   let steps++
   echo -e "Step ${steps} - Show instance state."

   if [ "${dbg}" == 'true' ];then set -x;fi

   instState=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "cn=${monitorUser},cn=config" 'base' "cn=${monitorUser}"|grep "^description:"|awk '{ print $2 }')

   case ${instState} in
      'instanceIsUp') state='UP';;
      'instanceIsMaint') state='MAINT';;
                      *) state='ERROR';;
   esac

   if [ "${state}" == 'ERROR' ]
   then
      showUsage "ERROR: Did not return valid state"
   else
      echo "Instance state is ${state}"
   fi
}

##############################################################################
# Update user description to enable/disable maintenance
##############################################################################
updateInstanceState() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   cfgProto='ldaps'

   case ${subsubcmd} in
      'UP') descValue='instanceIsUp';;
      'MAINT') descValue='instanceIsMaint';;
      *) showUsage "ERROR: Possible state values are UP and MAINT";exit 1;;
   esac

   let steps++
   echo -e "Step ${steps} - Update instance state to ${subsubcmd}."

   if [ "${dbg}" == 'true' ];then set -x;fi

   mstate_log="${logdir}/manage_state-${now}.log"
   touch "${mstate_log}"
   chmod 0600 "${mstate_log}"

   getPyCmd
   ${pycmd} - >> ${mstate_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Update the entry
try:
    mod_mstate = [
        ( ldap.MOD_REPLACE, 'description', [b"${descValue}"] )
    ]

    # Do the actual modification 
    l.modify_s("cn=${monitorUser},cn=config",mod_mstate)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: State change failed";fi
   set +x
}

###############################################################################
# Show muser
###############################################################################
showUser() {
   let steps++
   echo -e "Step ${steps} - Show ${uType} monitor user ${monitorUser}."

   if [ "${dbg}" == 'true' ];then set -x;fi

   if [ "${uType}" == 'admin' ]
   then
      userData=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "cn=${monitorUser},cn=config" 'base' "cn=${monitorUser}"|grep "^dn:")
   elif [ "${uType}" == 'data' ]
   then
      userData=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "${suffix}" 'sub' "cn=${monitorUser}"|grep "^dn:")
   else
      showUsage "ERROR: Invalid user type"
   fi

   if [ -n "${userData}" ]
   then
      echo "User ${monitorUser} exists."
   else
      echo "User ${monitorUser} does not exist."
   fi
}

check_requisites

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
          'help') showUsage;;
         'setup') setup_emitter;;
     'updatecfg') updateConfigs;;
         'query') query_target;;
       'monitor') monitor_target;;
         'start') start_all;;
          'stop') stop_all;;
        'status') status_all;;
     'deinstall') deinstall_exporter;;
        'update') update_node_exporter; update_oud_exporter;;
          'list') list_exporters;;
        'enable') enable_exporter;;
       'disable') disable_exporter;;
         'watch') watch_exporter;;
            'uc') updateCreds;;
            'dc') delCred;;
            'sc') showCreds;showMgmtAgentCreds;;
            'os') query_os;;
       'setupca') setup_ca;;
       'gencert') gen_host_cert;;
       'regenca') regen_ca_cert;;
     'regencert') regen_host_cert;;
      'listkeys') list_keystore;;
       'summary') summarize_keystore;;
      'list-rfc') list_rfc_keystore;;
      'showsudo') showSudoProfile;;
       'adduser') addUser;;
     'moduserpw') updateAdminPassword; updateUserPassword "${suffix}";;
      'modstate') updateInstanceState;;
     'showstate') showInstanceState;;
    'deleteuser') deleteUser "${suffix}";;
      'showuser') showUser;;
               *) showUsage;;
esac
