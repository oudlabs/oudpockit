#!/bin/bash
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

##############################################################################
# $Header: manage_csv2ldif.sh
#
#    NAME
#      manage_csv2ldif.sh
#
#    DESCRIPTION
#      Script to simplify directory services monitoring via OMC
#
##############################################################################
cmd=$(basename $0)

showUsage() {
   echo "Usage: ${cmd} --csvFile <file> --suffix <suffix> [ --rdn <rdn> --oc <objectClass> --ldifFile <file> --overwrite ]"
   echo "        * Default rdn is the first CSV field"
   echo "        * Default file is csv file name with .ldif ending"
   echo "        * --overwrite overwrites the existing .ldif file"
   echo "        * Default objectClass is inetOrgPerson.  Supported objectClasses include the following:"
   echo "           + person"
   echo "           + organizationalPerson"
   echo "           + inetOrgPerson"
   exit 1
}

while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            csvFile) csvFile="$1";;
            ldifFile) ldifFile="$1";;
            rdn) my_rdn="$1";shift;;
            suffix) suffix="$1";shift;;
            pgsz) pgsz="$1";shift;;
            overwrite) overwrite="true";;
        esac;;
        -*) case ${OPT:1} in
            h) showUsage;;
	    z) dbg="true";;
        esac;;
    esac
done

if [ -z "${ldifFile}" ];then ldifFile=$(echo ${csvFile}|sed -e "s/\.csv//g" -e "s/$/.ldif/g");fi

if [ -z "${csvFile}" ];then showUsage;fi
if [ -z "${suffix}" ];then showUsage;fi
if [ -z "${oc}" ];then oc='inetOrgPerson';fi
if [ -z "${pgsz}" ];then pgsz=500;fi

if [ -e "${csvFile}" ];then true; else echo "Error: File ${csvFile} does not exist";exit 1;fi

numLines=$(wc -l ${csvFile}|awk '{ print $1 }')

noc=$(echo ${oc}|tr '[:upper:]' '[:lower:]')

case ${noc} in
   'inetorgperson') ocList="objectClass: top\nobjectClass: person\nobjectClass: organizationalPerson\nobjectClass: inetOrgPerson";;
   'organizationalperson') ocList="objectClass: top\nobjectClass: person\nobjectClass: organizationalPerson";;
   'person') ocList="objectClass: top\nobjectClass: person";;
   *) echo "Error: Do not support objectClass ${oc}"; exit 1;;
esac

# Determine the attribute names from the first line of the CSV file
readarray -t attrNames < <(head -1 ${csvFile}|sed -e "s/\"//g" -e "s/,/ /g" -e "s/ /\n/g")

# Lookup the field number of the specified RDN value
rdnField=0
if [ -n "${my_rdn}" ]
then
   rdn="${my_rdn}"
   rdnField=''
   for (( n=0; n< ${#attrNames[*]}; n++ ))
   do
      if [ "${attrNames[${n}]}" == "${my_rdn}" ];then rdnField=${n};fi
   done

   if [ -z "${rdnField}" ];then echo "RDN name does not match any CSV field names";exit 1;fi
else
   rdn=$(echo ${attrNames[${rdnField}]}|sed -e "s/\"//g")
fi

if [ -e "${ldifFile}" ] && [ "${overwrite}" == 'true' ];then rm -f "${ldifFile}";fi
if [ -e "${ldifFile}" ];then echo "INFO: LDIF file (${ldifFile}) exists.  Appending to this file";fi

echo -e "Converting CSV file to LDIF"
echo -e "   Input CSV File: ${csvFile}"
echo -e "   Output LDIF File: ${ldifFile}"
echo -e "   Progress: 0%.\c"

# Iterate through n pages of ${pgsz} lines of CSV data per page 
l=2
while [ ${l} -lt ${numLines} ]
do
   # Read in ${pgsz} lines of CSV file
   attrValues=( )
   readarray -t attrValues < <(tail -n +${l} ${csvFile}|head -${pgsz}|sed -e "s/^/\"/g" -e "s/$/\"/g" -e "s/,/\",\"/g" -e "s/\"\"/\"/g" -e "s/ /SSPPAACCEE/g" -e "s/	/TTTAAABBB/g")
 
   if [ "${dbg}" == 'true' ];then echo -e "\n\nDEBUG: l=$l | pgsz=$pgsz | Array size=${#attrValues[*]}\n";fi

   # Process each page of CSV data
   for (( n=0; n< ${#attrValues[*]}; n++ ))
   do
      cutField=$((${rdnField}+1))
      rdnVal=$(echo ${attrValues[${n}]}|cut -d',' -f ${cutField}|sed -e "s/SSPPAACCEE/ /g" -e "s/TTTAAABBB/	/g" -e "s/\"//g")
      echo -e "\ndn: ${rdn}=${rdnVal},${suffix}" >> ${ldifFile}

      if [ "${dbg}" == 'true' ];then echo -e "\nDEBUG: dn: ${rdn}=${rdnVal},${suffix}";fi

      echo -e "${ocList}" >> ${ldifFile}

      attrCnt=$(echo ${attrNames[*]}|sed -e "s/,/ /g"|wc -w|sed -e "s/ //g")

      for (( a=0; a< ${attrCnt}; a++ ))
      do
         b=$((${a}+1))
         attrVal=$(echo ${attrValues[${n}]}|cut -d',' -f ${b}|sed -e "s/SSPPAACCEE/ /g" -e "s/TTTAAABBB/	/g" -e "s/\"//g")
         echo -e "${attrNames[${a}]}: ${attrVal}" >> ${ldifFile}
         if [ "${dbg}" == 'true' ];then echo -e "DEBUG: ${attrNames[${a}]}: ${attrVal}";fi
      done
   done
   m=$((100*${l}/${numLines}))
   if   [ ${m} -ge 10 ] && [ ${m} -lt 20 ]
   then
      echo -e "10%.\c"
   elif [ ${m} -ge 20 ] && [ ${m} -lt 30 ]
   then
      echo -e "20%.\c"
   elif [ ${m} -ge 30 ] && [ ${m} -lt 40 ]
   then
      echo -e "30%.\c"
   elif [ ${m} -ge 40 ] && [ ${m} -lt 50 ]
   then
      echo -e "40%.\c"
   elif [ ${m} -ge 50 ] && [ ${m} -lt 60 ]
   then
      echo -e "50%.\c"
   elif [ ${m} -ge 60 ] && [ ${m} -lt 70 ]
   then
      echo -e "60%.\c"
   elif [ ${m} -ge 70 ] && [ ${m} -lt 80 ]
   then
      echo -e "70%.\c"
   elif [ ${m} -ge 80 ] && [ ${m} -lt 90 ]
   then
      echo -e "80%.\c"
   elif [ ${m} -ge 90 ] && [ ${m} -lt 100 ]
   then
      echo -e "90%.\c"
   else
      echo -e ".\c"
   fi

   l=$((${l}+${pgsz}))
done
echo "100%.done"
