#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Define key variables
###############################################################################
adminDN="${bDN}"
dnLdif="${cfgdir}/entrydn.ldif"
dnFile="${cfgdir}/entrydn.list"
logFile="${logdir}/entrydn-${now}.log"
spcvar=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
tabvar=$(head -$((RANDOM % 10000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)

# Pick up where we left off
changeNumber=$(cat ${cfgdir}/.lastChangeNumber 2> /dev/null)
if [ -z "${changeNumber}" ];then changeNumber=0;fi
   
entrydn_checkpoint() {
   # Reset steps counter
   steps=0

   # Start with a fresh entryDN ldif file
   if [ -e "${dnFile}" ];then rm -f "${dnFile}" 2> /dev/null;fi
   if [ -e "${dnLdif}" ];then rm -f "${dnLdif}" 2> /dev/null;fi
   
   # Dump all changelog entries at page size of 250 per result set
   let steps++
   echo "Step ${steps}: Build entryDN candidate list"
   
   # Perform initial sweep of all existing changes in the changelog
   ${oudmwdir}/oud/bin/ldapsearch -T --simplePageSize 250 -h ${localHost} -Z -X -p ${ldapsPort} -D "${adminDN}" -j "${jPW}" -J "1.3.6.1.4.1.26027.1.5.4:false:;" -b "cn=changelog" -s sub "(&(changeNumber>=${changeNumber})(|(changeType=add)(changeType=modrdn)))" targetDN changeNumber 2> /dev/null > ${dnFile}
   rc=$?
   if [ ${rc} -ne 0 ]
   then
      echo "ERROR: Directory server ${localHost}:${ldapsPort} is not available"
      exit 1
   fi
   
   # Read in all DNs from the DN list
   readarray -t dnList <<< $(grep -i "^targetDN: " ${dnFile}|sed -e "s/^targetDN: //gi" -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g") 
   
   # Make LDIF based on DN list
   for (( x=0; x< ${#dnList[*]}; x++ ))
   do
      dn=$(echo "${dnList[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      echo -e "dn: ${dn}\nchangeType: modify\nreplace: entryDN\nentryDN: ${dn}\n" >> ${dnLdif}
   done
   
   # Apply updates
   entryDnCnt=$(grep -c "^targetDN: " ${dnFile} 2> /dev/null|sed -e "s/ //g" -e ':a;s/\B[0-9]\{3\}\>/,&/;ta')
   if [ -z "${entryDnCnt}" ];then entryDnCnt=0;fi
   let steps++
   echo "Step ${steps}: Update ${entryDnCnt} entryDN entries"
   if [ -e "${entryDnFile}" ]
   then
      ${oudmwdir}/oud/bin/ldapmodify -h ${localHost} -Z -X -p ${ldapsPort} -D "${adminDN}" -j "${jPW}" -c -f "${dnLdif}" > ${logFile} 2>&1
      rc=$?
      if [ ${rc} -ne 0 ]
      then
         echo -e "ERROR: Modify failed.  Review log file:\n${logFile}"
         exit 1
      fi
   fi

   # Determine last change number from this sweep
   lastChangeNumber=$(tail ${dnFile}| grep -i "^changeNumber: "|tail -1|awk '{ print $2 }')
   echo ${lastChangeNumber} > ${cfgdir}/.lastChangeNumber

   # Purge temporary files
   let steps++
   echo "Step ${steps}: Clean up temporary files"
   if [ -e "${dnLdif}" ];then rm -f "${dnLdif}" 2> /dev/null;fi
   if [ -e "${dnFile}" ];then rm -f "${dnFile}" 2> /dev/null;fi
   echo "entryDN update complete"
}
   
# Loop forever
while true
do
   entrydn_checkpoint
   sleep 10
done
