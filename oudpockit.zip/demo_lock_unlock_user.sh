#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            suffix) suffix="$1";shift;;
            domain) domain="$1";shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            n) templateName="$1";shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac    
done

###############################################################################
# Usage
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
#if [ -e "${cfgdir}/${templateName}.dn" ]
#then
#   true
#else
#   echo "DN file (${cfgdir}/${templateName}.dn) does not exist."
#   echo "Usage: ${cmd} [-n <template>]"
#   exit 1
#fi

###############################################################################
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi

#ckbatch=$(grep lockout-failure-count ${cfgdir}/${templateName}.batch 2> /dev/null) 
#if [ -n "${ckbatch}" ]
#then
#   true
#else
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= DEMO --> Generate data"
   ${curdir}/manage_data.sh genall -n ${templateName} -N 1 --rm ${dbgFlag}

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= DEMO --> Add password lockout failure count to 2 to batch config"
   echo "set-password-policy-prop --policy-name \"Default Password Policy\" --set lockout-failure-count:2" >> ${cfgdir}/${templateName}.batch
#fi

firstUserDN=$(head -1 ${cfgdir}/${templateName}.dn)

# Setup demo OUD instance
if [ -e "${oudmwdir}/oud30/OUD/bin/start-ds" ]
then
   true
else
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= DEMO --> Setup OUD instance"
   ${curdir}/manage_oud.sh setup --pnum 30 -n ${templateName} --notune --noroles ${dbgFlag}
fi

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO --> Show successful login:"
if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -T -h ${localHost} -Z -X -p 30636 -D "${firstUserDN}" -j "${jPW}" -b "${firstUserDN}" -s sub "objectClass=top" dn
rc=$?; set +x

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO --> Lock account:"
if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -h ${localHost} -Z -X -p 30636 -D "${firstUserDN}" -w 'BadPW' -b "${firstUserDN}" -s sub "objectClass=top" dn
rc=$?;set +x
tail -3 ${oudmwdir}/oud30/OUD/logs/access  | grep authFailureID | sed -e "s/.*authFailureReason=\"//g" -e "s/\".*//g" -e "s/^/   /g" -e "s/^/access log: /g"

if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -h ${localHost} -Z -X -p 30636 -D "${firstUserDN}" -w 'BadPW' -b "${firstUserDN}" -s sub "objectClass=top" dn
rc=$?;set +x
tail -3 ${oudmwdir}/oud30/OUD/logs/access  | grep authFailureID | sed -e "s/.*authFailureReason=\"//g" -e "s/\".*//g" -e "s/^/   /g" -e "s/^/access log: /g"

if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -h ${localHost} -Z -X -p 30636 -D "${firstUserDN}" -w 'BadPW' -b "${firstUserDN}" -s sub "objectClass=top" dn
rc=$?;set +x
tail -3 ${oudmwdir}/oud30/OUD/logs/access  | grep authFailureID | sed -e "s/.*authFailureReason=\"//g" -e "s/\".*//g" -e "s/^/   /g" -e "s/^/access log: /g"

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO --> Unlock account (Set orclAccountStatusEvent to 1 on user):"
if [ "${dbg}" == 'true' ];then set -x;fi
${lmod} -h ${localHost} -Z -X -p 30636 -D "${bDN}" -j "${jPW}" <<EOF
dn: ${firstUserDN}
changetype: modify
replace: orclAccountStatusEvent
orclAccountStatusEvent: 1
EOF

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO --> Show successful login:"
if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -T -h ${localHost} -Z -X -p 30636 -D "${bDN}" -j "${jPW}" -b "${firstUserDN}" -s sub "objectClass=top" dn
rc=$?; set +x
