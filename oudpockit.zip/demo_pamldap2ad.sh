#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            pnum) pnum="$1";shift;;
            ad) adHost="$1";shift;;
            aduser) adUser="$1";shift;;
            aduserpw) adUserPw="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Defaults
###############################################################################
if [ -z "${pnum}" ];then pnum=1;fi
#if [ -z "${adHost}" ];then echo "Must provide --ad <host>";exit 1;fi
if [ -z "${adHost}" ];then adHost="${localHost}";fi
if [ -z "${adUser}" ];then adUser="cn=admin1,cn=Admins,${suffix}";fi
#if [ -z "${adUserPw}" ];then echo "Must provide --aduserpw <user_pw>";exit 1;fi
if [ -z "${adUserPw}" ];then adUserPw="${bPW}";fi

###############################################################################
# If adHost is localHost, then make sure OUD is setup as virtual AD
###############################################################################
if [ "${adHost}" == "${localHost}" ]
then
   if [ -e "${oudmwdir}/oud0/OUD/bin/dsconfig" ]
   then
      echo "OUD AD emulated instance is already setup"
   else
      # Generate data if it doesn't already exist
      if [ -e "${oudmwdir}/cfg/ad.ldif" ]
      then
         true
      else
         echo -e "\nDEMO --> Generate AD data"

         if [ "${dbg}" == 'true' ];then set -x;fi
         ${curdir}/manage_data.sh genall -n ad -N 10 --rm --dnfilter cn=user
         rc=$?;set +x
      fi

      # Setup virtual AD instance
      echo -e "\nDEMO --> Setup an OUD instance to emulate AD"
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_oud.sh setup --pnum 0 -n ad --schema ${curdir}/samples/ad.schema
      rc=$?;set +x
   fi
fi

if [ -e "${oudmwdir}/proxy${pnum}/OUD/bin/dsconfig" ]
then
   echo "OUD proxy${pnum} is already setup"
else
   echo -e "\nDEMO --> Setup OUD proxy instance to AD"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_proxy.sh setup --pnum ${pnum} -n ad --schema ${curdir}/samples/ad.schema --suffix "${suffix}" --nodes "${adHost}:389:636" ${dbgFlag}
   rc=$?;set +x
fi

echo -e "\nDEMO --> Show first user in AD through OUD Proxy"
firstUser=$(head -1 "${cfgdir}/ad.rdn")
if [ -z "${firstUser}" ];then firstUser="cn=user1,cn=Users,${suffix}";fi
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
set -x
${lsrch} -T -h ${localHost} -Z -X -p 1637 -D "${adUser}" -w "${adUserPw}" -b "${suffix}" -s sub "(${firstUser})" dn
