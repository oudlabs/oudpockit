#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

useSSL=''
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done


###############################################################################
# Confirm OUD instances don't already exist
###############################################################################
err='false'
if [ -s "${oudmwdir}/oud1/OUD/bin/start-ds" ]
then
   echo "OUD1 should not exist for this demo"
   err='true'
fi

if [ -s "${oudmwdir}/oud1/OUD/bin/start-ds" ]
then
   echo "OUD2 should not exist for this demo"
   err='true'
fi

if [ "${err}" == 'true' ];then exit 1;fi


###############################################################################
# Generate data
###############################################################################
if [ -e "${cfgdir}/e2.dn" ]
then
   true
else
   echo -e "\nDEMO --> Generate data with e2 template"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_data.sh genall -n e2 -N 10000 --rm
   rc=$?;set +x
fi


###############################################################################
# Add encrypted attribute configuration to batch config
###############################################################################
ck4enc=$(grep set-data-encryption-prop ${cfgdir}/e2.batch 2> /dev/null)
if [ -z "${ck4enc}" ]
then
   echo "set-data-encryption-prop --set enabled:true --set attribute-encryption-include:userssn --set encryption-algorithm:aes-256 --set encrypted-suffix:${suffix}" >> ${cfgdir}/e2.batch
fi


###############################################################################
# Setup first OUD instance
###############################################################################
if [ -e "${oudmwdir}/oud1/OUD/bin/start-ds" ]
then
   true
else
   echo -e "\nDEMO --> Setup first OUD instance with e2 template"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oud.sh setup --pnum 1 -n e2 --schema "${samples}/e2.schema"
   rc=$?;set +x
fi


###############################################################################
# Setup second OUD instance
###############################################################################
if [ -e "${oudmwdir}/oud2/OUD/bin/start-ds" ]
then
   true
else
   echo -e "\nDEMO --> Setup second OUD instance with e2 template"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oud.sh setup --pnum 2 -n e2 --schema "${samples}/e2.schema" --supplier ${localHost}:1444:1989
   rc=$?;set +x
fi


###############################################################################
# Setup second OUD instance
###############################################################################
echo -e "\nDEMO --> Export to LDIF without decrypting encrypted attribute(s)"
if [ "${dbg}" == 'true' ];then set -x;fi
${oudmwdir}/oud1/OUD/bin/export-ldif -n userRoot -l ${tmpdir}/export-encrypted.ldif -h ${localHost} -p 1444 -D "${bDN}" -j "${jPW}" > ${logdir}/export-encrypted-${now}.log 2>&1
rc=$?;set +x

echo -e "\nDEMO --> Export to LDIF with decrypting encrypted attribute(s)"
if [ "${dbg}" == 'true' ];then set -x;fi
${oudmwdir}/oud1/OUD/bin/export-ldif --decrypt -n userRoot -l ${tmpdir}/export-decrypted.ldif -h ${localHost} -p 1444 -D "${bDN}" -j "${jPW}" > ${logdir}/export-decrypted-${now}.log 2>&1
rc=$?;set +x

echo -e "\nDEMO --> Diff the two LDIF exports"
set -x
diff ${tmpdir}/export-encrypted.ldif ${tmpdir}/export-decrypted.ldif | head -10
