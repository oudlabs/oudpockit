#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# manage_data.sh genall -n inetorg -N 10000 --rm
# manage_oud.sh setup --pnum 1 -n inetorg --norepl --noroles
# demo_rest.sh
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            pnum) pnum="$1";shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            n) myTemplate=$1;shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -z "${pnum}" ];then pnum=1;fi

if [ "${pnum}" == '0' ]
then
      ldapPort=389
      httpsPort=443
      adminPort=444
      httpsAdminPort=555
      ldapsPort=636
      replPort=989
else
      ldapPort=${pnum}389
      httpsPort=${pnum}443
      adminPort=${pnum}444
      httpsAdminPort=${pnum}555
      ldapsPort=${pnum}636
      replPort=${pnum}989
fi

if [ -n "${myTemplate}" ];then templateName=${myTemplate};else templateName='inetorg';fi

###############################################################################
# Usage
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
if [ -e "${cfgdir}/${templateName}.rdn" ]
then
   firstUser=$(head -1 "${cfgdir}/${templateName}.rdn")
else
   echo "Template RDN file ${cfgdir}/${templateName}.rdn does not exist"
   echo "Usage: ${0} -n <template>"
   exit 1
fi
set +x

if [ -e "${jPW}" ];then bPW=$(cat ${jPW});fi

echo "DEMO --> REST:"
set -x
   curl -sk "https://${bDN}:${bPW}@${localHost}:${httpsPort}/rest/v1/directory/${suffix}?&scope=sub&filter=${firstUser}&attributes=*"|python -mjson.tool
   rc=$?
set +x

echo "DEMO --> SCIM:"
if [ "${dbg}" == 'true' ];then set -x;fi
#entryUUID=$(curl -sk "https://${bDN}:${bPW}@${localHost}:${httpsPort}/rest/v1/directory/${suffix}?&scope=sub&filter=${firstUser}&attributes=entryUUID"|python -c "import sys,json,urllib;a=json.loads(sys.stdin.read());b=json.dumps(a['searchResultEntries'][0]['attributes']['entryUUID']);print urllib.quote_plus(b.replace('\"', ''))")

entryUUID=$(curl -sk "https://${bDN}:${bPW}@${localHost}:${httpsPort}/rest/v1/directory/${suffix}?&scope=sub&filter=${firstUser}&attributes=entryUUID"|python -mjson.tool|grep -i '"entryUUID"'|cut -d'"' -f4)



if [ -n "${entryUUID}" ]
then
   set -x
      curl -sk "https://${bDN}:${bPW}@${localHost}:${httpsPort}/iam/directory/oud/scim/v1/Users/${entryUUID}"|python -mjson.tool
      rc=$?
   set +x
fi

