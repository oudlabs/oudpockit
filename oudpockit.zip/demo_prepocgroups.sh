#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} --oid <oid_host>:<ldaps_port> --odn <rootdn> --opw <file>

DESCRIPTION
     Sample script to extract OracleContext group memberships

OPTIONS
     Setup Options
     The following options are supported:

         --oid <host:port>       OID host and LDAPS port from which to initialize replica
                                 Default: ${localHost}:3131

         --odn <rootdn>          OID root DN user 
                                 Default: cn=orcladmin

         --opw <pw_file>         Password file for OID rootdn
                                 Default: ${curdir}/.opw

EOF

   exit 1

}

###############################################################################
# Parse arguments
###############################################################################
sDN='cn=orcladmin'
sPW="${cfgdir}/.opw"
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            swdir) swdir="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            suffix) suffix="$1";shift;;
            oid) oidSource="$1";shift;;
            sdn) sDN="$1";shift;;
            spw) sPW="$1";shift;;
            jh) export JAVA_HOME="$1";PATH="$JAVA_HOME:$PATH";shift;;
            prepschema) prepSchema='true';;
            schema) schemaFile="$1";shift;;
            data) dataFile="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            D) bDN="$1";;
            j) jPW="$1";;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Determine defaults
###############################################################################
if [ -z "${prepSchema}" ];then prepSchema='false';fi
schemaOutFile="${curdir}/oidschema.ldif"
dataOutFile="${curdir}/oiddata.ldif"
oudHost=${localHost}
oudPort=6${ldapsPort}

if [ -z "${oudSupplier}" ]
then
   supplierHost=""
   supplierAdmin=""
   snum=""
else
   supplierHost=$(echo "${oudSupplier}:"|cut -d':' -f1)
   supplierAdmin=$(echo "${oudSupplier}:"|cut -d':' -f2)
   if [ -z "${supplierAdmin}" ];then supplierAdmin="${adminPort}";fi
   snum=$(echo "${supplierAdmin}"|sed -e "s/44[45]$//g")
fi

if [ -z "${oidSource}" ]
then
   oidHost=""
   oidPort=""
else
   oidHost=$(echo "${oidSource}:"|cut -d':' -f1)
   oidPort=$(echo "${oidSource}:"|cut -d':' -f2)
   if [ -z "${oidPort}" ];then oidPort='3131';fi
fi

###############################################################################
# Get OracleContext administrative memberships
###############################################################################
let steps++
echo "DEMO Step: ${steps} - Get OID OracleContext administrative group memberships"
if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -T -h ${oidHost} -Z -X -p ${oidPort} -D "${sDN}" -j "${sPW}" -b "${suffix}" -s sub '(&(objectClass=groupOfUniqueNames)(cn:dn:=OracleContext))' uniqueMember|grep -vi "uniqueMember: cn=orcladmin" | sed -e "s/^uniqueMember:/changeType: modify\nadd: uniqueMember\nuniqueMember:/gi" > ${curdir}/oidumembers.ldif 2> ${logdir}/oid-getumembers-${now}.log
rc=$?

${lsrch} -T -h ${oidHost} -Z -X -p ${oidPort} -D "${sDN}" -j "${sPW}" -b "${suffix}" -s sub '(&(objectClass=groupNames)(cn:dn:=OracleContext))' member|grep -vi "member: cn=orcladmin" | sed -e "s/^member:/changeType: modify\nadd: member\nmember:/gi" > ${curdir}/oidmembers.ldif 2> ${logdir}/oid-getmembers-${now}.log
rc=$?
set +x
