#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
clnFile="${cfgdir}/.cln"

###############################################################################
# Lookup last change time
###############################################################################
touch "${clnFile}"
if [ -s "${clnFile}" ]
then
   lastTime="$(cat ${clnFile})"
else
   lastTime="0"
fi

###############################################################################
# Check changelog
###############################################################################
setfmwenv
while true
do
   startTime=$(date +'%Y%m%d%H%M%S')
   readarray -t lastChanges <<< $(${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -J '1.3.6.1.4.1.26027.1.5.4:false:;' -b 'cn=changelog' -s sub "(changeTime>=${lastTime})" targetDN changes changeType|egrep -v "^#|^dn:"|sed -e "s/^$/EOR/g" -e "s/targetDN: //g" -e "s/^changes:: /|/g" -e "s/changeType: /|/gi"|tr -d '[\n\r]'|sed -e "s/EOR/\n/g")

   for (( i=0; i< ${#lastChanges[*]}; i++ ))
   do
      dn=$(echo ${lastChanges[${i}]}|cut -d'|' -f1)
      changes=$(echo ${lastChanges[${i}]}|cut -d'|' -f2|base64 -d 2> /dev/null|egrep -vi "modifiersName|modifyTimestamp|creatorsName|createTimestamp")
      changeType=$(echo ${lastChanges[${i}]}|cut -d'|' -f3)
      if [ -z "${changeType}" ];then changeType=$(echo ${lastChanges[${i}]}|cut -d'|' -f2);fi
      attrs=''
      case ${changeType} in
         'modify') attrs=$(echo "${changes}"|grep "^replace:"|cut -d':' -f2-|sed -e "s/^ /,/g"|egrep -vi "modifersName|modifyTimestamp"|tr -d '[\n\r]'|sed -e "s/^,//g");;
            'add') attrs=$(echo "${changes}"|cut -d':' -f1|sed -e "s/^/,/g"|egrep -vi "modifersName|modifyTimestamp|creatorsName|createTimestamp"|cut -d: -f1|sort|uniq|tr -d '[\n\r]'|sed -e "s/^,//g");;
      esac
      if [ -n "${dn}" ]
      then
         echo -e "POST|dn:${dn}|${changeType}|${attrs}"
      fi
   done
   lastTime="${startTime}"
   echo "${lastTime}" > ${clnFile}
   sleep 10
done
