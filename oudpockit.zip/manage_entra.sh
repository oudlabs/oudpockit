cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################


#!/bin/bash
wDir="$1"
appId="$2"
expiration="$3"
now=$(date +'%Y%m%d%H%M%S')

# Show usage if appId is not provided
if [ -z "${appId}" ]
then
   echo "Usage: $0 <db_client_app_id>"
   exit 1
fi

testLogin=$(az account show 2> /dev/null)
if [ -z "${testLogin}" ]
then
   echo "Login to Auzre for az CLI tool:"
   az login --allow-no-subscriptions --only-show-errors
fi

# Set default expiration at 10 years
if [ -z "${expiration}" ];then expiration=10;fi

# Securely read in the Oracle wallet password
echo -e "Enter wallet password: \c"
while IFS= read -r -s -n1 char
do
  [[ -z $char ]] && { printf '\n'; break; }
  if [[ $char == $'\x7f' ]]
  then
      [[ -n $wpw ]] && wpw=${wpw%?}
      printf '\b \b'
  else
    wpw+=$char
    printf '*'
  fi
done

# Path set from blog post demo
PATH=$PATH:/u01/23ai_fullclient/bin

# Reset secret and capture new password
secret=$(az ad app credential reset --only-show-errors --id ${appId} --display-name app_secret --years ${expiration} 2>> $0-${now}.log |jq -r '.password')
if [ -z "${secret}" ]
then
   echo "ERROR: Failed to create secret. See: $0-${now}.log"
   exit 1
fi

# Create wallet if one does not exist
if [ -e "${wDir}/ewallet.p12" ]
then
   walletOp='modify_entry'
else
   walletOp='create_entry'
   echo "Create wallet ${wDir}"
   orapki wallet create -wallet "${wDir}" -pwd "${wpw}"  -auto_login >> $0-${now}.log 2>&1
fi

# Load the wallet with  the secret
echo "Load secret into wallet"
orapki secretstore ${walletOp} -wallet "${wDir}" -pwd "${wpw}" -alias oracle.security.azure.credential.${appId} -secret "${secret}" >> $0-${now}.log 2>&1
rc=$?

if [ "${rc}" -ne 0 ]
then
   echo "ERROR: Failed to load secret into wallet. See: $0-${now}.log"
   exit 1
fi

echo "Secret loaded into wallet ${wDir}"



###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
   'regserver') register_database_server;;
   'regclient') register_database_server;;
      'rotsec') rotate_secret;;
esac
