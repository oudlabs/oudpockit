#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################
# Set default install type
if [ -z "${subcmd}" ];then subcmd='both';fi

# Set key vars
export oud12c_bits="${curdir}/bits/12c"
export oud14c_bits="${curdir}/bits/14c"

setup_oud12c_instances() {
   # If it doesn't already exist, setup a pair of OUD 12cPS4 instances
   if [ -e "${curdir}/mw_oud12c/oud1/OUD/bin/start-ds" ]
   then
      # OUD instance already exists
      true
   else

     fmwVersion=12c
     export fmwVersion

     echo -e "\nDEMO --> Install OUD 12cPS4 and setup two OUD instances"

     # Extract JDK
     ${curdir}/manage_install.sh extract jdk --12c --bitsdir ${oud12c_bits}

     # Set JAVA_HOME for JDK8
     export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g")

     # Install OUD 12c
     ${curdir}/manage_install.sh install oud --12c --bitsdir ${oud12c_bits} --step 2

     # Generate some data
     ${curdir}/manage_data.sh genall -n inetorg -N 10000 --rm --step 7 --12c

     ${curdir}/manage_oud.sh setup --pnum 1 -n inetorg --step 13 --12c
     ${curdir}/manage_oud.sh setup --pnum 2 -n inetorg --supplier ${localHost}:1444:1989 --step 19 --12c
  fi
}

purge_oud12c_software() {
   if [ -d "${swdir}" ]
   then
      cd ${swdir}
      rm -fr .p[0-9]*.extracted [0-9]* fmw_*
   fi
}

extract_oud14c() {
   echo -e "\nDEMO --> Extract JDK 21, OUD 14c and OUD 14c patches:"
   set -x
   cd ${swdir}
   tar -zxf ${oud14c_bits}/jdk-21_linux-x64_bin.tar.gz
   rc=$?
   unzip -qo ${oud14c_bits}/V1048467-01.zip
   rc=$?
   unzip -qo ${oud14c_bits}/p37376076_141200_Generic.zip
   rc=$?
   unzip -qo ${oud14c_bits}/p38015961_141200_Generic.zip
   rc=$?
   unzip -qo ${oud14c_bits}/p38032733_141210_Generic.zip
   rc=$?
   unzip -qo ${oud14c_bits}/p38130086_141200_Generic.zip
   rc=$?

   set +x
}

make_config_files() {
   echo
   echo -e "\nDEMO --> Make Oracle inventory config file:"
   echo "cat  ${cfgdir}/oraInventory.loc"
   cat ${cfgdir}/oraInventory.loc

   echo -e "\nDEMO --> Make OUD 14c response file:"
   cat > ${cfgdir}/oud14c-standalone.rsp <<EOF
[ENGINE] 
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${curdir}/${my_mwhome}
INSTALL_TYPE=Standalone Oracle Unified Directory Server (Managed independently of WebLogic server)
EOF

   echo "cat  ${cfgdir}/oud14c-standalone.rsp"
   cat  ${cfgdir}/oud14c-standalone.rsp
}

show_oud_version() {
   instNum=$1
   if [ -z "${instNum}" ];then instNum=1;fi
   echo -e "\nDEMO --> Show OUD version:"
   set -x
   ${curdir}/${my_mwhome}/oud${instNum}/OUD/bin/start-ds --version |tee -a ${logdir}/oud14c-upgrade-${now}.log 2>&1
   set +x
}

stop_oud12c_instances() {
   echo -e "\nDEMO --> Stop OUD 12c instances:"
   set -x
   export ORACLE_HOME="${curdir}/mw_oud12c"
   $ORACLE_HOME/oud1/OUD/bin/stop-ds >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   $ORACLE_HOME/oud2/OUD/bin/stop-ds >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x
}

backup_oud12c() {
   echo -e "\nDEMO --> Backup OUD 12c middlware home"
   set -x
   cd ${curdir}
   tar -czf ${curdir}/${my_mwhome}-${now}.tgz --exclude oud1 --exclude oud2 ${my_mwhome}
   rc=$?
   set +x

   echo -e "\nDEMO --> Backup existing OUD 12c instances:"
   set -x
   export ORACLE_HOME="${curdir}/mw_oud12c"
   cd $ORACLE_HOME
   tar -czf ${curdir}/oud1-${now}.tgz oud1
   rc=$?
   tar -czf ${curdir}/oud2-${now}.tgz oud2
   rc=$?
   set +x
}

deinstall_oud12c() {
   echo -e "\nDEMO --> Deinstall OUD 12c:"
   set -x
   export ORACLE_HOME=${curdir}/mw_oud12c
   $ORACLE_HOME/oui/bin/deinstall.sh -silent -distributionName 'Oracle Unified Directory' >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x
   if [ $rc -eq 0 ]
   then
      bmwdir=$(cd ${ORACLE_HOME}/..; pwd)
      set -x
      cd ${bmwdir}
      mv mw_oud12c mw_oud12c.${now}
      set +x
   else
      echo "ERROR: Deinstall failed. See ${logdir}/oud14c-upgrade-${now}.log"
      exit 1
   fi
   set +x
}

install_oud14c() {
   echo -e "\nDEMO --> Install OUD 14c"
   set -x
   $JAVA_HOME/bin/java -Djava.io.tmpdir=${tmpdir} -jar ${swdir}/fmw_14.1.2.1.0_oud.jar -silent -ignoreSysPrereqs -responseFile ${cfgdir}/oud14c-standalone.rsp -invPtrLoc ${cfgdir}/oraInventory.loc >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x
}

setup_swing_instance() {
   echo -e "\nDEMO --> Setup new OUD 14c instance (oud3)"
   set -x
   export ORACLE_HOME="${curdir}/mw_oud14c"
   $ORACLE_HOME/oud/oud-setup --cli --integration no-integration --instancePath $ORACLE_HOME/oud3/OUD --adminConnectorPort 3444 --ldapPort 3389 --ldapsPort 3636 --httpAdminConnectorPort 3555 --httpPort disabled --httpsPort 3443 --baseDN "${suffix}" --rootUserDN "${bDN}" --addBaseEntry --enableStartTLS --useJavaKeystore ${cfgdir}/certs/${localHost}/${localHost}.jks --keyStorePasswordFile ${cfgdir}/certs/${localHost}/${localHost}.pin --certNickname server-cert --hostName ${localHost} --noPropertiesFile >> ${logdir}/oud14c-upgrade-${now}.log 2>&1 <<EOF
${bPW}
${bPW}
2
2
yes
1
EOF
   rc=$?
   set +x

   echo -e "\nDEMO --> Enable DS+RS replication (oud3)"
   set -x
   export ORACLE_HOME="${curdir}/mw_oud14c"
   $ORACLE_HOME/oud3/OUD/bin/dsreplication enable --secureReplication1 --secureReplication2 --host1 ${localHost} --port1 1444 --bindDN1 "${bDN}" --bindPasswordFile1 ${jPW} --bindPasswordFile2 ${jPW} --replicationPort1 1989 --host2 ${localHost} --port2 3444 --bindDN2 "${bDN}" --replicationPort2 3989 --baseDN "${suffix}" --adminUID admin --adminPasswordFile ${jPW} --trustAll --noPropertiesFile --no-prompt >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x

   echo -e "\nDEMO --> Initialize from supplier poc (oud3)"
   set -x
   $ORACLE_HOME/oud3/OUD/bin/dsreplication initialize --hostSource ${localHost} --portSource 1444 --portProtocolSource auto-detect --hostDestination ${localHost} --portDestination 3444 --portProtocolDestination auto-detect --baseDN dc=example,dc=com --adminUID admin --adminPasswordFile "${jPW}" --trustAll --no-prompt >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x
}

upgrade_existing_oud12c_instances() {
   echo -e "\nDEMO --> Restore OUD 12c instances into middleware home:"
   set -x
   cd ${curdir}/${my_mwhome}
   tar -xzf ${curdir}/oud1-${now}.tgz
   rc=$?
   tar -xzf ${curdir}/oud2-${now}.tgz
   rc=$?
   set +x

   echo -e "\nDEMO --> Update JDK references in oud1 instance scripts"
   set -x
#   export JAVA_HOME=${J21Home}
   ${curdir}/mw_oud12c/oud/bin/upgrade-oud-instances --instancePath ${curdir}/${my_mwhome}/oud1 >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x

   show_oud_version 1

   echo -e "\nDEMO --> Upgrade OUD 14c oud1 instance data:"
   set -x
   ${curdir}/${my_mwhome}/oud1/OUD/bin/start-ds --upgrade >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x

   echo -e "\nDEMO --> Start OUD 14c oud1 instance:"
   set -x
   ${curdir}/${my_mwhome}/oud1/OUD/bin/start-ds >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x

   echo -e "\nDEMO --> Update JDK references in oud2 instance scripts"
   set -x
#   export JAVA_HOME=${J21Home}
   ${curdir}/mw_oud12c/oud/bin/upgrade-oud-instances --instancePath ${curdir}/mw_oud12c/oud2 >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x

   echo -e "\nDEMO --> Upgrade OUD 14c oud2 instance data:"
   set -x
   ${curdir}/${my_mwhome}/oud2/OUD/bin/start-ds --upgrade >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x

   echo -e "\nDEMO --> Start OUD 14c oud1 instance:"
   set -x
   ${curdir}/${my_mwhome}/oud2/OUD/bin/start-ds >> ${logdir}/oud14c-upgrade-${now}.log 2>&1
   rc=$?
   set +x
}

show_replication() {
   export ORACLE_HOME="${curdir}/mw_oud12c"
   echo -e "\nDEMO --> Show OUD replication status"
   set -x
   $ORACLE_HOME/oud1/OUD/bin/dsreplication status --dataToDisplay compact-view --hostname ${localHost} --port 1444 --portProtocol auto-detect --adminPasswordFile ${jPW} --bindDN "${bDN}" --trustAll --no-prompt --connectTimeout 1000000 --readTimeout 1000000 
   rc=$?
   set +x
}

show_search() {
   searchPort=$1
   if [ -z "${searchPort}" ];then searchPort=1636;fi

   firstUser=$(head -1 "${cfgdir}/inetorg.rdn")
   echo -e "\nDEMO --> Show OUD search for user ${firstUser}"
   set -x
   $ORACLE_HOME/oud1/OUD/bin/ldapsearch -T -h ${localHost} -Z -X -p ${searchPort} -D "${bDN}" -j ${jPW} -b "${suffix}" -s sub "(${firstUser})"  dn
   rc=$?
   set +x
}

# Iterate through each use case
case ${subcmd} in
  'existinghome') setup_oud12c_instances
                  my_mwhome='mw_oud12c'
                  show_oud_version 1
                  purge_oud12c_software
                  extract_oud14c
                  JAVA_HOME=$(ls -r1 ${swdir}/jdk-21*/bin/java ${swdir}/jdk-17*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g")
                  my_mwhome='mw_oud12c'
                  make_config_files
                  stop_oud12c_instances
                  backup_oud12c
                  deinstall_oud12c
                  install_oud14c
                  upgrade_existing_oud12c_instances
                  show_oud_version 1
                  show_oud_version 2
                  show_replication
                  show_search 1636
                  ;;
         'swing') setup_oud12c_instances
                  my_mwhome='mw_oud12c'
                  show_oud_version 1
                  purge_oud12c_software
                  extract_oud14c
                  JAVA_HOME=$(ls -r1 ${swdir}/jdk-21*/bin/java ${swdir}/jdk-17*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g")
                  my_mwhome='mw_oud14c'
                  make_config_files
                  install_oud14c
                  setup_swing_instance
                  show_oud_version 3
                  show_replication
                  show_search 3636
                  ;;
          'both') # First swing
                  setup_oud12c_instances
                  echo -e "\nDEMO --> First, do a swing migration by adding a 3rd OUD 14c instance in a new OUD 14c middlware home"
                  my_mwhome='mw_oud12c'
                  show_oud_version 1
                  purge_oud12c_software
                  extract_oud14c
                  JAVA_HOME=$(ls -r1 ${swdir}/jdk-21*/bin/java ${swdir}/jdk-17*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g")
                  my_mwhome='mw_oud14c'
                  make_config_files
                  install_oud14c
                  setup_swing_instance
                  show_replication
                  show_search 3636

                  # Then, upgrade existing instances
                  echo -e "\nDEMO --> Next, migrate existing OUD 12c instances to OUD 14c"
                  stop_oud12c_instances
                  backup_oud12c
                  deinstall_oud12c
                  my_mwhome='mw_oud12c'
                  install_oud14c
                  upgrade_existing_oud12c_instances
                  show_oud_version 1
                  show_oud_version 2
                  my_mwhome='mw_oud14c'
                  show_oud_version 3
                  show_replication
                  show_search 1636
                  ;;
       'cleanse') set -x
                  export fmwVersion=14c
                  ${curdir}/manage_oud.sh deinstall
                  export fmwVersion=12c
                  ${curdir}/manage_oud.sh deinstall
                  cd ${curdir}
                  rm -fr mw_* sw cfg *.tgz logs tmp
                  unset fmwVersion
                  set +x
                  ;;
               *) echo "ERROR: Invalid submcommad. Valid options: swing or existinghome"; exit 1;;
esac
