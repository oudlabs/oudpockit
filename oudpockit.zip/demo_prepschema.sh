#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# The purpose of this demo is to prepare source schema for loading into OUD
###############################################################################
unset JAVA_TOOL_OPTIONS
schemaLog="${logdir}/schematest-${now}.log"
instdir="${oudmwdir}/oud60/OUD"
schemadir="${instdir}/config/schema"
oudschemadir="${oudmwdir}/oud/config/schema"
useSSL=''
schemaFiles=( )
atCnt=0
atMaxCnt=0
ocCnt=0
ocMaxCnt=0
filteredIn='false'
filteredOut='false'

# Define special characters for beginning of line, attribute, and objectclass
begvar=$(head -$((RANDOM % 3000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
ocvar=$(head  -$((RANDOM % 4000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
atvar=$(head  -$((RANDOM % 5000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [options]

SYNOPSIS
     Prepare schema file:
        ${cmd} --schema /<path>/<schema_file> [Options]

     Prepare all schema files in a directory:
        ${cmd} --schemadir /<schema_directory> [Options]

     Prepare schema from source directory server from LDAP query:
        ${cmd} -h <host> -p <ldap_port> [-Z] [Options]

DESCRIPTION
     Custom schema preparation tool for migrating to OUD.

OPTIONS
     Options
     The following options are supported:

         --debug [-z]            Debug mode

         --norm                  Do not remove the temporary files from 

         --in                    List schema to be added to OUD

         --out                   List schema filtered out from being added to OUD

         --schema /<dir>/<file>  Custom schema file

         --schemadir /<dir>      Directory containing multiple schema files

         --host [-h]             Host of the source directory

         --port [-p]             LDAP port of the source directory

         --useSSL [-Z]           Use SSL/TLS connection to source directory

         --sdn                   Source directory DN
                                 Default: Anonymous DN

         --spw                   Source directory password file

EOF

   exit 1
}
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
   OPT=$1
   shift
   case $OPT in
       --*) case ${OPT:2} in
           help) showUsage;;
           swdir) swdir="$1";shift;;
           bitsdir) bitsdir="$1";shift;;
           schema) schemaIn="$1";shift;;
           schemadir) schemaDirIn="$1";shift;;
           host) dsHost="$1";shift;;
           port) dsPort="$1";shift;;
           sdn) srcDN="$1";shift;;
           spw) srcPW="$1";shift;;
           useSSL) useSSL='-Z -X';;
           in) filteredIn='true';;
           out) filteredOut='true';;
           outfile) outputFile='true';;
           dstype) dsType="$1";shift;;
           norm) norm='true';;
           debug) dbg="true";dbgFlag=' -z ';;
           14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
       esac;;
       -*) case ${OPT:1} in
           h) dsHost="$1";shift;;
           p) dsPort="$1";shift;;
           Z) useSSL='-Z -X';;
           H) showUsage;;
           z) dbg="true";dbgFlag=' -z ';;
       esac;;
   esac
done

if [ -z "${schemaIn}" ];then schemaIn="${tmpdir}/mySchema-v0-${now}.ldif";fi
sName=$(basename ${schemaIn})
if [ -z "${srcDN}" ];then srcDN='cn=orcladmin';fi
if [ -z "${srcPW}" ];then srcPW="${cfgdir}/.spw";fi

###############################################################################
# Make sure JDK/FMW/OUD are installed
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_install.sh install oud --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag} --step ${steps}
set +x

###############################################################################
# If host/port provided, retrieve the schema via ldapsearch
###############################################################################
if [ -n "${dsHost}" ] && [ -n "${dsPort}" ]
then
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Retrieve custom schema from directory server (${dsHost}:${dsPort})"
   if [ "${dbg}" == 'true' ];then set -x;fi

   # Check for most common schema
   if [ "${dbg}" == 'true' ];then set -x;fi
   touch ${schemaIn}
   ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} -b "cn=schema" -s base '(|(objectClass=ldapSubEntry)(objectClass=subSchema)(cn=schema)(cn=subSchemaSubentry)(cn=subschema))' attributeTypes objectClasses attributeType objectClass 2> /dev/null |egrep -i "^obj|^attr"|grep -i " NAME " > ${schemaIn}
   rc=$?
   set +x

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -s "${schemaIn}" ]
   then
      true
   else
      ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} -b "cn=schema" -s base 'objectClass=ldapSubEntry' attributeTypes objectClasses attributeType objectClass 2> /dev/null |egrep -i "^obj|^attr"|grep -i " NAME " > ${schemaIn}
      rc=$?
      set +x
   fi

   # Check for OID schema
   if [ -s "${schemaIn}" ]
   then
      true
   else

      if [ -n "${srcDN}" ] && [ -s "${srcPW}" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} ${oidCreds} -D "${srcDN}" -j "${srcPW}" -b "cn=subSchemaSubentry" -s base '(|(objectClass=ldapSubEntry)(objectClass=subSchema)(cn=schema)(cn=subSchemaSubentry)(cn=subschema))' attributeTypes objectClasses attributeType objectClass 2>&1 |egrep -i "^obj|^attr|deny anonymous bind"|egrep -i " NAME |deny anonymous bind" > ${schemaIn}
         rc=$?
         set +x
      else
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} ${oidCreds} -b "cn=subSchemaSubentry" -s base '(|(objectClass=ldapSubEntry)(objectClass=subSchema)(cn=schema)(cn=subSchemaSubentry)(cn=subschema))' attributeTypes objectClasses attributeType objectClass 2>&1 |egrep -i "^obj|^attr|deny anonymous bind"|egrep -i " NAME |deny anonymous bind" > ${schemaIn}
         rc=$?
         set +x
      fi

      ck4anon=$(grep 'Server is Configured to Deny Anonymous Binds' ${schemaIn})
      if [ ${rc} -ne 0 ] && [ -s "${schemaIn}" ] && [ -n "${ck4anon}" ] 
      then
         echo "ERROR: OID is configured to deny anonymous bind.  Please provide"
         echo "   --sdn <binddn> --spw <bindpw_file>"
         exit 1
      elif [ ${rc} -ne 0 ] && [ -e "${schemaIn}" ] && [ -z "${ck4anon}" ] && [ -n "${srcDN}" ] && [ -n "${srcPW}" ] 
      then
         echo "ERROR: Invalid OID credentials"
         echo "   --sdn <binddn> --spw <bindpw_file>"
         exit 1
      fi
   fi

   # Check for OpenLDAP schema
   if [ -s "${schemaIn}" ]
   then
      true
   else
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} -b "cn=subschema" -s base '(|(objectClass=ldapSubEntry)(objectClass=subSchema)(cn=schema)(cn=subSchemaSubentry)(cn=subschema))' attributeTypes objectClasses attributeType objectClass 2> /dev/null |egrep -i "^obj|^attr"|grep -i " NAME " > ${schemaIn}
      rc=$?
      set +x
   fi

   if [ -s "${schemaIn}" ]
   then
      schemaFiles[0]="${schemaIn}"
   else
      echo "Error: Input schema file (${sName}) from ldapsearch is empty."
      exit 1
   fi
fi

# Handle specifying a schema directory
if [ -n "${schemaDirIn}" ]
then
   if [ -d "${schemaDirIn}" ]
   then
      readarray -t schemaFiles < <(ls -1 ${schemaDirIn}/* 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")
   else
      echo "Schema directory is not a directory."
      exit 1
   fi
else
   # Handle specifying a specific schema file
   if [ -e "${schemaIn}" ]
   then
      if [ -s "${schemaIn}" ]
      then
         schemaFiles[0]="${schemaIn}"
      else
         echo "Error: schema file (${schemaIn}) is empty"
         exit 1
      fi
   else
      echo "Error: schema file (${schemaIn}) does not exist"
      exit 1
   fi
fi

###############################################################################
# Confirm that custom schema exists
###############################################################################
if [ ${#schemaFiles[*]} -eq 0 ]
then
   echo "Error: No custom schema found"
   exit 1
fi

###############################################################################
# Setup OUD instance for schema testing on port 60389
###############################################################################
if [ -e "${instdir}/bin/start-ds" ]
then
   true
else
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Setup OUD instance for schema testing"
   case ${dsType} in
      'oid') ${curdir}/manage_oud.sh setup --pnum 60 --norestart --noroles --norepl --schema ${curdir}/samples/oid.schema --nobatch ${dbgFlag};;
          *) ${curdir}/manage_oud.sh setup --pnum 60 --norestart --noroles --norepl --noschema --nobatch ${dbgFlag};; 
   esac
fi

###############################################################################
# Set JAVA_HOME if not already set
###############################################################################
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi

###############################################################################
# Load default schema into respective arrays
###############################################################################
ck4schema=$(ls -1 ${oudschemadir}/* 2> /dev/null)
if [ -z "${ck4schema}" ]
then
   echo "Error: There is no default schema in ${oudschemadir}"
   exit 1
else
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Read default OUD schema"
   readarray -t defaultSchema < <(egrep -hv "^#|^$"  ${oudschemadir}/*.ldif ${oudmwdir}/oud60/OUD/config/schema/* 2> /dev/null|sed -e "s/^ //g" -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g"|tr -d '[\n\r]'|sed -e "s/attribute[Tt]ypes:/\nattributeTypes:/g" -e "s/object[Cc]lasses:/\nobjectClasses:/g" -e "s/attribute[Tt]ype:/attributeTypes:/g" -e "s/object[Cc]lass:/objectClasses:/g"|egrep "attributeTypes:|objectClasses:")

   a=0
   b=0
   for (( x=0; x< ${#defaultSchema[*]}; x++ ))
   do
      schema=$(echo "${defaultSchema[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      # Lookup OIDs
      defaultOids[${x}]=$(echo "${schema}"|awk '{ print $3 }'|grep "^[0-9]")

      # Determine if schema is an attribute or objectClass
      ck4attr=$(echo -e "${schema}"|grep -i "attributeTypes:")
      ck4oc=$(echo -e "${schema}"|grep -i "objectClasses:")

      # Lookup Attributes
      if [ -n "${ck4attr}" ]
      then
         attr=$(echo "${schema}"|grep " NAME '"|sed -e "s/^.*NAME '//g" -e "s/'.*//g")
         if [ -n "${attr}" ]
         then
            defaultAttrs[${a}]="${attr}"
            let a++
         fi

         mattrs=$(echo "${schema}"|grep "NAME ("|sed -e "s/^.*NAME (//g" -e "s/).*//g" -e "s/'//g")
         if [ -n "${mattrs}" ]
         then
            for attr in ${mattrs}
            do
               defaultAttrs[${a}]="${attr}"
               let a++
            done
         fi
      elif [ -n "${ck4oc}" ]
      then
         oc=$(echo "${schema}"|grep " NAME '"|sed -e "s/^.*NAME '//g" -e "s/'.*//g")
         if [ -n "${oc}" ]
         then
            defaultOCs[${b}]="${oc}"
            let b++
         else
            moc=$(echo "${schema}"|grep " NAME ("|sed -e "s/^.*NAME *//g" -e "s/).*//g" -e "s/'//g")
            if [ -n "${moc}" ]
            then
               for oc in ${moc}
               do
                  defaultOCs[${b}]="${oc}"
                  let b++
               done
            fi
         fi
      fi
   done
fi

###############################################################################
# Process each custom schema file
###############################################################################
if [ ${#schemaFiles[*]} -gt 1 ]
then
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Read in and pre-screen custom schema"
fi

maxf=${#schemaFiles[*]}
numf=1
for (( x=0; x< ${#schemaFiles[*]}; x++ ))
do
   schemaIn=$(echo "${schemaFiles[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
   filename=$(basename ${schemaIn})
   echo "--> Process schema file ${numf} of ${maxf} (${filename}):"
   if [ "${filteredIn}" == 'false' ] && [ "${filteredOut}" == 'false' ];then echo -e "Progress.\c";fi

   # Determine next schema file version
   v=1
   foundNextFile='false'
   while [ "${foundNextFile}" != 'true'  ] && [ ${v} -lt 100 ]
   do
      if [ -e "${tmpdir}/mySchema-v${v}.schema" ]
      then
         true
      else
         schemaOut="${tmpdir}/mySchema-v${v}.schema"
         foundNextFile='true'
      fi
      let v++
   done

   readarray -t customSchema < <(cat ${schemaIn}|sed -e "s/^#.*//g" -e "s/^nss.*//gi" -e "s/^dn: .*//g" -e "s/^cn: .*//g" -e "s/^objectclass: .*//gi" -e "s/^search: .*//g" -e "s/^changetype: .*//gi" -e "s/^add: .*//gi" -e "s/ds-sync-generation-id: .*//gi" -e "s/^modifiersName: .*//gi" -e "s/^modifyTimestamp: .*//gi" -e "s/^ds-sync-state: .*//gi" -e "s/^result: .*//g" -e "s/ objectClass \\$/ oobbjjeeccttccllaass $/gi" -e "s/\\$ objectClass /$ oobbjjeeccttccllaass /gi" -e "s/ attributeTypes \\$/ aattrriibbuutteettyyppeess $/gi" -e "s/\\$ attributeTypes /$ aattrriibbuutteettyyppeess /gi" -e "s/^attribute[Tt]ypes=/${atvar}: /g" -e "s/^object[Cc]lasses=/${ocvar}: /g" -e "s/^object[Cc]lass: [tls].*//g" -e "s/^ //g" -e "s/^/${begvar}/g" -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/${begvar}${tabvar}/${spcvar}/g" -e "s/${begvar}object[Cc]lass${spcvar}/${begvar}${ocvar}:${spcvar}/g" -e "s/${begvar}object[Cc]lasses:/${begvar}${ocvar}:/g" -e "s/${begvar}attribute[Tt]ype${spcvar}/${begvar}${atvar}:${spcvar}/g" -e "s/${begvar}attribute[Tt]ypes/${begvar}${atvar}/g" -e "s/${tabvar}/${spcvar}/g"|tr -d '[\n\r]'|sed -e "s/${begvar}${ocvar}/\n${begvar}${ocvar}/g" -e "s/${begvar}${atvar}/\n${begvar}${atvar}/g"|egrep "${begvar}${ocvar}|${begvar}${atvar}"|sed -e "s/${begvar}${ocvar}/${begvar}objectClasses/g" -e "s/${begvar}${atvar}/${begvar}attributeTypes/g" -e "s/${begvar}//g" -e "s/oobbjjeeccttccllaass/objectClass/g" -e "s/aattrriibbuutteettyyppeess/attributeTypes/g" -e "s/${spcvar}${spcvar}${spcvar}${spcvar}/${spcvar}/g" -e "s/${spcvar}${spcvar}${spcvar}/${spcvar}/g" -e "s/${spcvar}${spcvar}/${spcvar}/g")

   a=0
   b=0
   for (( y=0; y< ${#customSchema[*]}; y++ ))
   do
      oidMatch='false'
      attrMatch='false'
      ocMatch='false'

      # Determine if schema is an attribute or objectClass
      schema=$(echo "${customSchema[${y}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      ck4attr=$(echo -e "${schema}"|grep -i "attributeTypes:")
      ck4oc=$(echo -e "${schema}"|grep -i "objectClasses:")

      # Check for Attr Match
      if [ -n "${ck4attr}" ]
      then
         stype='AT'
         ck4enc=$(echo -e "${schema}"|grep -i "^attributeTypes:: ")
         if [ -n "${ck4enc}" ]
         then
            encAttr=$(echo -e "${schema}"|sed -e "s/^attributeTypes:: //gi")
            encAttr=$(${instdir}/bin/base64 decode -d "${encAttr}")
            schema="attributeTypes: ${encAttr}"
            schema=$(echo "${schema}"|sed -e "s/    / /g" -e "s/   / /g" -e "s/  / /g")
         fi

         # Handle SYNTAX formatting differences
         ck4s=$(echo "${schema}"|grep "SYNTAX '")
         if [ -n "${ck4s}" ]
         then
            sid=$(echo "${schema}"|grep -i " SYNTAX "|sed -e "s/^.* SYNTAX//gi"|cut -d"'" -f2)
            if [ -n "${sid}" ];then schema=$(echo "${schema}"|sed -e "s/'${sid}'/${sid}/g");fi
         fi

         # Handle SYNTAX oids that OUD does not support
         ck4syn=$(echo "${schema}"|egrep "1.3.6.1.4.1.1466.115.121.1.1|1.3.6.1.4.1.4203.1.1.1|1.3.6.1.4.1.4203.666.2.1")
         if [ -n "${ck4syn}" ]
         then
            for sid in 1.3.6.1.4.1.1466.115.121.1.1 1.3.6.1.4.1.4203.1.1.1 1.3.6.1.4.1.4203.666.2.1
            do
               schema=$(echo "${schema}"|sed -e "s/'${sid}'/1.3.6.1.4.1.1466.115.121.1.15/g")
               schema=$(echo "${schema}"|sed -e "s/ ${sid} / 1.3.6.1.4.1.1466.115.121.1.15 /g")
            done
         fi

         # Handle CA asterisk (*) attribute
         ck4ast=$(echo "${schema}"|grep ' 2.1103 ')
         if [ -n "${ck4ast}" ]
         then
            schema=''
         fi

         # Handle OID <attr>;binary attribute syntax
         ck4bin=$(echo "${schema}"|grep ';binary')
         if [ -n "${ck4bin}" ]
         then
            schema=$(echo "${schema}"|sed -e "s/;binary//gi")
         fi

         # Handle OpenLDAP funky attribute naming
         ck4wfu=$(echo "${schema}"|grep -i "wfuProductionAttr:")
         if [ -n "${ck4wfu}" ]
         then
            schema=$(echo "${schema}"|sed -e "s/wfuProductionAttr:/wfuProductionAttr/gi")
         fi

         # Handle attribute superior formatting differences
         ck4s=$(echo "${schema}"|grep -i " SUP '")
         if [ -n "${ck4s}" ]
         then
            sid=$(echo "${schema}"|sed -e "s/.* SUP //gi"|cut -d"'" -f2)
            if [ -n "${sid}" ];then schema=$(echo "${schema}"|sed -e "s/SUP '${sid}'/SUP ${sid}/gi");fi
         fi

         # Handle matching rule differences
         schema=$(echo "${schema}"|sed -e "s/ORDERING caseExactIA5OrderingMatch//gi" -e "s/ORDERING caseIgnoreIA5OrderingMatch//gi" -e "s/ORDERING caseIgnoreMatch/ORDERING caseIgnoreOrderingMatch/gi" -e "s/EQUALITY accessDirectiveMatch//gi" -e "s/EQUALITY caseIgnoreSubStringsMatch/EQUALITY caseIgnoreMatch/gi" -e "s/SUBSTR caseIgnoreMatch/SUBSTR caseIgnoreSubstringsMatch/gi" -e "s/SUBSTR distinguishedNameMatch//gi" -e "s/EQUALITY OpenLDAPaciMatch/EQUALITY caseIgnoreMatch/gi")

         # Address all quoted OUD supported rules
         schema=$(echo "${schema}"|sed -e "s/'top'/ top /gi" -e "s/SUP ( 'top' )/SUP top/gi" -e "s/'caseExactMatch'/caseExactMatch/gi" -e "s/'caseIgnoreMatch'/caseIgnoreMatch/gi" -e "s/'caseIgnoreOrderingMatch'/caseIgnoreOrderingMatch/gi" -e "s/'caseExactSubstringsMatch'/caseExactSubstringsMatch/gi" -e "s/'caseIgnoreSubstringsMatch'/caseIgnoreSubstringsMatch/gi" -e "s/'distinguishedNameMatch'/distinguishedNameMatch/gi" -e "s/'caseIgnoreIA5Match'/caseIgnoreIA5Match/gi" -e "s/'integerOrderingMatch'/integerOrderingMatch/gi" -e "s/'caseIgnoreSubstringsMatch'/caseIgnoreSubstringsMatch/gi" -e "s/'caseIgnoreIA5SubstringsMatch'/caseIgnoreIA5SubstringsMatch/gi" -e "s/'booleanMatch'/booleanMatch/gi" -e "s/'generalizedTimeMatch'/generalizedTimeMatch/gi" -e "s/'integerMatch'/integerMatch/gi" -e "s/'octetStringMatch'/octetStringMatch/gi" -e "s/'caseExactIA5Match'/caseExactIA5Match/gi" -e "s/'caseExactIA5SubstringsMatch'/caseExactIA5SubstringsMatch/gi" -e "s/'objectIdentifierMatch'/objectIdentifierMatch/gi" -e "s/'generalizedTimeOrderingMatch'/generalizedTimeOrderingMatch/gi" -e "s/'caseIgnoreListSubstringsMatch'/caseIgnoreListSubstringsMatch/gi" -e "s/'telephoneNumberSubstringsMatch'/telephoneNumberSubstringsMatch/gi" -e "s/'numericStringSubstringsMatch'/numericStringSubstringsMatch/gi" -e "s/'numericStringMatch'/numericStringMatch/gi" -e "s/'presentationAddressMatch'/presentationAddressMatch/gi" -e "s/'protocolInformationMatch'/protocolInformationMatch/gi")

         # Filter out ACIs
         schema=$(echo "${schema}"|sed -e "s/aci:.*//g")

         # Filter out XSD
         schema=$(echo "${schema}"|sed -e "s/<xsd:.*//gi" -e "s/<\/xsd:.*//gi" -e "s/<definitions.*//gi" -e "s/nsSchemaCSN:.*//gi" -e "s/xmlns:.*//g" -e "s/xmlsns=.*//g" -e "s/<types>//g" -e "s/\?xml .*//g")

         # Address all quoted OUD supported rules
         schema=$(echo "${schema}"|sed -e "s/USAGE User /USAGE userApplications /gi" -e "s/userApplications Applications/userApplications/gi" -e "s/USAGE user Applications/USAGE userApplications/gi" )

         schemaname=$(echo "${schema}"|sed -e "s/^.*[0-9] NAME //i"|cut -d"'" -f2)
         schemaoid=$(echo "${schema}"|awk '{ print $3 }'|grep "^[0-9a-zA-Z]")

         customAttr=$(echo "${schema}"|grep " NAME '"|sed -e "s/^.*NAME '//g" -e "s/'.*//g"|tr '[:upper:]' '[:lower:]')
         if [ -n "${customAttr}" ]
         then
            for (( z=0; z< ${#defaultAttrs[*]}; z++ ))
            do
               defaultAttr=$(echo ${defaultAttrs[${z}]}|tr '[:upper:]' '[:lower:]')
               if [ "${defaultAttr}" == "${customAttr}" ];then attrMatch='true';fi
            done
         else
            mattrs=$(echo "${schema}"|grep "NAME ("|sed -e "s/^.*NAME (//g" -e "s/).*//g" -e "s/'//g"|tr '[:upper:]' '[:lower:]')
            if [ -n "${mattrs}" ]
            then
               for customAttr in ${mattrs}
               do
                  for (( z=0; z< ${#defaultAttrs[*]}; z++ ))
                  do
                     defaultAttr=$(echo ${defaultAttrs[${z}]}|tr '[:upper:]' '[:lower:]')
                     if [ "${defaultAttr}" == "${customAttr}" ];then attrMatch='true';fi
                  done
               done
            fi
         fi
      # Lookup ObjectClasses
      elif [ -n "${ck4oc}" ]
      then
         stype='OC'
         ck4enc=$(echo -e "${schema}"|grep -i "^objectClasses:: ")
         if [ -n "${ck4enc}" ]
         then
            encOC=$(echo -e "${schema}"|sed -e "s/^objectClasses:: //gi")
            encOC=$(${instdir}/bin/base64 decode -d "${encOC}")
            schema="objectClasses: ${encOC}"
            schema=$(echo "${schema}"|sed -e "s/    / /g" -e "s/   / /g" -e "s/  / /g")
         fi

         # Add extra space around $ character to deal with poor formatting
         schema=$(echo "${schema}"|sed -e "s/\\\$/ $ /g" -e "s/  / /g")

         # Handle objectClass superior formatting differences
         ck4s=$(echo "${schema}"|grep -i " SUP '")
         if [ -n "${ck4s}" ]
         then
            sid=$(echo "${schema}"|sed -e "s/.* SUP //gi"|cut -d"'" -f2)
            if [ -n "${sid}" ];then schema=$(echo "${schema}"|sed -e "s/SUP '${sid}'/SUP ${sid}/gi");fi
         fi

         # Handle OpenLDAP funky attribute naming
         ck4wfu=$(echo "${schema}"|grep -i "fuProductionObj:")
         if [ -n "${ck4wfu}" ]
         then
            schema=$(echo "${schema}"|sed -e "s/wfuProductionObj:/wfuProductionObj/gi")
         fi

         schemaname=$(echo "${schema}"|sed -e "s/^.*[0-9] NAME //i"|cut -d"'" -f2)
         schemaoid=$(echo "${schema}"|awk '{ print $3 }'|grep "^[0-9a-zA-Z]")

         customOC=$(echo "${schema}"|grep " NAME '"|sed -e "s/^.*NAME '//g" -e "s/'.*//g"|tr '[:upper:]' '[:lower:]')
         if [ -n "${customOC}" ]
         then
            for (( z=0; z< ${#defaultOCs[*]}; z++ ))
            do
               defaultoc=$(echo ${defaultOCs[${z}]}|tr '[:upper:]' '[:lower:]')
               if [ "${defaultoc}" == "${customOC}" ];then ocMatch='true';fi
            done
         else
            moc=$(echo "${schema}"|grep " NAME ("|sed -e "s/^.*NAME *//g" -e "s/).*//g" -e "s/'//g"|tr '[:upper:]' '[:lower:]')
            if [ -n "${moc}" ]
            then
               for customOC in ${moc}
               do
                  for (( z=0; z< ${#defaultOCs[*]}; z++ ))
                  do
                     defaultoc=$(echo ${defaultOCs[${z}]}|tr '[:upper:]' '[:lower:]')
                     if [ "${defaultoc}" == "${customOC}" ];then ocMatch='true';fi
                  done
               done
            fi
         fi
      fi

      # Check OID match
      for (( z=0; z< ${#defaultOids[*]}; z++ ))
      do
         if [ "${defaultOids[${z}]}" == "${schemaoid}" ];then oidMatch='true';fi
      done

      # If no match to existing schema, store in output file
      if [ "${oidMatch}" == 'false' ] && [ "${attrMatch}" == 'false' ] && [ "${ocMatch}" == 'false' ]
      then
         echo -e "${schema}" >> ${tmpdir}/.tmp-${now}.schema
         if [ "${filteredIn}" == 'true' ]
         then
            echo "    + Adding ${stype} ${schemaname} (${schemaoid})"
         fi
         if [ "${stype}" == 'AT' ];then let atCnt++;fi
         if [ "${stype}" == 'OC' ];then let ocCnt++;fi
      else
         if [ "${filteredOut}" == 'true' ]
         then
            echo "    + Filtered out ${stype} ${schemaname} (${schemaoid})"
         fi
      fi
      if [ "${filteredIn}" == 'false' ] && [ "${filteredOut}" == 'false' ];then echo -e ".\c";fi
      if [ "${stype}" == 'AT' ];then let atMaxCnt++;fi
      if [ "${stype}" == 'OC' ];then let ocMaxCnt++;fi
   done
   if [ "${filteredIn}" == 'false' ] && [ "${filteredOut}" == 'false' ];then echo ".done";fi
   let numf++
done

# Apply filters to clean up known and common synatax issues
cat ${tmpdir}/.tmp-${now}.schema 2> /dev/null \
            | sed \
               -e "s/${spcvar}/ /g" \
               -e "s/${tabvar}/	/g" \
               -e "s/	/ /g" \
               -e "s/)   /) /g" \
               -e "s/)   /) /g" \
               -e "s/)  /) /g" \
               -e "s/)  /) /g" \
               -e "s/)  /) /g" \
               -e "s/)  /) /g" \
               -e "s/) \$/)/g" \
               -e "s/\\\$$/$ /g" \
               -e "s/  / /g" \
               -e "s/  / /g" \
               -e "s/  / /g" \
               -e "s/SYNTAX/ SYNTAX /g" \
               -e "s/0SINGLE/0 SINGLE/g" \
               -e "s/1SINGLE/1 SINGLE/g" \
               -e "s/2SINGLE/2 SINGLE/g" \
               -e "s/3SINGLE/3 SINGLE/g" \
               -e "s/4SINGLE/4 SINGLE/g" \
               -e "s/5SINGLE/5 SINGLE/g" \
               -e "s/6SINGLE/6 SINGLE/g" \
               -e "s/7SINGLE/7 SINGLE/g" \
               -e "s/8SINGLE/8 SINGLE/g" \
               -e "s/9SINGLE/9 SINGLE/g" \
               -e "s/0X-ORIGIN/0 X-ORIGIN/g" \
               -e "s/1X-ORIGIN/1 X-ORIGIN/g" \
               -e "s/2X-ORIGIN/2 X-ORIGIN/g" \
               -e "s/3X-ORIGIN/3 X-ORIGIN/g" \
               -e "s/4X-ORIGIN/4 X-ORIGIN/g" \
               -e "s/5X-ORIGIN/5 X-ORIGIN/g" \
               -e "s/6X-ORIGIN/6 X-ORIGIN/g" \
               -e "s/7X-ORIGIN/7 X-ORIGIN/g" \
               -e "s/8X-ORIGIN/8 X-ORIGIN/g" \
               -e "s/9X-ORIGIN/9 X-ORIGIN/g" \
               -e "s/X-ORIGIN(/X-ORIGIN (/g" \
               -e "s/)X-ORIGIN/) X-ORIGIN/g" \
               -e "s/tX-ORIGIN/t X-ORIGIN/g" \
               -e "s/MAYs/MAY s/g" \
               -e "s/)MAY/) MAY/g" \
               -e "s/MAY(/MAY (/g" \
               -e "s/MUST(/MUST (/g" \
               -e "s/MUST(/MUST (/g" \
               -e "s/MUST (/MUST ( /g" \
               -e "s/MAY (/MAY ( /g" \
               -e "s/  / /g" \
               -e "s/USAGEdir/USAGE dir/g" \
               -e "s/SINGLE-VALUENO-USER-MODIFICATION/SINGLE-VALUE NO-USER-MODIFICATION/g" \
               -e "s/NO-USER-MODIFICATION//g" \
               -e "s/[tT][oO][pP]ABSTRACT/top ABSTRACT/g" \
               -e "s/[tT][oO][pP]STRUCTURAL/top STRUCTURAL/g" \
               -e "s/SUP[tT][oO][pP]/SUP top/g" \
               -e "s/STRUCTURALMUST/STRUCTURAL MUST/g" \
               -e "s/STRUCTURALMAY/STRUCTURAL MAY/g" \
               -e "s/DESC'/DESC '/g" \
               -e "s/directoryOperationX-DS-USE/directoryOperation X-DS-USE/g" \
               -e "s/'SUP/' SUP/g" \
               -e "s/nsSchemaCSN: .*//g" \
               -e "s/' '/ATTRALIASES/g" \
               -e "s/  / /g" \
               -e "s/  / /g" \
               -e "s/  / /g" \
               -e "s/ATTRALIASES/' '/g" \
               -e "s/^attribute[tT]ypes:/\ndn: cn=schema\nchangeType: modify\nadd: attributeTypes\nattributeTypes:/g" \
               -e "s/^object[cC]lasses:/\ndn: cn=schema\nchangeType: modify\nadd: objectClasses\nobjectClasses:/g" \
            > ${schemaOut}

if [ "${norm}" != 'true' ]
then
   rm -f ${tmpdir}/.tmp-*.schema
fi

###############################################################################
# Test schema
###############################################################################
if [ -s "${schemaOut}" ]
then
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Test schema: Load ${atCnt} of ${atMaxCnt} attributes and ${ocCnt} of ${ocMaxCnt} objectClasses into OUD"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${lmod} -Z -X -p 60444 -h ${localHost} -D "${bDN}" -j "${jPW}" -c -f "${schemaOut}" >> ${schemaLog} 2>&1
   rc=$?
   set +x
else
   echo "Error: Schema file ${schemaOut} is empty."
fi

###############################################################################
# Retry all superior 
###############################################################################
ck4sups=$(grep -i "declared a superior objectclass with an OID of" ${schemaLog} 2> /dev/null|sed -e "s/.*declared a superior objectclass with an OID of//g" -e "s/\..*//g")
n=1
while [ -n "${ck4sups}" ] && [ ${n} -le 5 ]
do
   echo "--> Retry(${n}) objectClasses that failed superior dependency"
   now=$(date +'%Y%m%d%H%M%S')
   readarray -t supOCs < <(echo "${ck4sups}")
   for (( x=0; x< ${#supOCs[*]}; x++ ))
   do
      grep -i "'${supOCs[${x}]}'" ${schemaOut} \
      | sed \
      -e "s/^attribute[tT]ypes:/\ndn: cn=schema\nchangeType: modify\nadd: attributeTypes\nattributeTypes:/g" \
      -e "s/^object[cC]lasses: /\ndn: cn=schema\nchangeType: modify\nadd: objectClasses\nobjectClasses: /g" \
      >> ${tmpdir}/mySchema-v${v}-retry${n}.ldif
   done

   if [ -s "${tmpdir}/mySchema-v${v}-retry${n}.ldif" ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${lmod} -Z -X -p 60444 -h ${localHost} -D "${bDN}" -j "${jPW}" -c -f "${tmpdir}/mySchema-v${v}-retry${n}.ldif" 2>&1 >> ${schemaLog}.${n} 2>&1
      rc=$?
      set +x

      cat ${tmpdir}/mySchema-v${v}-retry${n}.ldif >> ${schemaOut}

      if [ "${norm}" != 'true' ]
      then
         rm -f ${tmpdir}/mySchema-v${v}-retry${n}.ldif
      fi
   fi

   ck4sups=$(grep -i "declared a superior objectclass with an OID of" ${schemaLog}.${n}|sed -e "s/.*declared a superior objectclass with an OID of//g" -e "s/\..*//g")
   let n++
done

###############################################################################
# Check for processing errors
###############################################################################
ckFailedLoad=$(egrep -v "MODIFY operation successful|Processing MODIFY request|one or more duplicate values|Attribute or Value Exists|MODIFY operation failed|Result Code:.*19 (Constraint Violation)|Result Code:.*21.*(Invalid Attribute Syntax)|declared a superior objectclass" ${schemaLog} 2> /dev/null)
if [ -n "${ckFailedLoad}" ]
then
   echo -e "--> Problem: The following errors were returned during custom schema load."
   egrep -v "MODIFY operation successful|Processing MODIFY request|one or more duplicate values|Attribute or Value Exists|MODIFY operation failed|Result Code:.*19 (Constraint Violation)|Result Code:.*21.*(Invalid Attribute Syntax)|declared a superior objectclass" ${schemaLog} 2> /dev/null
fi

###############################################################################
# Check for core schema duplication
###############################################################################
# Wait a little while and stop the OUD instance to ensure custom schema files 
# and overlap files are created
sleep 30
${instdir}/bin/stop-ds > /dev/null 2>&1

ckCoreSchema=$(ls -1 ${schemadir}/ 2> /dev/null|grep -v 99-user.ldif)
if [ -n "${ckCoreSchema}" ]
then

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "--> Problem: Conflicts resulted from duplicates in the following default scema:"
   echo -e "--> Please review the following files for duplicate schema:\n${ckCoreSchema}"
fi

###############################################################################
# Find overlap with existing schema
###############################################################################
readarray -t sfiles < <(cd ${schemadir}/;ls -1 *.ldif 2> /dev/null|grep -v 99-user.ldif)

for (( x=0; x< ${#sfiles[*]}; x++ ))
do
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Check for schema overlap with default OUD file ${sfiles[${x}]}"

   # Check for overlap by OID
   for oid in $(awk '{ print $3 }' ${schemaOut}|grep "^[0-9]")
   do
      ckoid=$(cat ${oudschemadir}/${sfiles[${x}]}|egrep -v "^#"|sed -e "s/^ //g"|tr -d '[\n]'|sed -e "s/attribute[Tt]ypes:/\nattributeTypes:/g" -e "s/object[Cc]lasses:/\nobjectClasses:/g"|grep -i " ${oid} ")
      if [ -n "${ckoid}" ]
      then
         echo "OID match: ${ckoid}"
      fi
   done

   # Check for overlap by NAME
   for sname in $(egrep -hi "^attributeTypes:|^objectClasses:" ${schemaOut}|sed -e "s/^ //g"|tr -d '[\n]'|sed -e "s/attribute[Tt]ypes:/\nattributeTypes:/g" -e "s/object[Cc]lasses:/\nobjectClasses:/g"|sed -e "s/^.*NAME '//g" -e "s/'.*//g"|grep -v 'NAME (')
   do
      ckname=$(cat ${oudschemadir}/${sfiles[${x}]}|grep -i "'${sname}'"|cut -c1-64|sed -e "s/$/.../g")
      if [ -n "${ckname}" ]
      then
         echo "Name match: ${ckname}"
      fi
   done

   # Check for overlap by compound NAME
   for msname in $(grep -i 'NAME (' ${schemaOut}|egrep -v "^#"|sed -e "s/^ //g"|tr -d '[\n]'|sed -e "s/attribute[Tt]ypes:/\nattributeTypes:/g" -e "s/object[Cc]lasses:/\nobjectClasses:/g"|sed -e "s/^.*( //g" -e "s/ NAME.*//g" -e "s/).*//g"| sed -e "s/'//g" -e "s/ /\n/g"|grep -v "^$")
   do
      ckcompundname=$(cat ${oudschemadir}/${sfiles[${x}]}|grep -i "'${msname}'")
      if [ -n "${ckcompoundname}" ]
      then
         echo "Compound name match: ${ckcompoundname}"
      fi
   done
done

###############################################################################
# Remove the test instance
###############################################################################
if [ -e "${instdir}/uninstall" ] && [ "${norm}" != 'true' ]
then
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Remove OUD instance for schema testing"
   cd "${curdir}"
   ${curdir}/manage_oud.sh deinstall --pnum 60 ${dbgFlag}
fi

echo "Output schema file: ${schemaOut}"
if [ -n "${outputFile}" ]
then
   cp "${schemaOut}" "${outputFile}"
fi
