#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [setupca|gencert|updatecert] [options]

SYNOPSIS
     Setup Certificate Authority
        ${cmd} setupca

     Generate Certificate
        ${cmd} gencert -h <fqdn_host>

DESCRIPTION
     Sample script for generating certificates

OPTIONS
     Options
     The following options are supported:

         -h <fqdn_host>          Fully qualified Host name
                                 Default: $(hostname -f)

EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
sshkey="$HOME/.ssh/id_rsa.pub"

while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            cahost) caHost="$1";shift;;
            sshkey) sshkey="$1";shift;;
            sanlist) sanlist="$1";shift;;
            keystore) myKeyStore="$1";shift;;
            type) storeType="$1";shift;;
            step) mySteps="$1";steps=${mySteps};shift;;
            12c) fmwVersion='12c';fmwFlag="--${fmwVersion}";;
            14c) fmwVersion='14c';fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            h) myHost="$1";shift;;
            j) jPW="$1";shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done
export fmwVersion fmwFlag
setfmwenv

###############################################################################
# Set defaults
###############################################################################
cadir="${certdir}/CA"
icadir="${certdir}/intermediate"
csrdir="${certdir}/csr"
caTrustStore="${cadir}/truststore"

if [ "${cadir}" == '/CA' ]
then
   echo "ERROR: Cert dir may not be the root (/) directory"
   exit 1
fi

# Setup CA if it doesn't already exist
if [ -z "${myHost}" ];then myHost="${localHost}";fi
if [ -n "${myKeyStore}" ];then keystore="${myKeyStore}";fi
if [ -z "${keystore}" ];then keystore="${certdir}/${myHost}/${myHost}.p12";fi
if [ -z "${sanlist}" ];then sanlist="dns:${localH},dns:localhost,ip:127.0.0.1";fi

if [ -z "${storeType}" ];then storeType="JKS";fi

sshprivkey=$(echo ${sshkey}|sed -e "s/\.pub$//gi")

hostValidity=3650 
intValidity=$((${hostValidity}*10))
caValidity=$((${hostValidity}*20))

##############################################################################
# Setup Certificate Authority
# Excellent References:
#  * https://jamielinux.com/docs/openssl-certificate-authority/
#  * http://pages.cs.wisc.edu/~zmiller/ca-howto/
##############################################################################
setup_ca() {
   unset JAVA_TOOL_OPTIONS

   if [ -e "${cadir}/root-ca.jks" ]
   then
      true
   else
      msg=''

      let steps++
      echo "Step: ${steps} - Setup root and intermediate Certificate Authorities"| tee -a  ${logdir}/certs-${now}.log

      if [ "${dbg}" == 'true' ];then set -x;fi
      # Make requisite directories
      mkdir -p "${certdir}" "${cadir}" "${icadir}" > /dev/null 2>&1
      rc=$?

      cd "${cadir}"
      mkdir -p certs crl csr newcerts private > /dev/null 2>&1
      rc=$?

      cd "${icadir}"
      mkdir -p certs crl csr newcerts private > /dev/null 2>&1
      rc=$?
      set +x

      chmod -R 0750 ${certdir}

      # Create self-signed certificate for the root CA
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -genkeypair -keystore ${cadir}/root-ca.jks -storepass "${bPW}" -keypass "${bPW}" -alias root-ca-cert -dname "cn=Root CA" -keysize 2048 -keyalg "RSA" -sigalg SHA256withRSA -validity ${caValidity} -ext bc:c >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to generate self-signed cert for root CA";fi

      # Export root CA certificate 
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -storepass "${bPW}" -keystore ${cadir}/root-ca.jks -alias root-ca-cert -exportcert -rfc -file ${cadir}/certs/ca-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export root CA certificate";fi
   
      # Generate cert and key store for intermediate CA
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -genkeypair -keystore ${icadir}/ca.jks -storepass "${bPW}" -keypass "${bPW}" -alias ca-cert -dname "cn=Intermediate CA" -keysize 2048 -keyalg "RSA" -sigalg SHA256withRSA -validity ${intValidity} -ext bc:c >> ${logdir}/certs-${now}.log 2>&1

      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to generate cert and key store for intermediate CA";fi

      # Request cert for intermediate CA and sign by root CA
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -certreq -storepass "${bPW}" -keystore ${icadir}/ca.jks -keypass "${bPW}" -alias ca-cert -file  ${icadir}/csr/ca.csr >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to generate cert request for intermediate CA";fi

      # Sign intermediate CA's cert by root CA
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -gencert -storepass "${bPW}" -keystore ${cadir}/root-ca.jks -alias root-ca-cert -ext BC=0 -rfc -validity ${intValidity} -infile ${icadir}/csr/ca.csr -outfile ${icadir}/certs/ica-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to sign the intermediate CA's cert";fi

      # Import Root CA cert into intermediate CA's keystore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -trustcacerts -storepass "${bPW}" -keystore ${icadir}/ca.jks -alias root-ca-cert -file  ${cadir}/certs/ca-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Root CA cert into Intermediat CA keystore";fi

      # Import Intermediate CA cert into intermediate CA's keystore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert               -storepass "${bPW}" -keystore ${icadir}/ca.jks -alias ca-cert -file  ${icadir}/certs/ica-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Intermediate CA cert into Intermediat CA keystore";fi
   
      # Create Intermediate CA truststore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -trustcacerts -storepass "${bPW}" -keystore "${caTrustStore}" -alias root-ca-cert -file  ${cadir}/certs/ca-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to create Intermediate CA truststore";fi

      # Import Intermediate CA cert into Intermediate CA truststore
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -trustcacerts -storepass "${bPW}" -keystore "${caTrustStore}" -alias ca-cert -file  ${icadir}/certs/ica-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Intermediate CA cert into Intermediate truststore";fi

      # Create combined Root CA and Intermediate CA chain cert file
      if [ "${dbg}" == 'true' ];then set -x;fi
      touch ${icadir}/certs/ca-chain-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?
      chmod 0640 ${icadir}/certs/ca-chain-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?
      cat ${icadir}/certs/ica-cert.pem ${cadir}/certs/ca-cert.pem > ${icadir}/certs/ca-chain-cert.pem 2> /dev/null
      rc=$?;set +x
      chmod 0440 ${icadir}/certs/ca-chain-cert.pem >> ${logdir}/certs-${now}.log 2>&1
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Intermediate CA cert into Intermediate truststore";fi

      # Show errors
      if [ -n "${msg}" ];then echo -e "${msg}";exit 1;fi
   fi
}

##############################################################################
# Generate Certificate
##############################################################################
gen_host_cert() {
   unset JAVA_TOOL_OPTIONS

   msg=''

   # Make sure CA is setup
   setup_ca

   # Setup requisite directory for host cert
   mkdir -p "${certdir}/${myHost}"
   rc=$?

   cd "${certdir}/${myHost}"
   mkdir -p certs crl csr newcerts private > /dev/null 2>&1
   rc=$?

   # Set pin file
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -e "${certdir}/${myHost}/${myHost}.pin" ]
   then
      true
   else
      echo "${bPW}" > "${certdir}/${myHost}/${myHost}.pin"
   fi

   if [ -e "${certdir}/${myHost}/${myHost}.jks" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate and sign host cert ${myHost}"| tee -a  ${logdir}/certs-${now}.log

      # Set permissions
      chmod 0640 "${certdir}/${myHost}/*" 2> /dev/null

      # Create host server keystore 
      if [ "${dbg}" == 'true' ];then set -x;fi
      myH=$(echo "${myHost}."|cut -d. -f1)
      ${ktool} -genkeypair -keystore ${certdir}/${myHost}/${myHost}.jks -storepass "${bPW}" -keypass "${bPW}" -alias server-cert -ext "san=${sanlist}" -dname "CN=${myHost}" -keysize 2048 -keyalg "RSA" -sigalg SHA256withRSA -validity ${hostValidity} >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to host keystore";fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -certreq -storepass "${bPW}" -keystore ${certdir}/${myHost}/${myHost}.jks -keypass "${bPW}" -alias server-cert -ext "san=${sanlist}" -file  ${certdir}/${myHost}/csr/${myHost}.csr >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to create host cert request";fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -gencert -storepass "${bPW}" -keystore ${icadir}/ca.jks -alias ca-cert -ext BC=0 -ext "san=${sanlist}" -rfc -validity ${hostValidity} -infile ${certdir}/${myHost}/csr/${myHost}.csr -outfile ${certdir}/${myHost}.pem >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to sign host cert by Intermediate CA";fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -storepass "${bPW}" -keystore ${certdir}/${myHost}/${myHost}.jks -alias server-cert -file  ${certdir}/${myHost}.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import host cert into host keystore";fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importcert -storepass "${bPW}" -keystore ${certdir}/${myHost}/${myHost}.jks -alias root-ca-chain -file ${icadir}/certs/ca-chain-cert.pem -noprompt >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import CA chain cert into host keystore";fi

      # Create PKCS12 Version of server keystore 
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importkeystore -srckeystore ${certdir}/${myHost}/${myHost}.jks -destkeystore ${certdir}/${myHost}/${myHost}.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${bPW}" -deststorepass "${bPW}" -srcalias server-cert -destalias server-cert >> ${logdir}/certs-${now}.log 2>&1 <<EOF
yes
EOF
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS keystore to PKCS12 keystore";fi

      # Create PKCS12 Version of server truststore 
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importkeystore -srckeystore ${certdir}/CA/truststore -destkeystore ${certdir}/truststore.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${bPW}" -deststorepass "${bPW}" -srcalias ca-cert -destalias ca-cert >> ${logdir}/certs-${now}.log 2>&1 <<EOF
yes
EOF
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS truststore to PKCS12 keystore";fi

      # Create PKCS12 Version of server truststore 
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importkeystore -srckeystore ${certdir}/CA/truststore -destkeystore ${certdir}/truststore.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${bPW}" -deststorepass "${bPW}" -srcalias root-ca-cert -destalias root-ca-cert >> ${logdir}/certs-${now}.log 2>&1 <<EOF
yes
EOF
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS truststore to PKCS12 keystore";fi


      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -importkeystore -srckeystore ${certdir}/${myHost}/${myHost}.jks -destkeystore ${certdir}/${myHost}/dsee.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${bPW}" -deststorepass "${bPW}" -srcalias server-cert -destalias dsee-cert >> ${logdir}/certs-${now}.log 2>&1 <<EOF
yes
EOF
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS keystore to PKCS12 keystore for DSEE";fi


      if [ "${dbg}" == 'true' ];then set -x;fi
      ${ktool} -list -keystore ${certdir}/${myHost}/${myHost}.p12 -storetype PKCS12  -storepass "${bPW}" -v >> ${logdir}/certs-${now}.log 2>&1
      rc=$?;set +x
      if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to list contents of PKCS12 keystore";fi


      # Address compatibility with existing implementation
      if [ "${dbg}" == 'true' ];then set -x;fi
      #cp "${certdir}/${myHost}.p12" "${certdir}/${myHost}/keystore.p12" >> ${logdir}/certs-${now}.log 2>&1
      #cp "${certdir}/dsee.p12" "${certdir}/${myHost}/dsee.p12" >> ${logdir}/certs-${now}.log 2>&1
      #cp "${certdir}/${myHost}.jks" "${certdir}/${myHost}/keystore" >> ${logdir}/certs-${now}.log 2>&1
      set +x

      # Show errors
      if [ -n "${msg}" ];then echo -e "${msg}";exit 1;fi
   fi

}

##############################################################################
# Generate a Subject Alternative Name (SAN) Certificate
##############################################################################
gen_sancert() {

# 1. Create the cert config file
cat > request.config <<EOC
[req]
distinguished_name = req_distinguished_name
req_extensions = v3_req
prompt = no

[req_distinguished_name]
O = space
OU = solarsystem
CN = odsee111.solarsystem.space

[v3_req]
subjectAltName = @alt_names

[alt_names]
email = frank.juedes@oracle.com
DNS.1 = odsee111.solarsystem.space
EOC

# Example #2
# For example, see http://wiki.cacert.org/FAQ/subjectAltName 
 
cat > request.config <<EOC
[req]
req_extensions = v3_req
 
[ v3_req ]
 
# Extensions to add to a certificate request
 
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names
 
[alt_names]
DNS.1 = server1.example.com
DNS.2 = mail.example.com
DNS.3 = www.example.com
DNS.4 = www.sub.example.com
DNS.5 = mx.example.com
DNS.6 = support.example.com
IP.1 = 192.168.1.11
IP.2 = 192.168.1.12
IP.3 = 192.168.1.13

EOC


# 2. Generate the CSR from the key and config
openssl req -out file.csr -new -newkey rsa:2048 -nodes -keyout odsee111.request1.key -config request.config

# 3. Show contents of the CSR

# 4. Sign the cert

# 5. Show the contents of the signed certificate
openssl x509 -in odsee111.request1.pem -text -noout

# 6. Verify the contents of the certificate request
openssl req -text -noout -verify -in odsee111.request1.csr

# 7. Convert the certificate and the key-file into a PKCS12 container:
openssl pkcs12 -export -out odsee111.request1.pfx -inkey odsee111.request1.key -in odsee111.request1.pem

# 8. Verified the information in the container:
openssl pkcs12 -info -in odsee111.request1.pfx






}

##############################################################################
# Re-generate CA Certificate
##############################################################################
regen_ca_cert() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   rm -f ${cadir}/root-ca.jks ${icadir}/ca.jks ${caTrustStore} 2> /dev/null
   rc=$?;set +x
   setup_ca
}

##############################################################################
# Re-generate Host Certificate
##############################################################################
regen_host_cert() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   rm -f ${certdir}/${myHost}/${myHost}.jks 2> /dev/null
   rc=$?;set +x
   gen_host_cert
}

##############################################################################
# Retrieve host cert and trust store from CA host
##############################################################################
get_cert() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   rsync --progress -vvtre "ssh -h ${caHost} -p ${sshport} -i \"${sshprivkey}\" -o StrictHostKeyChecking=no" "${me}@${caHost}:${certdir}/." "${certdir}/."
   rc=$?;set +x
}

##############################################################################
# List keystore contents
##############################################################################
list_keystore() {
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= List certs:"
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${ktool} -list -keystore "${keystore}" -storetype ${storeType}  -storepass "${bPW}"
}

##############################################################################
# Summarize keystore contents
##############################################################################
summarize_keystore() {
   # Summarize certs
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= Summarize Host certs:"
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${ktool} -list -v -keystore "${keystore}" -storetype ${storeType}  -storepass "${bPW}"|egrep -i "^Certificate|^Owner:|^Issuer:|^Valid from:"

   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= Summarize CA cert chain:"
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${ktool} -list -v -keystore "${certdir}/truststore.p12" -storetype ${storeType}  -storepass "${bPW}"|egrep -i "^Certificate|^Owner:|^Issuer:|^Valid from:"
}

##############################################################################
# List keystore contents in RFC format
##############################################################################
list_rfc_keystore() {
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "=-= List certs in RFC format:"
   echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${ktool} -list -rfc -keystore "${keystore}" -storetype ${storeType}  -storepass "${bPW}"
}

##############################################################################
# Make sure JDK is installed
##############################################################################
${curdir}/manage_install.sh extract jdk ${dbgFlag} ${fmwFlag}
# Prefer a JDK version that is less than 1.8.0_200
export JAVA_HOME=$(ls -1 ${swdir}/jdk1.8.0_1*/bin/java ${swdir}/jdk-21*/bin/java ${swdir}/jdk-17*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g")
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
ktool="${JAVA_HOME}/bin/keytool"

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
        'setupca') setup_ca;;
        'regenca') regen_ca_cert;;
        'gencert') gen_host_cert;;
      'regencert') regen_host_cert;;
           'list') list_keystore;;
        'summary') summarize_keystore;;
       'list-rfc') list_rfc_keystore;;
                *) showUsage;;
esac

