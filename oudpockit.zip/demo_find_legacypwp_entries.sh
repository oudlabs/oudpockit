#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Find legacy password policy attributes
###############################################################################
set -x
${lsrch} -h ${localHost} -T -p 1393 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub '(|(passwordMinAge=*)(passwordMaxAge=*)(passwordExp=*)(passwordInHistory=*)(passwordSyntax=*)(passwordMinLength=*)(passwordWarning=*)(passwordMustChange=*)(passwordChange=*)(passwordStorageScheme=*)(passwordExpireWithoutWarning=*)(passwordLockout=*)(passwordLockoutDuration=*)(passwordUnlock=*)(passwordMaxFailure=*)(passwordResetFailureCount=*)(passwordResetDuration=*)(passwordCheckSyntax=*)(passwordRootdnMayBypassModsChecks=*)(passwordNonRootMayResetUserpwd=*))' passwordMinAge passwordMaxAge passwordExp passwordInHistory passwordSyntax passwordMinLength passwordWarning passwordMustChange passwordChange passwordStorageScheme passwordExpireWithoutWarning passwordLockout passwordLockoutDuration passwordUnlock passwordMaxFailure passwordResetFailureCount passwordResetDuration passwordCheckSyntax passwordRootdnMayBypassModsChecks passwordNonRootMayResetUserpwd
rc=$?

set +x
