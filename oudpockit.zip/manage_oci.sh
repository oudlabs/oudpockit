#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
cmdArg2=$2
curdir=$(cd ${curdir}; pwd)
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################


# Set language preferences
export LANG="en_US.UTF-8" LC_ALL="en_US.UTF-8" LC_CTYPE="en_US.UTF-8"

logdir=$HOME/.oudpockit/logs
cfgdir=$HOME/.oudpockit/cfg
tmpdir=$HOME/.oudpockit/tmp
localHost=$(hostname -f)
sshport=22
adminPort=1444
ldapPort=1389
ldapsPort=1636
replPort=1989
imageLinuxBase='Oracle-Linux'
burstRate="BASELINE_1_1"

# Make sure home dir exists
if [ -d "$HOME/.oudpockit" ];then true;else mkdir -p "$HOME/.oudpockit/logs" "$HOME/.oudpockit/cfg" "$HOME/.oudpockit/tmp";fi

os=$(uname -s 2> /dev/null)
if [ "${os}" == 'Darwin' ]
then
   PATH=/usr/local/opt:/usr/lib/amd64/gettext:/usr/gnu/bin:/usr/xpg4/bin:/usr/xpg6/bin:$PATH:/usr/sbin:/sbin:${curdir}/oci_cli/bin:$HOME/bin:.
   pyCmd='python3'
elif [ "${os}" == 'Linux' ]
then
   PATH=/usr/lib/amd64/gettext:/usr/gnu/bin:/usr/xpg4/bin:/usr/xpg6/bin:$PATH:/usr/sbin:/sbin:${curdir}/oci_cli/bin:$HOME/bin:.
   pyCmd='python'
else
   echo "ERROR: Only Linux and MacOS operating systems are supported"
   exit 1
fi
###############################################################################
# Sample OCI Config File ($HOME/.oci/config)
###############################################################################
# [DEFAULT]
# tenancy="ocid1.tenancy.oc1..aa..."
# region="us-ashburn-1"
# user="ocid1.user.oc1..aaaaaaaa5elh..."
# fingerprint="f5:e0:e0:d8:cc:92:57..."
# key_file="$HOME/.oci/oci_api_key.pem"
# compartment="ocid1.compartment.oc1..aaa..."
#
#subnet="ocid1.subnet.oc1.iad.aaaa..."
#image="ocid1.image.oc1.iad.aaaaaa..."
#
#ad="uYkY:US-ASHBURN-AD-1"
#shape="VM.Standard2.1"
#shape=VM.Standard.E3.Flex --shape-config '{"memoryInGBs": 16.0,"ocpus": 1.0}' 
#sshkey="/home/opc/.ssh/id_rsa.pub"

##############################################################################
# Global and default variables
##############################################################################
now=$(date +'%Y%m%d%H%M%S')
force=''
rdisp=''
radv=''
osuser='opc'
osgroup='opc'
pubip='false'
bm='false'
arch='amd-e3'
cores=1
mem=15
storage=200
sshkey="$HOME/.ssh/id_rsa.pub"
tag='null'
webproxy='false'
lb='false'
preemptibleFlag=''
preemptibleTag=''

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            osuser) osuser="$1";shift;;
            uocid) uocid="$1";shift;;
            tocid) tocid="$1";shift;;
            preemptible) preemptibleFlag='--preemptible-instance-config {"preemptionAction":{"type":"TERMINATE"}}';preemptibleTag='preemptible';;
            role) role="$1";shift;;
            name) cname="$1";shift;;
            region) region="$1";shift;;
            subnet) subnet="$1";shift;;
            compartment) compartment="$1";shift;;
            ad) ad="$1";shift;;
            image) myImage="$1";shift;;
            bm) bm='true';;
            arch) arch="$1";shift;;
            cores) cores="$1";shift;;
            burst12) burstRate="BASELINE_1_8";;
            burst50) burstRate="BASELINE_1_2";;
            mem) mem="$1";shift;;
            storage) storage="$1";shift;;
            pubip) pubip='true';;
            sshkey) sshkey="$1";shift;;
            base) remoteBase="$1";shift;;
            bitsdir) remoteBitsDir="$1";shift;;
            cfgdir) remoteCfgDir="$1";shift;;
            tag) tag="$1";shift;;
            webproxy) webproxy=true;;
            lb) lb=true;;
            pw) bPW="$1";shift;;
            cmd) mycmd="$1";shift;;
            src) src="$1";shift;;
            dst) dst="$1";shift;;
            quiet) quiet=true;;
            os) ociOS="$1";shift;;
            oci) myOci="$1";shift;;
            autonomous) imageLinuxBase='Oracle-Autonomous-Linux';;
        esac;;
        -*) case ${OPT:1} in
            w) bPW="$1";shift;;
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';ociDbg=' --debug ';;
        esac;;
    esac
done

##############################################################################
# Parse inputs
##############################################################################
if [ -z "${region}" ];then region='us-ashburn-1';fi
if [ -z "${ad}" ];then ad='uYkY:US-ASHBURN-AD-1';fi
if [ -z "${remoteBase}" ];then remoteBase="/opt/ods/poc";fi
if [ -z "${remoteCfgDir}" ];then remoteCfgDir="${remoteBase}/cfg";fi
if [ -z "${remoteBitsDir}" ];then remoteBitsDir="${remoteBase}/bits";fi
jPW="${remoteCfgDir}/...pw"

subdir=$(dirname "${remoteBase}/.")
case ${subdir} in
   '/') echo "ERROR: base directory cannot be ${subdir}";exit 1;;
   '/var') echo "ERROR: base directory cannot be ${subdir}";exit 1;;
   '/usr') echo "ERROR: base directory cannot be ${subdir}";exit 1;;
   '/opt') echo "ERROR: base directory cannot be ${subdir}";exit 1;;
   '/tmp') echo "ERROR: base directory cannot be ${subdir}";exit 1;;
esac

sshprivkey=$(echo ${sshkey}|sed -e "s/\.pub$//gi")

if [ -n "${ociOS}" ];then ociOS="${ociOS}";else ociOS='ol8';fi

# Find OCI CLI command
if [ "${dbg}" == 'true' ];then set -x;fi
if [ -n "${myOci}" ];then oci="${myOci}"; else oci="${curdir}/oci_cli/bin/oci";fi
if [ "${subcmd}" != 'setup' ]
then
   if [ -e "${oci}" ]
   then
      true
   else
      oci=$(which oci)
      if [ -e "${oci}" ]
      then
         true
      else
         echo "ERROR: OCI CLI not installed"
         exit 1
      fi
   fi
fi
set +x

if [ "${dbg}" == 'true' ];then set -x;fi
if [ "${subcmd}" == 'launch' ]
then
   if [ -n "${myImage}" ]
   then
      image="${myImage}"
   else
      case ${ociOS} in 
         'ol7') oslv=$(${oci} compute image list --all --region ${region} --compartment-id ${compartment} --query "data [?contains(\"display-name\", '${imageLinuxBase}-7')].{ImageName:\"display-name\"}" --output json 2> /dev/null|grep ImageName|cut -d'"' -f4|sed -e "s/${imageLinuxBase}-//g" -e "s/-.*//g"|head -1)
                image=$(${oci} compute image list --all --region ${region} --compartment-id ${compartment} --query "data [?contains(\"display-name\", '${imageLinuxBase}-${oslv}-20')].{ImageName:\"display-name\", OCID:id}" --output json 2> /dev/null|grep "OCID"|cut -d'"' -f 4|head -1)
                osn="Oracle Linux"
                if [ -z "${image}" ]
                then
                   case ${region} in 
                      'us-ashburn-1') image='ocid1.image.oc1.iad.aaaaaaaaoi4aun3xgz7cwwzrwkiunk6dpi7htuicu7aktsgulbnjdzb6l6aq';;
                      'us-phoenix-1') image='ocid1.image.oc1.phx.aaaaaaaaqwxxx56vulzifjqxvizgf44xx7qwlxhbj56wo5ottxholaxbyxlq';;
                   esac
                fi
                ;;
         'ol8') oslv=$(${oci} compute image list --all --region ${region} --compartment-id ${compartment} --query "data [?contains(\"display-name\", '${imageLinuxBase}-8')].{ImageName:\"display-name\"}" --output json 2> /dev/null|grep ImageName|cut -d'"' -f4|sed -e "s/${imageLinuxBase}-//g" -e "s/-.*//g"|head -1)
                image=$(${oci} compute image list --all --region ${region} --compartment-id ${compartment} --query "data [?contains(\"display-name\", '${imageLinuxBase}-${oslv}-20')].{ImageName:\"display-name\", OCID:id}" --output json 2> /dev/null|grep "OCID"|cut -d'"' -f 4|head -1)
                osn="Oracle Linux"
                if [ -z "${image}" ]
                then
                   case ${region} in 
                      'us-ashburn-1') image='ocid1.image.oc1.iad.aaaaaaaaya3igqt72lr4erpo2drcaj4svag7cuxgp2h453ekn26dc7upc4ea';;
                   esac
                fi
                ;;
        'ol9') oslv=$(${oci} compute image list --all --region ${region} --compartment-id ${compartment} --query "data [?contains(\"display-name\", '${imageLinuxBase}-9')].{ImageName:\"display-name\"}" --output json 2> /dev/null|grep ImageName|cut -d'"' -f4|sed -e "s/${imageLinuxBase}-//g" -e "s/-.*//g"|head -1)
                image=$(${oci} compute image list --all --region ${region} --compartment-id ${compartment} --query "data [?contains(\"display-name\", '${imageLinuxBase}-${oslv}-20')].{ImageName:\"display-name\", OCID:id}" --output json 2> /dev/null|grep "OCID"|cut -d'"' -f 4|head -1)
                osn="Oracle Linux"
                if [ -z "${image}" ]
                then
                   case ${region} in 
                      'us-ashburn-1') image='ocid1.image.oc1.iad.aaaaaaaanlmlgzeplkg65zaqmd7we4rbmthpylssgbvqexryovcgnzg7llaa';;
                   esac
                fi
                ;;
             *) oslv=$(${oci} compute image list --all --region ${region} --compartment-id ${compartment} --query "data [?contains(\"display-name\", '${imageLinuxBase}-8')].{ImageName:\"display-name\"}" --output json 2> /dev/null|grep ImageName|cut -d'"' -f4|sed -e "s/${imageLinuxBase}-//g" -e "s/-.*//g"|head -1)
                image=$(${oci} compute image list --all --region ${region} --compartment-id ${compartment} --query "data [?contains(\"display-name\", '${imageLinuxBase}-${oslv}-20')].{ImageName:\"display-name\", OCID:id}" --output json 2> /dev/null|grep "OCID"|cut -d'"' -f 4|head -1)
                osn="Oracle Linux"
                ;;
      esac
  fi
fi

if [ -z "${image}" ] && [ "${subcmd}" == "launch" ];then echo "Error: No OS image is available for ${osn} ${oslv} on ${arch}";exit 1;fi

cores=$(echo ${cores}|tr -dc '0-9')
if [ -z "${cores}" ];then echo "Error: Cores must be number between 1 and 128";exit 1;fi

mem=$(echo ${mem}|tr -dc '0-9')
if [ -z "${mem}" ];then echo "Error: Mem must be number in GB between 1 and 1010";exit 1;fi

storage=$(echo ${storage}|tr -dc '0-9')
if [ -z "${storage}" ];then echo "Error: Boot volume storage must be between 30GB and 32,768GB";exit 1;fi

arch=$(echo ${arch}|tr '[:upper:]' '[:lower:]')
case "${bm}" in
   'false') case ${arch} in
               'intel') if [ ${cores} -eq 1 ] && [ ${mem} -le 15 ]
                        then
                           shape="VM.Standard2.1"
                        elif [ ${cores} -eq 2 ] && [ ${mem} -le 30 ]
                        then
                           shape="VM.Standard2.2"
                        elif [ ${cores} -le 4 ] && [ ${mem} -le 60 ]
                        then
                           shape="VM.Standard2.4"
                        elif [ ${cores} -le 8 ] && [ ${mem} -le 120 ]
                        then
                           shape="VM.Standard2.8"
                        elif [ ${cores} -le 16 ] && [ ${mem} -le 240 ]
                        then
                           shape="VM.Standard2.16"
                        fi
                        ;;
                 'amd'|'amd-e3') if [ ${mem} -le 1010 ] && [ ${cores} -le 64 ]
                        then
                           ckcores=$((${mem}/16))
                           if [ ${ckcores} -eq 0 ];then ckcores=1;fi
                           if [ ${cores} -le ${ckcores} ];then cores=${ckcores};fi
                           shape="VM.Standard.E3.Flex"
                        else
                           shape="VM.Standard.E3.Flex"
                        fi
                        ;;
                 'amd-e4') if [ ${mem} -le 1010 ] && [ ${cores} -le 64 ]
                        then
                           ckcores=$((${mem}/16))
                           if [ ${ckcores} -eq 0 ];then ckcores=1;fi
                           if [ ${cores} -le ${ckcores} ];then cores=${ckcores};fi
                           shape="VM.Standard.E4.Flex"
                        else
                           shape="VM.Standard.E4.Flex"
                        fi
                        ;;
                 'amd-e5') if [ ${mem} -le 1010 ] && [ ${cores} -le 64 ]
                        then
                           ckcores=$((${mem}/16))
                           if [ ${ckcores} -eq 0 ];then ckcores=1;fi
                           if [ ${cores} -le ${ckcores} ];then cores=${ckcores};fi
                           shape="VM.Standard.E5.Flex"
                        else
                           shape="VM.Standard.E5.Flex"
                        fi
                        ;;
                 'amd-e6') if [ ${mem} -le 1010 ] && [ ${cores} -le 64 ]
                        then
                           ckcores=$((${mem}/16))
                           if [ ${ckcores} -eq 0 ];then ckcores=1;fi
                           if [ ${cores} -le ${ckcores} ];then cores=${ckcores};fi
                           shape="VM.Standard.E6.Flex"
                        else
                           shape="VM.Standard.E6.Flex"
                        fi
                        ;;
                 'arm') if [ ${mem} -le 1010 ] && [ ${cores} -le 64 ]
                        then
                           ckcores=$((${mem}/16))
                           if [ ${ckcores} -eq 0 ];then ckcores=1;fi
                           if [ ${cores} -le ${ckcores} ];then cores=${ckcores};fi
                           shape="VM.Standard.A1.Flex --shape-config '{\"memoryInGBs\": ${mem}.0,\"ocpus\": ${cores}.0}'"
                        else
                           shape="VM.Standard.A1.Flex --shape-config '{\"memoryInGBs\": 1010.0,\"ocpus\": ${cores}.0}'"
                        fi
                        ;;
                     *) echo "ERROR: Invalid arch opton";exit 1;;
            esac
            ;;
    'true') if [ ${cores} -lt 128 ] || [ ${mem} -lt 2048 ]
            then
               shape="BM.Standard2.52"
            elif [ ${cores} -ge 128 ]
            then
               shape="BM.Standard.E3.128"
            fi
            ;;
    *) echo "ERROR: Invalid bare metal opton";exit 1;;
esac

if [ "${subcmd}" == 'setup' ] && [ "${dbg}" == 'true' ];then echo "DEBUG: arch=${arch} cores=${cores} mem=${mem} shape=${shape}";fi

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

   findpager

cat << EOF | ${pgcmd}
NAME
     ${cmd} [setup|deinstall|start|stop|apply|rstatus] [options]

SYNOPSIS
     Setup OCI commad line interface
        ${cmd} setup cli [options]

     Setup OCI squid web proxy
        ${cmd} setup squid [options]

     Setup OCI haproxy load balancer
        ${cmd} setup haproxy [options]

     Launch compute instance
        ${cmd} launch --name <name> [options]

     Terminate compute instance
        ${cmd} terminate --name <name> [options]

     Terminate ALL compute instances
        ${cmd} terminateall [options]

     Reoobt compute instance
        ${cmd} reboot --name <name> [options]

     Reoobt ALL compute instances
        ${cmd} rebootall --name <name> [options]

     Start compute instance
        ${cmd} start --name <name> [options]

     Start ALL compute instances
        ${cmd} startall --name <name> [options]

     Stop compute instance
        ${cmd} stop --name <name> [options]

     Stop ALL compute instances
        ${cmd} stopall --name <name> [options]

     List compute instance(s)
        ${cmd} list [<object>] [options]

        Where objects include compute, linux, and ad (availability domains)

     Secure Shell into compute instance
        ${cmd} ssh --name <name> [options]

     Deinstall OCI console configuration
        ${cmd} deinstall [options]

DESCRIPTION
     Sample script manage Oracle Cloud Infrastructure (OCI) compute
     instances.

OPTIONS
     General Options

        --role <role>               Compute instance role:
                                          dr = Directory and Replication Server
                                          ds = Directory Server
                                          rs = Replication Server
                                       oudsm = OUDSM Web Admin
                                       proxy = OUD Proxy
                                       slamd = SLAMD Server
                                         cli = SLAMD Client
                                    Default: dr

        --name <name>               Name of compute node
                                    Note: No whitespace in name

        --compartment <ocid>        OCI id of compartment

        --ad <availability_domain>  OCI Availability Domain

        --subnet <ocid>             OCI id of VCN subnet

        --pubip                     Public IP address
                                    Default: true

        --image <ocid>              OCI id of Operating System image
                                    Default: OCID for Oracle Linux 7u9

        --bm                        Use bare metal rathar host than virtual
                                    machine for OCI compute instance
                                    Default: Use virtual machine

        --arch <amd|intel>          Processor architecture of amd or intel
                                    Default: amd
                                    Options: intel, amd, amd-e3, amd-e4

        --cores <cores>             Number of cores to allocate to host
                                    Default: 1

        --mem <mem_in_gb>           Amount of memory in GB to allocate to host
                                    Default: 15

        --storage <storage_in_gb>   Specify boot volume storage size
                                    Default: 200GB

        --os <os>                   Operating system and version
                                    Default: ol8

        --osuser <userid>           Operating system user
                                    Default: ${osuser}

        --sshkey <file>             SSH public key file including path
                                    Default: $HOME/.ssh/id_rsa.pub

        --bitsdir <dir>             Path to JDK, FMW, and OUD software images
                                    Default: ${remoteBase}/bits

EXAMPLES

     List OCI compute instances
        ${cmd} list --compartment ocid1.compartment.oc1...

     Launch OCI compute instance for OUD Directory+Replication Server
     with a single AMD core, 15GB of RAM
        ${cmd} launch \
           --name ouddr1 \
           --role dr \
           --region us-ashburn-ad-1 \
           --ad uYkY:US-ASHBURN-AD-1 \
           --subnet ocid1.subnet.oc1.iad.aaaa... \
           --compartment ocid1.compartment.oc1... \
           --arch amd \
           --cores 1 \
           --mem 15

     Terminate OCI compute instance named ouddr1
        ${cmd} terminate --name ouddr1

     Reboot OCI compute instance named cli1
        ${cmd} terminate --name cli1

EOF
}

###############################################################################
# Setup web proxy for yum relay for nodes on private network
###############################################################################
setup_squid() {
   if [ "${webproxy}" == 'true' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      sudo -n yum -y install squid
      rc=$?
      sudo -n firewall-cmd --add-port=3128/tcp --permanent
      rc=$?
      sudo -n firewall-cmd --reload
      rc=$?
      sudo -n systemctl restart firewalld.service
      rc=$?
      sudo -n systemctl enable squid
      rc=$?
      sudo -n systemctl start squid
      rc=$?
      set +x
   fi
}

###############################################################################
# Setup LB proxy for load balancing
###############################################################################
setup_haproxy() {
   if [ "${lb}" == 'true' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      hadomain=${domain}
      sudo -n yum install -y haproxy
      sudo -n mkdir -p /var/lib/haproxy
      sudo -n chown -R ${osuser}:${osuser} /var/lib/haproxy /etc/haproxy
      cp /etc/haproxy/haproxy.cfg /etc/haproxy/haproxy.cfg-${now}

      cat > /etc/haproxy/haproxy.cfg <<EOF
global
    log         127.0.0.1 local2

    #chroot      /var/lib/haproxy
    #pidfile     /var/run/haproxy.pid
    pidfile     /etc/haproxy/haproxy.pid
    maxconn     10000
    user        ${osuser}
    group       ${osgroup}
    daemon

    # turn on stats unix socket
    stats socket /var/lib/haproxy/stats

defaults
    mode                    tcp
    log                     global
    option                  dontlognull
    option                  redispatch
    retries                 3
    timeout http-request    10s
    timeout queue           1m
    timeout connect         10s
    timeout client          1m
    timeout server          1m
    timeout http-keep-alive 10s
    timeout check           10s
    maxconn                 10000

frontend  oud-in
    bind *:10389
    default_backend oud-out

frontend  secure-oud-in
    bind *:10636
    default_backend secure-oud-out

backend oud-out
    balance     roundrobin
EOF

      n=1
      for host in $(grep -h "^oud" ${cfgdir}/hosts|cut -d'|' -f1)
      do
         ckLDAP=$(test_port ${host} 1389)
         if [ -z "${ckLDAP}" ]
         then
            cat >> /etc/haproxy/haproxy.cfg <<EOF
    server      oud${n} ${host}:1389 check maxconn 5000
EOF
         fi
         let n++
      done

      cat >> /etc/haproxy/haproxy.cfg <<EOF

backend secure-oud-out
    balance     roundrobin
EOF

      n=1
      for host in $(grep -h "^oud" ${cfgdir}/hosts|cut -d'|' -f1)
      do
         ckLDAP=$(test_port ${host} 1636)
         if [ -z "${ckLDAP}" ]
         then
            cat >> /etc/haproxy/haproxy.cfg <<EOF
    server      oud${n} ${host}:1636 check maxconn 5000
EOF
         fi
         let n++
      done

      cat >> /etc/haproxy/haproxy.cfg <<EOF

listen admin
    mode http
    bind *:8181
    stats enable
EOF

      sudo -n firewall-cmd --add-port=8181/tcp --add-port=10389/tcp --add-port=10636/tcp --permanent
      sudo -n firewall-cmd --reload
      sudo -n systemctl enable haproxy
      sudo -n systemctl stop haproxy
      sudo -n systemctl start haproxy
      set +x
   fi
}

###############################################################################
# Setup OCI configuration and set key variables
###############################################################################
setup_oci_cli() {
   if [ -z "${tocid}" ]
   then
      echo -e "Enter Tenancy OCID: \c"
      read tocid
   fi

   if [ -z "${uocid}" ]
   then
      echo -e "Enter User OCID: \c"
      read uocid
   fi

   if [ -z "${compartment}" ]
   then
      echo -e "Enter Compartment OCID: \c"
      read compartment
   fi

   if [ -z "${region}" ]
   then
      echo -e "Enter Region: \c"
      read region
   fi

   . ${curdir}/poc_vars
   isInstalled='false'

   # Install OCI command line interface
   if [ -e "${curdir}/oci_cli/bin/oci" ]
   then
      isInstalled='true'
   else
      let steps++
      echo "[oci:setup] Step: ${steps} - Install OCI CLI" | tee -a ${logdir}/oci-install-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      mkdir -p "${curdir}/oci_cli" 2> /dev/null
      cd "${curdir}/oci_cli"
      curl -ksL -o oci_install.sh https://raw.githubusercontent.com/oracle/oci-cli/master/scripts/install/install.sh >> ${logdir}/oci-install-${now}.log 2>&1
      rc=$?

      if [ ${rc} -ne 0 ]
      then
         echo -e "ERROR: Cannot download OCI CLI. See log file:\n   ${logdir}/oci-install-${now}.log"
         exit 1
      fi

      chmod 0700 ./oci_install.sh
      rc=$?

      ./oci_install.sh --install-dir "${curdir}/oci_cli" --exec-dir "${curdir}/oci_cli" --script-dir "${curdir}/oci_cli" --python-install-location "${curdir}/oci_cli" --accept-all-defaults >> ${logdir}/oci-install-${now}.log 2>&1
      rc=$?

      if [ ${rc} -eq 0 ]
      then
         rm -f oci_install.sh 2> /dev/null
      elif [ ${rc} -ne 0 ]
      then
         echo -e "ERROR: OCI CLI install failed. See log file:\n   ${logdir}/oci-install-${now}.log"
         exit 1
      fi
   fi

   # Setup OCI CLI keys
   if [ -e "$HOME/.oci/oudpockit.pem" ]
   then
      true
   else
      let steps++
      echo "[oci:setup] Step: ${steps} - Setup OCI API Keys" | tee -a ${logdir}/oci-setup-${now}.log

      # Workaround 
      cd "${curdir}/oci_cli"
      if [ -e "lib64/python3.6/site-packages/oci_cli/cli_setup.py" ]
      then
         cp lib64/python3.6/site-packages/oci_cli/cli_setup.py lib64/python3.6/site-packages/oci_cli/cli_setup.py.${now}
         egrep -v " if not passphrase:| passphrase = prompt_for_passphrase()" lib64/python3.6/site-packages/oci_cli/cli_setup.py.${now} > lib64/python3.6/site-packages/oci_cli/cli_setup.py
      fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oci} setup keys --key-name oudpockit --output-dir "$HOME/.oci" --passphrase '' --config-file "$HOME/.oci/config" >> ${logdir}/oci-setup-${now}.log 2>&1
      rc=$?

      if [ ${rc} -ne 0 ]
      then
         echo "ERROR: Could not generate OCI key"
         exit 1
      fi
   fi

   fingerprint=$(grep "Public key fingerprint" ${logdir}/oci-setup-${now}.log|cut -d' ' -f4-)

   # Setup OCI CLI config
   if [ -e "$HOME/.oci/config" ]
   then
      true
   else
      let steps++
      echo "[oci:setup] Step: ${steps} - Setup OCI CLI config" | tee -a ${logdir}/oci-setup-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi

      cat > ~/.oci/config <<EOF
[DEFAULT]
user=${uocid}
fingerprint=${fingerprint}
key_file=$HOME/.oci/oudpockit.pem
tenancy=${tocid}
region=${region}
EOF

      chmod 0600 "$HOME/.oci/config"

      # Add default compartment-id to OCI CLI config
      ck=$(grep "compartment-id=${compartment}" $HOME/.oci/config)
      if [ -n "${compartment}" ] && [ -z "${ck}" ]
      then
         echo "compartment-id=${compartment}" >> $HOME/.oci/config
      fi

      ck=$(grep "subnet-id=${subnet}" $HOME/.oci/config)
      if [ -n "${subnet}" ] && [ -z "${ck}" ]
      then
         echo "subnet-id=${subnet}" >> $HOME/.oci/config
      fi

      echo "   Next Steps:"
      echo "   1. Open the Oracle Cloud Console"
      echo "   2. Add the following public key as a new API Key to your OCI account:"
      cat $HOME/.oci/oudpockit_public.pem
   fi
}

###############################################################################
# Run appropriate setup
###############################################################################
setup_oci() {
   case ${cmdArg2} in
          'cli') setup_oci_cli;;
        'squid') webproxy=true;setup_squid;;
      'haproxy') lb=true;setup_haproxy;;
              *) showUsage;;
   esac
}

###############################################################################
# Launch OCI Compute Instance
###############################################################################
launch_compute() {
   # Validate inputs
   if [ -z "${cname}" ]
   then
      echo "ERROR: Must provide --cname <compute_name>"
      exit 1
   fi

   # Check locally
   if [ -e "${cfgdir}/oci-${compartment}-${cn}.info" ]
   then
      echo "ERROR: OCI compute instance ${cname} already exists"
      exit 1
   else
      if [ "${dbg}" == 'true' ];then set -x;fi
      ck4cn=$(${oci} compute instance list --all --compartment-id ${compartment} --region ${region} --query 'data[*].["display-name","lifecycle-state","id"]' --output table 2> /dev/null|grep "^| ${cname} "|egrep "RUNNING|STOPPED"|awk '{ print $6 }')
      if [ -n "${ck4cn}" ]
      then
         echo "OCI compute instance ${cname} already exists"
         exit 0
      fi
   fi

   cn=$(echo "${cname}"|sed -e "s/	/_/g" -e "s/ /_/g")
   let steps++
   echo "[oci:${cname}] Step: ${steps} - Launch compute ${cname} (${cores} ${arch}|${mem}GB|${storage}GB|${preemptibleTag})" | tee -a ${logdir}/oci-${cn}-${now}.log
   #lenName=$(echo ${cname}|wc -c|sed -e "s/ //g")
   #printf "     %-11s%-8s%-12s%-12s%-17s%-17s\n" "Core(s)"            "RAM(GB)" "Storage(GB)" "Preemptible" "Private IP" "Public IP" | tee -a ${logdir}/oci-${cn}-${now}.log
   #printf "     %-11s%-8s%-12s%-12s%-17s%-17s\n" "----------"         "-------" "-----------" "-----------" "----------------" "----------------" | tee -a ${logdir}/oci-${cn}-${now}.log
   #printf "     %-11s%-8s%-12s%-12s"             "${cores} ${arch}"   "${mem}"  "${storage}"  "${preemptibleTag}"                    | tee -a ${logdir}/oci-${cn}-${now}.log

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ ${arch} == 'intel' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oci} compute instance launch ${preemptibleFlag} --region ${region} --availability-domain ${ad} --display-name "${cn}" --image-id ${image} --subnet-id ${subnet} --shape ${shape} --compartment-id ${compartment} --boot-volume-size-in-gbs ${storage} --assign-public-ip ${pubip} --ssh-authorized-keys-file "${sshkey}" > ${logdir}/oci-${cname}-${now}.json 2> ${logdir}/oci-${cn}-${now}.log
      rc=$?;set +x
   elif [ ${arch} == 'amd' ] || [ ${arch} == 'amd-e3' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oci} compute instance launch ${preemptibleFlag} --region ${region} --availability-domain ${ad} --display-name "${cn}" --image-id ${image} --subnet-id ${subnet} --shape ${shape} --shape-config "{\"memoryInGBs\": ${mem}.0,\"ocpus\": ${cores}.0, \"baselineOcpuUtilization\": \"${burstRate}\"}" --compartment-id ${compartment} --boot-volume-size-in-gbs ${storage} --assign-public-ip ${pubip} --ssh-authorized-keys-file "${sshkey}" > ${logdir}/oci-${cname}-${now}.json 2> ${logdir}/oci-${cn}-${now}.log
      rc=$?;set +x
   elif [ ${arch} == 'amd-e4' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oci} compute instance launch ${preemptibleFlag} --region ${region} --availability-domain ${ad} --display-name "${cn}" --image-id ${image} --subnet-id ${subnet} --shape ${shape} --shape-config "{\"memoryInGBs\": ${mem}.0,\"ocpus\": ${cores}.0, \"baselineOcpuUtilization\": \"${burstRate}\"}" --compartment-id ${compartment} --boot-volume-size-in-gbs ${storage} --assign-public-ip ${pubip} --ssh-authorized-keys-file "${sshkey}" > ${logdir}/oci-${cname}-${now}.json 2> ${logdir}/oci-${cn}-${now}.log
      rc=$?;set +x
   elif [ ${arch} == 'amd-e5' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oci} compute instance launch ${preemptibleFlag} --region ${region} --availability-domain ${ad} --display-name "${cn}" --image-id ${image} --subnet-id ${subnet} --shape ${shape} --shape-config "{\"memoryInGBs\": ${mem}.0,\"ocpus\": ${cores}.0, \"baselineOcpuUtilization\": \"${burstRate}\"}" --compartment-id ${compartment} --boot-volume-size-in-gbs ${storage} --assign-public-ip ${pubip} --ssh-authorized-keys-file "${sshkey}" > ${logdir}/oci-${cname}-${now}.json 2> ${logdir}/oci-${cn}-${now}.log
      rc=$?;set +x
   elif [ ${arch} == 'arm' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      #${oci} compute instance launch ${preemptibleFlag} --region ${region} --availability-domain ${ad} --display-name "${cn}" --image-id ${image} --subnet-id ${subnet} --shape ${shape} --shape-config "{\"memoryInGBs\": ${mem}.0,\"ocpus\": ${cores}.0, \"baselineOcpuUtilization\": \"${burstRate}\"}" --compartment-id ${compartment} --boot-volume-size-in-gbs ${storage} --assign-public-ip ${pubip} --ssh-authorized-keys-file "${sshkey}" > ${logdir}/oci-${cname}-${now}.json 2> ${logdir}/oci-${cn}-${now}.log
      ${oci} compute instance launch ${preemptibleFlag} --region ${region} --availability-domain ${ad} --display-name "${cn}" --image-id ${image} --subnet-id ${subnet} --shape "${shape}" --compartment-id ${compartment} --boot-volume-size-in-gbs ${storage} --assign-public-ip ${pubip} --ssh-authorized-keys-file "${sshkey}" > ${logdir}/oci-${cname}-${now}.json 2> ${logdir}/oci-${cn}-${now}.log
      rc=$?;set +x
   fi

   if [ ${rc} -ne 0 ]
   then
      echo "ERROR: oci compute instance lauch failed with the following error:"
      cat ${logdir}/oci-${cn}-${now}.log
      exit 1
   fi

   compute_id=$(cat ${logdir}/oci-${cname}-${now}.json|${pyCmd} -c 'import sys,json; print(json.load(sys.stdin)["data"]["id"])')
   set +x

   # Wait for instance to reach RUNNING state
   state=''
   if [ "${dbg}" == 'true' ];then set -x;fi
   while [ "$state" != 'RUNNING' ] && [ "$state" != 'TERMINATED' ]
   do
      state=$(${oci} compute instance get --instance-id ${compute_id} --region ${region} --query 'data.["lifecycle-state"]' --output json 2>&1 |${pyCmd} -c 'import sys,json; print(json.load(sys.stdin)[0])')
      sleep 1
   done
   set +x

   if [ "${state}" == 'TERMINATED' ]
   then
      echo "ERROR: oci compute instance lauch failed with the following error:"
      echo "cat ${logdir}/oci-${cn}-${now}.log"
      cat ${logdir}/oci-${cn}-${now}.log
      exit 1
   fi

   # Lookup IP addresses
   if [ "${dbg}" == 'true' ];then set -x;fi
   privateip=$(${oci} compute instance list-vnics --all --instance-id ${compute_id} --region ${region} 2>&1|${pyCmd} -c 'import sys,json; print(json.load(sys.stdin)["data"][0]["private-ip"])')
   publicip=$(${oci} compute instance list-vnics --all --instance-id ${compute_id} --region ${region} 2>&1|${pyCmd} -c 'import sys,json; print(json.load(sys.stdin)["data"][0]["public-ip"])')
   set +x

   # Finish showing the details for this compute instance
   #printf "%-17s%-17s\n" "${privateip}" "${publicip}" | tee -a ${logdir}/oci-${cn}-${now}.log

   echo "${cn}|${cname}|${compute_id}|${compartment}|${privateip}|${publicip}" > ${cfgdir}/oci-${compartment}-${cn}.info

   if [ "${publicip}" != 'None' ];then sship=${publicip};else sship=${privateip};fi

   # Update ssh known hosts
   if [ "${dbg}" == 'true' ];then set -x;fi
   ssh-keygen -R ${sship} -f "$HOME/.ssh/known_hosts" >> ${logdir}/ssh-${now}.log 2>&1

   # Wait until ssh is up
   sshstate=''
   while [ "$sshstate" != "${osuser}" ]
   do
      sshstate=$(ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} id -n -u 2> /dev/null)
      sleep 1
   done
   set +x

   # Give OCI a few seconds to complete name service mapping
   sleep 5

   let steps++
   echo "[oci:${cname}] Step: ${steps} - Setup requisite directory path structure" | tee -a ${logdir}/oci-${cn}-${now}.log
   if [ "${dbg}" == 'true' ];then set -x;fi

   tries=0
   unset rhost
   while [ -z "${rhost}" ] && [ ${tries} -le 5 ]
   do
      let tries++
      rhost=$(nslookup ${cname}|awk '{ print $2 }'|grep oraclevcn.com)
      if [ -z "${rhost}" ];then rhost=$(nslookup ${sship}|awk '{ print $2 }'|grep oraclevcn.com);fi
      if [ -z "${rhost}" ];then rhost=$(ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "getent hosts ${privateip}" 2> /dev/null|grep -i oraclevcn.com|awk '{ print $2 }');fi
      sleep 5
   done

   if [ -z "${rhost}" ];then echo "ERROR: Cannot determine FQDN of host ${cname} (${privateip})";exit 1;fi
   ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n hostnamectl set-hostname ${rhost}" >> ${logdir}/oci-${cn}-${now}.log 2>&1
   ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n mkdir -p \"${remoteBitsDir}\" \"${remoteCfgDir}\" \"${remoteBase}/samples\" \"${remoteBase}/kubernetes\";sudo -n chown -R ${osuser}:${osgroup} ${subdir}" >> ${logdir}/oci-${cn}-${now}.log 2>&1
   if [ -n "${bPW}" ]
   then
      let steps++
      echo "[oci:${cname}] Step: ${steps} - Set OUD Kit default password" | tee -a ${logdir}/oci-${cn}-${now}.log
      ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "echo ${bPW} > ${jPW}" >> ${logdir}/oci-${cn}-${now}.log 2>&1
   fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   # Add yum proxy config
   if [ "${webproxy}" == 'true' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "echo -e \"proxy=http://${localHost}:3128\nrepo_gpgcheck=0\" |sudo -n tee -a /etc/yum.conf > /dev/null 2>&1"
      rc=$?;set +x
   fi
   set +x

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ "${webproxy}" == 'true' ]
   then
      repoAvailable='false'
      n=0
      while [ "${repoAvailable}" == 'false' ] && [ ${n} -le 10 ]
      do
         let n++
         ckrepo=$(curl -s -x http://${localHost}:3128 https://yum.oracle.com/RPM-GPG-KEY-oracle-${ociOS} 2> /dev/null|grep GnuPG)
         if [ -n "${ckrepo}" ];then repoAvailable='true';fi
         sleep 1
      done
      if [ "${repoAvailable}" == 'false' ]
      then
         echo "ERROR: Yum repo is available or cannot connect through web proxy"
         exit 1
      fi
   fi
   set +x

   if [ "${dbg}" == 'true' ];then set -x;fi
   installedSuccessfully='false'
   n=0
   while [ "${installedSuccessfully}" == 'false' ] && [ ${n} -le 50 ]
   do
      let n++
      ckrepo=$(ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n yum install -y psmisc" 2>&1 |grep 'already installed')
      if [ -n "${ckrepo}" ];then installedSuccessfully='true';fi
      sleep 5
   done
   if [ "${installedSuccessfully}" == 'false' ]
   then
      echo "ERROR: Yum repo is available or cannot connect through web proxy"
      exit 1
   fi
   set +x

   # Install ODS+ requisites
   let steps++
   echo "[oci:${cname}] Step: ${steps} - Install OS requisites" | tee -a ${logdir}/oci-${cn}-${now}.log
   if [ "${dbg}" == 'true' ];then set -x;fi
   ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n yum install -y cloud-utils-growpart rsync;echo $?" >> ${logdir}/oci-${cn}-${now}.log 2>&1
   rc=$?;set +x

   # Install partition tools and expand partition to boot drive size
   if [ "${dbg}" == 'true' ];then set -x;fi
   case ${ociOS} in
      'ol7') ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n growpart /dev/sda 3;sudo -n xfs_growfs -d /" >> ${logdir}/oci-${cn}-${now}.log 2>&1;;
      'ol8') ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n growpart /dev/sda 3;sudo -n pvresize /dev/sda3;sudo -n lvextend -l +100%FREE /dev/mapper/ocivolume-root;sudo -n xfs_growfs -d /" >> ${logdir}/oci-${cn}-${now}.log 2>&1;;
      'ol9') ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n growpart /dev/sda 3;sudo -n pvresize /dev/sda3;sudo -n lvextend -l +100%FREE /dev/mapper/ocivolume-root;sudo -n xfs_growfs -d /" >> ${logdir}/oci-${cn}-${now}.log 2>&1;;
   esac
   rc=$?;set +x

   let steps++
   echo "[oci:${cname}] Step: ${steps} - Copy kit and bits to ${cname}" | tee -a ${logdir}/oci-${cn}-${now}.log
   if [ "${dbg}" == 'true' ];then set -x;fi
   rsync -qHae "ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no" ${curdir}/bits/. ${osuser}@${sship}:${remoteBase}/bits/. >> ${logdir}/oci-${cn}-${now}.log 2>&1
   rc=$?
   rsync -qHae "ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no" ${curdir}/poc_vars ${osuser}@${sship}:${remoteBase}/. >> ${logdir}/oci-${cn}-${now}.log 2>&1
   rc=$?
   rsync -qHae "ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no" ${curdir}/*.sh ${osuser}@${sship}:${remoteBase}/. >> ${logdir}/oci-${cn}-${now}.log 2>&1
   rc=$?
   rsync -qHae "ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no" ${curdir}/samples/. ${osuser}@${sship}:${remoteBase}/samples/. >> ${logdir}/oci-${cn}-${now}.log 2>&1
   rc=$?
   rsync -qHae "ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no" ${curdir}/kubernetes/. ${osuser}@${sship}:${remoteBase}/kubernetes/. >> ${logdir}/oci-${cn}-${now}.log 2>&1
   rc=$?
   set +x

   let steps++
   echo "[oci:${cname}] Step: ${steps} - Enable firewall for ${role} role" | tee -a ${logdir}/oci-${cn}-${now}.log
   if [ "${dbg}" == 'true' ];then set -x;fi
   case ${role} in
       'dr'|'ds') ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n firewall-cmd --permanent --zone=public --add-port=${adminPort}/tcp --add-port=${ldapPort}/tcp --add-port=${ldapsPort}/tcp --add-port=${replPort}/tcp --add-port=2444/tcp --add-port=2389/tcp --add-port=2636/tcp --add-port=2989/tcp --add-port=3444/tcp --add-port=3389/tcp --add-port=3636/tcp --add-port=3989/tcp --add-port=4444/tcp --add-port=4389/tcp --add-port=4636/tcp --add-port=4989/tcp --add-port=5444/tcp --add-port=5389/tcp --add-port=5636/tcp --add-port=5989/tcp --add-port=6444/tcp --add-port=6389/tcp --add-port=6636/tcp --add-port=6989/tcp --add-port=7444/tcp --add-port=7389/tcp --add-port=7636/tcp --add-port=7989/tcp --add-port=8444/tcp --add-port=8389/tcp --add-port=8636/tcp --add-port=8989/tcp --add-port=9444/tcp --add-port=9389/tcp --add-port=9636/tcp --add-port=9989/tcp; sudo -n firewall-cmd --reload; 2>&1" >> ${logdir}/oci-${cn}-${now}.log 2>&1;;
            'rs') ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n firewall-cmd --permanent --zone=public --add-port=${adminPort}/tcp --add-port=${replPort}/tcp --add-port=2444/tcp --add-port=2989/tcp --add-port=3444/tcp --add-port=3989/tcp --add-port=4444/tcp --add-port=4989/tcp --add-port=5444/tcp --add-port=5989/tcp --add-port=6444/tcp --add-port=6989/tcp --add-port=7444/tcp --add-port=7989/tcp --add-port=8444/tcp --add-port=8989/tcp --add-port=9444/tcp --add-port=9989/tcp;sudo -n firewall-cmd --reload; 2>&1" >> ${logdir}/oci-${cn}-${now}.log 2>&1;;
         'proxy') ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n firewall-cmd --permanent --zone=public --add-port=1445/tcp; sudo -n firewall-cmd --permanent --zone=public --add-port=1390/tcp; sudo -n firewall-cmd --permanent --zone=public --add-port=1637/tcp; sudo -n firewall-cmd --reload; 2>&1" >> ${logdir}/oci-${cn}-${now}.log 2>&1;;
         'oudsm') ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n firewall-cmd --permanent --zone=public --add-port=7002/tcp; sudo -n firewall-cmd --reload; 2>&1" >> ${logdir}/oci-${cn}-${now}.log 2>&1;;
         'slamd') ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n firewall-cmd --permanent --zone=public --add-port=8080/tcp --add-port=3000/tcp; sudo firewall-cmd --reload; 2>&1" >> ${logdir}/oci-${cn}-${now}.log 2>&1;;
   esac
   set +x

   let steps++
   echo "[oci:${cname}] Step: ${steps} - Tune Linux for OUD" | tee -a ${logdir}/oci-${cn}-${now}.log
   if [ -e "${cfgdir}/limits.conf" ]
   then
      true
   else
      cat >> ${cfgdir}/limits.conf <<EOF
${osuser}       hard    nofile  65536
${osuser}       soft    nofile  8192
${osuser}       hard    nproc   16384
${osuser}       soft    nproc   16384
EOF
   fi

   cat ${cfgdir}/limits.conf|ssh -t -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n tee -a /etc/security/limits.conf" >> ${logdir}/oud-env-${now}.log 2>&1
   #rm ${cfgdir}/limits.conf

   echo -e "vm.swappiness = 0\nnet.netfilter.nf_conntrack_tcp_timeout_time_wait=1\nnet.ipv4.tcp_tw_reuse=1\nnet.ipv4.tcp_fin_timeout=1"|ssh -t -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n tee -a /etc/sysctl.conf" >> ${logdir}/oud-env-${now}.log 2>&1

   ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "sudo -n sysctl -p /etc/sysctl.conf" >> ${logdir}/oud-env-${now}.log 2>&1

   ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${sship} "free;lsmem;lscpu" > ${logdir}/oci-${cn}-${now}.metrics

   vmMetricsFile="${logdir}/oci-${cn}-${now}.metrics"
   vmVCPUs=$(grep "^CPU(s):" ${vmMetricsFile}|awk '{ print $2 }')
   vmThreadsPerCore=$(grep "^Thread(s) per core:" ${vmMetricsFile}|awk '{ print $4 }')
   vmCorePerSocket=$(grep "^Core(s) per socket:" ${vmMetricsFile}|awk '{ print $4 }')
   vmCoreCnt=$((${vmVCPUs}/${vmThreadsPerCore}))
   vmCoreModel=$(grep "^Model name:" ${vmMetricsFile}|cut -d':' -f2-|sed -e "s/^ .*AMD/AMD/g" -e "s/^ .*Intel/Intel/g")
   vmCoreHz=$(grep "^CPU MHz:" ${vmMetricsFile}|awk '{ printf "%.0f", $3 }')
   vmMem=$(grep "^Mem:" ${vmMetricsFile}|awk '{ printf "%.1f", $2/1000/1000 }')

   printf "%-${lenName}s%-16s%-16s%-6s%-8s%-9s%-5s%-20s\n" "Name" "PublicIP" "PrivateIP" "Cores" "Mem(GB)" "Disk(GB)" "Hz" "Model" > ${cfgdir}/oci-${compartment}-${cn}.resources
   printf "%-${lenName}s%-16s%-16s%-6s%-8s%-9s%-5s%-20s\n" "${cname}" "${publicip}" "${privateip}" "${vmCoreCnt}" "${vmMem}" "${storage}" "${vmCoreHz}" "${vmCoreModel}" >> ${cfgdir}/oci-${compartment}-${cn}.resources
}

###############################################################################
# Lookp Compute OCID
###############################################################################
lookup_compute_ocid() {
   cn=$(echo "${cname}"|sed -e "s/	/_/g" -e "s/ /_/g")
   if [ -e "${cfgdir}/oci-${compartment}-${cn}.info" ]
   then
      # 1     2        3             4              5            6
      # ${cn}|${cname}|${compute_id}|${compartment}|${privateip}|${publicip}
      compute_id=$(cat ${cfgdir}/oci-${compartment}-${cn}.info 2> /dev/null|cut -d'|' -f3)
      if [ -z "${compartment}" ];then compartment=$(cat ${cfgdir}/oci-${compartment}-${cn}.info 2> /dev/null|cut -d'|' -f4);fi
   fi

   if [ "${subcmd}" == 'setup'  ] && [ -z "${compartment}" ]
   then
      echo "ERROR: Must provide --compartment <compartment_id>"
      exit 1
   fi

   if [ -z "${compute_id}" ]
   then
      compute_id=$(${oci} compute instance list --all --compartment-id ${compartment} --region ${region} --query 'data[*].["display-name","lifecycle-state","id"]' --output table|grep -v TERMINATED|sed -e "s/ //g"|grep "|${cname}|"|cut -d'|' -f4)
   fi

   #if [ -z "${compute_id}" ]
   #then
   #   echo "ERROR: No OCID found for node ${cname}"
   #   exit 1
   #fi
}

###############################################################################
# Check to see if compute instance is preemptible
###############################################################################
ckpreemptible() {
   ck4preemptible=$(${oci} compute instance list --compartment-id ${compartment} --region ${region} --display-name "${cn}" --lifecycle-state 'RUNNING' --query 'data[*].["display-name","preemptible-instance-config","id"]' --output table|grep "${cn_ocid}"|awk '{ print $4 }'|grep preempt)
}

###############################################################################
# Terminate OCI Compute Instance
###############################################################################
terminate_compute() {
   lookup_compute_ocid

   if [ -n "${compute_id}" ]
   then
      let steps++
      echo "[oci:${cname}] Step: ${steps} - Terminate compute instance ${cname}" | tee -a ${logdir}/oci-${cn}-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oci} compute instance terminate --force --max-wait-seconds 6000 --wait-for-state TERMINATED --instance-id ${compute_id} --region ${region} >> ${logdir}/oci-${cn}-${now}.log 2>&1
      rc=$?;set +x

      echo "Action completed. Waiting until the resource has entered state: ('TERMINATED',)"

      # Wait for instance to reach TERMINATED state
      ck4termination=''
      while [ -n "${ck4termination}" ]
      do
         ck4termination=$(${oci} compute instance list --all --compartment-id ${compartment} --region ${region} --query 'data[*].["display-name","lifecycle-state","id"]' --output table|sed -e "s/ //g"|grep "|${cname}|"|grep "|TERMINATED|")
         sleep 1
      done

      # Remove compute instance info and resources files
      rm -f "${cfgdir}/oci-${compartment}-${cn}.info" 2> /dev/null
      rm -f "${cfgdir}/oci-${compartment}-${cn}.resources" 2> /dev/null
   else
      echo "INFO: OCI compute node ${cname} does not exist"
   fi
}

###############################################################################
# Stop OCI Compute Instances
###############################################################################
stop_compute() {
   lookup_compute_ocid
   ckpreemptible

   let steps++
   echo "[oci:${cname}] Step: ${steps} - Stopping node" | tee -a ${logdir}/oci-${cn}-${now}.log

   if [ -n "${ck4preemptible}" ]
   then
      echo "[${cname}] This node is preemptible, which does not support stop/start/reboot"
   else
      if [ "${dbg}" == 'true' ];then set -x;fi
      timeout 5m ${oci} compute instance action --action SOFTSTOP --max-wait-seconds 6000 --wait-for-state STOPPED --region ${region} --instance-id ${compute_id} >> ${logdir}/oci-${cn}-${now}.log
      rc=$?;set +x
   fi
}

###############################################################################
# Start OCI Compute Instances
###############################################################################
start_compute() {
   lookup_compute_ocid
   ckpreemptible

   let steps++
   echo "[oci:${cname}] Step: ${steps} - Starting node" | tee -a ${logdir}/oci-${cn}-${now}.log

   if [ -n "${ck4preemptible}" ]
   then
      echo "[${cname}] This node is preemptible, which does not support stop/start/reboot"
   else
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oci} compute instance action --action START --max-wait-seconds 6000 --wait-for-state RUNNING --region ${region} --instance-id ${compute_id} >> ${logdir}/oci-${cn}-${now}.log
      rc=$?
      set +x
   fi
}

###############################################################################
# Reboot OCI Compute Instance
###############################################################################
reboot_compute() {
   lookup_compute_ocid
   ckpreemptible

   let steps++
   echo "[oci:${cname}] Step: ${steps} - Rebooting node" | tee -a ${logdir}/oci-${cn}-${now}.log

   if [ -n "${ck4preemptible}" ]
   then
      echo "[${cname}] This node is preemptible, which does not support stop/start/reboot"
   else
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oci} compute instance action --max-wait-seconds 6000 --wait-for-state RUNNING --region ${region} --instance-id ${compute_id} --action SOFTRESET >> ${logdir}/oci-${cn}-${now}.log
      rc=$?; set +x
   fi
}

###############################################################################
# List OCI Compute Instance
###############################################################################
list_compute() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -n "${compartment}" ]
   then
      if [ "${os}" == 'Darwin' ]
      then
         read -r -a nodes <<< $(${oci} compute instance list --all --compartment-id ${compartment} --region ${region} --query 'data[*].["display-name","lifecycle-state","shape","id"]' --output table|sed -e "s/ //g"|grep "|oci"|egrep -v -- 'TERMINATED|---')
      elif [ "${os}" == 'Linux' ]
      then
         readarray -t nodes < <(${oci} compute instance list --all --compartment-id ${compartment} --region ${region} --query 'data[*].["display-name","lifecycle-state","shape","id"]' --output table|sed -e "s/ //g"|grep "|oci"|egrep -v -- 'TERMINATED|---')
      fi

      # Determine column width of name var
      if [ ${lenName} -eq 0 ]
      then
         for (( i=0; i< ${#nodes[*]}; i++ ))
         do
            cklen=$(echo ${nodes[${i}]}|cut -d'|' -f2|wc -c|sed -e "s/ //g")
            if [ ${cklen} -gt ${lenName} ];then lenName=${cklen};fi
         done
         let lenName++
      fi

      printf "%-${lenName}s%-16s%-21s%-85s\n" "Name" "State" "Shape" "ID"
      for (( i=0; i< ${#nodes[*]}; i++ ))
      do
         name=$(echo ${nodes[${i}]}|cut -d'|' -f2)
         state=$(echo ${nodes[${i}]}|cut -d'|' -f3)
         shape=$(echo ${nodes[${i}]}|cut -d'|' -f4)
         id=$(echo ${nodes[${i}]}|cut -d'|' -f5)
         printf "%-${lenName}s%-16s%-21s%-85s\n" "${name}" "${state}" "${shape}" "${id}"
      done
   else
      echo "Error: Must provide --compartment <ocid> --region <region>"
      exit 1
   fi
}

###############################################################################
# List OCI Linux Images
###############################################################################
list_linux() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -n "${compartment}" ]
   then
      ${oci} compute image list --all --compartment-id ${compartment} --region ${region} --query "data [?contains(\"display-name\", '${imageLinuxBase}-')].{ImageName:\"display-name\", OCID:id}" --output table|egrep -v "GPU-|aarch64-"
      rc=$?;set +x
   else
      echo "Error: Must provide --compartment <ocid>"
      exit 1
   fi
}

###############################################################################
# List OCI Regions
###############################################################################
list_region() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -n "${compartment}" ]
   then
      ${oci} iam region list --output table --query "data [*].{Region:\"name\"}"|sed -e "s/[| ]//g"|grep -v -- '---'
      rc=$?;set +x
   else
      echo "Error: Must provide --compartment <ocid>"
      exit 1
   fi
}

###############################################################################
# List OCI Availability Domains
###############################################################################
list_ad() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -n "${compartment}" ]
   then
      ${oci} iam availability-domain list ${ociDbg} --region ${region} --compartment-id ${compartment} --output table --query "data [*].{\"Availability Domain\":\"name\"}"|egrep -- '-AD-|Avail'|sed -e "s/[| ]//g"|grep -v -- '---'
      rc=$?;set +x
   else
      echo "Error: Must provide --compartment <ocid>"
      exit 1
   fi
}

###############################################################################
# List OCI IP Addresses
###############################################################################
list_net() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   touch ${cfgdir}/hosts


   if [ -n "${compartment}" ]
   then
      if [ "${os}" == 'Darwin' ]
      then
         read -r -a nodes <<< $(${oci} compute instance list --all --compartment-id ${compartment} --region ${region} --query 'data[*].["display-name","id","lifecycle-state"]' --output table|egrep "RUNNING|STOPPED"|grep '.'|sed -e "s/ //g"|grep "|oci")
      elif [ "${os}" == 'Linux' ]
      then
         readarray -t nodes < <(${oci} compute instance list --all --compartment-id ${compartment} --region ${region} --query 'data[*].["display-name","id","lifecycle-state"]' --output table|egrep "RUNNING|STOPPED"|grep '.'|sed -e "s/ //g"|grep "|oci")
      fi

      if [ ${lenName} -eq 0 ]
      then
         for (( i=0; i< ${#nodes[*]}; i++ ))
         do
            cklen=$(echo ${nodes[${i}]}|cut -d'|' -f2|wc -c|sed -e "s/ //g")
            if [ ${cklen} -gt ${lenName} ];then lenName=${cklen};fi
         done
         let lenName++
      fi

      printf "%-${lenName}s%-16s%-16s%-20s\n" "Name" "PrivateIP" "PublicIP" "ID"
      for (( i=0; i< ${#nodes[*]}; i++ ))
      do
         name=$(echo ${nodes[${i}]}|cut -d'|' -f2)
         cn=$(echo "${name}"|sed -e "s/	/_/g" -e "s/ /_/g")
         id=$(echo ${nodes[${i}]}|cut -d'|' -f3)
         privateip=$(cat ${cfgdir}/oci-${compartment}-${cn}.info 2> /dev/null|cut -d'|' -f5)
         if [ -z "${privateip}" ]
         then
            privateip=$(${oci} compute instance list-vnics --all --instance-id ${id} --region ${region} 2> /dev/null|${pyCmd} -c 'import sys,json; print(json.load(sys.stdin)["data"][0]["private-ip"])')
         fi
         publicip=$(cat ${cfgdir}/oci-${compartment}-${cn}.info 2> /dev/null|cut -d'|' -f6)
         if [ -z "${publicip}" ]
         then
            publicip=$(${oci} compute instance list-vnics --all --instance-id ${id} --region ${region} 2> /dev/null|${pyCmd} -c 'import sys,json; print(json.load(sys.stdin)["data"][0]["public-ip"])')
         fi
         printf "%-${lenName}s%-16s%-16s%-20s\n" "${name}" "${privateip}" "${publicip}" "${id}"
         echo "${name}|${privateip}|${publicip}" >> ${cfgdir}/hosts.${now}

         # Create an info file if one does not already exist
         cn=$(echo "${name}"|sed -e "s/	/_/g" -e "s/ /_/g")
         if [ -e "${cfgdir}/oci-${compartment}-${cn}.info" ]
         then
            true
         else
            if [ -n "${cn}" ]
            then
               echo "${cn}|${name}|${id}|${compartment}|${privateip}|${publicip}" > ${cfgdir}/oci-${compartment}-${cn}.info
            fi
         fi
      done

      # Re-create hosts with current data if updated
      if [ -s "${cfgdir}/hosts.${now}" ]
      then
         if [ -d "${cfgdir}/archive" ];then true;else mkdir "${cfgdir}/archive";fi
         mv ${cfgdir}/hosts ${cfgdir}/archive/hosts-backup.${now}
         cat ${cfgdir}/hosts.${now} > ${cfgdir}/hosts
         rm ${cfgdir}/hosts.${now}
      fi
   else
      echo "Error: Must provide --compartment <ocid>"
      exit 1
   fi
}

###############################################################################
# List OCI Objects
###############################################################################
list_objects() {
   export lenName=0
   case ${cmdArg2} in
      compute) list_compute;;
        linux) list_linux;;
       region) list_region;;
           ad) list_ad;;
          net) list_net;;
          all) list_compute;echo;list_net;echo;list_region;echo;list_ad;;
            *) list_compute;;
   esac
}

###############################################################################
# Deinstall OCI configuration
###############################################################################
deinstall_oci() {
   if [ -e "${curdir}/oci_cli/bin/pip" ]
   then
      let steps++
      echo "Step: ${steps} - Deinstall OCI cli" | tee -a ${logdir}/oci-${cn}-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/oci_cli/bin/pip uninstall -y oci-cli >> ${logdir}/deinstall-cli-${now}.log 2>&1
      rc=$?
      ${curdir}/oci_cli/bin/pip uninstall -y oci >> ${logdir}/deinstall-cli-${now}.log 2>&1
      rc=$?
      set +x

      # Remove oci cli install
      if [ "${dbg}" == 'true' ];then set -x;fi
      rm -fr "${curdir}/oci_cli" 2> /dev/null
      rc=$?;set +x
   fi

   # Remove OCI CLI config
   if [ -e "$HOME/.oci/config" ]
   then
      let steps++
      echo "Step: ${steps} - Deinstall OCI CLI config" | tee -a ${logdir}/oci-deinstall-${now}.log

      if [ "${dbg}" == 'true' ];then set -x;fi
      rm -fr "$HOME/.oci/config" 2> /dev/null
      rc=$?;set +x
   fi

   # Remove OCI CLI config
   if [ -e "$HOME/.oci/oudpockit.pem" ]
   then
      let steps++
      echo "Step: ${steps} - Deinstall OCI CLI API Key" | tee -a ${logdir}/oci-deinstall-${now}.log

      if [ "${dbg}" == 'true' ];then set -x;fi
      rm -fr $HOME/.oci/oudpockit* 2> /dev/null
      rc=$?;set +x
   fi
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
         'setup') setup_oci;;
       'setuplb') lb=true;setup_haproxy;;
    'setupproxy') webproxy=true;setup_squid;;
     'deinstall') deinstall_oci;;
        'launch') launch_compute;;
     'terminate') terminate_compute;;
  'terminateall') if [ "${dbg}" == 'true' ];then set -x;fi
                  ${cmd} list --compartment ${compartment}|awk '{ print $1 }'|grep -v "^Name$"|xargs -n1 ${cmd} terminate --compartment ${compartment} --name
                  rc=$?;set +x
                  ;;
        'reboot') reboot_compute;;
     'rebootall') if [ "${dbg}" == 'true' ];then set -x;fi
                  ${cmd} list --compartment ${compartment}|awk '{ print $1 }'|grep -v "^Name$"|xargs -n1 ${cmd} reboot --compartment ${compartment} --name
                  rc=$?;set +x
                  ;;
          'stop') stop_compute;;
       'stopall') if [ "${dbg}" == 'true' ];then set -x;fi
                  ${cmd} list --compartment ${compartment}|awk '{ print $1 }'|grep -v "^Name$"|xargs -n1 ${cmd} stop --compartment ${compartment} --name
                  rc=$?;set +x
                  ;;
         'start') start_compute;;
      'startall') if [ "${dbg}" == 'true' ];then set -x;fi
                  ${cmd} list --compartment ${compartment}|awk '{ print $1 }'|grep -v "^Name$"|xargs -n1 ${cmd} start --compartment ${compartment} --name
                  rc=$?;set +x
                  ;;
          'list') list_objects;;
         'getip') if [ "${dbg}" == 'true' ];then set -x;fi
                  #publicip=$(cat ${cfgdir}/oci-${compartment}-${cname}.info 2> /dev/null|cut -d'|' -f6)
                  if [ -z "${publicip}" ]
                  then
                     lookup_compute_ocid
                     publicip=$(${oci} compute instance list-vnics --all --instance-id ${compute_id} --region ${region} 2> /dev/null|${pyCmd} -c 'import sys,json; print(json.load(sys.stdin)["data"][0]["public-ip"])')
                  fi
                  if [ -n "${publicip}" ]
                  then
                     echo "${publicip}"
                  else
                     echo "ERROR: No public IP available for ${cname}"
                  fi
                  set +x
                  ;;
         'getpip') if [ "${dbg}" == 'true' ];then set -x;fi
                  #privateip=$(cat ${cfgdir}/oci-${compartment}-${cname}.info 2> /dev/null|cut -d'|' -f5)
                  if [ -z "${privateip}" ]
                  then
                     lookup_compute_ocid
                     privateip=$(${oci} compute instance list-vnics --all --instance-id ${compute_id} --region ${region} 2> /dev/null|${pyCmd} -c 'import sys,json; print(json.load(sys.stdin)["data"][0]["private-ip"])')
                  fi
                  if [ -n "${privateip}" ]
                  then
                     echo "${privateip}"
                  else
                     echo "ERROR: No private IP available for ${cname}"
                  fi
                  set +x
                  ;;
           'ssh') if [ "${dbg}" == 'true' ];then set -x;fi
                  lookup_compute_ocid

                  if [ -n "${compute_id}" ]
                  then
                     cn=$(echo "${cname}"|sed -e "s/	/_/g" -e "s/ /_/g")
                     myip=$(cat ${cfgdir}/oci-${compartment}-${cname}.info 2> /dev/null|cut -d'|' -f6)
                     if [ "${myip}" == 'None' ];then myip=$(cat ${cfgdir}/oci-${compartment}-${cname}.info 2> /dev/null|cut -d'|' -f5);fi
                     if [ -n "${myip}" ]
                     then
                        if [ -n "${mycmd}" ]
                        then
                           if [ "${quiet}" != 'true' ]
                           then
                              let steps++
                              echo "[ssh:${cn}] Step: ${steps} - Run the following on ${cn} " | tee -a ${logdir}/oci-${cn}-${now}.log
                              echo "[exec] ${mycmd}" | tee -a ${logdir}/oci-${cn}-${now}.log
                           fi
                           ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${myip} "${mycmd}"
                           rc=$?;set +x
                        else
                           let steps++
                           echo "[ssh:${cn}] Step: ${steps} - ssh to ${cn} " | tee -a ${logdir}/oci-${cn}-${now}.log
                           ssh -p ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no ${osuser}@${myip}
                           rc=$?;set +x
                        fi
                     else
                        echo "ERROR: No IP found for ${cname}"
                        exit 1
                     fi
                  else
                     echo "INFO: OCI compute node ${cname} does not exist"
                     exit 1
                  fi
                  ;;
          'sync') if [ "${dbg}" == 'true' ];then set -x;fi
                  lookup_compute_ocid

                  if [ -n "${compute_id}" ]
                  then
                     cn=$(echo "${cname}"|sed -e "s/	/_/g" -e "s/ /_/g")
                     sship=$(cat ${cfgdir}/oci-${compartment}-${cname}.info 2> /dev/null|cut -d'|' -f6)
                     if [ "${sship}" == 'None' ];then sship=$(cat ${cfgdir}/oci-${compartment}-${cname}.info 2> /dev/null|cut -d'|' -f5);fi
                     if [ -n "${sship}" ]
                     then
                        if [ "${quiet}" != 'true' ]
                        then
                           let steps++
                           echo "[sync:${cn}] Step: ${steps} - Sync ${src} to ${cn}" | tee -a ${logdir}/oci-${cn}-${now}.log
                        fi
                        rsync -qHae "ssh -qp ${sshport} -i "${sshprivkey}" -o StrictHostKeyChecking=no" "${src}" "${osuser}@${sship}:${dst}"
                        rc=$?;set +x
                     else
                        echo "ERROR: No IP found for ${cname}"
                        exit 1
                     fi
                  else
                     echo "INFO: OCI compute node ${cname} does not exist"
                     exit 1
                  fi
                  ;;
               *) showUsage;;
esac
