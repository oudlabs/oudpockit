#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# The purpose of this script os to provide an example for how to manage
# minimally-privileged monitor user(s) to an existing OUD, Proxy, Replication 
# Gateway, or ODSEE instance.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   findpager

   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat << EOF | ${pgcmd}
NAME
     ${cmd} [add|modpw|delete|show] [options]

SYNOPSIS
     Generate data

     add      - Add a monitor user

     modpw    - Modify a monitor user's password

     delete   - Delete a monitor user

     show     - Show monitor user

DESCRIPTION
     Sample script to manage a minimally-privileged monitor user.

OPTIONS
     The following options are supported:

         --dstype [oud|dsee]     Directory service product
                                 Default: oud
                                 
         --utype [admin|data]    Administrative or data/suffix user

         --host <host>           Host on which DS runs
                                 Default: ${localHost}

         --port <port>           Secure LDAP or Admin port of DS instance
                                 Default: ${portAdmin}

         -D <dn>                 Privileged user used for managing the
                                 monitor user
                                 Default: cn=Directory Manager

         -j <file>               Password file of privileged user


         --muser <name>          Privileged user used for managing the
                                 Default: muser

         --suffix <dn>           Base suffix for the data user
                                 Default: ${suffix}

         --mpw <file>            File containing password of monitor user.

         --eus                   Add if needing to add monitor user to the
                                 following suffixes:
                                    cn=OracleContext
                                    cn=OracleContext,<suffix>

EXAMPLES

   Add minimally privileged monitor user to OUD administrative config.
 
   ${cmd} add --dsType oud --utype admin -j $HOME/.pw --mpw $HOME/.mpw

   Delete monitor user from OUD administrative config.

   ${cmd} delete --dsType oud --utype admin -j $HOME/.pw

   Change password of monitor user

   ${cmd} modpw --dsType oud --utype admin -j $HOME/.pw --mpw $HOME/.mpw

EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            utype) uType="$1";shift;;
            dstype) dsType="$1";shift;;
            host) myHost="$1";shift;;
            port) myPort="$1";shift;;
            muser) myMonitorUser="$1";shift;;
            mpw) myPwFile="$1";shift;;
            eus) eus='true';shift;;
            suffix) mySuffix="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            D) mybDN="$1";shift;;
            j) myjPW="$1";shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set defaults
###############################################################################
if [ -z "${uType}" ];then uType='admin';fi
if [ -z "${dsType}" ];then dsType='oud';fi

dsHost=${localHost}
case ${dsType} in
    'oud') # Storage, Proxy, and Replication Gateway
           case ${uType} in
              'admin') dsPort=${adminPort};suffix="cn=config";;
              'data') dsPort=${ldapsPort};;
           esac
           ;;
   'dsee') # Storage and Proxy
           if [ "${uType}" == 'admin' ];then suffix="cn=Administrators,cn=config";fi
           dsPort=1640
           ;;
        *) showUsage;;
esac

if [ -n "${myHost}" ];then dsHost="${myHost}";fi
if [ -n "${myPort}" ];then dsPort="${myPort}";fi
if [ -n "${myPwFile}" ];then pwFile=${myPwFile};fi
if [ "${uType}" != 'admin' ] && [ -n "${mySuffix}" ];then suffix=${mySuffix};fi
 
if [ -n "${myMonitorUser}" ];then monitorUser="${myMonitorUser}";fi
if [ -z "${monitorUser}" ];then monitorUser='muser';fi

if [ "${uType}" == 'admin' ]
then
   case ${dsType} in
         'oud') muserDN="cn=${monitorUser},cn=config";;
   esac
else
      case ${dsType} in
      'oud') muserDN="cn=${monitorUser},${suffix}";;
   esac
fi

if [ -e "${pwFile}" ]
then
   mPW=$(cat ${pwFile} 2> /dev/null)
else
   if [ "${subcmd}" == 'add' ]
   then
      echo "ERROR: Monitor user password file ${pwFile} does not exist"
      exit 1
   fi
fi

##############################################################################
# Ensure all requisites are satisfied
##############################################################################
getPyCmd

case ${subcmd} in
   'add'|'modify'|'delete'|'show') true;;
   *) showUsage "ERROR: Invalid subcommand. Only add, modify, delete, and show are allwed."
esac

if [ "${subcmd}" == 'add' ]
then
   if [ -z "${bPW}" ] || [ -z "${mPW}" ]
   then
      showUsage "ERROR: Must provide required arguments."
      exit 1
   fi
else
   if [ -z "${bPW}" ]
   then
      showUsage "ERROR: Must provide required arguments."
      exit 1
   fi
fi

##############################################################################
# Add global ACI for monitor user
##############################################################################
addGlobalAci() {
   cfgProto='ldaps'
   if [ "${dbg}" == 'true' ];then set -x;fi

   let steps++
   echo -e "Step ${steps} - Add global ACI for monitor user ${monitorUser}."

   muser_log="${logdir}/muser-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

#        ( ldap.MOD_ADD, 'ds-cfg-global-aci', b'(targetattr="*")(version 3.0; acl "dsMonUser"; allow (read,compare,search) userdn = "ldap:///${muserDN}"; )' ),

   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)
  exit(0)

# Add the global ACI
try:
    mod_aci = [
        ( ldap.MOD_ADD, 'ds-cfg-global-aci', b'(targetattr="*")(targetscope=subtree)(version 3.0; acl "dsMonUser"; allow (read,compare,search) userdn = "ldap:///${muserDN}"; )' ),
        ( ldap.MOD_ADD, 'ds-cfg-global-aci', b'(targetcontrol="1.3.6.1.4.1.26027.1.5.5") (version 3.0; acl "dsMonUser"; allow(read) userdn="ldap:///${muserDN}";)' )
    ]

    # Do the actual modification 
    l.modify_s('cn=Access Control Handler,cn=config',mod_aci)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: Global ACI add failed";fi
   set +x
}

##############################################################################
# Add OUD admin monitor user
##############################################################################
addOudAdminUser() {
   cfgProto='ldaps'
   if [ "${dbg}" == 'true' ];then set -x;fi

   let steps++
   echo -e "Step ${steps} - Add ${uType} monitor user ${monitorUser}."

   muser_log="${logdir}/muser-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)
  exit(0)

# Add muser
try:
    add_muser = [
        ('objectclass', [b'person', b'organizationalPerson', b'inetOrgPerson']),
        ('description', [b"instanceIsUp"] ),
        ('cn', [b"${monitorUser}"] ),
        ('sn', [b"${monitorUser}"] )
    ]

    # Do the actual modification 
    l.add_s("${muserDN}",add_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)

# Update the entry
try:
    mod_muser = [
        ( ldap.MOD_REPLACE, 'userPassword', [b'${mPW}'] ),
        ( ldap.MOD_REPLACE, 'description', b'instanceIsUp' ),
        ( ldap.MOD_REPLACE, 'ds-pwp-password-policy-dn', [b'cn=Root Password Policy,cn=Password Policies,cn=config'] ),
        ( ldap.MOD_REPLACE, 'ds-privilege-name', [b'config-read', b'bypass-lockdown', b'jmx-notify', b'jmx-read', b'unindexed-search', b'subentry-read'] ),
        ( ldap.MOD_REPLACE, 'ds-rlim-lookthrough-limit', b'0' ),
        ( ldap.MOD_REPLACE, 'ds-rlim-size-limit', b'0' ),
        ( ldap.MOD_REPLACE, 'ds-rlim-time-limit', b'0' )
    ]

    # Do the actual modification 
    l.modify_s("${muserDN}",mod_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: User add failed";fi
   set +x
}

##############################################################################
# Add data monitor user
##############################################################################
addDataUser() {
   mySuffix="$1"
   cfgProto='ldaps'

   let steps++
   echo -e "Step ${steps} - Add ${uType} monitor user (cn=${monitorUser},${mySuffix})."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Add muser
try:
    add_muser = [
        ('objectclass', [b'person', b'organizationalPerson', b'inetOrgPerson']),
        ('cn', [b"${monitorUser}"] ),
        ('description', [b"instanceIsUp"] ),
        ('sn', [b"${monitorUser}"] ),
        ('userPassword', [b"${mPW}"] ),
        ('aci', [b'(targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)'] )
    ]

    # Do the actual modification 
    l.add_s("cn=${monitorUser},${mySuffix}",add_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)

# Update the OUD ACI
#try:
#    mod_aci = [
#        ( ldap.MOD_ADD, 'aci', b'(targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)' ),
#    ]
#
#    # Do the actual modification 
#    l.modify_s("cn=${monitorUser},${mySuffix}",mod_aci)
#
#except ldap.LDAPError as e:
#  if type(e.message) == dict and e.message.has_key('desc'):
#      print(e.message['desc'])
#  else:
#      print(e)
l.unbind_s()
EOPY
   pyRC=$?

   if [ ${pyRC} -ne 0 ];then echo "ERROR: User add failed";cat ${muser_log};fi
   set +x
}

##############################################################################
# Modify DSEE DBMonitor ACI
##############################################################################
addDbAci() {
   cfgProto='ldaps'
   let steps++
   echo -e "Step ${steps} - Add DSEE DB monitor ACI for ${monitorUser})."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Update the DSEE ACI
try:
    mod_aci = [
        ( ldap.MOD_REPLACE, 'aci', b'(target ="ldap:///cn=monitor*")(targetattr != "aci || connection")(version 3.0; acl "dbmonitor"; allow( read, search, compare) userdn = "ldap:///${muserDN}";)' ),
    ]

    # Do the actual modification 
    l.modify_s("cn=ldbm database, cn=plugins, cn=config",mod_aci)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
      exit(1)
  else:
      print(e)
l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: User add failed";fi
   set +x
}

##############################################################################
# Update user's password
##############################################################################
updateUserPassword() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   mySuffix="$1"
   cfgProto='ldaps'

   let steps++
   echo -e "Step ${steps} - Update password of ${uType} monitor user ${monitorUser}."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Update the entry
try:
    mod_muser = [
        ( ldap.MOD_REPLACE, 'userPassword', [b"${mPW}"] )
    ]

    # Do the actual modification 
    l.modify_s("cn=${monitorUser},${mySuffix}",mod_muser)

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: User add failed";fi
   set +x
}

##############################################################################
# Delete user
##############################################################################
deleteUser() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   mySuffix="$1"
   cfgProto='ldaps'
   let steps++
   echo -e "Step ${steps} - Delete ${uType} monitor user ${monitorUser}."

   if [ "${dbg}" == 'true' ];then set -x;fi

   muser_log="${logdir}/manage_users-${now}.log"
   touch "${muser_log}"
   chmod 0600 "${muser_log}"

   ${pycmd} - >> ${muser_log} 2>&1 <<EOPY
import sys,ldap,ldif, ldap.modlist as modlist

ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)

# Set vars
binddn = "${bDN}"
pw = "${bPW}"

# Connect to directory server
try:
   l = ldap.initialize("${cfgProto}://${dsHost}:${dsPort}")
   l.set_option(ldap.OPT_DEBUG_LEVEL, 255 )
   l.set_option(ldap.OPT_REFERRALS, 0)
   l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
   l.set_option(ldap.OPT_NETWORK_TIMEOUT, 10.0)
   l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
   l.set_option(ldap.OPT_X_TLS_NEWCTX, 0)
   l.simple_bind_s(binddn, pw)

except ldap.SERVER_DOWN:
  print("LDAP server is unavailable.")
  exit(1)

except ldap.INVALID_CREDENTIALS:
  print("Your username or password is incorrect.")
  exit(1)

  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)
  exit(0)

# Delete the entry
try:
    # Do the actual modification 
    l.delete_s("cn=${monitorUser},${mySuffix}")

except ldap.LDAPError as e:
  if type(e.message) == dict and e.message.has_key('desc'):
      print(e.message['desc'])
  else:
      print(e)

l.unbind_s()
EOPY
   pyRC=$?
   if [ ${pyRC} -ne 0 ];then echo "ERROR: User add failed";fi
   set +x
}

###############################################################################
# Add muser
###############################################################################
addUser() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   case ${dsType} in
       'oud') case ${uType} in
                 'admin') ldpPW="${bPW}"
                          ck4muser=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "${muserDN}" 'base' "objectClass=top" 2>&1|grep "does not exist")
                          if [ -n "${ck4muser}" ]
                          then
                             addOudAdminUser
                          else
                             echo "Admin monitor user ${monitorUser} already exists"
                          fi

                          ck4aci=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "cn=Access Control Handler,cn=config" 'base' "objectClass=top" 2>&1|grep "ds-cfg-global-aci"|grep "dsMonUser")
                          if [ -z "${ck4aci}" ]
                          then
                             addGlobalAci
                          fi
                          ;;
                  'data') ldpPW="${bPW}"
                          ck4muser=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "${muserDN}" 'base' "objectClass=top" 2>&1|grep "does not exist")
                          if [ -n "${ck4muser}" ]
                          then
                             addDataUser "${suffix}"
                             if [ "${eus}" == 'true' ]
                             then
                                addDataUser "cn=OracleContext,${suffix}"
                             fi
                          else
                             echo "Data monitor user ${monitorUser} already exists"
                          fi
                          ;;
                       *) showUsage;;
              esac
              ;;
      'dsee') ldpPW="${bPW}"
              ck4muser=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "${muserDN}" 'base' "objectClass=top" 2>&1|grep "${muserDN} does not exist")
              if [ -z "${ck4muser}" ]
              then
                 case ${uType} in
                    'admin') addDataUser "cn=Administrators,cn=config";addDbAci;;
                     'data') addDataUser "${suffix}";;
                          *) showUsage;;
                 esac
              else
                 case ${uType} in
                    'admin') echo "Admin monitor user ${monitorUser} already exists";;
                     'data') echo "Data monitor user ${monitorUser} already exists";;
                 esac
                 exit 1
              fi
              ;;
           *) showUsage "Invalid DS type"
   esac
}

###############################################################################
# Show muser
###############################################################################
showUser() {
   let steps++
   echo -e "Step ${steps} - Show ${uType} monitor user ${monitorUser}."

   if [ "${dbg}" == 'true' ];then set -x;fi

   ldpPW="${bPW}"
   userData=$(pyLdapSearch ldaps "${dsHost}" "${dsPort}" "${bDN}" "${muserDN}" 'base' "objectClass=top"|grep "^dn:")
   if [ -n "${userData}" ]
   then
      echo "User ${monitorUser} exists."
   else
      echo "User ${monitorUser} does not exist."
   fi
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
      'add') addUser;;
    'modpw') updateUserPassword "${suffix}";;
   'delete') deleteUser "${suffix}";;
     'show') showUser;;
          *) showUsage;;
esac
