CREATE TABLE oudadmin.people (
	dbid	   				VARCHAR2(128) NOT NULL,
	sn		   			VARCHAR2(128) NOT NULL,
	cn		   			VARCHAR2(128) NOT NULL,
	givenname		   		VARCHAR2(128),
	title		   			VARCHAR2(128),
	org		   			VARCHAR2(128),
	telephoneNumber		   		VARCHAR2(128),
	userPassword		   		VARCHAR2(512),
	CONSTRAINT dbid_PK PRIMARY KEY 
    (
      dbid 
    )
    ENABLE 
);

CREATE INDEX oudadmin.people_sn ON oudadmin.people (sn);
CREATE INDEX oudadmin.people_cn ON oudadmin.people (cn);
CREATE INDEX oudadmin.people_title ON oudadmin.people (title);
CREATE INDEX oudadmin.people_givenname ON oudadmin.people (givenname);
CREATE INDEX oudadmin.people_org ON oudadmin.people (org);
