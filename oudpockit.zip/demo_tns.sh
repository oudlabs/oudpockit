#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   findpager
   cat << EOF | ${pgcmd}
NAME
     ${cmd} [options]

SYNOPSIS
     Demonstrate OUD setup for Oracle Database Name Services (TNS)
        ${cmd} [options]

OPTIONS
           --suffix <suffix>      Base suffix
                                  Default: dc=example,dc=com

           -N <number>            Number of databases
                                  Default: 1

           -T <number>            Number of SLAMD client threads
                                  Default: 10

           -M <number>            Maxium rate of TNS lookups
                                  Default: 10000

           --nodb                 Don't install the database
EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            suffix) suffix="$1";shift;;
            domain) domain="$1";shift;;
            pnum) pnum="$1";shift;;
            nodb) nodb='true';;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
            j) jPW=$1;shift;;
            N) numDBs=$1;shift;;
            T) threads=$1;shift;;
        esac;;
    esac
done

###############################################################################
# Set defaults
###############################################################################
if [ -z "${pnum}" ];then pnum=10;fi
if [ -z "${numDBs}" ];then numDBs=1;fi
if [ -z "${threads}" ];then threads=10;fi
if [ -z "${eusAdmin}" ];then eusAdmin='cn=eusadmin,ou=EUSAdmins,cn=oracleContext';fi

###############################################################################
# Install database
###############################################################################
# Load DB ENV variables
if [ "${dbg}" == 'true' ];then set -x;fi
if [ -e "$ORACLE_HOME/bin/dbca" ] || [ "${nodb}" == 'true' ]
then
   true
else
   setOraEnv 
   echo -e "\nDEMO --> Install and setup an Oracle database"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_eus.sh setupdb ${dbgFlag}
   rc=$?
fi
set +x

if [ "${dbg}" == 'true' ];then set -x;fi
if [ -e "$ORACLE_HOME/network/admin/ldap.ora" ] || [ "${nodb}" == 'true' ]
then
   true
else
   echo -e "\nDEMO --> Configure sqlnet.ora and ldap.ora:"
   ${curdir}/manage_eus.sh cfgdb --suffix "${suffix}" {dbgFlag}
   rc=$?
fi
set +x

###############################################################################
# Setup OUD instances
###############################################################################
if [ -d "${oudmwdir}/oud10" ]
then
   true
else
   echo -e "\nDEMO --> Setup OUD instances with EUS integration enabled:"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_eus.sh setupoud -n tns -N ${numDBs} --suffix "${suffix}" ${dbgFlag}
   rc=$?
fi

###############################################################################
# Setup OUD instances
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
sudo firewall-cmd --permanent --zone=public --add-port=10444/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10389/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10636/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10989/tcp
sudo firewall-cmd --reload
set +x

###############################################################################
# Prepare EUS configuration
###############################################################################
if [ -e "${cfgdir}/.eusrealm-loaded" ]
then
   true
else
   echo -e "\nDEMO --> Prepare OUD for Net Services/TNS data"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_eus.sh prepoud --suffix "${suffix}" --step 1 ${dbgFlag}
   rc=$?
   set +x
fi

###############################################################################
# Generate DB Data
###############################################################################
echo -e "\nDEMO --> Generate ${numDBs} database entries to be loaded:"
cat ${samples}/tns.tmpl | sed \
   -e "s/^define suffix=.*/define suffix=${suffix}/g" \
   -e "s/^define domain=.*/define domain=${domain}/g" \
   -e "s/^define numdbs=.*/define numdbs=${numDBs}/g" \
   > ${cfgdir}/tns.tmpl

if [ "${dbg}" == 'true' ];then set -x;fi
if [ -e "${cfgdir}/tns.ldif" ];then rm -f "${cfgdir}/tns.ldif" 2> /dev/null;fi
#${curdir}/manage_data.sh gentempl -n tns -N 3 --rm --suffix "${suffix}" ${dbgFlag}
#rc=$?
#${curdir}/manage_data.sh gendata -n tns --rm ${dbgFlag}
#rc=$?;set +x

${curdir}/manage_data.sh genall -n tns -N ${numDBs} --dnfilter cn=mydb --rm --suffix "${suffix}" ${dbgFlag}
rc=$?;set +x


###############################################################################
# Add database entries
###############################################################################
echo -e "\nDEMO --> Add generated databases to OUD topology:"
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
if [ "${dbg}" == 'true' ];then set -x;fi
${lmod} -h ${localHost} -p ${pnum}389 -D "${bDN}" -j "${jPW}" -a -c -f "${cfgdir}/tns.ldif" >> ${logdir}/load-DBs-${now}.log 2>&1
rc=$?;set +x

###############################################################################
# Show databases
###############################################################################
echo -e "\nDEMO --> Show all databases:"
${curdir}/manage_tns.sh list --suffix "${suffix}" ${dbgFlag}

###############################################################################
# Register DB
###############################################################################
if [ "${nodb}" == 'true' ]
then
   echo -e "\nDEMO --> Register CDB database with manage_tns.sh"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_tns.sh register -n ${localH} --suffix "${suffix}" -j "${jPW}" ${dbgFlag}
   rc=$?;set +x
else
   echo -e "\nDEMO --> Register CDB database with dbca"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_eus.sh regcdb ${dbgFlag}
   rc=$?;set +x
fi

###############################################################################
# Register PDB
###############################################################################
if [ "${nodb}" == 'true' ]
then
   echo -e "\nDEMO --> Register PDB database with manage_tns.sh"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_tns.sh register -n PDB1_${localH} --suffix "${suffix}" -j "${jPW}" ${dbgFlag}
   rc=$?;set +x
else
   echo -e "\nDEMO --> Register PDB database with dbca"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_eus.sh regpdb ${dbgFlag}
   rc=$?;set +x
fi

###############################################################################
# Show databases
###############################################################################
echo -e "\nDEMO --> Show all databases."
echo "         Note the addition of CDB (cn=${localH}) and PDB (cn=PDB1_${localH})"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_tns.sh list --suffix "${suffix}" ${dbgFlag}
rc=$?;set +x

###############################################################################
# Show tnsping of each database
###############################################################################
if [ "${nodb}" != 'true' ]
then
   echo -e "\nDEMO --> Show tnsping of CDB (${localH}) and PDB (PDB1_${localH})"
   ${curdir}/manage_eus.sh testtns ${dbgFlag}
fi

###############################################################################
# Unregister DB
###############################################################################
if [ "${nodb}" == 'true' ]
then
   echo -e "\nDEMO --> Unregister CDB database with manage_tns.sh"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_tns.sh unregister -n ${localH} --suffix "${suffix}" -j "${jPW}" ${dbgFlag}
   rc=$?;set +x
else
   echo -e "\nDEMO --> Unregister CDB database with dbca"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_eus.sh unregcdb ${dbgFlag}
   rc=$?;set +x
fi

###############################################################################
# Unegister PDB
###############################################################################
if [ "${nodb}" == 'true' ]
then
   echo -e "\nDEMO --> Unregister PDB database with manage_tns.sh"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_tns.sh unregister -n PDB1_${localH} --suffix "${suffix}" -j "${jPW}" ${dbgFlag}
   rc=$?;set +x
else
   echo -e "\nDEMO --> Unregister PDB database with dbca"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_eus.sh unregpdb ${dbgFlag}
   rc=$?;set +x
fi

###############################################################################
# Show databases
###############################################################################
echo -e "\nDEMO --> Show all databases. Note the absence of cn=${localH} and cn=PDB1_${localH}"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_tns.sh list --suffix "${suffix}" ${dbgFlag}
rc=$?;set +x

###############################################################################
# Show basic benchmark of OUD for TNS clients
###############################################################################
echo -e "\nDEMO --> Basic TNS benchmark against single OUD instance"
lookupos
case ${os} in
   'Linux') cksysctl=$(sysctl -a 2> /dev/null|egrep "vm.swappiness|net.netfilter.nf_conntrack_tcp_timeout_time_wait|net.ipv4.tcp_tw_reuse|net.ipv4.tcp_fin_timeout"|wc -l)
            if [ ${cksysctl} -lt 4 ]
            then
               cat << EOF
Make sure that the following settings are in /etc/sysctl.conf:
   vm.swappiness = 0 
   net.netfilter.nf_conntrack_tcp_timeout_time_wait=1
   net.ipv4.tcp_tw_reuse=1
   net.ipv4.tcp_fin_timeout=1
EOF
            fi
            ;;
   'SunOS') true;;
esac

if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_slamd.sh mksvcinfo -n tns ${dbgFlag}
${curdir}/manage_slamd.sh install ${dbgFlag}
timeout 60 ${curdir}/manage_slamd.sh benchtns -p ${pnum}389 -T ${threads} -M 10000 -N ${numDBs} --suffix "${suffix}" ${dbgFlag}
set +x

###############################################################################
# Register database
###############################################################################
echo -e "\nDEMO --> Register Entra ID integrated database with manage_tns.sh"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_tns.sh register -n mytestdb -p 10636 --suffix "${suffix}" --method interactive --tenantid 7f4c6e3e-a1e0-43fe-14c5-c2f051a0a3a1 --clientid e5124a85-ac3e-14a4-f2ca-1ad635cf781a --serveruri "https://dbauthdemo.com/16736175-ca41-8f33-af0d-4616ade17621" ${dbgFlag}
rc=$?;set +x

###############################################################################
# Show database
###############################################################################
echo -e "\nDEMO --> Show database with manage_tns.sh"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_tns.sh show -n mytestdb -p 10636 --suffix "${suffix}" ${dbgFlag}
rc=$?;set +x

###############################################################################
# Expansion instructions
###############################################################################
echo -e "\nDEMO --> To expand to another host, run the following on the destination host"

cat <<EOF

# Open requisite firewall ports on local and remote OUD/TNS hosts
sudo firewall-cmd --permanent --zone=public --add-port=10444/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10389/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10636/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10989/tcp
sudo firewall-cmd --reload

# Add new OUD instnace to OUD topology
${curdir}/manage_eus.sh expand --pnum 20 --supplier ${localHost}:10444:10989

# Show replication status
${curdir}/manage_oud.sh rstatus --pnum 10

EOF
