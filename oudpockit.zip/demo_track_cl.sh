#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
##############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
##############################################################################

ldapHost=${localHost}

clLog="${logdir}/cl-${today}.log"
cnFile="${tmpdir}/.myCN"

touch ${clLog}
prevFirst=0
prevLast=0


checkCL() {
   cnNow=$(date +'%Y:%m:%d %H:%M:%S')
   clNumbers=$(${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b '' -s base '(objectClass=top)' firstChangeNumber lastChangeNumber|grep ChangeNumber)
   cnFirst=$(echo "${clNumbers}"|grep "^first"|awk '{ print $2 }')
   cnLast=$(echo "${clNumbers}"|grep "^last"|awk '{ print $2 }')

   deltaFirst=$((${cnFirst}-${prevFirst}))
   deltaLast=$((${cnLast}-${prevLast}))

   echo "sample ${n} at ${cnNow}:" 2>&1 |tee -a ${clLog}
   echo "   ${cnNow} first=${cnFirst} last=${cnLast} deltaFirst=${deltaFirst} deltaLast=${deltaLast}" 2>&1 |tee -a ${clLog}

   cn1Now=$(date +'%Y:%m:%d %H:%M:%S')
   cnPrevFirst=$((${cnFirst}-1))
   if [ ${cnPrevFirst} -le 0 ];then cnPrevFirst=1;fi
   cnPrevFirstData=$(${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b cn=changelog -s sub "(changenumber=${cnPrevFirst})" changeTime|grep "^changeTime:"|awk '{ print $2 }')
   if [ -z "${cnPrevFirstData}" ];then cnPrevFirstData='no return';fi

   cn2Now=$(date +'%Y:%m:%d %H:%M:%S')
   cnFirstData=$(${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b cn=changelog -s sub "(changenumber=${cnFirst})" changeTime|grep "^changeTime:"|awk '{ print $2 }')

   cn3Now=$(date +'%Y:%m:%d %H:%M:%S')
   cnLastLast=$((${cnLast}-1))
   if [ ${cnLastLast} -le 0 ];then cnLastLast=1;fi
   cnLastData=$(${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b cn=changelog -s sub "(changenumber=${cnLastLast})" changeTime|grep "^changeTime:"|awk '{ print $2 }')

   #cnLastData=$(${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b cn=changelog -s sub "(changenumber=${cnLastLast})" changeTime|egrep "^dn:|^changeTime:"|sed -e "s/^dn:/BEGINNINGdn:/g"|tr -d '[\n\r]'|sed -e "s/$/\n/g" -e "s/BEGINNINGdn/\ndn/g" -e "s/dn: changeNumber=//gi" -e "s/,cn=changelog//g" -e "s/changeTime: /|/gi"|awk -F'|' '{ printf("sample:   lastChange=%s time=%s", $1,$2) }')
   #cnLastData=$(${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b cn=changelog -s sub "(changenumber=${cnLastLast})" changeTime|egrep "^dn:|^changeTime:"|sed -e "s/^dn:/BEGINNINGdn:/g"|tr -d '[\n\r]'|sed -e "s/$/\n/g" -e "s/BEGINNINGdn/\ndn/g" -e "s/dn: changeNumber=//g" -e "s/,cn=changelog//g" -e "s/changeTime: /|/g"|awk -F'|' '{ printf("change=%s time=%s", $1,$2) }'|sed -e "s/change= time= //g")

   maxLen=$(echo -e "${cnPrevFirst}\n${cnFirst}\n${cnLast}"|awk '{ print length($0) "|" $0; }'|sort -rn|head -1|cut -d'|' -f1)

   printf "   %-19s   prevChange=%-${maxLen}s time=%-20s\n" "${cn1Now}" "${cnPrevFirst}" "${cnPrevFirstData}" 2>&1 |tee -a ${clLog}
   printf "   %-19s  firstChange=%-${maxLen}s time=%-20s\n" "${cn2Now}" "${cnFirst}" "${cnFirstData}" 2>&1 |tee -a ${clLog}
   printf "   %-19s   lastChange=%-${maxLen}s time=%-20s\n" "${cn3Now}" "${cnLast}" "${cnLastData}" 2>&1 |tee -a ${clLog}

   prevFirst=${cnFirst}
   prevLast=${cnLast}
}

processChanges() {
   if [ ${myCN} -eq ${cnLast} ]
   then
      echo "changes: No changes" 2>&1 |tee -a ${clLog}
   else
      echo "changes:" 2>&1 |tee -a ${clLog}
      cnNow=$(date +'%Y:%m:%d %H:%M:%S')
      ${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b 'cn=changelog' -s sub "(&(changenumber>=${myCN})(changenumber<=${cnLast}))" changeTime targetDN changes|egrep "^dn:|^changeTime:|^target|^changes"|sed -e "s/^dn:/BEGINNINGdn:/g"|tr -d '[\n\r]'|sed -e "s/$/\n/g" -e "s/BEGINNINGdn/\ndn/g" -e "s/targetDN: /|/g" -e "s/dn: changeNumber=//g" -e "s/,cn=changelog//g" -e "s/changeTime: /|/g" -e "s/changes:: /|/g"|awk -F'|' '{ printf("change=%s time=%s targetDN=%s whom=", $1,$4,$2); system("/usr/bin/echo " $3 "|/usr/bin/base64 -d|/usr/bin/grep modifiers.*ame:|/usr/bin/cut -c16-")  }' |grep -v "change= time= targetDN="|sed -e "s/change= time= targetDN= whom=//g"|sed -e "s/^change=/   ${cnNow} changeNumber=/g" 2>&1 |tee -a ${clLog}
      rc=$?

      myCN=${cnLast}
      echo "${myCN}" > ${cnFile}
   fi
}

START_TIME=`echo $(($(date +%s%N)/1000000))`
if [ -e "${cnFile}" ]
then
   myCN=$(cat ${cnFile})
else
   myCN=0
fi

n=1
while true
do
   END_TIME=`echo $(($(date +%s%N)/1000000))`
   if [ $((${END_TIME}-${START_TIME})) -gt 60000 ]
   then
      checkCL
      processChanges
      START_TIME=${END_TIME}
      let n++
   fi
done
