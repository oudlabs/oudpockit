#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
curdir=$(cd ${curdir}; pwd)
build=$1
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################
steps=0
cd "${curdir}"
mkdir -p tmp/ojdbc-extensions lib/ojdbc-extensions 2> /dev/null

if [ -z "${build}" ]
then
   let steps++
   echo "Step: ${steps} Lookup current ojdbc-extension build version"
   build=$(curl -sL https://github.com/oracle/ojdbc-extensions/releases/|grep "/oracle/ojdbc-extensions/releases/tag/v"|sed -e "s/^.*tag\/v//g" -e "s/\".*//g"|sort -ur|head -1)
fi
if [ -z "${build}" ];then build="1.0.5";fi

let steps++
echo "Step: ${steps} Download dependencies"

case ${build} in
   '1.0.4') jars="asm/asm com/fasterxml/jackson/core/jackson-annotations com/fasterxml/jackson/core/jackson-core com/fasterxml/jackson/core/jackson-databind com/fasterxml/jackson/datatype/jackson-datatype-jsr310 com/fasterxml/jackson/module/jackson-module-jaxb-annotations com/microsoft/azure/azure-core com/azure/azure-core-http-netty com/azure/azure-data-appconfiguration com/azure/azure-identity com/azure/azure-json com/azure/azure-security-keyvault-secrets com/azure/azure-xml com/microsoft/azure/msal4j com/microsoft/azure/msal4j-persistence-extension com/nimbusds/content-type com/nimbusds/lang-tag com/nimbusds/nimbus-jose-jwt com/nimbusds/oauth2-oidc-sdk io/netty/netty-buffer io/netty/netty-codec io/netty/netty-codec-dns io/netty/netty-codec-http io/netty/netty-codec-http2 io/netty/netty-codec-socks io/netty/netty-common io/netty/netty-handler io/netty/netty-handler-proxy io/netty/netty-resolver io/netty/netty-resolver-dns io/netty/netty-resolver-dns-classes-macos io/netty/netty-resolver-dns-native-macos io/netty/netty-tcnative-boringssl-static io/netty/netty-tcnative-classes io/netty/netty-transport io/netty/netty-transport-classes-epoll io/netty/netty-transport-classes-kqueue io/netty/netty-transport-native-epoll io/netty/netty-transport-native-kqueue io/netty/netty-transport-native-unix-common io/projectreactor/reactor-core io/projectreactor/netty/reactor-netty-core io/projectreactor/netty/reactor-netty-http net/java/dev/jna/jna net/java/dev/jna/jna-platform net/jcip/jcip-annotations net/minidev/accessors-smart net/minidev/json-smart org/reactivestreams/reactive-streams org/slf4j/slf4j-api com/oracle/database/jdbc/ojdbc8";;
   '1.0.5') jars="asm/asm com/fasterxml/jackson/core/jackson-annotations com/fasterxml/jackson/core/jackson-core com/fasterxml/jackson/core/jackson-databind com/fasterxml/jackson/datatype/jackson-datatype-jsr310 com/fasterxml/jackson/module/jackson-module-jaxb-annotations com/microsoft/azure/azure-core com/azure/azure-core-http-netty com/azure/azure-data-appconfiguration com/azure/azure-identity com/azure/azure-json com/azure/azure-security-keyvault-secrets com/azure/azure-xml com/microsoft/azure/msal4j com/microsoft/azure/msal4j-persistence-extension com/nimbusds/content-type com/nimbusds/lang-tag com/nimbusds/nimbus-jose-jwt com/nimbusds/oauth2-oidc-sdk io/netty/netty-buffer io/netty/netty-codec io/netty/netty-codec-dns io/netty/netty-codec-http io/netty/netty-codec-http2 io/netty/netty-codec-socks io/netty/netty-common io/netty/netty-handler io/netty/netty-handler-proxy io/netty/netty-resolver io/netty/netty-resolver-dns io/netty/netty-resolver-dns-classes-macos io/netty/netty-resolver-dns-native-macos io/netty/netty-tcnative-boringssl-static io/netty/netty-tcnative-classes io/netty/netty-transport io/netty/netty-transport-classes-epoll io/netty/netty-transport-classes-kqueue io/netty/netty-transport-native-epoll io/netty/netty-transport-native-kqueue io/netty/netty-transport-native-unix-common io/projectreactor/reactor-core io/projectreactor/netty/reactor-netty-core io/projectreactor/netty/reactor-netty-http net/java/dev/jna/jna net/java/dev/jna/jna-platform net/jcip/jcip-annotations net/minidev/accessors-smart net/minidev/json-smart org/reactivestreams/reactive-streams org/slf4j/slf4j-api com/oracle/database/jdbc/ojdbc8"
            n=1
            let n++;jars[${n}]="commons-codec/commons-codec/1.16.1/commons-codec-1.16.1.jar"
            let n++;jars[${n}]="commons-codec/commons-codec/1.11/commons-codec-1.11.jar"
            let n++;jars[${n}]="dom4j/dom4j/1.1/dom4j-1.1.jar"
            let n++;jars[${n}]="net/minidev/json-smart/2.5.0/json-smart-2.5.0.jar"
            let n++;jars[${n}]="net/minidev/accessors-smart/2.5.0/accessors-smart-2.5.0.jar"
            let n++;jars[${n}]="net/java/dev/jna/jna/5.13.0/jna-5.13.0.jar"
            let n++;jars[${n}]="net/java/dev/jna/jna-platform/5.13.0/jna-platform-5.13.0.jar"
            let n++;jars[${n}]="commons-chain/commons-chain/1.1/commons-chain-1.1.jar"
            let n++;jars[${n}]="commons-logging/commons-logging/1.2/commons-logging-1.2.jar"
            let n++;jars[${n}]="junit/junit/3.8.1/junit-3.8.1.jar"
            let n++;jars[${n}]="commons-collections/commons-collections/3.2.2/commons-collections-3.2.2.jar"
            let n++;jars[${n}]="org/javassist/javassist/3.25.0-GA/javassist-3.25.0-GA.jar"
            let n++;jars[${n}]="org/eclipse/sisu/org.eclipse.sisu.inject/0.3.5/org.eclipse.sisu.inject-0.3.5.jar"
            let n++;jars[${n}]="org/eclipse/sisu/org.eclipse.sisu.plexus/0.3.5/org.eclipse.sisu.plexus-0.3.5.jar"
            let n++;jars[${n}]="org/eclipse/aether/aether-util/1.0.0.v20140518/aether-util-1.0.0.v20140518.jar"
            let n++;jars[${n}]="org/eclipse/aether/aether-impl/1.0.0.v20140518/aether-impl-1.0.0.v20140518.jar"
            let n++;jars[${n}]="org/eclipse/aether/aether-spi/0.9.0.M2/aether-spi-0.9.0.M2.jar"
            let n++;jars[${n}]="org/eclipse/aether/aether-api/1.0.0.v20140518/aether-api-1.0.0.v20140518.jar"
            let n++;jars[${n}]="org/slf4j/slf4j-api/1.7.36/slf4j-api-1.7.36.jar"
            let n++;jars[${n}]="org/slf4j/slf4j-api/1.7.33/slf4j-api-1.7.33.jar"
            let n++;jars[${n}]="org/junit/platform/junit-platform-engine/1.9.0/junit-platform-engine-1.9.0.jar"
            let n++;jars[${n}]="org/junit/platform/junit-platform-engine/1.9.2/junit-platform-engine-1.9.2.jar"
            let n++;jars[${n}]="org/junit/platform/junit-platform-commons/1.9.0/junit-platform-commons-1.9.0.jar"
            let n++;jars[${n}]="org/junit/platform/junit-platform-commons/1.9.2/junit-platform-commons-1.9.2.jar"
            let n++;jars[${n}]="org/junit/platform/junit-platform-launcher/1.9.0/junit-platform-launcher-1.9.0.jar"
            let n++;jars[${n}]="org/junit/platform/junit-platform-launcher/1.9.2/junit-platform-launcher-1.9.2.jar"
            let n++;jars[${n}]="org/junit/jupiter/junit-jupiter-api/5.9.0/junit-jupiter-api-5.9.0.jar"
            let n++;jars[${n}]="org/junit/jupiter/junit-jupiter-engine/5.9.0/junit-jupiter-engine-5.9.0.jar"
            let n++;jars[${n}]="org/reactivestreams/reactive-streams/1.0.4/reactive-streams-1.0.4.jar"
            let n++;jars[${n}]="org/iq80/snappy/snappy/0.4/snappy-0.4.jar"
            let n++;jars[${n}]="org/ow2/asm/asm/9.3/asm-9.3.jar"
            let n++;jars[${n}]="org/ow2/asm/asm/9.4/asm-9.4.jar"
            let n++;jars[${n}]="org/glassfish/jersey/connectors/jersey-apache-connector/2.35/jersey-apache-connector-2.35.jar"
            let n++;jars[${n}]="org/glassfish/jersey/core/jersey-client/2.35/jersey-client-2.35.jar"
            let n++;jars[${n}]="org/glassfish/jersey/core/jersey-common/2.35/jersey-common-2.35.jar"
            let n++;jars[${n}]="org/glassfish/jersey/inject/jersey-hk2/2.35/jersey-hk2-2.35.jar"
            let n++;jars[${n}]="org/glassfish/jersey/ext/jersey-entity-filtering/2.35/jersey-entity-filtering-2.35.jar"
            let n++;jars[${n}]="org/glassfish/jersey/media/jersey-media-json-jackson/2.35/jersey-media-json-jackson-2.35.jar"
            let n++;jars[${n}]="org/glassfish/hk2/osgi-resource-locator/1.0.3/osgi-resource-locator-1.0.3.jar"
            let n++;jars[${n}]="org/glassfish/hk2/hk2-api/2.6.1/hk2-api-2.6.1.jar"
            let n++;jars[${n}]="org/glassfish/hk2/hk2-utils/2.6.1/hk2-utils-2.6.1.jar"
            let n++;jars[${n}]="org/glassfish/hk2/external/aopalliance-repackaged/2.6.1/aopalliance-repackaged-2.6.1.jar"
            let n++;jars[${n}]="org/glassfish/hk2/external/jakarta.inject/2.6.1/jakarta.inject-2.6.1.jar"
            let n++;jars[${n}]="org/glassfish/hk2/hk2-locator/2.6.1/hk2-locator-2.6.1.jar"
            let n++;jars[${n}]="org/apiguardian/apiguardian-api/1.1.2/apiguardian-api-1.1.2.jar"
            let n++;jars[${n}]="org/bouncycastle/bcutil-jdk15to18/1.78.1/bcutil-jdk15to18-1.78.1.jar"
            let n++;jars[${n}]="org/bouncycastle/bcprov-jdk15to18/1.78.1/bcprov-jdk15to18-1.78.1.jar"
            let n++;jars[${n}]="org/bouncycastle/bcpkix-jdk15to18/1.78.1/bcpkix-jdk15to18-1.78.1.jar"
            let n++;jars[${n}]="org/sonatype/plexus/plexus-cipher/1.4/plexus-cipher-1.4.jar"
            let n++;jars[${n}]="org/sonatype/plexus/plexus-sec-dispatcher/1.3/plexus-sec-dispatcher-1.3.jar"
            let n++;jars[${n}]="org/sonatype/plexus/plexus-build-api/0.0.7/plexus-build-api-0.0.7.jar"
            let n++;jars[${n}]="org/opentest4j/opentest4j/1.2.0/opentest4j-1.2.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-container-default/1.0-alpha-30/plexus-container-default-1.0-alpha-30.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-utils/4.0.1/plexus-utils-4.0.1.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-utils/3.5.0/plexus-utils-3.5.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-utils/3.5.1/plexus-utils-3.5.1.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-utils/3.4.2/plexus-utils-3.4.2.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-compiler-api/2.13.0/plexus-compiler-api-2.13.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-java/1.1.2/plexus-java-1.1.2.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-compiler-javac/2.13.0/plexus-compiler-javac-2.13.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-interpolation/1.27/plexus-interpolation-1.27.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-interpolation/1.26/plexus-interpolation-1.26.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-xml/3.0.0/plexus-xml-3.0.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-compiler-manager/2.13.0/plexus-compiler-manager-2.13.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-io/3.4.0/plexus-io-3.4.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-io/3.4.2/plexus-io-3.4.2.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-component-annotations/1.5.5/plexus-component-annotations-1.5.5.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-component-annotations/2.0.0/plexus-component-annotations-2.0.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-interactivity-api/1.1/plexus-interactivity-api-1.1.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-archiver/4.7.1/plexus-archiver-4.7.1.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-archiver/4.4.0/plexus-archiver-4.4.0.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-archiver/4.9.2/plexus-archiver-4.9.2.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-velocity/1.2/plexus-velocity-1.2.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-i18n/1.0-beta-10/plexus-i18n-1.0-beta-10.jar"
            let n++;jars[${n}]="org/codehaus/plexus/plexus-classworlds/2.5.1/plexus-classworlds-2.5.1.jar"
            let n++;jars[${n}]="org/apache/httpcomponents/httpcore/4.4.13/httpcore-4.4.13.jar"
            let n++;jars[${n}]="org/apache/httpcomponents/httpcore/4.4.16/httpcore-4.4.16.jar"
            let n++;jars[${n}]="org/apache/httpcomponents/httpclient/4.5.14/httpclient-4.5.14.jar"
            let n++;jars[${n}]="org/apache/httpcomponents/httpclient/4.5.13/httpclient-4.5.13.jar"
            let n++;jars[${n}]="org/apache/commons/commons-compress/1.23.0/commons-compress-1.23.0.jar"
            let n++;jars[${n}]="org/apache/commons/commons-compress/1.26.1/commons-compress-1.26.1.jar"
            let n++;jars[${n}]="org/apache/commons/commons-compress/1.21/commons-compress-1.21.jar"
            let n++;jars[${n}]="org/apache/commons/commons-text/1.10.0/commons-text-1.10.0.jar"
            let n++;jars[${n}]="org/apache/commons/commons-lang3/3.14.0/commons-lang3-3.14.0.jar"
            let n++;jars[${n}]="org/apache/commons/commons-lang3/3.12.0/commons-lang3-3.12.0.jar"
            let n++;jars[${n}]="org/apache/maven/reporting/maven-reporting-api/3.1.1/maven-reporting-api-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/maven-settings-builder/3.1.1/maven-settings-builder-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/surefire-shared-utils/3.1.2/surefire-shared-utils-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/surefire-logger-api/3.1.2/surefire-logger-api-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/surefire-junit-platform/3.1.2/surefire-junit-platform-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/surefire-extensions-spi/3.1.2/surefire-extensions-spi-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/maven-surefire-common/3.1.2/maven-surefire-common-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/surefire-api/3.1.2/surefire-api-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/surefire-extensions-api/3.1.2/surefire-extensions-api-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/common-java5/3.1.2/common-java5-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/surefire/surefire-booter/3.1.2/surefire-booter-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/maven-model-builder/3.1.1/maven-model-builder-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-compiler-plugin/3.11.0/maven-compiler-plugin-3.11.0.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-clean-plugin/3.2.0/maven-clean-plugin-3.2.0.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-resources-plugin/3.3.1/maven-resources-plugin-3.3.1.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-surefire-plugin/3.1.2/maven-surefire-plugin-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-javadoc-plugin/3.5.0/maven-javadoc-plugin-3.5.0.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-jar-plugin/3.3.0/maven-jar-plugin-3.3.0.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-jar-plugin/3.4.1/maven-jar-plugin-3.4.1.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-source-plugin/3.3.0/maven-source-plugin-3.3.0.jar"
            let n++;jars[${n}]="org/apache/maven/plugins/maven-install-plugin/3.1.2/maven-install-plugin-3.1.2.jar"
            let n++;jars[${n}]="org/apache/maven/doxia/doxia-sink-api/1.11.1/doxia-sink-api-1.11.1.jar"
            let n++;jars[${n}]="org/apache/maven/doxia/doxia-site-renderer/1.11.1/doxia-site-renderer-1.11.1.jar"
            let n++;jars[${n}]="org/apache/maven/doxia/doxia-skin-model/1.11.1/doxia-skin-model-1.11.1.jar"
            let n++;jars[${n}]="org/apache/maven/doxia/doxia-logging-api/1.11.1/doxia-logging-api-1.11.1.jar"
            let n++;jars[${n}]="org/apache/maven/doxia/doxia-module-xhtml/1.11.1/doxia-module-xhtml-1.11.1.jar"
            let n++;jars[${n}]="org/apache/maven/doxia/doxia-module-xhtml5/1.11.1/doxia-module-xhtml5-1.11.1.jar"
            let n++;jars[${n}]="org/apache/maven/doxia/doxia-core/1.11.1/doxia-core-1.11.1.jar"
            let n++;jars[${n}]="org/apache/maven/doxia/doxia-decoration-model/1.11.1/doxia-decoration-model-1.11.1.jar"
            let n++;jars[${n}]="org/apache/maven/maven-artifact/3.1.1/maven-artifact-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/shared/maven-shared-utils/3.3.4/maven-shared-utils-3.3.4.jar"
            let n++;jars[${n}]="org/apache/maven/shared/file-management/3.1.0/file-management-3.1.0.jar"
            let n++;jars[${n}]="org/apache/maven/shared/maven-common-artifact-filters/3.1.1/maven-common-artifact-filters-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/shared/maven-common-artifact-filters/3.2.0/maven-common-artifact-filters-3.2.0.jar"
            let n++;jars[${n}]="org/apache/maven/shared/maven-shared-incremental/1.1/maven-shared-incremental-1.1.jar"
            let n++;jars[${n}]="org/apache/maven/shared/maven-invoker/3.2.0/maven-invoker-3.2.0.jar"
            let n++;jars[${n}]="org/apache/maven/shared/maven-filtering/3.3.1/maven-filtering-3.3.1.jar"
            let n++;jars[${n}]="org/apache/maven/maven-archiver/3.6.2/maven-archiver-3.6.2.jar"
            let n++;jars[${n}]="org/apache/maven/maven-archiver/3.6.0/maven-archiver-3.6.0.jar"
            let n++;jars[${n}]="org/apache/maven/maven-model/3.1.1/maven-model-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/maven-plugin-api/3.1.1/maven-plugin-api-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/maven-core/3.1.1/maven-core-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/maven-aether-provider/3.1.1/maven-aether-provider-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/wagon/wagon-provider-api/2.4/wagon-provider-api-2.4.jar"
            let n++;jars[${n}]="org/apache/maven/maven-repository-metadata/3.1.1/maven-repository-metadata-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/maven-settings/3.1.1/maven-settings-3.1.1.jar"
            let n++;jars[${n}]="org/apache/maven/resolver/maven-resolver-api/1.9.18/maven-resolver-api-1.9.18.jar"
            let n++;jars[${n}]="org/apache/maven/resolver/maven-resolver-util/1.9.18/maven-resolver-util-1.9.18.jar"
            let n++;jars[${n}]="org/apache/velocity/velocity/1.7/velocity-1.7.jar"
            let n++;jars[${n}]="org/apache/velocity/velocity-tools/2.0/velocity-tools-2.0.jar"
            let n++;jars[${n}]="org/tukaani/xz/1.9/xz-1.9.jar"
            let n++;jars[${n}]="oro/oro/2.0.8/oro-2.0.8.jar"
            let n++;jars[${n}]="io/projectreactor/netty/reactor-netty-http/1.0.48/reactor-netty-http-1.0.48.jar"
            let n++;jars[${n}]="io/projectreactor/netty/reactor-netty-core/1.0.48/reactor-netty-core-1.0.48.jar"
            let n++;jars[${n}]="io/projectreactor/reactor-core/3.4.41/reactor-core-3.4.41.jar"
            let n++;jars[${n}]="io/vavr/vavr/0.10.2/vavr-0.10.2.jar"
            let n++;jars[${n}]="io/vavr/vavr-match/0.10.2/vavr-match-0.10.2.jar"
            let n++;jars[${n}]="io/netty/netty-codec-http/4.1.115.Final/netty-codec-http-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-handler/4.1.115.Final/netty-handler-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-tcnative-boringssl-static/2.0.69.Final/netty-tcnative-boringssl-static-2.0.69.Final-linux-aarch_64.jar"
            let n++;jars[${n}]="io/netty/netty-tcnative-boringssl-static/2.0.69.Final/netty-tcnative-boringssl-static-2.0.69.Final-osx-aarch_64.jar"
            let n++;jars[${n}]="io/netty/netty-tcnative-boringssl-static/2.0.69.Final/netty-tcnative-boringssl-static-2.0.69.Final-windows-x86_64.jar"
            let n++;jars[${n}]="io/netty/netty-tcnative-boringssl-static/2.0.69.Final/netty-tcnative-boringssl-static-2.0.69.Final-linux-x86_64.jar"
            let n++;jars[${n}]="io/netty/netty-tcnative-boringssl-static/2.0.69.Final/netty-tcnative-boringssl-static-2.0.69.Final-osx-x86_64.jar"
            let n++;jars[${n}]="io/netty/netty-tcnative-boringssl-static/2.0.69.Final/netty-tcnative-boringssl-static-2.0.69.Final.jar"
            let n++;jars[${n}]="io/netty/netty-transport-classes-kqueue/4.1.115.Final/netty-transport-classes-kqueue-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-codec/4.1.115.Final/netty-codec-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-transport-classes-epoll/4.1.115.Final/netty-transport-classes-epoll-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-common/4.1.115.Final/netty-common-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-transport-native-epoll/4.1.115.Final/netty-transport-native-epoll-4.1.115.Final-linux-x86_64.jar"
            let n++;jars[${n}]="io/netty/netty-resolver/4.1.115.Final/netty-resolver-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-codec-dns/4.1.112.Final/netty-codec-dns-4.1.112.Final.jar"
            let n++;jars[${n}]="io/netty/netty-codec-http2/4.1.115.Final/netty-codec-http2-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-resolver-dns-classes-macos/4.1.112.Final/netty-resolver-dns-classes-macos-4.1.112.Final.jar"
            let n++;jars[${n}]="io/netty/netty-transport/4.1.115.Final/netty-transport-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-transport-native-unix-common/4.1.115.Final/netty-transport-native-unix-common-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-buffer/4.1.115.Final/netty-buffer-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-codec-socks/4.1.115.Final/netty-codec-socks-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-resolver-dns-native-macos/4.1.112.Final/netty-resolver-dns-native-macos-4.1.112.Final-osx-x86_64.jar"
            let n++;jars[${n}]="io/netty/netty-transport-native-kqueue/4.1.115.Final/netty-transport-native-kqueue-4.1.115.Final-osx-x86_64.jar"
            let n++;jars[${n}]="io/netty/netty-tcnative-classes/2.0.69.Final/netty-tcnative-classes-2.0.69.Final.jar"
            let n++;jars[${n}]="io/netty/netty-handler-proxy/4.1.115.Final/netty-handler-proxy-4.1.115.Final.jar"
            let n++;jars[${n}]="io/netty/netty-resolver-dns/4.1.112.Final/netty-resolver-dns-4.1.112.Final.jar"
            let n++;jars[${n}]="io/github/resilience4j/resilience4j-core/1.7.1/resilience4j-core-1.7.1.jar"
            let n++;jars[${n}]="io/github/resilience4j/resilience4j-circuitbreaker/1.7.1/resilience4j-circuitbreaker-1.7.1.jar"
            let n++;jars[${n}]="commons-lang/commons-lang/2.4/commons-lang-2.4.jar"
            let n++;jars[${n}]="jakarta/activation/jakarta.activation-api/1.2.1/jakarta.activation-api-1.2.1.jar"
            let n++;jars[${n}]="jakarta/annotation/jakarta.annotation-api/2.1.1/jakarta.annotation-api-2.1.1.jar"
            let n++;jars[${n}]="jakarta/xml/bind/jakarta.xml.bind-api/2.3.2/jakarta.xml.bind-api-2.3.2.jar"
            let n++;jars[${n}]="jakarta/ws/rs/jakarta.ws.rs-api/2.1.6/jakarta.ws.rs-api-2.1.6.jar"
            let n++;jars[${n}]="javax/enterprise/cdi-api/1.2/cdi-api-1.2.jar"
            let n++;jars[${n}]="javax/inject/javax.inject/1/javax.inject-1.jar"
            let n++;jars[${n}]="javax/annotation/javax.annotation-api/1.3.2/javax.annotation-api-1.3.2.jar"
            let n++;jars[${n}]="javax/annotation/javax.annotation-api/1.2/javax.annotation-api-1.2.jar"
            let n++;jars[${n}]="commons-io/commons-io/2.6/commons-io-2.6.jar"
            let n++;jars[${n}]="commons-io/commons-io/2.16.1/commons-io-2.16.1.jar"
            let n++;jars[${n}]="commons-io/commons-io/2.12.0/commons-io-2.12.0.jar"
            let n++;jars[${n}]="commons-io/commons-io/2.11.0/commons-io-2.11.0.jar"
            let n++;jars[${n}]="commons-digester/commons-digester/1.8/commons-digester-1.8.jar"
            let n++;jars[${n}]="commons-beanutils/commons-beanutils/1.7.0/commons-beanutils-1.7.0.jar"
            let n++;jars[${n}]="com/azure/azure-data-appconfiguration/1.7.3/azure-data-appconfiguration-1.7.3.jar"
            let n++;jars[${n}]="com/azure/azure-core-http-netty/1.15.7/azure-core-http-netty-1.15.7.jar"
            let n++;jars[${n}]="com/azure/azure-xml/1.1.0/azure-xml-1.1.0.jar"
            let n++;jars[${n}]="com/azure/azure-core/1.54.1/azure-core-1.54.1.jar"
            let n++;jars[${n}]="com/azure/azure-identity/1.14.2/azure-identity-1.14.2.jar"
            let n++;jars[${n}]="com/azure/azure-security-keyvault-secrets/4.9.1/azure-security-keyvault-secrets-4.9.1.jar"
            let n++;jars[${n}]="com/azure/azure-json/1.3.0/azure-json-1.3.0.jar"
            let n++;jars[${n}]="com/microsoft/azure/msal4j-persistence-extension/1.3.0/msal4j-persistence-extension-1.3.0.jar"
            let n++;jars[${n}]="com/microsoft/azure/msal4j/1.17.2/msal4j-1.17.2.jar"
            let n++;jars[${n}]="com/oracle/database/security/oraclepki/23.8.0.25.04/oraclepki-23.8.0.25.04.jar"
            let n++;jars[${n}]="com/oracle/database/jdbc/ojdbc8/23.8.0.25.04/ojdbc8-23.8.0.25.04.jar"
            let n++;jars[${n}]="com/oracle/database/jdbc/ojdbc-provider-azure/1.0.5/ojdbc-provider-azure-1.0.5.jar"
            let n++;jars[${n}]="com/oracle/database/jdbc/ojdbc-provider-azure/1.0.5/ojdbc-provider-azure-1.0.5-javadoc.jar"
            let n++;jars[${n}]="com/oracle/database/jdbc/ojdbc-provider-azure/1.0.5/ojdbc-provider-azure-1.0.5-sources.jar"
            let n++;jars[${n}]="com/oracle/database/jdbc/ojdbc-provider-common/1.0.5/ojdbc-provider-common-1.0.5-javadoc.jar"
            let n++;jars[${n}]="com/oracle/database/jdbc/ojdbc-provider-common/1.0.5/ojdbc-provider-common-1.0.5-sources.jar"
            let n++;jars[${n}]="com/oracle/database/jdbc/ojdbc-provider-common/1.0.5/ojdbc-provider-common-1.0.5.jar"
            let n++;jars[${n}]="com/oracle/database/jdbc/ojdbc-provider-common/1.0.5/ojdbc-provider-common-1.0.5-tests.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-objectstorage/3.48.0/oci-java-sdk-objectstorage-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-secrets/3.48.0/oci-java-sdk-secrets-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-common-httpclient-jersey/3.48.0/oci-java-sdk-common-httpclient-jersey-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-objectstorage-extensions/3.48.0/oci-java-sdk-objectstorage-extensions-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-workrequests/3.48.0/oci-java-sdk-workrequests-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-common/3.48.0/oci-java-sdk-common-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-databasetools/3.48.0/oci-java-sdk-databasetools-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-database/3.48.0/oci-java-sdk-database-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-identitydataplane/3.48.0/oci-java-sdk-identitydataplane-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-objectstorage-generated/3.48.0/oci-java-sdk-objectstorage-generated-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-common-httpclient/3.48.0/oci-java-sdk-common-httpclient-3.48.0.jar"
            let n++;jars[${n}]="com/oracle/oci/sdk/oci-java-sdk-circuitbreaker/3.48.0/oci-java-sdk-circuitbreaker-3.48.0.jar"
            let n++;jars[${n}]="com/github/stephenc/jcip/jcip-annotations/1.0-1/jcip-annotations-1.0-1.jar"
            let n++;jars[${n}]="com/github/luben/zstd-jni/1.5.5-11/zstd-jni-1.5.5-11.jar"
            let n++;jars[${n}]="com/github/luben/zstd-jni/1.5.5-2/zstd-jni-1.5.5-2.jar"
            let n++;jars[${n}]="com/thoughtworks/qdox/qdox/2.0.3/qdox-2.0.3.jar"
            let n++;jars[${n}]="com/nimbusds/content-type/2.3/content-type-2.3.jar"
            let n++;jars[${n}]="com/nimbusds/nimbus-jose-jwt/9.40/nimbus-jose-jwt-9.40.jar"
            let n++;jars[${n}]="com/nimbusds/lang-tag/1.7/lang-tag-1.7.jar"
            let n++;jars[${n}]="com/nimbusds/oauth2-oidc-sdk/11.18/oauth2-oidc-sdk-11.18.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/core/jackson-databind/2.17.1/jackson-databind-2.17.1.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/core/jackson-databind/2.17.2/jackson-databind-2.17.2.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/core/jackson-core/2.17.1/jackson-core-2.17.1.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/core/jackson-core/2.17.2/jackson-core-2.17.2.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/core/jackson-annotations/2.17.1/jackson-annotations-2.17.1.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/core/jackson-annotations/2.17.2/jackson-annotations-2.17.2.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/module/jackson-module-jaxb-annotations/2.12.2/jackson-module-jaxb-annotations-2.12.2.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/datatype/jackson-datatype-jsr310/2.17.1/jackson-datatype-jsr310-2.17.1.jar"
            let n++;jars[${n}]="com/fasterxml/jackson/datatype/jackson-datatype-jsr310/2.17.2/jackson-datatype-jsr310-2.17.2.jar"
            ;;
esac

for jar in ${jars[*]}
do
   # Determine latest version
   #ver=$(curl -sL https://repo1.maven.org/maven2/${jar}/|sed -e "s/^.*\">//g" -e "s/\/<\/a.*//g"|egrep "^[0-9]|^v[0-9]"|sort -nr|egrep -v "empty-to-avoid"|head -1)
   #jarFile="${jar}-${ver}.jar"
   #jarLib=$(basename ${jarFile})

   jarLib=$(basename ${jar})

#   if [ -z "${ver}" ]
#   then
#      echo "   ERROR: No version of ${jar} is available. Here is list of options:"
#      curl -Ls https://repo1.maven.org/maven2/${jar}/|sed -e "s/^.*\">//g" -e "s/\/<\/a.*//g"|egrep "^[0-9]|^v[0-9]"|sort -nr
#   else
      # Download curent version
      curl -sLo lib/ojdbc-extensions/${jarLib} https://repo1.maven.org/maven2/${jar}
      rc=$?
#   fi
done

# com/oracle/database/jdbc/ojdbc-provider-jackson-oson 

let steps++
echo "Step: ${steps} Download ojdbc-extensions"
set -x
for jar in com/oracle/database/jdbc/ojdbc-provider-azure com/oracle/database/jdbc/ojdbc-provider-oci com/oracle/database/jdbc/ojdbc-provider-common 
do
   jarLib=$(basename ${jar})
   jarLib="${jarLib}-${build}.jar"

   # Download curent version
   curl -sLo lib/ojdbc-extensions/${jarLib} https://repo1.maven.org/maven2/${jar}/${build}/${jarLib}
   rc=$?
done
set +x


let steps++
echo "Step: ${steps} Make product.conf for SQLDeveloper"
cd ${curdir}/lib/ojdbc-extensions
rm -f product.conf 2> /dev/null
for jar in *.jar
do
   echo "AddJavaLibFile C:\Program Files\sqldeveloper\ojdbc-extensions-${build}\\${jar}" >> product.conf
done

let steps++
echo "Step: ${steps} Bundle up the ojdbc-extensions: ojdbc-extensions-${build}.zip"
cd ${curdir}/lib/ojdbc-extensions
zip -qo ${curdir}/ojdbc-extensions-${build}.zip *.jar product.conf
cd ${curdir}

let steps++
echo "Step: ${steps} Clean up"
rm -fr lib/ojdbc-extensions
