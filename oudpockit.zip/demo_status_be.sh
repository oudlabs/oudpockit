#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
force=''
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            pnum) pnum="$1";shift;;
        esac;;
    esac
done

if [ -z "${pnum}" ]; then pnum=1;fi


###############################################################################
# Add backend to OUD instance
###############################################################################
if [ -e "${oudmwdir}/oud1/OUD/bin/start-ds" ]
then
   true
else
   echo "DEMO --> Setup OUD instance" | tee -a  ${logdir}/demo-status-${now}.log
   ${curdir}/manage_oud.sh setup ${dbgFlag}
fi

###############################################################################
# Set JAVA_HOME if not already set
###############################################################################
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi

echo "DEMO --> Add cn=status backend to OUD instance" | tee -a  ${logdir}/demo-status-${now}.log
set -x
${dcfg} --batchFilePath ${samples}/status.batch --hostName ${localHost} --port ${pnum}444 --bindDN "${bDN}" --bindPasswordFile "${jPW}" --trustAll --no-prompt --noPropertiesFile  >> ${logdir}/demo-status-${now}.log 2>&1
rc=$?
set +x

echo "DEMO --> Update status.ldif with ou=${localHost}" | tee -a  ${logdir}/demo-status-${now}.log
sed -e "s/<hostname>/${localHost}:${pnum}389/g" ${samples}/status.ldif > ${cfgdir}/status.ldif

echo "DEMO --> Load status.ldif" | tee -a  ${logdir}/demo-status-${now}.log
set -x
${lmod} -h ${localHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" -c -f "${cfgdir}/status.ldif" 2>&1 | tee -a  ${logdir}/demo-status-${now}.log
rc=$?
set +x

rm -f "${cfg}/status.ldif"

echo "DEMO --> Show cn=status" | tee -a  ${logdir}/demo-status-${now}.log
set -x
${lsrch} -h ${localHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" -b 'cn=status' -s base "cn=status"
rc=$?

