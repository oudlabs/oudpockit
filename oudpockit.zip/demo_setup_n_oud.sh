#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
cmdArg2=$2
curdir=$(cd ${curdir}; pwd)
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################


os=$(uname -s 2> /dev/null)
if [ "${os}" == 'Darwin' ]
then
   logdir=$HOME/.oudpockit/logs
   cfgdir=$HOME/.oudpockit/cfg
   tmpdir=$HOME/.oudpockit/tmp

   localHost=$(hostname -f)
   sshport=22
   adminPort=1444
   ldapPort=1389
   ldapsPort=1636
   replPort=1989
elif [ "${os}" == 'Linux' ]
then
   sshport=22
   . ${curdir}/poc_vars
else
   echo "ERROR: Only Linux and MacOS operating systems are supported"
   exit 1
fi
##############################################################################
y=1  # Instance per VM
dr=0 # Number of DS+RS instances
rs=0 # Number of RS instances
ds=0 # Number of DS instances
slamd_clients=0 # Number of SLAMD clients
zones=()
throttle=2
ocilag=1
oudRatio=1
pFlag=''
now=$(date +'%Y%m%d%H%M%S')

# Testing Env OCI Params:
# --compartment ocid1.compartment.oc1..aaaaaaaaxky7uzkyj4ws7yrdauqlagbewaelkrv5mozqzbl6xhp5zpnklypa 
# --zone "us-ashburn-1|uYkY:US-ASHBURN-AD-1|ocid1.subnet.oc1.iad.aaaaaaaa2rh2rwdszqriirmm5qqlhdz7tdbqaowx7eyni5mvis45et7fzzqa" 
# --zone "us-ashburn-1|uYkY:US-ASHBURN-AD-2|ocid1.subnet.oc1.iad.aaaaaaaa2rh2rwdszqriirmm5qqlhdz7tdbqaowx7eyni5mvis45et7fzzqa" 
# --zone "us-ashburn-1|uYkY:US-ASHBURN-AD-3|ocid1.subnet.oc1.iad.aaaaaaaa2rh2rwdszqriirmm5qqlhdz7tdbqaowx7eyni5mvis45et7fzzqa" 

##############################################################################
# Process inputs
##############################################################################
z=0
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            compartment) compartment="$1";shift;;
            region) myRegion="$1";shift;;
            subnet) mySubnet="$1";shift;;
            ad) myAD="$1";shift;;
            base) remoteBase="$1";shift;;
            bitsdir) remoteBitsDir="$1";shift;;
            cfgdir) remoteCfgDir="$1";shift;;
            preemptible) pFlag='--preemptible';;
            storage) storage="$1";shift;;
            zone) zones[${z}]="$1";let z++;shift;;
            pw) bindPW=$1;bPW="$1";shift;;
            image) image="$1";shift;;
            dr) dr="$1";shift;;
            rs) rs="$1";shift;;
            ds) ds="$1";shift;;
            cli) slamd_clients="$1";shift;;
            slamdHost) myAdminHost=$1; shift;;
            slamdPort) mySlamdPort=$1; shift;;
            bm) bm='true';;
            arch) arch="$1";shift;;
            cores) cores="$1";shift;;
            mem) mem="$1";shift;;
            jmem) myJmem="$1";shift;;
            suffix) suffix=$1; shift;;
            template) myTemplateName=$1; shift;;
            batch) myBatchFile=$1; shift;;
            schema) mySchemaFile=$1; shift;;
            data) myDataFile=$1; shift;;
            templ) templateFile=$1; shift;;
            ratio) oudRatio=$1; shift;;
            throttle) throttle=$1; shift;;
            ldifFile'ldiffile') myLdifFile=$1; shift;;
            hard) hardStop='true';;
            webproxy) webProxyFlag='--webproxy';;
            pubip) pubipFlag='--pubip';;
            os) ociOS="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            z) dbg="true";dbgFlag=' -z ';;
            h) myHost=$1; shift;;
            p) myPort=$1; shift;;
            Z) useSSL='SSL';;
            D) bindDN=$1;bDN=$1; shift;;
            w) bindPW=$1;bPW=$1; shift;;
            C) slamd_clients=$1; shift;;
            T) threads=$1; shift;;
            M) myModulateOps=$1;modulateOps=$1; shift;;
            m) myMaxOps=$1;maxOps=$1; shift;;
            A) attrs=$1; shift;;
            r) rateDN=$1; shift;;
            S) suffix=$1; shift;;
            s) mySchemaFile=$1; shift;;
            t) templateFile=$1; shift;;
            n) myTemplateName=$1; shift;;
            u) templUserFile=$1; shift;;
            l) myLdifFile=$1; shift;;
            W) mySwDir=$1; shift;;
            a) args=$1; shift;;
            q) disclaimOnce=1;addQ=' -q ';;
            P) prePurge=true;prePurgeFlag=' -P ';;
            N) myNumUsers=$1;shift;;
            g) numGroups=$1; prePurge=true;shift;;
            G) numMembers=$1; prePurge=true;shift;;
        esac;;
    esac
done

##############################################################################
# Initialize key variables
##############################################################################
if [ -n "${myHost}" ];then dsHost="${myHost}";else dsHost=${localHost};fi
if [ -n "${myPort}" ];then dsPort="${myPort}";else dsPort=${ldapPort};fi
if [ -z "${bPW}" ];then bPW="Oracle123";fi
if [ -z "${suffix}" ];then suffix='dc=example,dc=com';fi

if [ -z "${remoteBase}" ];then remoteBase="/opt/ods/poc";fi
if [ -z "${remoteCfgDir}" ];then remoteCfgDir="${remoteBase}/cfg";fi
if [ -z "${remoteBitsDir}" ];then remoteBitsDir="${remoteBase}/bits";fi
jPW="${remoteCfgDir}/.pw"

if [ -n "${myRegion}" ];then region="${myRegion}";else region='us-ashburn-1';fi
if [ -n "${myAD}"     ];then availabilityDomain="${myAD}";else availabilityDomain='uYkY:US-ASHBURN-AD-1';fi
if [ -n "${mySubnet}" ];then subnet="${mySubnet}";fi

numZones=$((${#zones[*]}-1))

if [ -z "${dr}" ];then dr=0;fi
if [ -z "${ds}" ];then ds=0;fi
if [ -z "${rs}" ];then rs=0;fi
if [ -z "${slamd_clients}" ];then slamd_clients=0;fi

#set -x
#if [ "${subcmd}" == 'setup' ]
#then
#   if [ ${ds} -gt 0 ] || [ ${rs} -gt 0 ]
#   then
#      if [ ${dr} -lt 2 ];then echo "ERROR: Must have at least 2 DS+RS instances";exit 1;fi
#   fi
#fi
#set +x

if [ -n "${myOudRatio}" ]
then
   oudRatio=$(echo "${oudRatio}"|tr -dc '[:digit:]' 2> /dev/null)
   if [ -z "${oudRatio}" ]
   then
      echo "ERROR: Invalid ratio number"
      exit 1
   fi
fi

if [ -n "${ociOS}" ];then ociOS="${ociOS}";else ociOS='ol8';fi

maxInstances=$(((${dr}+${rs}+${ds})))
totalInstances=$((${maxInstances}*${oudRatio}))

if [ -n "${myTemplateName}" ];then templateName="${myTemplateName}";fi

if [ -n "${myBatchFile}" ]
then
   batchFile="${myBatchFile}"
elif [ -n "${templateName}" ]
then
   batchFile="${cfgdir}/${templateName}.batch"
else
   batchFile="${cfgdir}/data.batch"
fi

if [ -n "${mySchemaFile}" ]
then
   schemaFile="${mySchemaFile}"
elif [ -n "${templateName}" ]
then
   schemaFile="${curdir}/samples/${templateName}.schema"
else
   schemaFile="${curdir}/samples/enterprise.schema"
fi

if [ -n "${myDataFile}" ]
then
   dataFile="${myDataFile}"
else
   dataFile="${cfgdir}/data.ldif"
fi

if [ "${subcmd}" == 'setup' ]
then
   if [ -s "${dataFile}" ]
   then
      true
   else
      echo "ERROR: Data file (${dataFile}) is empty."
      exit 1
   fi
fi

if [ -e "${batchFile}" ];then true;else touch ${batchFile} 2> /dev/null;fi
if [ -e "${schemaFile}" ];then true;else touch ${schemaFile} 2> /dev/null;fi

if [ -z "${bm}" ];then bm='false';fi
if [ -z "${arch}" ];then arch='amd-e4';fi
if [ -z "${cores}" ];then cores='1';fi
if [ -z "${mem}" ];then mem='15';fi
if [ -z "${storage}" ];then storage='100';fi

if [ -n "${myAdminHost}" ];then slamdHost=${myAdminHost};else slamdHost="${localHost}";fi
if [ -n "${myAdminPort}" ];then slamdPort=${myAdminPort};else slamdPort="8080";fi

privip=''
pubip=''

##############################################################################
# Sanity check inputs and quit if all requisite inputs are not provided
##############################################################################
if [ ${totalInstances} -eq 0 ] && [ ${slamd_clients} -eq 0 ]
then
   echo "Error: Must specify some number of dr, rs, and ds or SLAMD client instances"
   exit 1
fi


##############################################################################
# Lookup IP from $HOME/.oudpockit/cfg/hosts
##############################################################################
lookupip() {
   lhost="$1"
   if [ -z "${lhost}" ];then echo "Error: Must provide name on IP lookup";exit 1;fi
   privip=$(grep -h "^${lhost}|" $HOME/.oudpockit/cfg/hosts 2> /dev/null|cut -d'|' -f2)
   pubip=$(grep -h "^${lhost}|" $HOME/.oudpockit/cfg/hosts 2> /dev/null|cut -d'|' -f3)
   if [ -z "${pubip}" ] || [ "${pubip}" == 'None' ]
   then
      sship="${privip}"
   else
      sship="${pubip}"
   fi
}

##############################################################################
# Launch compute instances for OUD
##############################################################################
setup_oci() {
   if [ -z "${compartment}" ];then echo "ERROR: Must provide compartment";exit 1;fi

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Setup OCI infrastructure for OUD"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ociCnt=${throttle}
   z=0
   x=1
   while [ ${x} -le ${dr} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi
            
      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      if [ "${dbg}" == 'true' ];then echo "DEBUG: ociCnt=${ociCnt} ouddr${x}";fi
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_oci.sh launch --name ouddr${x} --role dr --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --storage ${storage} ${pFlag} --pw "${bPW}" --ocios ${ociOS} ${pubipFlag} --tag ${now} ${webProxyFlag} ${dbgFlag} &
      rc=$?
      if [ ${rc} -ne 0 ];then echo "ERROR: OCI launch of ouddr${x} failed";exit 1;fi
      sleep ${ocilag}
      set +x
      let x++
      if [ ${z} -lt ${numZones} ];then let z++;else z=0;fi
      ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance launch"|sed -e "s/ //g")
      while [ ${ociCnt} -ge ${throttle} ]
      do
         if [ "${dbg}" == 'true' ];then echo "DEBUG: Wait until ociCnt=${ociCnt} is less than ${throttle}";fi
         sleep 1
         ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance launch"|sed -e "s/ //g")
      done
   done

   z=0
   x=1
   while [ ${x} -le ${ds} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi
            
      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      if [ "${dbg}" == 'true' ];then echo "DEBUG: ociCnt=${ociCnt} oudds${x}";fi
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_oci.sh launch --name oudds${x} --role ds --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --storage ${storage} ${pFlag} --pw "${bPW}" --ocios ${ociOS} ${pubipFlag} --tag ${now} ${webProxyFlag} ${dbgFlag} &
      rc=$?
      if [ ${rc} -ne 0 ];then echo "ERROR: OCI launch of oudds${x} failed";exit 1;fi
      sleep ${ocilag}
      set +x
      let x++
      if [ ${z} -lt ${numZones} ];then let z++;else z=0;fi

      # Throttle to ensure that no more than to concurrent launches
      ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance launch"|sed -e "s/ //g")
      while [ ${ociCnt} -ge ${throttle} ]
      do
         if [ "${dbg}" == 'true' ];then echo "DEBUG: Wait until ociCnt=${ociCnt} is less than ${throttle}";fi
         sleep 1
         ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance launch"|sed -e "s/ //g")
      done
   done

   z=0
   x=1
   while [ ${x} -le ${rs} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi
            
      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      if [ "${dbg}" == 'true' ];then echo "DEBUG: ociCnt=${ociCnt} oudrs${x}";fi
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_oci.sh launch --name oudrs${x} --role rs --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --storage ${storage} ${pFlag} --pw "${bPW}" --ocios ${ociOS} ${pubipFlag} --tag ${now} ${webProxyFlag} ${dbgFlag} &
      rc=$?
      if [ ${rc} -ne 0 ];then echo "ERROR: OCI launch of oudrs${x} failed";exit 1;fi
      sleep ${ocilag}
      set +x
      let x++
      if [ ${z} -lt ${numZones} ];then let z++;else z=0;fi
      ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance launch"|sed -e "s/ //g")
      while [ ${ociCnt} -ge ${throttle} ]
      do
         if [ "${dbg}" == 'true' ];then echo "DEBUG: Wait until ociCnt=${ociCnt} is less than ${throttle}";fi
         sleep 1
         ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance launch"|sed -e "s/ //g")
      done
   done

   z=0
   x=1
   while [ ${x} -le ${slamd_clients} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi
            
      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      if [ "${dbg}" == 'true' ];then echo "DEBUG: ociCnt=${ociCnt} oudds${x}";fi
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_oci.sh launch --name cli${x} --role cli --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --storage ${storage} ${pFlag} --pw "${bPW}" --ocios ${ociOS} ${pubipFlag} --tag ${now} ${webProxyFlag} ${dbgFlag} &
      rc=$?
      if [ ${rc} -ne 0 ];then echo "ERROR: OCI launch of cli${x} failed";exit 1;fi
      sleep ${ocilag}
      set +x
      let x++
      if [ ${z} -lt ${numZones} ];then let z++;else z=0;fi

      # Throttle to ensure that no more than to concurrent launches
      ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance launch"|sed -e "s/ //g")
      while [ ${ociCnt} -ge ${throttle} ]
      do
         if [ "${dbg}" == 'true' ];then echo "DEBUG: Wait until ociCnt=${ociCnt} is less than ${throttle}";fi
         sleep 1
         ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance launch"|sed -e "s/ //g")
      done
   done

   # Wait for compute instances to complet setup
   wait

   # Update OUD POC Kit hosts file
   echo "[oci:${localH}] Step 1 - Update OCI local hosts"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oci.sh list net --region ${region} --subnet ${subnet} --compartment ${compartment} ${dbgFlag} > /dev/null 2>&1
   set +x
   
}

##############################################################################
# Deinstall OUD instances
##############################################################################
deinstall_slamd_clients() {
   if [ -z "${compartment}" ];then echo "ERROR: Must provide compartment";exit 1;fi
   x=0
   while [ ${x} -lt ${slamd_clients} ]
   do
      let x++
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_oci.sh ssh --name cli${x} --cmd "${remoteCfgDir}/manage_slamd.sh deinstall slamdcli --slamdHost ${slamdHost} --slamdPort ${slamdPort}" --region ${region} --compartment ${compartment} | tee -a ${logdir}/slamd-client${x}-deinstall-${now}.log
   done
}

##############################################################################
# Deinstall OUD instances
##############################################################################
deinstall_oud() {
   if [ "${hardStop}" != 'true' ] && [ ${ds} -gt 0 ]
   then
      x=0
      while [ ${x} -lt ${ds} ]
      do
         let x++
         echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
         echo      "=-= Deinstall OUD DS instance (oud${y}) from oudds${x}"
         echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${curdir}/manage_oci.sh ssh --name oudds${x} --cmd "${remoteBase}/manage_oud.sh deinstall --pnum ${y} ${dbgFlag} 2>&1" --region ${region} --compartment ${compartment} | tee -a ${logdir}/oud-deinstall-oudds${x}-${now}.log
         set +x
      done
   fi

   if [ "${hardStop}" != 'true' ] && [ ${rs} -gt 0 ]
   then
      x=0
      while [ ${x} -lt ${rs} ]
      do
         let x++
         echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
         echo      "=-= Deinstall OUD RS instance (oud${y}) from oudrs${x}"
         echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${curdir}/manage_oci.sh ssh --name oudrs${x} --cmd "${remoteBase}/manage_oud.sh deinstall --pnum ${y} ${dbgFlag} 2>&1" --region ${region} --compartment ${compartment} | tee -a ${logdir}/oud-deinstall-oudrs${x}-${now}.log
         set +x
      done
   fi

   if [ "${hardStop}" != 'true' ] && [ ${dr} -gt 0 ]
   then
      x=0
      while [ ${x} -lt ${dr} ]
      do
         let x++
         echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
         echo      "=-= Deinstall OUD DS+RS instance (oud${y}) from ouddr${x}"
         echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${curdir}/manage_oci.sh ssh --name ouddr${x} --cmd "${remoteBase}/manage_oud.sh deinstall --pnum ${y} ${dbgFlag} 2>&1" --region ${region} --compartment ${compartment} | tee -a ${logdir}/oud-deinstall-ouddr${x}-${now}.log
         set +x
      done
   fi
}


##############################################################################
# Setup OUD instances
##############################################################################
setup_slamd_client() {
   if [ -z "${compartment}" ];then echo "ERROR: Must provide compartment";exit 1;fi
   myDomain=${domain}
   x=0
   while [ ${x} -lt ${slamd_clients} ]
   do
      let x++
      echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      echo "=-= Setup SLAMD client on cli${x}.${myDomain}"
      echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_oci.sh ssh --name cli${x} --cmd "${remoteBase}/manage_slamd.sh setup slamdcli -C 20 --slamdHost ${slamdHost} --slamdPort ${slamdPort}" --region ${region} --compartment ${compartment} | tee -a ${logdir}/slamd-client${x}-setup-${now}.log
   done
}

##############################################################################
# Setup OUD instances
##############################################################################
setup_oud() {
   if [ -z "${compartment}" ];then echo "ERROR: Must provide compartment";exit 1;fi

   x=1 # OUD instance counter
   z=0 # Zone

   drx=0
   rsx=0
   dsx=0

   supplier=''

   # Distribute OUD instances across availability domains of a specified region
   while [ ${x} -le ${maxInstances} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi
            
      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      # Determine LDIF size
      if [ -n "${myJmem}" ]
      then
         jmem="${myJmem}"
      else
         ldifSize=$(du -ms ${dataFile} 2> /dev/null|awk '{ print $1 }')
         if [ -z "${ldifSize}" ];then ldifSize=4096;fi
         jmem=$(echo ${ldifSize}|awk '{ print int($1*2.5+2048) }')
         if [ -z "${jmem}" ];then jmem=4096;fi
      fi

      # Update the local cfg hosts file
      ${curdir}/manage_oci.sh list net --region ${region} --subnet ${subnet} --compartment ${compartment} ${dbgFlag} > /dev/null 2>&1

      # Handle the first OUD instance
      if [ ${x} -eq 1 ]
      then
         let drx++
         if [ -e "${schemaFile}" ]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${curdir}/manage_oci.sh sync --name "ouddr${drx}" --region ${region} --compartment ${compartment} --src "${schemaFile}" --dst "${remoteCfgDir}/data.schema"
            rc=$?
            if [ ${rc} -ne 0 ];then echo "ERROR: Cannot copy bits to ouddr${drx}";exit 1;fi
         fi

         ${curdir}/manage_oci.sh sync --name "ouddr${drx}" --region ${region} --compartment ${compartment} --src "${batchFile}" --dst "${remoteCfgDir}/data.batch"
         rc=$?

         ${curdir}/manage_oci.sh sync --name "ouddr${drx}" --region ${region} --compartment ${compartment} --src "${dataFile}" --dst "${remoteCfgDir}/data.ldif"
         rc=$?

         set +x
         echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
         echo      "=-= Setup OUD DS+RS instance (oud${y}) on ouddr${drx}"
         echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${curdir}/manage_oci.sh ssh --name ouddr${drx} --cmd "${remoteBase}/manage_oud.sh setup --pnum ${y} --suffix \"${suffix}\" --jmem ${jmem} --noroles --batch \"${remoteCfgDir}/data.batch\" --schema \"${remoteCfgDir}/data.schema\" --data \"${remoteCfgDir}/data.ldif\" ${dbgFlag} 2>&1" --region ${region} --compartment ${compartment} ${dbgFlag} | tee -a ${logdir}/oud-setup-ouddr${drx}-${now}.log
         rc=$?
         supplier=$(${curdir}/manage_oci.sh ssh --name ouddr${drx} --cmd "hostname -f" --quiet --region ${region} --compartment ${compartment})
         set +x
      fi

      # Handle the second OUD instance
#      if [ ${dr} -gt 1 ] && [ ${x} -eq 2 ]
#      then
#         let drx++
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         ${curdir}/manage_oci.sh sync --name "ouddr${drx}" --region ${region} --compartment ${compartment} --src "${schemaFile}" --dst "${remoteCfgDir}/data.schema"
#         rc=$?
#         if [ ${rc} -ne 0 ];then echo "ERROR: Cannot copy bits to ouddr${drx}";exit 1;fi
#         ${curdir}/manage_oci.sh sync --name "ouddr${drx}" --region ${region} --compartment ${compartment} --src "${batchFile}" --dst "${remoteCfgDir}/data.batch"
#         rc=$?
#         set +x
#         echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
#         echo      "=-= Setup OUD DS+RS instance (oud${y}) on ouddr${drx}"
#         echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         ${curdir}/manage_oci.sh ssh --name ouddr${drx} --cmd "${remoteBase}/manage_oud.sh setup --pnum ${y} --suffix \"${suffix}\" --jmem ${jmem} --noroles --batch \"${remoteCfgDir}/data.batch\" --schema \"${remoteCfgDir}/data.schema\"  --supplier ${supplier}:${adminPort}:${replPort} ${dbgFlag} 2>&1" --region ${region} --compartment ${compartment} ${dbgFlag} | tee -a ${logdir}/oud-setup-ouddr${drx}-${now}.log
#         set +x
#      fi

      if [ ${dr} -ge 1 ] && [ ${x} -gt 1 ]
      then
         if [ ${drx} -lt ${dr} ]
         then
            let drx++
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${curdir}/manage_oci.sh sync --name "ouddr${drx}" --region ${region} --compartment ${compartment} --src "${schemaFile}" --dst "${remoteCfgDir}/data.schema"
            rc=$?
            if [ ${rc} -ne 0 ];then echo "ERROR: Cannot copy bits to ouddr${drx}";exit 1;fi
            ${curdir}/manage_oci.sh sync --name "ouddr${drx}" --region ${region} --compartment ${compartment} --src "${batchFile}" --dst "${remoteCfgDir}/data.batch"
            rc=$?
            set +x
            echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
            echo      "=-= Setup OUD DS+RS instance (oud${y}) on ouddr${drx}"
            echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${curdir}/manage_oci.sh ssh --name ouddr${drx} --cmd "${remoteBase}/manage_oud.sh setup --pnum ${y} --jmem ${jmem} --suffix \"${suffix}\" --noroles --batch \"${remoteCfgDir}/data.batch\" --schema \"${remoteCfgDir}/data.schema\"  --supplier ${supplier}:${adminPort}:${replPort} ${dbgFlag} 2>&1" --region ${region} --compartment ${compartment} ${dbgFlag} | tee -a ${logdir}/oud-setup-ouddr${drx}-${now}.log
            set +x
         elif [ ${rsx} -lt ${rs} ]
         then
            let rsx++
            echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
            echo      "=-= Setup OUD RS instance (oud${y}) on oudrs${rsx}"
            echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${curdir}/manage_oci.sh sync --name "oudrs${rsx}" --region ${region} --compartment ${compartment} --src "${schemaFile}" --dst "${remoteCfgDir}/data.schema"
            rc=$?
            if [ ${rc} -ne 0 ];then echo "ERROR: Cannot copy bits to oudrs${rsx}";exit 1;fi
            ${curdir}/manage_oci.sh sync --name "oudrs${rsx}" --region ${region} --compartment ${compartment} --src "${batchFile}" --dst "${remoteCfgDir}/data.batch"
            rc=$?
            set +x
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${curdir}/manage_oci.sh ssh --name oudrs${rsx} --cmd "${remoteBase}/manage_oud.sh setup --pnum ${y} --rs --suffix \"${suffix}\" --noroles --batch \"${remoteCfgDir}/data.batch\" --schema \"${remoteCfgDir}/data.schema\"  --supplier ${supplier}:${adminPort}:${replPort} ${dbgFlag} 2>&1" --region ${region} --compartment ${compartment} ${dbgFlag} | tee -a ${logdir}/oud-setup-ouddr${rsx}-${now}.log
            set +x
         elif [ ${dsx} -lt ${ds} ]
         then
            let dsx++
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${curdir}/manage_oci.sh sync --name "oudds${dsx}" --region ${region} --compartment ${compartment} --src "${schemaFile}" --dst "${remoteCfgDir}/data.schema"
            rc=$?
            if [ ${rc} -ne 0 ];then echo "ERROR: Cannot copy bits to oudds${dsx}";exit 1;fi
            ${curdir}/manage_oci.sh sync --name "oudds${dsx}" --region ${region} --compartment ${compartment} --src "${batchFile}" --dst "${remoteCfgDir}/data.batch"
            rc=$?
            set +x
            echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
            echo      "=-= Setup OUD DS instance (oud${y}) on oudds${dsx}"
            echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${curdir}/manage_oci.sh ssh --name oudds${dsx} --cmd "${remoteBase}/manage_oud.sh setup --pnum ${y} --ds --jmem ${jmem} --suffix \"${suffix}\" --noroles --batch \"${remoteCfgDir}/data.batch\" --schema \"${remoteCfgDir}/data.schema\"  --supplier ${supplier}:${adminPort}:${replPort} ${dbgFlag} 2>&1" --region ${region} --compartment ${compartment} ${dbgFlag} | tee -a ${logdir}/oud-setup-ouddr${dsx}-${now}.log
            set +x
         fi
      fi

      # Increment global instance counter
      let x++
      if [ ${z} -lt ${numZones} ];then let z++;else z=0;fi
   done
}

##############################################################################
# Run end-to-end campaign
##############################################################################
terminate_oci() {
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e   "=-= Terminate OCI infrastructure"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ociCnt=${throttle}
   z=0
   x=1
   while [ ${x} -le ${dr} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi

      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      ck4i=$(grep "ouddr${x}|" $HOME/.oudpockit/cfg/hosts)
      if [ -n "${ck4i}" ]
      then
         ${curdir}/manage_oci.sh terminate --name ouddr${x} --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} ${dbgFlag} &

         sleep ${ocilag}
         ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance terminate"|sed -e "s/ //g")
         while [ ${ociCnt} -ge ${throttle} ]
         do
            if [ "${dbg}" == 'true' ];then echo "DEBUG: Wait until ociCnt=${ociCnt} is less than ${throttle}";fi
            sleep 1
            ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance terminate"|sed -e "s/ //g")
         done
      fi
      let x++
      if [ ${z} -lt ${numZones} ];then let z++;else z=0;fi
   done

   z=0
   x=1
   while [ ${x} -le ${ds} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi

      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      ck4i=$(grep "oudds${x}|" $HOME/.oudpockit/cfg/hosts)
      if [ -n "${ck4i}" ]
      then
         ${curdir}/manage_oci.sh terminate --name oudds${x} --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} ${dbgFlag} &
         sleep ${ocilag}
         ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance terminate"|sed -e "s/ //g")
         while [ ${ociCnt} -ge ${throttle} ]
         do
            if [ "${dbg}" == 'true' ];then echo "DEBUG: Wait until ociCnt=${ociCnt} is less than ${throttle}";fi
            sleep 1
            ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance terminate"|sed -e "s/ //g")
         done
      fi
      let x++
   done

   z=0
   x=1
   while [ ${x} -le ${rs} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi

      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      ck4i=$(grep "oudrs${x}|" $HOME/.oudpockit/cfg/hosts)
      if [ -n "${ck4i}" ]
      then
         ${curdir}/manage_oci.sh terminate --name oudrs${x} --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} ${dbgFlag} &
         sleep ${ocilag}
         ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance terminate"|sed -e "s/ //g")
         while [ ${ociCnt} -ge ${throttle} ]
         do
            if [ "${dbg}" == 'true' ];then echo "DEBUG: Wait until ociCnt=${ociCnt} is less than ${throttle}";fi
            sleep 1
            ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance terminate"|sed -e "s/ //g")
         done
      fi
      let x++
   done

   z=0
   x=1
   while [ ${x} -le ${slamd_clients} ]
   do
      zRegion=$(echo ${zones[${z}]}|cut -d'|' -f1)
      if [ -n "${zRegion}" ];then region="${zRegion}";fi
      zAD=$(echo ${zones[${z}]}|cut -d'|' -f2)
      if [ -n "${zAD}"     ];then availabilityDomain="${zAD}";fi
      zSubnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
      if [ -n "${zSubnet}" ];then subnet="${zSubnet}";fi

      if [ -z "${subnet}" ]
      then
         echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
         exit 1
      fi

      ck4i=$(grep "cli${x}|" $HOME/.oudpockit/cfg/hosts)
      if [ -n "${ck4i}" ]
      then
         ${curdir}/manage_oci.sh terminate --name cli${x} --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} ${dbgFlag} &
         sleep ${ocilag}
         ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance terminate"|sed -e "s/ //g")
         while [ ${ociCnt} -ge ${throttle} ]
         do
            if [ "${dbg}" == 'true' ];then echo "DEBUG: Wait until ociCnt=${ociCnt} is less than ${throttle}";fi
            sleep 1
            ociCnt=$(ps -ef|grep -v grep|grep -c "oci compute instance terminate"|sed -e "s/ //g")
         done
      fi
      let x++
   done

   # Wait for all compute terminations to complete
   wait

   # Make sure no launches are still running
   ck4pids=$(ps -ef|grep -v grep|grep "oci compute instance launch"|awk '{ print $2 }')
   if [ -n "${ck4pids}" ];then echo ${ck4pids}|xargs -n1 kill;fi

   # Update OUD POC Kit hosts file
   ${curdir}/manage_oci.sh list net --region ${region} --subnet ${subnet} --compartment ${compartment} ${dbgFlag} > /dev/null 2>&1
}

##############################################################################
# Run setup routines
##############################################################################
case "${subcmd}" in
     'setup') setup_oci;setup_oud;setup_slamd_client;;
 'deinstall') deinstall_slamd_clients;deinstall_oud;;
 'terminate') deinstall_slamd_clients;deinstall_oud;terminate_oci;;
           *) echo -e "Error: Invalid command.\nRun "${curdir}/${cmd} --help" to see proper usage.";exit 1;;
esac
