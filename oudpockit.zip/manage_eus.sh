#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOUSAGE
NAME
     ${cmd} [subcommand] [options]

SYNOPSIS
     Demo EUS with local database
        ${cmd} demo

     Expand OUD topology
        ${cmd} expand --pnum <number> [--supplier <host>:10444:10989]

     Test EUS
        ${cmd} testeus

     Test TNS
        ${cmd} testtns

     Show DBs
        ${cmd} list

     Setup OUD instance(s) for EUS
        ${cmd} setupoud

     Load realm data into OUD
        ${cmd} prepoud

     Configure DB (sqlnet.ora and ldap.ora)
        ${cmd} cfgdb

     Add shared user schema and roles to DB
        ${cmd} prepdb

     Apply roles to DB
        ${cmd} applyroles

     Register CDB to OUD
        ${cmd} regcdb

     Register PDB to OUD
        ${cmd} regpdb

     Unregister CDB to OUD
        ${cmd} unregcdb

     Unregister PDB to OUD
        ${cmd} unregpdb

     Setup DB for EUS
        ${cmd} setupdb

     Re-start OUD
        ${cmd} restart


DESCRIPTION
     Sample script for demonstrating EUS

OPTIONS
     The following options are supported:

     -z                 Show debug output

EUS Troubleshooting Tips

###############################################################################
# Error Message: ORA-28030
###############################################################################
Oracle Database Error:
   ORA-28030: Server encountered problems accessing LDAP directory service
OUD access logs:
   [16/Jan/2018:18:19:29 -0600] CONNECT conn=74 from=172.16.41.101:61589 to=172.16.33.88:1636 protocol=LDAPS
   [16/Jan/2018:18:19:29 -0600] DISCONNECT conn=74 reason="I/O Error" msg="Client requested protocol SSLv3 not enabled or not supported"
   [27/Aug/2019:15:31:39 -0500] CONNECT conn=31 from=10.89.5.164:41586 to=10.92.218.198:1636 protocol=LDAPS
   [27/Aug/2019:15:31:39 -0500] DISCONNECT conn=31 reason="I/O Error" msg="SSLv2Hello is disabled"
Resolution:
   * Make sure database includes latest patches that address cryptographic
     issues or improvements:
       + 12c: 19285025 and 30193165 (Doc ID 2377263.1) 
          alter system set "_ldap_password_oneway_auth"=TRUE scope=both;

###############################################################################
# Error Message: ORA-12154
###############################################################################
ORA-12154: TNS:could not resolve the connect identifier specified
Solution: Likely registered database into wrong context and the 
  context used by the tnsping resolver in ldap.ora is pointing to
  the wrong context.

###############################################################################
# Error Message: ORA-01017
###############################################################################
Oracle Database Error: ORA-01017: invalid username/password; logon denied

This error can be especially frustrating because there are a variety of 
possible causes.

Here are some common causes and corresponding solutions for this error.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= Wrong user passsword
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
The first thing to check is whether the test user has a valid password value
in userPassword for OUD/OID or orclCommonAttribute for AD.

For OUD/OID:
ldapsearch -D ${bDN} -b ${suffix} -s sub uid=user1 userPassword

For AD:
ldapsearch -D ${bDN} -b ${suffix} -s sub cn=user1 orclCommonAttribute

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= The wallet wallet containing the ORACLE.SECURITY.DN and 
=-= ORACLE.SECURITY.PASSWORD entries does not exist
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
CDB:
$ ls -al $ORACLE_BASE/admin/$ORACLE_SID/wallet

PDB:
$ ls -al $ORACLE_BASE/admin/$ORACLE_SID/$PDBGUID/wallet

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= The wallet containing the ORACLE.SECURITY.DN and ORACLE.SECURITY.PASSWORD 
=-= exists but is empty or has missing or incorrect values including case 
=-= sensitive passwords.  To troubleshoot, retrieve the values from the wallet 
=-= with:
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

$ $ORACLE_HOME/bin/mkstore -wrl $ORACLE_BASE/admin/$ORACLE_SID/wallet -list -viewEntry ORACLE.SECURITY.DN -viewEntry ORACLE.SECURITY.PASSWORD <<EOF
YourWalletPassword
EOF

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= If Oracle database was upgraded from earlier version to 18c or newer, the 
=-= mappings may need to be re-created. See Doc ID 2611300.1
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= The EUS realm configuration (e.g. Sample in 
=-= /<oud_install/oud/config/EUS/modifyRealm.ldif) has not yet been applied or 
=-= is mis-configured.  See Doc ID 2118421.1
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= The Certificate Authority (CA) certificate chain or OUD self-signed 
=-= certificate is not loaded into the wallet.  To troubleshoot this issue, 
=-= confirm the presence of the certificate in the wallet with:
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Show certificate stored in the CDB wallet:
$ORACLE_HOME/bin/orapki wallet display -wallet $ORACLE_BASE/admin/$ORACLE_SID/wallet -pwd YourWalletPassword

Show certificate stored in the PDB wallet:
$ORACLE_HOME/bin/orapki wallet display -wallet $ORACLE_BASE/admin/$ORACLE_SID/$PDBGUID/wallet -pwd YourWalletPassword

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= Encoded Kerberos ticket is too large. See Doc ID 1956558.1
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= Database start fails with ORA-01017. In this case grid user's group needs 
=-= to be a member of the  OSRACDBA group.  See Doc ID 2313555.1
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= Get ORA-01017 with RAC database.  This can be caused by the having 
=-= inconsistent wallets on each RAC node or by using the same wallet via NFS 
=-= share on all three nodes but where auto_login only works for the node on 
=-= which it was set.
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= May have specified the wrong ORACLE_SID environment variable value and the
=-= authentication fails because you are attempting to connect to the wrong 
=-= database.
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= If using tnsnames.ora, the connect string may be pointing to the wrong 
=-= database for which the user or user/password combination are not valid.
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
=-= General Troubleshooting: Use db tracing to find out from DB perspective 
=-= why authN fails
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  
   Step 1: Enable DB tracing by with:
      $ $ORACLE_HOME/bin/sqlplus / as sysdba
      SQL> alter system set events '28033 trace name context forever, level 9';

   Step 2: Perform authentication attempt that fails with ORA-01017
      $ $ORACLE_HOME/bin/sqlplus -S -L ${firstUser}/${bPW}@$ORACLE_SID
        ERROR: ORA-01017: invalid username/password; logon denied

   Step 3: Disable DB tracing with:
      $ $ORACLE_HOME/bin/sqlplus / as sysdba
      SQL> alter system set events '28033 trace name context off';

   Step 4: Lookup the path of the trace files (in case they aren't in 
           default location):

      $ $ORACLE_HOME/bin/sqlplus / as sysdba
      SQL> sho param dbug;

      Or, on newer versions or Exa systems
      $ $ORACLE_HOME/bin/sqlplus / as sysdba
      SQL> select TRACE_FILENAME from v$DIAG_TRACE_FILE;
TRACE_FILENAME
--------------------------------------------------------------------
db19c_ora_190141.trc

      SQL> ! find / -name db19c_ora_190141.trc 2> /dev/null
/opt/ods/poc/db/19c/app/oracle/diag/rdbms/db19c/db19c/trace/db19c_ora_190141.trc

      SQL> ! cat /opt/ods/poc/db/19c/app/oracle/diag/rdbms/db19c/db19c/trace/db19c_ora_190141.trc

   Step 5: Review trace file looking for KZLD_ERR messages
  
Possible Solutions:
   * The wallet exists but is empty:
      $ $ORACLE_HOME/bin/mkstore -wrl $ORACLE_BASE/admin/$ORACLE_SID/wallet -list -viewEntry ORACLE.SECURITY.DN -viewEntry ORACLE.SECURITY.PASSWORD
      ${bPW}
      EOF

   * If DB was upgraded from earlier version to 18c or newer, the mappings
     may need to be re-created. See DocID 2611300.1.

   * The realm.ldif has not yet been applied or is mis-configured.
     See DocID 2118421.1.

   * The OUD certificate (or CA signing cert chain) may not be loaded into 
     the wallet.
      Show certificate stored in the CDB wallet:
      $ORACLE_HOME/bin/orapki wallet display -wallet $ORACLE_BASE/admin/$ORACLE_SID/wallet -pwd ${bPW}

      Show certificate stored in the PDB wallet:
      $ORACLE_HOME/bin/orapki wallet display -wallet $ORACLE_BASE/admin/$ORACLE_SID/$PDBGUID/wallet -pwd ${bPW}


Note that with 19c and newer versions of Oracle database, you can only create
common (global) users (e.g. c##testuser).  Further, when logging in to CDB or
PDB as a common (global) user, the user name must be prefaced with c##.  If 
the common (global) user exists but you don't preface the userid with c##, the
error "ORA-01017: invalid username/password; logon denied" will be returned.
See: Doc ID 2768783.1

###############################################################################
# Error Message: DBT-08001
###############################################################################
[FATAL] [DBT-08001] Invalid directory service credentials.
   ACTION: Verify the directory service credentials and the correctness of
   the configuration file (ldap.ora).

Resolution steps:
   1. Remove anon from jdk.tls.disabledAlgorithms in JDK's java.security:
      From:
         jdk.tls.disabledAlgorithms=SSLv3, TLSv1, TLSv1.1, RC4, DES, MD5withRSA, \
             DH keySize < 1024, EC keySize < 224, 3DES_EDE_CBC, anon, NULL, \
             include jdk.disabled.namedCurves
      To:
         jdk.tls.disabledAlgorithms=SSLv3, TLSv1, TLSv1.1, RC4, DES, MD5withRSA, \
             DH keySize < 1024, EC keySize < 224, 3DES_EDE_CBC, NULL, \
             include jdk.disabled.namedCurves
   2. Add the TLS_DH_anon_WITH_AES_256_GCM_SHA384 and TLS_DH_anon_WITH_AES_128_GCM_SHA256 cyher suites to the OUD instance with:
         dsconfig set-connection-handler-prop \
                   --handler-name LDAPS\ Connection\ Handler \
                   --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_256_GCM_SHA384 \
                   --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_128_GCM_SHA256 \
                   --hostname ${localHost} \
                   --port ${adminPort} \
                   --portProtocol LDAP \
                   --trustAll \
                   --bindDN cn=Directory\ Manager \
                   --bindPasswordFile ${cfgdir}/...pw \
                   --no-prompt
   3. Re-start OUD instance
         /<instance_dir>/OUD/bin/stop-ds
         /<instance_dir>/OUD/bin/start-ds

###############################################################################
# Error Message: SaslException(DIGEST-MD5: digest response format violation
###############################################################################
[09/Jun/2022:08:17:24 -0700] CONNECT conn=45 from=10.49.80.1:22809 to=10.49.80.173:38948 protocol=LDAP
[09/Jun/2022:08:17:25 -0700] BIND REQ conn=45 op=0 msgID=1 type=SASL mechanism=DIGEST-MD5 dn="" version=3
[09/Jun/2022:08:17:25 -0700] BIND RES conn=45 op=0 msgID=1 result=14 etime=7
[09/Jun/2022:08:17:25 -0700] BIND REQ conn=45 op=1 msgID=2 type=SASL mechanism=DIGEST-MD5 dn="" version=3
[09/Jun/2022:08:17:25 -0700] BIND RES conn=45 op=1 msgID=2 result=49 authFailureID=1310929 authFailureReason="SASL DIGEST-MD5 protocol error: SaslException(DIGEST-MD5: digest response format violation. Mismatched URI: ldap/oud.example.com; expecting: ldap/oud1.example.com)" etime=0
[09/Jun/2022:08:17:25 -0700] DISCONNECT conn=45 reason="Client Disconnect"

Solution: 
set-sasl-mechanism-handler-prop --handler-name DIGEST-MD5 --set server-fqdn:<lb_fqdn>
set-sasl-mechanism-handler-prop --handler-name DIGEST-MD5 --set server-fqdn:oud.example.com

###############################################################################
# Error Message: SASL DIGEST-MD5 authentication is not possible for user ${eusAdmin} because none of the passwords in the user entry are stored in a reversible form
###############################################################################
BIND RES conn=725 op=1 msgID=2 result=49 authFailureID=1245392 authFailureReason="SASL DIGEST-MD5 authentication is not possible for user ${eusAdmin} because none of the passwords in the user entry are stored in a reversible form" etime=2010

Solution: Make sure user is assigned to password policy that includes


###############################################################################
# Error Message: DBT-12107
###############################################################################
[FATAL] [DBT-12107] There is no listener associated with the database,that is required for the correct configuration of directory service.
ACTION: Register the database with a listener.

Soltuion
See: DocID 2370412.1
   Copy from $ORACLE_BASE if it exists or create one:
   cp $ORACLE_BASE/admin/listener.ora $ORACLE_HOME/network/admin
LISTENER =
 (DESCRIPTION_LIST =
   (DESCRIPTION =
     (ADDRESS = (PROTOCOL = TCP)(HOST = dbca.example.com)(PORT = 1521))
     (ADDRESS = (PROTOCOL = IPC)(KEY = EXTPROC1521))
   )
 )


###############################################################################
# Error Message: DBT-08001
###############################################################################
Error when registering database into OUD with dbca:
[FATAL] [DBT-08001] Invalid directory service credentials.
   ACTION: Verify the directory service credentials and the correctness of the configuration file (ldap.ora).
[FATAL] [DBT-12107] There is no listener associated with the database,that is required for the correct configuration of directory service.
   ACTION: Register the database with a listener.


###############################################################################
# Error Message: DBT-16001
###############################################################################
[FATAL] [DBT-16001] Database configuration operation cannot be performed.
   CAUSE: Either no configuration update is specified for the database or specified options are already configured on the given database.

Solution: Update sqlnet.ora for LDAP and add ldap.ora


###############################################################################
# Error Message: DBT-08001
###############################################################################
[FATAL] [DBT-08001] Invalid directory service credentials.
   ACTION: Verify the directory service credentials and the correctness of the configuration file (ldap.ora).

See the following in OUD access logs:
[13/Apr/2022:16:18:45 +0000] CONNECT conn=22 from=10.0.20.225:52042 to=10.0.20.225:1636 protocol=LDAPS
[13/Apr/2022:16:18:45 +0000] DISCONNECT conn=22 reason="I/O Error" msg="no cipher suites in common"

###############################################################################
# Error Message: ORA-12547
###############################################################################
$ $ORACLE_HOME/bin/sqlplus -L -S / as sysdba
ERROR: ORA-12547: TNS:lost contact

###############################################################################
# Error Message: DBT-12104
###############################################################################
$ $ORACLE_HOME/bin/dbca -silent -configureDatabase -sourceDB ol8 -unregisterWithDirService true -dirServiceUserName cn=eusadmin,ou=EUSAdmins,cn=oracleContext -dirServicePassword ${bPW} -walletPassword ${bPW}
[FATAL] [DBT-12104] The specified database (ol8) is not registered with directory service.
   ACTION: Register the specified database or verify the directory service credentials.
$ echo $?
254

Solution: Set OUD to use modified java.security and restart OUD:
$ export OPENDS_JAVA_ARGS="-Djava.security.properties=/opt/ods/poc/samples/eus-java.security"
$ /opt/ods/poc/manage_oud.sh stop;/opt/ods/poc/manage_oud.sh start

EOUSAGE

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            pnum) myPnum="$1";shift;;
            suffix) suffix="$1";shift;;
            supplier) oudSupplier="$1";shift;;
            dbv) dbv="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            swdir) swdir="$1";shift;;
            ldapHost|ldaphost) myLdapHost="$1";shift;;
            ldap|ldapPort|ldapport) myLdapPort="$1";shift;;
            ldaps|ldapsPort|ldapsport) myLdapsPort="$1";shift;;
            repl|replPort|replport) myReplPort="$1";shift;;
            eusAdmin|ldapadmin) myLdapAdmin="$1";shift;;
            ldapPW|ldappw) ldapPW="$1";shift;;
            step) mySteps="$1";steps=${mySteps};shift;;
            pdb) pdbName="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            E) myEusAdmin="$1";shift;;
            j) jPW="$1";shift;;
            n) templateName="$1";shift;;
            N) numUsers="$1";shift;;
            t) threads="$1";shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -n "${oudSupplier}" ]
then        
   supplierHost=$(echo "${oudSupplier}:"|cut -d':' -f1)
   supplierH=$(echo "${supplierHost}."|cut -d. -f1)
   supplierPort=$(echo "${oudSupplier}:"|cut -d':' -f2)
   supplierReplPort=$(echo "${oudSupplier}:"|cut -d':' -f3)
fi          

if [ -n "${mySteps}" ];then steps=${mySteps};else steps=0;fi
if [ -n "${myEusAdmin}" ];then eusAdmin="${myEusAdmin}";fi
if [ -z "${templateName}" ];then templateName="inetorg";fi
if [ -z "${threads}" ];then threads=10;fi

###############################################################################
# Set Defaults
###############################################################################
if [ -z "${dbv}" ];then dbv='19c';fi
if [ -z "${pdbName}" ];then pdbName='PDB1';fi

# DB Connect Strings
setOraEnv
CDBCONNSTR="${ORACLE_SID}"
PDBCONNSTR="${localHost}:1521/${pdbName}.${domain}"
PDBCONNSTR="${localHost}:1521/${pdbName}"
PDBSID="${pdbName}_${ORACLE_SID}"

case ${dbv} in
   '21.3.0.0'|'21.3.0'|'21.3'|'21'|'21c') export dbvdir="21c" ;;
   '19.3.0.0'|'19.3.0'|'19.3'|'19'|'19c') export dbvdir="19c" ;;
   '18.0.0.0'|'18.0.0'|'18.0'|'18'|'18c') export dbvdir="18c" ;;
   '12.2.0.1') export dbvdir="12.2.0" ;;
   '12.1.0.2') export dbvdir="12.1.0" ;;
   '11.2.0.4') export dbvdir="11.2.0" ;;
esac

if [ -n "${myPnum}" ];then pnum=${myPnum};else pnum=10;fi
if [ -n "${myAdminPort}" ];then adminPort=${myAdminPort};else adminPort=${pnum}444;fi
if [ -n "${myLdapPort}" ];then ldapPort=${myLdapPort};else ldapPort=${pnum}389;fi
if [ -n "${myLdapsPort}" ];then ldapsPort=${myLdapsPort};else ldapsPort=${pnum}636;fi
if [ -n "${myReplPort}" ];then replPort=${myReplPort};else replPort=${pnum}989;fi

if [ -z "${ldapHost}" ];then ldapHost="${localHost}";fi
if [ -n "${myLdapAdmin}" ];then eusAdmin="${myLdapAdmin}";fi
if [ -z "${eusAdmin}" ];then eusAdmin='cn=eusadmin,ou=EUSAdmins,cn=oracleContext';fi
if [ -z "${tnsAdmin}" ];then tnsAdmin='cn=tnsadmin,ou=TNSAdmins,cn=oracleContext';fi
if [ -z "${ldapPW}" ];then ldapPW="${bPW}";fi

###############################################################################
# Create eus batch configuration file
###############################################################################
gen_eus_batch() {
   if [ -e "${cfgdir}/eus.batch" ]
   then
      true
   else
      cat > ${cfgdir}/eus.batch <<EOF
set-connection-handler-prop --handler-name "LDAPS Connection Handler" --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_128_GCM_SHA256 

create-password-policy --type generic --policy-name EUSAdmins --set password-attribute:userpassword --set default-password-storage-scheme:AES --set default-password-storage-scheme:Salted\ SHA-512

set-password-policy-prop --policy-name "Default Password Policy" --add default-password-storage-scheme:"EUS PBKDF2 SHA-512"

set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true

#set-work-queue-prop --set max-work-queue-capacity:500000

EOF
   fi
}

###############################################################################
# Make and load realm
###############################################################################
load_realm() {
   if [ -s "${cfgdir}/eus.realm" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Load EUS realm data" | tee -a  ${logdir}/oud-setup-${now}.log
      # Create realm file
      cat > ${cfgdir}/eus.realm <<EOF
dn: ou=EUSAdmins,cn=OracleContext
changetype: add
objectClass: top
objectClass: organizationalUnit
ou: EUSAdmins

dn: ${eusAdmin}
changetype: add
objectClass: top
objectClass: organizationalperson
objectClass: inetorgperson
uid: ${eusAdmin}
cn: eusadmin
sn: EUS
givenName: Admin
userPassword: ${bPW}
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search
ds-privilege-name: modify-acl
ds-pwp-password-policy-dn: cn=EUSAdmins,cn=Password Policies,cn=config

dn: ou=TNSAdmins,cn=OracleContext
changetype: add
objectClass: top
objectClass: organizationalUnit
ou: TNSAdmins

dn: ${tnsAdmin}
changetype: add
objectClass: top
objectClass: organizationalperson
objectClass: inetorgperson
uid: ${tnsAdmin}
cn: tnsadmin
sn: TNS
givenName: Admin
userPassword: ${bPW}
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search
ds-privilege-name: modify-acl

dn: cn=Common,cn=Products,cn=OracleContext
changetype: modify
replace: orclSubscriberSearchBase
orclSubscriberSearchBase: ${suffix}

dn: cn=Common,cn=Products,cn=OracleContext
changetype: modify
replace: orclSubscriberNickNameAttribute
orclSubscriberNickNameAttribute: dc

dn: cn=Common,cn=Products,cn=OracleContext
changetype: modify
replace: orclDefaultSubscriber
orclDefaultSubscriber: ${suffix}

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonUserSearchBase
orclCommonUserSearchBase: ou=People,${suffix}

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonUserCreateBase
orclCommonUserCreateBase: ou=People,${suffix}

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonDefaultUserCreateBase
orclCommonDefaultUserCreateBase: ou=People,${suffix}

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonGroupCreateBase
orclCommonGroupCreateBase: ou=Groups,${suffix}

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonDefaultGroupCreateBase
orclCommonDefaultGroupCreateBase: ou=Groups,${suffix}

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonGroupSearchBase
orclCommonGroupSearchBase: ou=Groups,${suffix}

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonNicknameAttribute
orclCommonNicknameAttribute: uid

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonKrbPrincipalAttribute
orclCommonKrbPrincipalAttribute: userPrincipalName

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonNamingAttribute
orclCommonNamingAttribute: cn

dn: cn=Common,cn=Products,cn=OracleContext,${suffix}
changetype: modify
replace: orclCommonWindowsPrincipalAttribute
orclCommonWindowsPrincipalAttribute: samAccountName

dn: cn=OracleContextAdmins,cn=groups,cn=OracleContext,${suffix}
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}
uniqueMember: ${tnsAdmin}

dn: cn=OracleDomainAdmins,cn=OracleDefaultDomain,cn=OracleDBSecurity,cn=Products,cn=OracleContext,${suffix}
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}
uniqueMember: ${tnsAdmin}

dn: cn=PolicyCreators,cn=Policies,cn=LabelSecurity,cn=Products,cn=OracleContext,${suffix}
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}

dn: cn=OracleDBCreators,cn=OracleContext
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}
uniqueMember: ${tnsAdmin}

dn: cn=OracleNetAdmins,cn=OracleContext
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}

dn: cn=OracleContextAdmins,cn=Groups,cn=OracleContext
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}
uniqueMember: ${tnsAdmin}

dn: cn=OracleUserSecurityAdmins,cn=Groups,cn=OracleContext
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}

dn: cn=OracleNetAdmins,cn=OracleContext,${suffix}
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}
uniqueMember: ${tnsAdmin}

dn: cn=OracleDBCreators,cn=OracleContext,${suffix}
changetype: modify
add: uniqueMember
uniqueMember: ${eusAdmin}
uniqueMember: ${tnsAdmin}
EOF
   fi

   # Load the realm
   if [ -s "${cfgdir}/.eusrealm-loaded" ]
   then
      true
   else
      if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
      setfmwenv
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${lmod} -Z -X -p ${ldapsPort} -h ${localHost} -D "${bDN}" -j "${jPW}" -c -f "${cfgdir}/eus.realm" >> ${logdir}/load-realm-${now}.log 2>&1
      rc=$?; set +x
      if [ ${rc} -eq 0 ];then touch "${cfgdir}/.eusrealm-loaded";fi
   fi
}

###############################################################################
# Upate oracle wallet with OUD cert
###############################################################################
update_wallet() {


ck4ca=$($ORACLE_HOME/bin/orapki wallet display -wallet ${ORACLE_BASE}/admin/${ORACLE_SID}/${GUID}/wallet -pwd "${bPW}"|grep "Root CA")

#$ORACLE_HOME/bin/orapki wallet create -wallet $ORACLE_BASE/admin/${dbh}/wallet -auto_login -pwd ${bPW} #>> ${{logdir}}/eus-${now}.log 2>&1
#      rc=$?;set +x

$ORACLE_HOME/bin/orapki wallet add -wallet ${ORACLE_BASE}/admin/${ORACLE_SID}/${GUID}/wallet -trusted_cert -cert ${certdir}/${localHost}.pem -pwd "${bPW}" >> ${{logdir}}/eus-${now}.log 2>&1
            rc=$?;set +x


#mkdir -p ${ORACLE_HOME}/admin/${ORACLE_SID}/${GUID}  >> ${{logdir}}/eus-${now}.log 2>&1
#            ln -s ${ORACLE_BASE}/admin/${ORACLE_SID}/${GUID}/wallet ${ORACLE_HOME}/admin/${ORACLE_SID}/${GUID} >> ${{logdir}}/eus-${now}.log 2>&1
#            rc=$?;set +x

#$ORACLE_HOME/bin/mkstore -wrl $ORACLE_BASE/admin/${ORACLE_SID}/wallet  -viewEntry ORACLE.SECURITY.DN

}

###############################################################################
# Configure Database
###############################################################################
configure_db() {
   setOraEnv
   let steps++
   echo "Step: ${steps} - Configure DB TNS to use LDAP (netca)" | tee -a ${logdir}/cfg-odb-${now}.log

   if [ "${dbg}" == 'true' ];then echo;set -x;fi

   # Backup files
   if [ -e "$ORACLE_HOME/network/admin/sqlnet.ora" ]
   then
      cp -p $ORACLE_HOME/network/admin/sqlnet.ora ${cfgdir}/sqlnet.${now}
   else
      touch $ORACLE_HOME/network/admin/sqlnet.ora
   fi

   if [ -e "$ORACLE_HOME/network/admin/ldap.ora" ]
   then
      cp -p $ORACLE_HOME/network/admin/ldap.ora ${cfgdir}/ldap.${now}
   fi


   if [ -e "$ORACLE_HOME/network/admin/ldap.ora" ]
   then
      true
   else
      cat > $ORACLE_HOME/network/admin/ldap.ora 2> /dev/null << EOF
DIRECTORY_SERVERS= (${localHost}:${ldapPort}:${ldapsPort})
DEFAULT_ADMIN_CONTEXT = "${suffix}"
DIRECTORY_SERVER_TYPE = OID
EOF
   fi

   cksqlnet=$(grep "NAMES.DIRECTORY_PATH.*LDAP" $ORACLE_HOME/network/admin/sqlnet.ora)
   if [ -z "${cksqlnet}" ]
   then
      cknames=$(grep "NAMES.DIRECTORY_PATH" $ORACLE_HOME/network/admin/sqlnet.ora)
      if [ -n "${cknames}" ]
      then
         sed -e "s/^NAMES.DIRECTORY_PATH.*/NAMES.DIRECTORY_PATH=(LDAP, TNSNAMES, EZCONNECT)/g" \
            ${cfgdir}/sqlnet.${now} \
            > $ORACLE_HOME/network/admin/sqlnet.ora 2> /dev/null
      else
         echo "NAMES.DIRECTORY_PATH=(LDAP, TNSNAMES, EZCONNECT)" >> $ORACLE_HOME/network/admin/sqlnet.ora 2> /dev/null
      fi
   fi

   ## Force persistent TLS 1.2 conections
   ckpersistence=$(grep "NAMES.LDAP_PERSISTENT_SESSION" $ORACLE_HOME/network/admin/sqlnet.ora)
   if [ -z "${ckpersistence}" ]
   then
      cat >> $ORACLE_HOME/network/admin/sqlnet.ora << EOF
#NAMES.LDAP_PERSISTENT_SESSION=true
#SSL_VERSION = 1.2

EOF
   fi

#   echo "Configure database to allow EUS users and roles to have sys* grants"
#   echo -e "SQL> ALTER SYSTEM SET ldap_directory_sysauth = YES SCOPE=SPFILE ;\c" >> ${logdir}/cfg-odb-${now}.log 2>&1
#   $ORACLE_HOME/bin/sqlplus -S / as sysdba >> ${logdir}/cfg-odb-${now}.log 2>&1 << EOF
#ALTER SYSTEM SET LDAP_DIRECTORY_SYSAUTH = YES SCOPE=SPFILE;
#EOF
#
#   echo "Restart database to apply sysauth change"
#   ${curdir}/manage_db.sh stop
#   ${curdir}/manage_db.sh start
}

###############################################################################
# Register Oracle CDB Database to OUD
###############################################################################
register_cdb() {
   setOraEnv

   # Make sure that the listener.ora exists in $ORACLE_HOME
   if [ -e "$ORACLE_HOME/network/admin/listener.ora" ]
   then
      true
   elif [ -e "$ORACLE_BASE/admin/listener.ora" ]
   then
      cp $ORACLE_BASE/admin/listener.ora $ORACLE_HOME/network/admin
   fi

   if [ -e "$ORACLE_HOME/bin/dbca" ]
   then
      let steps++
      echo "Step: ${steps} - Register CDB (cn=${ORACLE_SID}) instance with dbca" | tee -a ${logdir}/odb-reg-${now}.log

      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/dbca \
         -silent \
         -configureDatabase \
         -sourceDB $ORACLE_SID \
         -registerWithDirService true \
         -dirServiceUserName "${eusAdmin}" \
         -dirServicePassword "${bPW}" \
         -walletPassword "${bPW}" \
         >>  ${logdir}/odb-dbca-${now}.log 2>&1
      rc=$?;set +x
   fi
   set +x
}

###############################################################################
# Un-register Oracle Database to OUD
###############################################################################
unregister_cdb() {
   setOraEnv
   if [ -e "$ORACLE_HOME/bin/dbca" ]
   then
      let steps++
      echo "Step: ${steps} - Un-register database instance with dbca" | tee -a ${logdir}/odb-reg-${now}.log

      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/dbca \
         -silent \
         -configureDatabase \
         -sourceDB $ORACLE_SID \
         -unregisterWithDirService true \
         -dirServiceUserName "${eusAdmin}" \
         -dirServicePassword "${bPW}" \
         -walletPassword "${bPW}" \
         >>  ${logdir}/odb-dbca-${now}.log 2>&1
      rc=$?;set +x
   fi
   set +x
}

###############################################################################
# Register Oracle PDB Database to OUD
###############################################################################
register_pdb() {
   setOraEnv

   # Make sure that the listener.ora exists in $ORACLE_HOME
   if [ -e "$ORACLE_HOME/network/admin/listener.ora" ]
   then
      true
   elif [ -e "$ORACLE_BASE/admin/listener.ora" ]
   then
      cp $ORACLE_BASE/admin/listener.ora $ORACLE_HOME/network/admin
   fi

   if [ -n "${PDBS}" ] && [ -e "$ORACLE_HOME/bin/dbca" ]
   then
      for pdbName in ${PDBS}
      do
         let steps++
         echo "Step: ${steps} - Register PDB (cn=${PDBSID}) with dbca" | tee -a ${logdir}/odb-reg-${now}.log

         if [ "${dbg}" == 'true' ];then set -x;fi
         $ORACLE_HOME/bin/dbca \
            -silent \
            -configurePluggableDatabase \
            -pdbName ${pdbName} \
            -sourceDB $ORACLE_SID \
            -registerWithDirService true \
            -dirServiceUserName "${eusAdmin}" \
            -dirServicePassword "${bPW}" \
            -walletPassword "${bPW}" \
            >>  ${logdir}/odb-dbca-${now}.log 2>&1
         rc=$?;set +x

         # Lookup PDB GUID
         PDBGUID="${cfgdir}/${ORACLE_SID}.${pdbName}.guid"
         rm -f "${PDBGUID}" 2> /dev/null
         $ORACLE_HOME/bin/sqlplus -S / as sysdba > ${PDBGUID} <<EOSQL
set pagesize 0;
select guid from v\$pdbs where name='${pdbName}';
EOSQL

         # If PDB GUID not set, lookup PDB GUID through PDB
         if [ -s "${PDBGUID}" ]
         then
            true
         else
            $ORACLE_HOME/bin/sqlplus -S sys/${bPW}@${PDBSID} as sysdba > ${PDBGUID} 2>&1 << EOF
set pagesize 0;
select GUID from v\$pdbs where name='${pdbName}';
EOF
            rc=$?;set +x
         fi

         # Make sure that the CA cert is loaded into the PDB wallet
         GUID=$(cat ${PDBGUID}|grep -v "^$")

         if [ -n "${GUID}" ]
         then
            ck4ca=$($ORACLE_HOME/bin/orapki wallet display -wallet ${ORACLE_BASE}/admin/${ORACLE_SID}/${GUID}/wallet -pwd "${bPW}"|grep "Subject:")
         else
            echo "Error: Cannot determine PDB GUID"
            exit 1
         fi

         if [ -n "${GUID}" ] && [ -z "${ck4ca}" ]
         then
            let steps++
            echo "Step: ${steps} - Import certificate into the wallet of PDB Database ${pdbName}"
            if [ "${dbg}" == 'true' ];then echo;set -x;fi
            $ORACLE_HOME/bin/orapki wallet add -wallet $ORACLE_BASE/admin/$ORACLE_SID/${GUID}/wallet -trusted_cert -cert ${certdir}/${localHost}.pem -pwd "${bPW}" >> ${logdir}/eus-${now}.log 2>&1
            rc=$?;set +x

#            echo "Link wallet to admin/<sid>/<pdbguid>"
#            if [ "${dbg}" == 'true' ];then echo;set -x;fi
#            mkdir -p ${ORACLE_HOME}/admin/${ORACLE_SID}/${GUID}  >> ${logdir}/eus-${now}.log 2>&1
#            ln -s ${ORACLE_BASE}/admin/${ORACLE_SID}/${GUID}/wallet ${ORACLE_HOME}/admin/${ORACLE_SID}/${GUID} >> ${logdir}/eus-${now}.log 2>&1
#            rc=$?;set +x
         fi

      done
   fi
   set +x
}

###############################################################################
# Un-register Oracle Pluggable Database from OUD
###############################################################################
unregister_pdb() {
   setOraEnv
   if [ -e "$ORACLE_HOME/bin/dbca" ]
   then
      let steps++
      echo "Step: ${steps} - Un-register pluggable database with dbca" | tee -a ${logdir}/odb-reg-${now}.log

      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/dbca \
         -silent \
         -configurePluggableDatabase \
         -pdbName ${pdbName} \
         -sourceDB $ORACLE_SID \
         -unregisterWithDirService true \
         -dirServiceUserName "${eusAdmin}" \
         -dirServicePassword "${bPW}" \
         -walletPassword "${bPW}" \
         >>  ${logdir}/odb-dbca-${now}.log 2>&1
      rc=$?;set +x
   fi
   set +x
}

###############################################################################
# Setup DB for EUS
###############################################################################
setup_db() {
   ${curdir}/manage_db.sh setup --step ${steps}
   if [ -e "${cfgdir}/.steps.install.db" ];then instSteps=$(cat ${cfgdir}/.steps.install.db);steps=$((${steps}+${instSteps}));fi
}

###############################################################################
# Re-start OUD
###############################################################################
restart_oud() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   export OPENDS_JAVA_ARGS="-Djava.security.properties=${samples}/eus-java.security"
   set +x
   let steps++
   ${curdir}/manage_oud.sh stop ${dbgFlag} --step ${steps}
   let steps++
   ${curdir}/manage_oud.sh start ${dbgFlag} --step ${steps}
}

###############################################################################
# Reset demo enviroment
###############################################################################
reset_oud() {
   rm -f "${cfgdir}/.eusrealm-loaded" 2> /dev/null
   rm -f "${cfgdir}/.eusbatch-${pnum}-loaded" 2> /dev/null
   if [ -e "${oudmwdir}/${oudprefix}${pnum}/OUD" ]
   then
      ${curdir}/manage_oud.sh deinstall ${dbgFlag}
   fi
}

###############################################################################
# Expand OUD topology for EUS or TNS
###############################################################################
expand_oud() {
   if [ -z "${myPnum}" ];then echo "ERROR: Must provide --pnum <number>";exit 1;fi
   if [ -z "${supplierHost}" ];then supplierHost=$(hostname -f);fi
   if [ -z "${supplierH}" ];then supplierH=$(echo "${supplierHost}."|cut -d. -f1);fi
   if [ -z "${supplierPort}" ];then supplierPort="10444";fi
   if [ -z "${supplierReplPort}" ];then supplierReplPort="10989";fi

   # Create requisite eus batch configuration file
   ${curdir}/manage_data.sh genbatch -n eus
   let steps++

   # Setup another OUD instance
   ${curdir}/manage_oud.sh setup --pnum ${pnum} -n ${templateName} --suffix "${suffix}" --noroles --integration eus --batch ${cfgdir}/eus.batch --step ${steps} --supplier ${supplierHost}:${supplierPort}:${supplierReplPort} ${dbgFlag}
   if [ -e "${cfgdir}/.steps.oud" ];then steps=$(cat ${cfgdir}/.steps.oud);fi
}

###############################################################################
# Setup OUD for EUS
###############################################################################
setup_oud() {
   rm -f "${cfgdir}/.eusrealm-loaded" 2> /dev/null
   rm -f "${cfgdir}/.eusbatch-${pnum}-loaded" 2> /dev/null

   # If no data exists, generate inetorg data
   if [ -e "${cfgdir}/inetorg.ldif" ]
   then
      true
   else
      ${curdir}/manage_data.sh genall -n ${templateName} -N ${numUsers} --rm --step ${steps}
      if [ -e "${cfgdir}/.steps.gendata" ];then steps=$(cat ${cfgdir}/.steps.gendata);fi
   fi

   gen_eus_batch

#   echo "   Use eus-java.security rather than default java.security with anon allowed with:"
#   echo "   export OPENDS_JAVA_ARGS=\"-Djava.security.properties=${samples}/eus-java.security\""
#   export OPENDS_JAVA_ARGS="-Djava.security.properties=${samples}/eus-java.security"

   # Setup first OUD instance
   ${curdir}/manage_oud.sh setup --pnum ${pnum} -n ${templateName} --suffix "${suffix}" --noroles --integration eus --batch ${cfgdir}/eus.batch --step ${steps} ${dbgFlag}

   if [ -e "${cfgdir}/.steps.oud" ];then steps=$(cat ${cfgdir}/.steps.oud);fi

   restart_oud
}

###############################################################################
# List enterprise mappings
###############################################################################
list_enterprise_mappings() {
   setOraEnv

   firstUserDN=$(head -1 ${cfgdir}/${templateName}.dn)
   firstUser=$(echo ${firstUserDN}|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")
   secondUserDN=$(head -2 ${cfgdir}/${templateName}.dn|tail -1)
   secondUser=$(echo ${secondUserDN}|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")

   let steps++
   echo -e "\nStep: ${steps} - List EUS mappings"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm listMappings               domain_name="OracleDefaultDomain" realm_dn="${suffix}" ldap_host="${localHost}" ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}"
   rc=$?;set +x

   let steps++
   echo -e "\nStep: ${steps} - List global CDB roles"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm listGlobalRolesInDB        dbuser="system" dbuser_password="${bPW}" dbconnect_string="${CDBCONNSTR}"
   rc=$?;set +x

   let steps++
   echo -e "\nStep: ${steps} - List PDB ${pdbName} roles"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm listGlobalRolesInDB        dbuser="system" dbuser_password="${bPW}" dbconnect_string="${PDBCONNSTR}"
   rc=$?;set +x

   let steps++
   echo -e "\nStep: ${steps} - List Enterprise Roles"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm listEnterpriseRoles        domain_name="OracleDefaultDomain" realm_dn="${suffix}" ldap_host="${localHost}" ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}"
   rc=$?;set +x

   let steps++
   echo -e "\nStep: ${steps} - List Enterprise Role Information of ent_dba_role"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm listEnterpriseRoleInfo     domain_name="OracleDefaultDomain" enterprise_role="ent_dba_role" realm_dn="${suffix}" ldap_host="${localHost}" ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}"
   rc=$?;set +x

   let steps++
   echo
   echo "Step: ${steps} - List Enterprise Role Information of ent_hrapp_role"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm listEnterpriseRoleInfo     domain_name="OracleDefaultDomain" enterprise_role="ent_hrapp_role" realm_dn="${suffix}" ldap_host="${localHost}" ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}"
   rc=$?;set +x

#   let steps++
#   echo
#   echo "Step: ${steps} - Show dba_role_privs granted to hrapp_role"
#   if [ "${dbg}" == 'true' ];then set -x;fi
#   echo -e "SQL> select GRANTED_ROLE from ldba_role_privs where GRANTEE = 'HRAPP_ROLE';\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
#   $ORACLE_HOME/bin/sqlplus -S / as sysdba 2>&1 <<EOF
#select GRANTED_ROLE from dba_role_privs where GRANTEE = 'HRAPP_ROLE';
#EOF
#   rc=$?;set +x
#
#   let steps++
#   echo
#   echo "Step: ${steps} - Show dba_sys_privs granted to hrapp_role"
#   if [ "${dbg}" == 'true' ];then set -x;fi
#   echo -e "SQL> select PRIVILEGE from dba_sys_privs where GRANTEE = 'HRAPP_ROLE';\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
#   $ORACLE_HOME/bin/sqlplus -S / as sysdba 2>&1 <<EOF
#select PRIVILEGE from dba_sys_privs where GRANTEE = 'HRAPP_ROLE';
#EOF
#   rc=$?;set +x

   let steps++
   echo
   echo "Step: ${steps} - List enterprise roles of ${firstUser} "
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm listEnterpriseRolesOfUser  user_dn="${firstUserDN}" realm_dn="${suffix}" ldap_host="${localHost}" ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}"
   rc=$?;set +x

   let steps++
   echo
   echo "Step: ${steps} - List enterprise roles of ${secondUser} "
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm listEnterpriseRolesOfUser  user_dn="${secondUserDN}" realm_dn="${suffix}" ldap_host="${localHost}" ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}"
   rc=$?;set +x

}

###############################################################################
# Apply enterprise mappings
###############################################################################
apply_enterprise_mappings() {
   setOraEnv

   firstUserDN=$(head -1 ${cfgdir}/${templateName}.dn)
   firstUser=$(echo ${firstUserDN}|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")
   secondUser=$(head -2 ${cfgdir}/${templateName}.dn|tail -1|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")

   msg=''

   let steps++
   echo "Step: ${steps} - Create Enterprise User Schema (Subtree Mapping to ${suffix})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm createMapping              domain_name="OracleDefaultDomain" map_type=SUBTREE map_dn="${suffix}" schema="c##eusdbusers" realm_dn="${suffix}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}" >> ${logdir}/eus-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -ne 0 ];then msg="$msg\n   Error: Creating enterprise user schema failed.";fi

   let steps++
   echo "Step: ${steps} - Create Individual User Schema for user ${firstUserDN}"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm createMapping              domain_name="OracleDefaultDomain" map_type=ENTRY   map_dn="${firstUserDN}"  schema="${firstUser}" realm_dn="${suffix}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}" >> ${logdir}/eus-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -ne 0 ];then msg="$msg\n   Error: Creating enterprise ${firstUser} schema failed.";fi

   # Command to delete this mapping:
   if [ "${dbg}" == 'true' ];then set -x;fi
   # $ORACLE_HOME/bin/eusm                            deleteMapping domain_name="OracleDefaultDomain" mapping_name="MAPPING0" realm_dn="${suffix}" ldap_host="${localHost}" ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}"
   #rc=$?;set +x

   let steps++
   echo "Step: ${steps} - Create enterprise roles ent_dba_role and ent_hrapp_role"

   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm createRole                 domain_name="OracleDefaultDomain" enterprise_role=ent_dba_role       realm_dn="${suffix}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}" >> ${logdir}/eus-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -ne 0 ];then msg="$msg\n   Error: Creating ent_dba_role enterprise role failed.";fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm createRole                 domain_name="OracleDefaultDomain" enterprise_role=ent_hrapp_role     realm_dn="${suffix}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}" >> ${logdir}/eus-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -ne 0 ];then msg="$msg\n   Error: Creating ent_hrapp_role enterprise role failed.";fi


#   let steps++
#   echo "Step: ${steps} - Map enterprise roles to database roles)"
#   # Map enterprise role (ent_dba_role) to database role (dba_role)
#   if [ "$debug" == 'on' ];then echo;set -x;fi
#   $ORACLE_HOME/bin/eusm addGlobalRole             domain_name="OracleDefaultDomain" enterprise_role=ent_dba_role      realm_dn="${suffix}" database_name=${PDBSID} global_role="c##dba_role" dbuser="system" dbuser_password="${bPW}" dbconnect_string="${PDBCONNSTR}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password=${bPW} >> ${logdir}/eus-$now.log 2>&1
#   rc=$?
#   set +x
#   if [ $rc -ne 0 ];then ck='WARN';allGood='false';msg="$msg\n   Error: Assigning DB role (c##dba_role) to enterprise role (ent_dba_role) failed.";fi

   # Map enterprise role (ent_dba_role) to database role (dba_role)
   let steps++
   echo "Step: ${steps} - Map enterprise role (ent_dba_role) to DB role (dba_role) to PDB ${pdbName}"
   if [ "$debug" == 'on' ];then echo;set -x;fi
   $ORACLE_HOME/bin/eusm addGlobalRole              domain_name="OracleDefaultDomain" enterprise_role=ent_dba_role       realm_dn="${suffix}" database_name=${PDBSID}  global_role="dba_role"    dbuser="system" dbuser_password="${bPW}" dbconnect_string="${PDBCONNSTR}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password=${bPW} >> ${logdir}/eus-$now.log 2>&1
   rc=$?
   set +x
   if [ $rc -ne 0 ];then ck='WARN';allGood='false';msg="$msg\n   Error: Assigning DB role (dba_role) to enterprise role (ent_dba_role) failed.";fi

   let steps++
   echo "Step: ${steps} - Map enterprise role (ent_hrapp_role) to DB role (hrapp_role) to PDB ${pdbName}"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm addGlobalRole              domain_name="OracleDefaultDomain" enterprise_role=ent_hrapp_role     realm_dn="${suffix}" database_name=${PDBSID}  global_role="hrapp_role"  dbuser="system" dbuser_password="${bPW}" dbconnect_string="${PDBCONNSTR}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password=${bPW} >> ${logdir}/eus-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -ne 0 ];then msg="$msg\n   Error: Adding global role (hrapp_role) failed.";fi

   let steps++
   echo "Step: ${steps} - Map enterprise roles to respective DS group"
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm grantRole                  domain_name="OracleDefaultDomain" enterprise_role=ent_dba_role       realm_dn="${suffix}" group_dn="cn=group0,ou=Groups,${suffix}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}" >> ${logdir}/eus-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -ne 0 ];then msg="$msg\n   Error: Assigning LDAP group to enterprise role (ent_dba_role) failed.";fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/eusm grantRole                  domain_name="OracleDefaultDomain" enterprise_role=ent_hrapp_role     realm_dn="${suffix}" group_dn="cn=group1,ou=Groups,${suffix}" ldap_host=${localHost} ldap_port=${ldapPort} ldap_user_dn="${eusAdmin}" ldap_user_password="${bPW}" >> ${logdir}/eus-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -ne 0 ];then msg="$msg\n   Error: Assigning LDAP group to enterprise role (ent_hrapp_role) failed.";fi

   list_enterprise_mappings

   if [ -n "${msg}" ];then echo "${msg}";exit 1;fi
   set +x
}

###############################################################################
# List registered databases
###############################################################################
list_dbs() {
   let steps++
   echo "Step: ${steps} - List registered databases"
   setfmwenv
   if [ "${dbg}" == 'true' ]
   then
      set -x
      ${lsrch} -T -h ${localHost} -p ${ldapsPort} -X -Z -D "${eusAdmin}" -j "${jPW}" -b "${suffix}" -s sub '(|(objectClass=orclDBServer)(objectClass=orclNetService))' 
      rc=$?;set +x
   else
      ${lsrch} -T -h ${localHost} -p ${ldapsPort} -X -Z -D "${eusAdmin}" -j "${jPW}" -b "${suffix}" -s sub '(|(objectClass=orclDBServer)(objectClass=orclNetService))' dn
      rc=$?
   fi
}

###############################################################################
# Prepare DB for EUS
# 1. Add global user schema to CDB (and PDB) if appropriate
###############################################################################
prep_db() {
   firstUserDN=$(head -1 ${cfgdir}/${templateName}.dn)
   firstUser=$(echo ${firstUserDN}|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")
   secondUser=$(head -2 ${cfgdir}/${templateName}.dn|tail -1|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")

   # Load DB Environment
   setOraEnv

   echo "Define global shared user schema in CDB"

   echo -e "\nsqlplus -S sys/${bPW}@${CDBCONNSTR} as sysdba" 2>&1 | tee -a ${logdir}/eus-${now}.log

   echo -e "SQL> create user c##eusdbusers identified globally CONTAINER=ALL; \c" 2>&1 | tee -a ${logdir}/eus-${now}.log
   if [ "${dbg}" == 'true' ];then set -x;fi
   $ORACLE_HOME/bin/sqlplus -S sys/${bPW}@${CDBCONNSTR} as sysdba << EOF
create user c##eusdbusers identified globally CONTAINER=ALL;
EOF
   rc=$?

   echo "Define local PDB specific roles in PDB ${pdbName}"

   echo -e "\nsqlplus -S sys/${bPW}@${PDBSID} as sysdba" 2>&1 | tee -a ${logdir}/eus-${now}.log

   echo -e "\nCreate DBA role in PDB ${pdbName}"
   echo -e "SQL> create role dba_role identified globally;\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
   $ORACLE_HOME/bin/sqlplus -S sys/${bPW}@${PDBSID} as sysdba <<EOF
create role dba_role identified globally;
EOF
   rc=$?

   echo -e "\nGrant DBA privileges to dba_role in PDB ${pdbName}"
   echo -e "SQL> GRANT DBA, CONNECT, RESOURCE, CREATE TABLESPACE, SELECT ANY TABLE, DROP ANY TABLE, CREATE ANY TABLE, CREATE USER to dba_role;\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
   $ORACLE_HOME/bin/sqlplus -S sys/${bPW}@${PDBSID} as sysdba 2>&1 <<EOF
GRANT DBA, CONNECT, RESOURCE, CREATE TABLESPACE, SELECT ANY TABLE, DROP ANY TABLE, CREATE ANY TABLE, CREATE USER to dba_role;
EOF
   rc=$?

   echo -e "\nCreate HR role in PDB ${pdbName}"
   echo -e "SQL> create role hrapp_role identified globally\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
   $ORACLE_HOME/bin/sqlplus -S sys/${bPW}@${PDBSID} as sysdba <<EOF
create role hrapp_role identified globally;
EOF
   rc=$?

   echo -e "\nGrant privileges to hrapp_role in PDB ${pdbName}"
   echo -e "SQL> GRANT CREATE SESSION, RESOURCE to hrapp_role;\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
   $ORACLE_HOME/bin/sqlplus -S sys/${bPW}@${PDBSID} as sysdba 2>&1 <<EOF
GRANT CREATE SESSION, RESOURCE to hrapp_role;
EOF
   rc=$?

   echo -e "\nCreate user ${firstUser} in PDB ${pdbName}"
   echo -e "SQL> create user ${firstUser} identified as '${firstUserDN}';\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
   $ORACLE_HOME/bin/sqlplus -S sys/${bPW}@${PDBSID} as sysdba <<EOF
create user ${firstUser} identified globally;
EOF
   rc=$?

   echo -e "\nGrant privileges to ${firstUser} in PDB ${pdbName}"
   echo -e "SQL> grant CREATE SESSION, CONNECT, RESOURCE, DBA, SYSDBA to ${firstUser};\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
   $ORACLE_HOME/bin/sqlplus -S sys/${bPW}@${PDBSID} as sysdba 2>&1 <<EOF
grant CREATE SESSION, CONNECT, RESOURCE, DBA to ${firstUser};
EOF
   rc=$?
}

###############################################################################
# Demo end-to-end setup and demo
###############################################################################
test_eus() {
   # Load DB Environment
   setOraEnv

   echo -e "\n\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Test DB can authenticate to OUD "
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="

   if [ "${dbg}" == 'true' ];then set -x;fi
   echo " "

   PDBLOG="${cfgdir}/.pdb_log"

   PDBGUID="${cfgdir}/${ORACLE_SID}.${pdbName}.guid"
   GUID=$(cat ${PDBGUID}|grep -v "^$")

   PDBLOG="${cfgdir}/.pdb_log"

   echo "mkstore -wrl $ORACLE_BASE/admin/${ORACLE_SID}/${GUID}/wallet  -viewEntry ORACLE.SECURITY.DN"
   $ORACLE_HOME/bin/mkstore -wrl $ORACLE_BASE/admin/${ORACLE_SID}/${GUID}/wallet  -viewEntry ORACLE.SECURITY.DN > ${PDBLOG} 2>&1 << EOF
${bPW}
EOF
   DBDN=$(tail -1 ${PDBLOG} | awk '{print $3}')
   echo "ORACLE.SECURITY.DN = ${DBDN}"
   echo " "

   echo "mkstore -wrl $ORACLE_BASE/admin/${ORACLE_SID}/${GUID}/wallet -viewEntry ORACLE.SECURITY.PASSWORD"
   $ORACLE_HOME/bin/mkstore -wrl $ORACLE_BASE/admin/${ORACLE_SID}/${GUID}/wallet -viewEntry ORACLE.SECURITY.PASSWORD 2>&1 > ${PDBLOG} 2>&1 << EOF
${bPW}
EOF

   DBPASS=$(tail -1 ${PDBLOG} | awk '{print $3}')
   echo "ORACLE.SECURITY.PASSWORD = ${DBPASS}"
   echo " "

   rm -f "${PDBLOG}"

   if [ -n "${DBDN}" ] && [ -n "${DBPASS}" ]
   then
      echo "ldapbind using database credentials: "
      echo " "
      PORT=$(grep DIRECTORY_SERVERS $ORACLE_HOME/network/admin/ldap.ora | cut -d ":" -f2)
      echo "ldapbind -h ${localHost} -p ${ldapPort} -D "${DBDN}" -w ${DBPASS} "
      $ORACLE_HOME/bin/ldapbind -h ${localHost} -p ${ldapPort} -D "${DBDN}" -w "${DBPASS}"
      rc=$? ;set +x
      if [ $rc -ne 0 ]
      then
         echo "Can not connect to Directory server"
         exit
      fi
      echo ""

      if [[ ${dbvdir} =~ 12.* ]] || [[ ${dbvdir} =~ 18.* ]] || [[ ${dbvdir} =~ 19.* ]]
      then
         echo "ldapbind (SSL) using database credentials:"
         echo " "
         PORTS=$(grep DIRECTORY_SERVERS $ORACLE_HOME/network/admin/ldap.ora | cut -d ":" -f3| cut -d ")" -f1 )
         echo "ldapbind -h ${localHost} -p ${PORTS} -D ${DBDN} -w ${DBPASS} -U 1 "
         $ORACLE_HOME/bin/ldapbind -h ${localHost} -p ${ldapsPort} -D "${DBDN}" -w "${DBPASS}" -U 1 #>> ${LOGS}/eus-wallet-${now}.log 2>&1
         rc=$? ;set +x
         if [ $rc -ne 0 ]
         then
            echo "Could not connect to Directory server"
            exit
         fi;
         echo ""
      fi
   fi

   firstUserDN=$(head -1 ${cfgdir}/${templateName}.dn)
   firstUser=$(echo ${firstUserDN}|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")
   secondUser=$(head -2 ${cfgdir}/${templateName}.dn|tail -1|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")
   thirdUser=$(head  -3 ${cfgdir}/${templateName}.dn|tail -1|cut -d',' -f1|sed -e "s/uid=//g" -e "s/ $//g")

   for dbudata in "${firstUser}|individuallay mapped user" "${secondUser}|shared schema user" "${thirdUser}|shared schema user with no privileges"
   do
      dbuser=$(echo ${dbudata}|cut -d'|' -f1)
      userdesc=$(echo ${dbudata}|cut -d'|' -f2)

      #CONNECTIDENTIFIER="${dbuser}/${bPW}@${localHost}:1521/${pdbName}.${domain}"
      CONNECTIDENTIFIER="${dbuser}/${bPW}@${PDBSID}"
      echo -e "\n\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      echo "--TEST ${t}--> Demonstrate use cases for ${userdesc} (${dbuser})"
      echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      echo "--TEST ${t} (1of4)--> Show User"
      echo "sqlplus -S $CONNECTIDENTIFIER"
      echo "SQL> show user;"
      ${ORACLE_HOME}/bin/sqlplus -S $CONNECTIDENTIFIER << EOF
show user;
EOF

      echo -e "\n\n--TEST ${t} (2of4)--> Show User ID"
      echo "sqlplus -S $CONNECTIDENTIFIER"
      echo "SQL> select sys_context('USERENV','AUTHENTICATED_IDENTITY') from dual;"
      ${ORACLE_HOME}/bin/sqlplus -S $CONNECTIDENTIFIER << EOF
select sys_context('USERENV','AUTHENTICATED_IDENTITY') from dual;
EOF

      echo -e "\n\n--TEST ${t} (3of4)--> Show User DN"
      echo "sqlplus -S $CONNECTIDENTIFIER"
      echo "SQL> select sys_context('USERENV','ENTERPRISE_IDENTITY') from dual;"
      ${ORACLE_HOME}/bin/sqlplus -S $CONNECTIDENTIFIER << EOF
select sys_context('USERENV','ENTERPRISE_IDENTITY') from dual;
EOF

      echo -e "\n\n--TEST ${t} (4of4)--> Show User's Roles"
      echo "sqlplus -S $CONNECTIDENTIFIER"
      echo "SQL> select * from session_roles;"
      ${ORACLE_HOME}/bin/sqlplus -S $CONNECTIDENTIFIER << EOF
select * from session_roles;
EOF

#   let steps++
#   echo
#   echo -e "\nStep: ${steps} - Show dba_role_privs granted to ${dbuser}"
#   if [ "${dbg}" == 'true' ];then set -x;fi
#   echo -e "SQL> select GRANTED_ROLE from dba_role_privs where GRANTEE = "${dbuser}";\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
#   $ORACLE_HOME/bin/sqlplus -S / as sysdba 2>&1 <<EOF
#select GRANTED_ROLE from dba_role_privs where GRANTEE = '${dbuser}';
#EOF
#   rc=$?;set +x
#
#   let steps++
#   echo
#   echo "Step: ${steps} - Show dba_sys_privs granted to dba_role"
#   if [ "${dbg}" == 'true' ];then set -x;fi
#   echo -e "SQL> select PRIVILEGE from dba_sys_privs where GRANTEE = '${dbuser}';\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
#   $ORACLE_HOME/bin/sqlplus -S / as sysdba 2>&1 <<EOF
#select PRIVILEGE from dba_sys_privs where GRANTEE = '${dbuser}';
#EOF
#   rc=$?;set +x

#      echo "--TEST ${t} (5of4)--> Show User as sysdba"
#      ucFirstUser=$(echo ${firstUser}|tr -s '[:lower:]' '[:upper:]')
#      CONNECTIDENTIFIER="${dbuser}/${bPW}@${PDBSID}"
#      echo "sqlplus -S ${ucFirstUser}/${bPW}@${PDBSID} as sysdba"
#      echo "SQL> show user;"
#      ${ORACLE_HOME}/bin/sqlplus -S ${ucFirstUser}/${bPW}@${PDBSID} as sysdba << EOF
#show user;
#EOF

   done
}

###############################################################################
# Demo testing of TNS
###############################################################################
test_tns() {
   # Load DB Environment
   setOraEnv

   echo -e "\n\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Show TNS Ping to container DB "
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   set -x
   ${ORACLE_HOME}/bin/tnsping ${dbH}
   rc=$?;set +x

   echo -e "\n\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Show the corresponding OUD access log entries "
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   tail -7 ${oudmwdir}/${oudprefix}10/OUD/logs/access

   echo -e "\n\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Show TNS Ping to pluggable DB "
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   set -x
   ${ORACLE_HOME}/bin/tnsping PDB1_${dbH}
   rc=$?;set +x

   echo -e "\n\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Show the corresponding OUD access log entries "
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   tail -7 ${oudmwdir}/${oudprefix}10/OUD/logs/access

}

###############################################################################
# Demo end-to-end setup and demo
###############################################################################
demo_eus() {
   setup_db
   configure_db
   setup_oud

   # Remove user1, user2, and user3 from specific groups
   let steps++
   echo "Step: ${steps} - Remove select users from select enterprise mapped groups" | tee -a ${logdir}/eus-${now}.log
   if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
   setfmwenv
   ${lmod} -h ${localHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" >> ${logdir}/eus-${now}.log 2>&1 <<EOF
dn: cn=group0,ou=Groups,${suffix}
changeType: modify
delete: uniqueMember
uniqueMember: uid=user1,ou=People,${suffix}


dn: cn=group0,ou=Groups,${suffix}
changeType: modify
delete: uniqueMember
uniqueMember: uid=user3,ou=People,${suffix}


dn: cn=group1,ou=Groups,${suffix}
changeType: modify
delete: uniqueMember
uniqueMember: uid=user2,ou=People,${suffix}


dn: cn=group1,ou=Groups,${suffix}
changeType: modify
delete: uniqueMember
uniqueMember: uid=user3,ou=People,${suffix}
EOF

   load_realm
   register_cdb
   register_pdb
   list_dbs
   prep_db
   apply_enterprise_mappings
   test_eus
}

###############################################################################
# Set JAVA_HOME if not already set
###############################################################################
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
if [ -z "${JAVA_HOME}" ];then unset JAVA_HOME;fi

###############################################################################
# Process subcommand
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
case ${subcmd} in
        'prepoud') load_realm;;
         'prepdb') prep_db;;
          'cfgdb') configure_db;;
         'regcdb') register_cdb;;
         'regpdb') register_pdb;;
       'unregcdb') unregister_cdb;;
       'unregpdb') unregister_pdb;;
        'setupdb') setup_db;;
       'setupoud') setup_oud;;
         'expand') expand_oud;;
           'demo') demo_eus;;
       'resetoud') reset_oud;;
        'restart') restart_oud;;
     'applyroles') apply_enterprise_mappings;;
      'listroles') list_enterprise_mappings;;
        'testeus') test_eus;;
        'testtns') test_tns;;
           'list') list_dbs;;
                *) showUsage;;
esac
set +x
