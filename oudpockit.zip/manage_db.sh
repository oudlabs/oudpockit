#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [setup|deinstall|start|stop] [options]

SYNOPSIS
     Setup DB Instance
        ${cmd} setup [other optons]

     Start DB instance
        ${cmd} start

     Stop DB instance
        ${cmd} stop

     Install DB software
        ${cmd} install

DESCRIPTION
     Sample script for managing Oracle Database 19c (or newer) instance

OPTIONS
     Setup Options
     The following options are supported:

         --dbv <version>         Database version
                                 Default: 19c

         --bitsdir <dir>         Directory of the software packages

         --swdir <dir>           Directory of the extracted software

EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            dbv) dbv="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            swdir) swdir="$1";shift;;
            ldapHost|ldaphost) ldapHost="$1";shift;;
            ldapPort|ldapport) ldapPort="$1";shift;;
            ldapAdmin|ldapadmin) ldapAdmin="$1";shift;;
            ldapPW|ldappw) ldapPW="$1";shift;;
            step) mySteps="$1";steps=${mySteps};shift;;
            pdb) pdbName="$1";shift;;
            14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            j) jPW="$1";;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -n "${mySteps}" ]; then steps=${mySteps};else steps=0;fi


###############################################################################
# Set Defaults
###############################################################################
if [ -z "${dbv}" ];then dbv='19c';fi
if [ -z "${pdbName}" ];then pdbName='PDB1';fi

case ${dbv} in
   '23ai'|'23.0.0.0'|'23.4.0'|'23.4'|'23.5.0'|'23.5'|'23') export dbvdir="23ai" ;;
   '21c'|'21.3.0.0'|'21.3.0'|'21.3'|'21') export dbvdir="21c" ;;
   '19c'|'19.3.0.0'|'19.3.0'|'19.3'|'19') export dbvdir="19c" ;;
   '18c'|'18.0.0.0'|'18.0.0'|'18.0'|'18') export dbvdir="18c" ;;
   '12c'|'12.2.0.1') export dbvdir="12.2.0" ;;
   '12cPS2'|'12.1.0.2') export dbvdir="12.1.0" ;;
   '11g'|'11.2.0.4') export dbvdir="11.2.0" ;;
   *) echo "ERROR: DB Version ${dbv} is not supported";exit 1 ;;
esac

if [ -z "${ldapHost}" ];then ldapHost="${localHost}";fi
if [ -z "${ldapAdmin}" ];then ldapAdmin='cn=eusadmin,ou=Admins,cn=oracleContext';fi
if [ -z "${ldapPW}" ];then ldapPW="${bPW}";fi

###############################################################################
# Make response files
###############################################################################
extract_software() {
   # Set Oracle Env variables
   setOraEnv

   if [ -z "$ORACLE_HOME" ]
   then
      echo "ERROR: ORACLE_HOME not set"
      exit 1
   fi

   if [ -d "$ORACLE_HOME/bin/dbca" ]
   then
      true
   else
      if [ "${dbg}" == 'true' ];then set -x;fi
      case ${dbvdir} in
           23ai|23.5.0)
            if [ -e "$ORACLE_HOME/bin/dbca" ]
            then
               true
            elif [ -e "${bitsdir}/V1043785-01.zip" ]
            then
               let steps++
               echo "Step: ${steps} - Extract ODB ${dbvdir} software" | tee -a  ${logdir}/sw-extract-${now}.log
               if [ "${dbg}" == 'true' ];then set -x;fi
               mkdir -p "$ORACLE_HOME" 2> /dev/null
               unzip -d "$ORACLE_HOME" -qo ${bitsdir}/V1043785-01.zip
               rc=$?
               set +x
            fi
            ;;
         21.3.0)
            if [ -e "$ORACLE_HOME/bin/dbca" ]
            then
               true
            elif [ -e "${bitsdir}/V1011496-01.zip" ]
            then
               let steps++
               echo "Step: ${steps} - Extract ODB ${dbvdir} software" | tee -a  ${logdir}/sw-extract-${now}.log
               if [ "${dbg}" == 'true' ];then set -x;fi
               mkdir -p "$ORACLE_HOME" 2> /dev/null
               unzip -d "$ORACLE_HOME" -qo ${bitsdir}/V1011496-01.zip
               rc=$?
               set +x
            fi
            ;;
            19c)
            if [ -e "$ORACLE_HOME/bin/dbca" ]
            then
               true
            elif [ -e "${bitsdir}/V982063-01.zip" ]
            then
               let steps++
               echo "Step: ${steps} - Extract ODB ${dbvdir} software" | tee -a  ${logdir}/sw-extract-${now}.log
               if [ "${dbg}" == 'true' ];then set -x;fi
               mkdir -p "$ORACLE_HOME" 2> /dev/null
               unzip -d "$ORACLE_HOME" -qo ${bitsdir}/V982063-01.zip
               rc=$?
               set +x
            fi
            ;;
         18.0.0)
            if [ -e "$ORACLE_HOME/bin/dbca" ]
            then
               true
            elif [ -e "${bitsdir}/V978967-01.zip" ]
            then
               let steps++
               echo "Step: ${steps} - Extract ODB ${dbvdir} software" | tee -a  ${logdir}/sw-extract-${now}.log
               if [ "${dbg}" == 'true' ];then set -x;fi
               mkdir -p "$ORACLE_HOME" 2> /dev/null
               unzip -d "$ORACLE_HOME" -qo ${bitsdir}/V978967-01.zip
               rc=$?
               set +x
            fi
            ;;
      esac
   fi
}

###############################################################################
# Make response files
###############################################################################
mk_response() {
   setOraEnv
   if [ -e "${cfgdir}/oraInventory.loc" ]
   then
      true
   else
      mkdir -p "${cfgdir}" 2> /dev/null
      cat > ${cfgdir}/oraInventory.loc <<EOF
inventory_loc=${cfgdir}/oraInventory
inst_group=${me}
EOF
   fi

#   mkdir -p "${curdir}/db/${dbvdir}/admin" 2> /dev/null
#ORACLE_BASE=${curdir}/db/${dbvdir}/app/oracle
#ORACLE_HOME=${curdir}/db/${dbvdir}/dbhome_1
   case ${dbvdir} in
         23ai|23.5.0) cat > ${cfgdir}/odb${dbvdir}.rsp <<EOF
oracle.install.responseFileVersion=/oracle/install/rspfmt_dbinstall_response_schema_v23.0.0
installOption=INSTALL_DB_SWONLY
UNIX_GROUP_NAME=${myg}
INVENTORY_LOCATION=${cfgdir}/oraInventory
ORACLE_BASE=$ORACLE_BASE
ORACLE_HOME=$ORACLE_HOME
installEdition=EE
OSDBA=${myg}
OSOPER=${myg}
OSBACKUPDBA=${myg}
OSDGDBA=${myg}
OSKMDBA=${myg}
OSRACDBA=${myg}
executeRootScript=
configMethod=
sudoPath=
sudoUserName=
clusterNodes=
dbType=GENERAL_PURPOSE
gdbName=
dbSID=
pdbName=
charSet=
enableAutoMemoryManagement=false
memoryLimit=4096
allSchemaPassword=${bPW}
sysPassword=
systemPassword=
dbsnmpPassword=
pdbadminPassword=
managementOption=DEFAULT
omsHost=
omsPort=0
emAdminUser=
emAdminPassword=
enableRecovery=false
storageType=FILE_SYSTEM_STORAGE
dataLocation=$ORACLE_BASE/oradata
recoveryLocation=
diskGroup=
asmsnmpPassword=
EOF
              cat > ${cfgdir}/odb${dbvdir}-deinstall.rsp <<EOF
ORACLE_BASE=$ORACLE_BASE
ORACLE_HOME=$ORACLE_HOME
COMPS_TO_REMOVE=oledbolap,ntoledb,asp.net,odp.net
ORACLE_HOME_VERSION=23.0.0.0.0
INVENTORY_LOCATION=${cfgdir}/oraInventory
CRS_HOME=false
HOME_TYPE=CLIENT
silent=true
WindowsRegistryCleanupList=
MinimumSupportedVersion=23.0.0.0.0
LOCAL_NODE=ol8
local=false
ObaseCleanupPtrLoc=
ORACLE_HOME=$ORACLE_HOME
LOGDIR=${logdir}
OLD_ACTIVE_ORACLE_HOME=
ORACLE_HOME_VERSION_VALID=true
EOF
              ;;

#ORACLE_HOME=${curdir}/db/${dbvdir}/dbhome_1
#ORACLE_BASE=${curdir}/db/${dbvdir}/app/oracle
         19c) cat > ${cfgdir}/odb${dbvdir}.rsp <<EOF
oracle.install.responseFileVersion=/oracle/install/rspfmt_dbinstall_response_schema_v19.0.0
oracle.install.option=INSTALL_DB_SWONLY
UNIX_GROUP_NAME=${myg}
INVENTORY_LOCATION=${cfgdir}/oraInventory
ORACLE_BASE=$ORACLE_BASE
ORACLE_HOME=$ORACLE_HOME
oracle.install.db.InstallEdition=EE
oracle.install.db.OSDBA_GROUP=${myg}
oracle.install.db.OSOPER_GROUP=${myg}
oracle.install.db.OSBACKUPDBA_GROUP=${myg}
oracle.install.db.OSDGDBA_GROUP=${myg}
oracle.install.db.OSKMDBA_GROUP=${myg}
oracle.install.db.OSRACDBA_GROUP=${myg}

oracle.install.db.config.starterdb.memoryOption=false
oracle.install.db.config.starterdb.memoryLimit=4096
oracle.install.db.config.starterdb.password.ALL=${bPW}
oracle.install.db.config.starterdb.managementOption=DEFAULT
oracle.install.db.config.starterdb.enableRecovery=false
oracle.install.db.config.starterdb.storageType=FILE_SYSTEM_STORAGE
oracle.install.db.config.starterdb.fileSystemStorage.dataLocation=$ORACLE_BASE/oradata
SECURITY_UPDATES_VIA_MYORACLESUPPORT=false
DECLINE_SECURITY_UPDATES=true
oracle.installer.autoupdates.option=SKIP_UPDATES
EOF

              cat > ${cfgdir}/odb${dbvdir}-deinstall.rsp <<EOF
ORACLE_BASE=$ORACLE_BASE
ORACLE_HOME=$ORACLE_HOME
COMPS_TO_REMOVE=oledbolap,ntoledb,asp.net,odp.net
ORACLE_HOME_VERSION=19.0.0.0.0
INVENTORY_LOCATION=${cfgdir}/oraInventory
CRS_HOME=false
HOME_TYPE=CLIENT
silent=true
WindowsRegistryCleanupList=
MinimumSupportedVersion=11.2.0.1.0
LOCAL_NODE=ol8
local=false
ObaseCleanupPtrLoc=
LOGDIR=${logdir}
OLD_ACTIVE_ORACLE_HOME=
ORACLE_HOME_VERSION_VALID=true
EOF


#oracle.install.db.DBA_GROUP=${ogid}
#oracle.install.db.OPER_GROUP=${ogid}
#oracle.install.db.BACKUPDBA_GROUP=${ogid}
#oracle.install.db.DGDBA_GROUP=${ogid}
#oracle.install.db.KMDBA_GROUP=${ogid}
#oracle.install.db.OSRACDBA_GROUP=${ogid}
#oracle.install.db.isRACOneInstall=false
#oracle.install.db.config.starterdb.memoryOption=false
#oracle.install.db.config.starterdb.memoryLimit=${dbMem}
#oracle.install.db.config.starterdb.password.ALL=${bPW}
#oracle.install.db.config.starterdb.managementOption=DEFAULT
#oracle.install.db.config.starterdb.enableRecovery=false
#oracle.install.db.config.starterdb.storageType=FILE_SYSTEM_STORAGE
#oracle.install.db.config.starterdb.fileSystemStorage.dataLocation=${demoDir}/database/oradata
#SECURITY_UPDATES_VIA_MYORACLESUPPORT=false
#DECLINE_SECURITY_UPDATES=true
#oracle.installer.autoupdates.option=SKIP_UPDATES
              ;;
   esac

}

###############################################################################
# Check requisites
###############################################################################
ck_reqs() {

   let steps++
   echo "Step: ${steps} - Confirm OS packages are installed for ODB" | tee -a  ${logdir}/os-requisites-${now}.log

   lookupos

   if [ "${os}" == 'Linux' ]
   then
      if [ "${olv}" == '6' ] || [ "${olv}" == '7' ]
      then
         if [[ ${dbvdir} == 12* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-server-12cR2-preinstall)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-server-12cR2-preinstall > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         elif [[ ${dbvdir} == 18* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-preinstall-18c)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-preinstall-18c > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         elif [[ ${dbvdir} == 19* ]] || [[ ${dbvdir} == 20* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-preinstall-19c)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-preinstall-19c > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         elif [[ ${dbvdir} == 21* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-preinstall-21c)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-preinstall-21c > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         elif [[ ${dbvdir} == 23* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-preinstall-23)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-preinstall-23ai > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         fi
      elif [ "${olv}" == '8' ]
      then
         if [[ ${dbvdir} == 19* ]] || [[ ${dbvdir} == 20* ]]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            sudo -n yum install -y oracle-database-preinstall-19c > ${logdir}/os-requisites-${now}.log 2>&1
            rc=$?;set +x
         elif [[ ${dbvdir} == 21* ]]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            sudo -n yum install -y oracle-database-preinstall-21c > ${logdir}/os-requisites-${now}.log 2>&1
            rc=$?;set +x
         elif [[ ${dbvdir} == 23* ]]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            sudo -n yum install -y oracle-database-preinstall-23ai > ${logdir}/os-requisites-${now}.log 2>&1
            rc=$?;set +x
         fi

         # Other requisites
         if [ "${dbg}" == 'true' ];then set -x;fi
         sudo -n yum install -y libnsl > ${logdir}/os-requisites-${now}.log 2>&1
         rc=$?;set +x
      fi
   fi

#   ck4shmmni=$(grep 'wmem_default = 4194304' /etc/sysctl.conf)
#   if [ -z "${ck4shmmni}" ]
#   then
#      sudo -n tee -a /etc/sysctl.conf <<EOF
## Added for ODB
#fs.file-max = 2251799813685247
#fs.aio-max-nr = 212992
#net.core.rmem_default = 32768
#net.core.rmem_max = 262144
#net.core.wmem_default = 4194304
#net.core.wmem_max = 262144
#
#EOF
#   fi

   # Make sure sysctl.conf updates are applied
   sudo -n sysctl -p /etc/sysctl.conf >> ${logdir}/sysctl-${now}.log
 
   if [ -d "${cfgdir}/oraInventory" ]
   then
      true
   else
      mkdir "${cfgdir}/oraInventory" 2> /dev/null
   fi
   set +x

   # Make sure there is sufficient swap
   instSwap

#   swapSize=$(free -k|grep "^Mem:"|awk '{ print $2 }') >> ${logdir}/swap-$now.log 2>&1
#   #swapSize=$((1024*1024*16))
#   swapFile="${curdir}/tmp/pocSwapFile"
#   if [ -e "${swapFile}" ]
#   then
#      true
#   else
#      let steps++
#      echo "Step: ${steps} - Increase swap to satisfy Oracle Universal Installer" | tee -a  ${logdir}/swap-${now}.log
#
#      dd if=/dev/zero of="${swapFile}" bs=1k count=${swapSize} >> ${logdir}/swap-$now.log 2>&1
#      rc=$?
#      chmod 600 "${swapFile}" >> ${logdir}/swap-$now.log 2>&1
#      rc=$?
#      mkswap -f ${swapFile} >> ${logdir}/swap-$now.log 2>&1
#      rc=$?
#      sudo -n chown root ${swapFile} >> ${logdir}/swap-$now.log 2>&1
#      rc=$?
#   fi
#   ckswap=$(swapon -s|grep pocSwapFile)
#   if [ -z "${ckswap}" ]
#   then
#      sudo -n /sbin/swapon ${swapFile} >> ${logdir}/swap-$now.log 2>&1
#      rc=$?
#   fi
#   set +x
}

###############################################################################
# Wait for database to transition to finish starting up
###############################################################################
wait4db() {
   if [ "$1" == 'test' ];then dbTstCnt=2;else dbTstCnt=40;fi

   # Set Oracle Env variables
   setOraEnv

   if [ -e "$ORACLE_HOME/bin/sqlplus" ]
   then
      isDbUp=''
      isCDB='NO'
      n=1
      ### Determine if it's a CDB 
      if [[ ${dbvdir} == 18* ]] || [[ ${dbvdir} == 19* ]] || [[ ${dbvdir} == 21* ]] || [[ ${dbvdir} == 23* ]]
      then
         # Determine whether it's a CDB
         #isCDB=$(export ORACLE_HOME=${curdir}/database/product/${dbvdir}/dbhome_1 ORACLE_SID=${dbH};$ORACLE_HOME/bin/sqlplus -S system/${bPW}   2> /dev/null << EOF
         isCDB=$($ORACLE_HOME/bin/sqlplus -S system/${bPW} 2> /dev/null << EOF
SELECT CDB FROM V\$DATABASE;
EOF
)
         isCDB=$(echo $isCDB | cut -d " " -f3)
         #isCDB=$(echo ${isCDB}|egrep "^YES|^NO")
      fi
   
      if [ "${isCDB}" == "YES" ]
      then 
          # Make sure each PDB is up
          isPdbUp=''
          while [[ "${isPdbUp}" != 'WRITE' ]] && [ $n -lt ${dbTstCnt} ]
          do
             # Wait fore a few seconds
             sleep 5
             if [ "${dbg}" == 'on' ];then echo;set -x;fi
             #isPdbUp=$(export ORACLE_HOME=$demoDir/database/product/${dbvdir}/dbhome_1 ORACLE_SID=${dbh}
             isPdbUp=$($ORACLE_HOME/bin/sqlplus -S system/${bPW} as sysdba << EOF
COLUMN NAME FORMAT A8;
select name, open_mode from v\$pdbs where con_id>=3;
EOF
)
              isPdbUp=$(echo ${isPdbUp} |grep "WRITE" | cut -d " " -f7)
              set +x
              let n++
          done

          if [ "${isPdbUp}" != 'WRITE' ]
          then
             echo "Error: PDB database is not responding."
             exit 1
          fi
      else 
         while [ "${isDbUp}" != 'USER is "SYSTEM"' ] && [ $n -lt ${dbTstCnt} ]
         do
            # Wait fore a minute
            sleep 5
            if [ "${dbg}" == 'on' ];then echo;set -x;fi
            isDbUp=$($ORACLE_HOME/bin/sqlplus -S system/${bPW} 2> /dev/null << EOF
show user;
EOF
)
            set +x
            let n++
         done

         if [ "${cmd}" == 'setup' ] || [ "${cmd}" == 'start' ]
         then
            if [ "${isDbUp}" != 'USER is "SYSTEM"' ]
            then
               echo "Error: Database is not responding."
               exit 1
            fi
         fi
      fi
   else
      echo "Error: Database is not installed."
      exit 1
   fi
}

###############################################################################
# Patch Oracle Database
###############################################################################
patch_db() {
   ck_reqs

   # Extract all patches in ${bitsdir}
   ${curdir}/manage_install.sh extract patches ${fmwFlag}

   # If an updated OPatch version exists, install it
   if [ -d "${swdir}/OPatch" ]
   then
      setOraEnv
      let steps++
      echo "Step: ${steps} - Apply OPatch update" | tee -a  ${logdir}/sw-install-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      rsync -Ha "${swdir}/OPatch/." "$ORACLE_HOME/OPatch/."
      rc=$?;set +x
   fi

   # Look for DB patches
   q=0
   readarray -t tmpPatches < <(ls -1d ${swdir}/*/README.html 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/        /${tabvar}/g" -e "s/\/README.html//g")
   for (( x=0; x< ${#tmpPatches[*]}; x++ ))
   do
      patch=$(echo "${tmpPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/      /g")
      ckpatch=$(grep "Database Release Update" ${patch}/README.*)
      if [ -n "${ckpatch}" ]
      then
         patchname=$(basename "${tmpPatches[${x}]}")
         if [ -e "$ORACLE_HOME/.patch.${patchname}.installed" ]
         then
            true
         elif [ -n "${patchname}" ]
         then
            patchOud='true'
            let q++
            opatchPatches[${q}]="${patchname}"
         fi
      fi
   done


   # Stop DB if any patches exist to be applied
   if [ ${#opatchPatches[*]} -gt 0 ]
   then
      # Stop DB
      stop_db

      # Apply OPatch updates
      for patch in ${opatchPatches[*]}
      do
         if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
         let steps++
         echo "Step: ${steps} - Apply DB patch ${patch}" | tee -a  ${logdir}/sw-install-${now}.log
         setOraEnv
         if [ "${dbg}" == 'true' ];then set -x;fi
         cd ${swdir}/${patch}
         $ORACLE_HOME/OPatch/opatch apply -silent >> ${logdir}/patch-opatch-${now}.log 2>&1
         rc=$?;set +x
         ck4warn=$(grep 'OPatch installation completed with warnings' ${logdir}/patch-opatch-${now}.log)
         if [ -n "${ck4warn}" ]
         then
            echo "WARNING: OPatch install failed.  See: ${logdir}/patch-opatch-${now}.log for details"
         else
            touch "$ORACLE_HOME/.patch.${patch}.installed"
         fi
         set +x
      done

      # Start DB
      start_db
   fi
}

###############################################################################
# Install Oracle Database
###############################################################################
install_db() {
   ck_reqs
   mk_response
   extract_software
   setOraEnv
   lookupos

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -d "$ORACLE_HOME/bin/dbca" ]
   then
      true
   else
      case ${dbvdir} in
             19c|23ai|23.5.0)
                 if [ -e "$ORACLE_HOME/runInstaller" ] && [ -e "$ORACLE_HOME/root.sh.old.2" ]
                 then
                    true
                 elif [ -e "$ORACLE_HOME/runInstaller" ]
                 then
                    if [ "${olv}" == '8' ];then export CV_ASSUME_DISTID=OEL7.8;fi

                    let steps++
                    echo "Step: ${steps} - Install ${dbvdir} database" | tee -a ${logdir}/odb-install-${now}.log
                    if [ "${dbg}" == 'true' ];then set -x;fi
                    $ORACLE_HOME/runInstaller -silent -responseFile "${cfgdir}/odb${dbvdir}.rsp" -waitforcompletion >> ${logdir}/odb-install-${now}.log 2>&1
                    rc=$?
                    if [ ${rc} -ne 0 ];then echo "Error: Review log ${logdir}/odb-install-${now}.log";exit 1;fi

                    if [ -e "${cfgdir}/oraInventory/orainstRoot.sh" ]
                    then
                       sudo -n ${cfgdir}/oraInventory/orainstRoot.sh >> ${logdir}/odb-install-${now}.log 2>&1
                       rc=$?
                       if [ ${rc} -ne 0 ];then echo "Error: Review log ${logdir}/odb-install-${now}.log";exit 1;fi
                    fi

                    sudo -n $ORACLE_HOME/root.sh >> ${logdir}/odb-install-${now}.log 2>&1
                    rc=$?
                    if [ ${rc} -ne 0 ];then echo "Error: Review log ${logdir}/odb-install-${now}.log";exit 1;fi

                    echo ${steps} > ${cfgdir}/.steps.install.db

#                    Oracle 12c use case
#                    sudo -n $ORACLE_HOME/bin/relink all >> ${logdir}/odb-install-${now}.log 2>&1
#                    rc=$?
#                    if [ ${rc} -ne 0 ];then echo "Error: Review log ${logdir}/odb-install-${now}.log";exit 1;fi

                    set +x
                 fi
              ;;
      esac
   fi
   set +x

   # Confirm that DB installed
   if [ -e "$ORACLE_HOME/bin/lsnrctl" ]
   then
      true
   else
      echo "ERROR: DB version ${dbvdir} is not installed"
      echo "   ORACLE_HOME=$ORACLE_HOME"
      echo "   ORACLE_BASE=$ORACLE_BASE"
      echo "   TNS_ADMIN=$TNS_ADMIN"
      exit 1
   fi

   # Apply DB patches
   patch_db
}

###############################################################################
# Stop Oracle Listener
###############################################################################
stop_listener() {
   setOraEnv

   ck4lsnr=$(ps -ef|grep tnslsnr|grep -v grep|awk '{ print $2 }')
   if [ -n "${ck4lsnr}" ]
   then
      let steps++
      echo "Step: ${steps} - Stop Oracle ${dbvdir} database listener" | tee -a ${logdir}/odb-ctl-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/lsnrctl stop >> ${logdir}/odb-ctl-$now.log 2>&1
      rc=$?;set +x
      sleep 2
      ck4lsnr=$(ps -ef|grep tnslsnr|grep -v grep|awk '{ print $2 }')
      if [ -n "${ck4lsnr}" ];then kill -9 ${ck4lsnr};fi
   fi

   echo ${steps} > ${cfgdir}/.steps.stop.db
}

###############################################################################
# Stop Oracle Database
###############################################################################
stop_db() {
   setOraEnv

   if [ -s "$ORACLE_HOME/network/admin/samples/sqlnet.ora" ]
   then
      ck4db=$(ps -ef|grep ora_|grep -v grep|awk '{ print $2 }')
      if [ -n "${ck4db}" ]
      then
         let steps++
         echo "Step: ${steps} - Stop Oracle ${dbvdir} database instance" | tee -a ${logdir}/odb-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         $ORACLE_HOME/bin/sqlplus / as sysdba >> ${logdir}/odb-ctl-${now}.log 2>&1 << EOF
shutdown immediate ;
EOF
         rc=$?;set +x
      fi

      stop_listener
   else
      exit 0
   fi
}

###############################################################################
# Start Oracle Database
###############################################################################
start_db() {
   setOraEnv

   # If database exists, then start it up. Otherwise exit.
   if [ -s "$ORACLE_HOME/network/admin/samples/sqlnet.ora" ]
   then
      ck4lsnr=$(ps -ef|grep tnslsnr|grep -v grep|awk '{ print $2 }')
      if [ -z "${ck4lsnr}" ]
      then
         let steps++
         echo "Step: ${steps} - Start Oracle ${dbvdir} database listener" | tee -a ${logdir}/odb-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         $ORACLE_HOME/bin/lsnrctl start >> ${logdir}/odb-ctl-$now.log 2>&1
         rc=$?;set +x
      fi

      ck4db=$(ps -ef|grep ora_|grep -v grep|awk '{ print $2 }')
      if [ -z "${ck4db}" ]
      then
         let steps++
         echo "Step: ${steps} - Start Oracle ${dbvdir} database instance" | tee -a ${logdir}/odb-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         $ORACLE_HOME/bin/sqlplus / as sysdba >> ${logdir}/odb-ctl-$now.log 2>&1 << EOF
startup;
alter system register;
exit
EOF
         rc=$?;set +x
      fi

      # Start PDB databases
      isCDB='NO'
      n=1
      ### Determine if it's a CDB 
      if [[ ${dbvdir} == 18* ]] || [[ ${dbvdir} == 19* ]] || [[ ${dbvdir} == 21* ]] || [[ ${dbvdir} == 23* ]]
      then
         # Determine whether it's a CDB
         isCDB=$($ORACLE_HOME/bin/sqlplus -S system/${bPW} 2> /dev/null << EOF
SELECT CDB FROM V\$DATABASE;
EOF
)
         PDBLOG="${cfgdir}/.pdbs"
         isCDB=$(echo ${isCDB}| cut -d " " -f3)
         if [ "${isCDB}" == "YES" ]
         then
            let steps++
            echo "Step: ${steps} - Start Oracle ${dbvdir} plugable databases" | tee -a ${logdir}/odb-ctl-${now}.log
            if [ "$dbg" == 'on' ];then echo;set -x;fi
            # Start PDBs
            $ORACLE_HOME/bin/sqlplus / as sysdba > ${PDBLOG} 2>&1 << EOF
alter pluggable database all open;
alter system register;
alter session set container=${pdbName};
exec DBMS_XDB_CONFIG.SETHTTPSPORT(5501);
EOF
            rc=$?;set +x
         fi
      fi

      wait4db

      echo ${steps} > ${cfgdir}/.steps.start.db
   else
      exit 0
   fi
}

###############################################################################
# Start Oracle Database
###############################################################################
show_status() {
   setOraEnv

   let steps++
   echo "###############################################################################"
   echo "Step: ${steps} - Show Listener Status"
   set -x
   $ORACLE_HOME/bin/lsnrctl status
   rc=$?;set +x

   let steps++
   echo "###############################################################################"
   echo "Step: ${steps} - CDB ping"
   set -x
   $ORACLE_HOME/bin/tnsping ${localHost}
   rc=$?
   $ORACLE_HOME/bin/tnsping ${localH}
   rc=$?
   $ORACLE_HOME/bin/tnsping pdb1_${localH}
   rc=$?
   set +x

   let steps++
   echo "###############################################################################"
   echo "Step: ${steps} - CDB status"
   $ORACLE_HOME/bin/sqlplus -S / as sysdba << EOF
set pagesize 0;
COLUMN NAME FORMAT A8;
SELECT INSTANCE_NAME, STATUS, DATABASE_STATUS FROM V\$INSTANCE;
set linesize 200
col HOST_NAME for a25
select instance_name,INSTANCE_ROLE,STATUS,DATABASE_STATUS,host_name,to_char(startup_time,'mm/dd/yyyy HH24:MI:SS') as "StartTime",LOGINS from gv\$instance;
select name,open_mode,database_role,flashback_on,log_mode from v\$database;
EOF

   let steps++
   echo "###############################################################################"
   echo "Step: ${steps} - PDB status"
   $ORACLE_HOME/bin/sqlplus -S / as sysdba 2>&1 << EOF
set pagesize 0;
COLUMN NAME FORMAT A8;
select name,OPEN_MODE from V\$PDBS;
EOF

   let steps++
   echo "###############################################################################"
   echo "Step: ${steps} - Show Oracle database processes"
   set -x
   ps -ef|grep pmon
   set +x
}

###############################################################################
# Delete Oracle Database
###############################################################################
delete_db() {
   setOraEnv
   if [ -e "$ORACLE_HOME/bin/dbca" ]
   then
      let steps++
      echo "Step: ${steps} - Delete database instance" | tee -a ${logdir}/odb-dbca-${now}.log

      # Set Oracle Env variables
      setOraEnv
      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/dbca \
         -silent \
         -deleteDatabase \
         -sourceDB ${dbH} \
         -sysDBAUserName sys \
         -sysDBAPassword "${bPW}" \
         >>  ${logdir}/odb-dbca-rm-$now.log 2>&1
      rc=$?
   fi
}

###############################################################################
# Setup Oracle Database
###############################################################################
setup_db() {
   install_db

   setOraEnv
   if [ -s "$ORACLE_HOME/dbs/spfile$ORACLE_SID.ora" ]
   then
      echo "INFO: Database is already setup"
      exit
   fi

   if [ -e "$ORACLE_HOME/bin/netca" ]
   then
      ck4lsnr=$(ps -ef|grep tnslsnr|grep -v grep|awk '{ print $2 }')
      if [ -z "${ck4lsnr}" ]
      then
         let steps++
         echo "Step: ${steps} - Setup listener" | tee -a ${logdir}/odb-netca-${now}.log

         if [ "${dbg}" == 'true' ];then set -x;fi
         $ORACLE_HOME/bin/netca /orahome "$ORACLE_HOME" /instype typical /inscomp client,oraclenet,javavm,server,ano /insprtcl tcp /cfg local /authadp NO_VALUE /responseFile $ORACLE_HOME/network/install/netca_typ.rsp /lisport ${dbPort} /silent /orahnam ${dbH} >> ${logdir}/odb-netca-${now}.log 2>&1
         rc=$?
      fi
   fi

   if [ -e "$ORACLE_HOME/bin/dbca" ]
   then
      let steps++
      echo "Step: ${steps} - Setup database instance" | tee -a ${logdir}/odb-dbca-${now}.log

      # -emConfiguration DBEXPRESS -emExpressPort 5500

      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/dbca \
         -silent \
         -createDatabase \
         -databaseConfigType SINGLE \
         -emConfiguration NONE \
         -templateName General_Purpose.dbc \
         -characterSet AL32UTF8 \
         -totalMemory 4096 \
         -storageType FS \
         -datafileDestination "$ORACLE_BASE/oradata" \
         -datafileJarLocation "$ORACLE_HOME/assistants/dbca/templates" \
         -sampleSchema FALSE \
         -oratabLocation /etc/oratab  \
         -runCVUChecks false \
         -continueOnNonFatalErrors true \
         -createAsContainerDatabase true \
         -gdbName ${dbH} \
         -sid ${dbH} \
         -initParams filesystemio_options=setall \
         -ignorePrereqs \
         -numberOfPDBs 1 \
         -pdbName ${pdbName} \
         -pdbadminUsername pdbadmin \
         -pdbAdminPassword "${bPW}" \
         -sysPassword "${bPW}" \
         -systemPassword "${bPW}" \
         >>  ${logdir}/odb-dbca-$now.log 2>&1
      rc=$?
   fi
   set +x

   # Make sure that oratab is set to Y
   grep -vi "^$ORACLE_SID:" /etc/oratab > ${cfgdir}/oratab-${now} 2> /dev/null
   cat ${cfgdir}/oratab-${now} | sudo -n tee /etc/oratab > /dev/null
   echo "$ORACLE_SID:$ORACLE_HOME:Y:" | sudo -n tee -a /etc/oratab > /dev/null
   rc=$?

   # Setup listener
   cp $ORACLE_HOME/network/admin/samples/listener.ora $ORACLE_HOME/network/admin
   cat >> $ORACLE_HOME/network/admin/listener.ora <<EOF
LISTENER =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = ${localHost})(PORT = ${dbPort}))
      (ADDRESS = (PROTOCOL = IPC)(KEY = EXTPROC${dbPort}))
    )
  )
EOF

   start_db
}

###############################################################################
# Deinstall DB
###############################################################################
deinstall_db() {
   setOraEnv
   lookupos

   #if [ -x $ORACLE_HOME/bin/dbca ] && [ -d "$ORACLE_BASE/admin/$ORACLE_SID" ]

   if [ -s "$ORACLE_HOME/deinstall/deinstall" ]
   then
#      stop_db
#  
#      let steps++
#      echo "Step: ${steps} - Remove database instance " | tee -a ${logdir}/db-deinstall-${now}.log
#      echo "Remove ${swVer} database content from $h"
#         if [ "${dbg}" == 'true' ];then set -x;fi
#      $ORACLE_HOME/bin/dbca -deleteDatabase -silent -sourceDB  $h > ${logdir}/db-deinstall-$now.log 2>&1
#      rc=$?;set +x
#
#      # Remove DB 
#      if [ -d "$ORACLE_HOME" ]
#      then
#         echo "Deinstall Database product from $h"
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         echo rm -fr "$ORACLE_HOME"
#         rc=$?;set +x
#      fi

      # Deinstall Oracle Database instance
      let steps++
      echo "Step: ${steps} - Deinstall database instance" | tee -a ${logdir}/db-deinstall-${now}.log
#      lookupos
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ ${olv} -eq 8 ];then export CV_ASSUME_DISTID=OL7;fi
      $ORACLE_HOME/deinstall/deinstall -silent -paramfile "${cfgdir}/odb${dbvdir}-deinstall.rsp" > ${logdir}/db-deinstall-$now.log 2>&1
   fi

   # Make sure listener is stopped
   stop_listener

   if [ -n "${dbvdir}" ] && [ -d "${curdir}/db/${dbvdir}" ]
   then
      let steps++
      echo "Step: ${steps} - Deinstall database software" | tee -a ${logdir}/db-deinstall-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      rm -fr ${curdir}/db/${dbvdir} 2> /dev/null
      set +x
   fi

   if [ -e "/etc/oratab" ];then sudo -n rm -f /etc/oratab;fi
   if [ -e "${cfgdir}/.pdbs" ];then rm -f ${cfgdir}/.pdbs;fi
   if [ -e "${cfgdir}/.eusbatch-loaded" ];then rm -f ${cfgdir}/.eusbatch-loaded;fi
   if [ -e "${cfgdir}/.eusrealm-loaded" ];then rm -f ${cfgdir}/.eusrealm-loaded;fi
}

###############################################################################
# Add PDB
###############################################################################
add_pdb() {
   cdbH=$(echo ${dbH}|tr -s '[:lower:]' '[:upper:]')
   pdbH=$(echo ${pdbName}|tr -s '[:lower:]' '[:upper:]')

   # Set Oracle Env variables
   setOraEnv
   
   let steps++
   echo "Step: ${steps} - Add PDB ${pdbName}" | tee -a ${logdir}/pdb-add-${now}.log
   $ORACLE_HOME/bin/sqlplus -S / as sysdba >> ${logdir}/pdb-add-${now}.log 2>&1 << EOF
CREATE PLUGGABLE DATABASE ${pdbName} ADMIN USER admin IDENTIFIED BY "${bPW}" FILE_NAME_CONVERT=('${ORACLE_BASE}/oradata/${cdbH}/pdbseed/','${ORACLE_BASE}/oradata/${cdbH}/${pdbName}/');

ALTER PLUGGABLE DATABASE ${pdbName} OPEN;
EOF
   rc=$?;set +x

   cksuccess=$(grep "Pluggable database created" ${logdir}/pdb-add-${now}.log)
   if [ -n "${cksuccess}" ]
   then
      echo "${cksuccess}"
   else
      ckerror=$(grep "Pluggable database .* already exists" ${logdir}/pdb-add-${now}.log)
      if [ -n "${ckerror}" ]
      then
         echo "ERROR: ${ckerror}"
         exit 1
      fi
   fi

   cat <<EOP
Be sure to add the PDB entry for ${pdbName} to tnsnames.ora:
${pdbName} =
  (DESCRIPTION=
    (ADDRESS=(PROTOCOL = TCP)(HOST = ${localHost})(PORT = ${dbPort}))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = ${pdbName})
    )
  )

EOP
}

###############################################################################
# Delete PDB
###############################################################################
del_pdb() {
   pdbH=$(echo ${pdbName}|tr -s '[:lower:]' '[:upper:]')
   
   # Set Oracle Env variables
   setOraEnv

   let steps++
   echo "Step: ${steps} - Delete PDB ${pdbName}" | tee -a ${logdir}/pdb-del-${now}.log
   $ORACLE_HOME/bin/sqlplus -S / as sysdba >> ${logdir}/pdb-del-${now}.log 2>&1 << EOF
ALTER PLUGGABLE DATABASE ${pdbH} close IMMEDIATE;
DROP PLUGGABLE DATABASE ${pdbH} INCLUDING DATAFILES;
quit;
EOF
   rc=$?;set +x

   cksuccess=$(grep "Pluggable database dropped" ${logdir}/pdb-del-${now}.log)
   if [ -n "${cksuccess}" ]
   then
      echo "${cksuccess}"
   else
      ckerror=$(grep "Pluggable database .* does not exist" ${logdir}/pdb-del-${now}.log)
      if [ -n "${ckerror}" ]
      then
         echo "ERROR: ${ckerror}"
      fi
   fi
}

###############################################################################
# List PDB
###############################################################################
list_pdb() {
   # Set Oracle Env variables
   setOraEnv

   let steps++
   echo "Step: ${steps} - List PDB(s)" | tee -a ${logdir}/pdb-list-${now}.log
   $ORACLE_HOME/bin/sqlplus -S / as sysdba 2>&1 << EOF
SHOW PDBS;
quit;
EOF
   rc=$?;set +x
}

###############################################################################
# Process subcommand
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
case ${subcmd} in
        'extract') extract_software;;
        'install') install_db;;
          'patch') patch_db;;
          'setup') setup_db;;
         'delete') delete_db;;
           'stop') stop_db;;
          'start') start_db;;
      'deinstall') deinstall_db;;
          'mkenv') setOraEnv;;
         'status') show_status;;
         'addpdb') add_pdb;;
         'delpdb') del_pdb;;
        'listpdb') list_pdb;;
                *) showUsage;;
esac
