###############################################################################
# Oracle Unified Directory Proof of Concept README 
#
# This Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended
# to serve as an example for how to install and setup OUD instances in order to
# evaluate OUD features and functionality. The following workflow will 
# introduce the core capabilities using the following default configuration:
#    Suffix: dc=example,dc=com
#    Users: N users with RDN uid=user<N> in ou=People,dc=example,dc=com 
#    Groups: 
# 
# Minum requirements for POC environment:
#    Cores: 4
#    RAM: 16GB
#    Storage: 200GB
# 
# IMPORTANT NOTE: Add -z flag to any script to see what operations are being
#    performed by the script. 
# 
# If installing Applying OUD patch on RedHat/Oracle Linux 7, the fuser command 
# and is installed with: sudo yum install -y psmisc
###############################################################################
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
lookupos
setfmwenv

# Uncomment the following two lines to enable debug mode
set -x

# Uncomment the following to use OUD and FMW 12c
#export fmwVersion='12c'

###############################################################################
# OUD 14c Download Requisite Software:
###############################################################################
#  1. Setup a RedHat/Oracle Linux 8 (or newer) host with at least 30GB of RAM,
#     4 cores, and 200GB of storage
#     IMPORTANT NOTEs:
#       * The unqualified hostname must be 12 characters or less length
#       * sudo is required for this demo environment to setup the host
# 
#  2. Make the requisite directory structure for the POC environment and set 
#     the directory structure to be owned by the runtime user, which is opc 
#     for OCI Linux VMs:
#       $ sudo mkdir -p /u01/bits
#       $ sudo chown -R opc:opc /u01
# 
#  3. Download the requisite ODB 19c, JDK 21 (or 17), OUD 14c, software to 
#     the bits directory (/u01/bits) of the VM
# 
#     Note that ODB is only necessary for EUS, TNS, and JDBC use cases
# 
#     JDK 21 (LTM) or JDK 17
#     3a. Go to the JDK 21 download page at https://www.oracle.com/java/technologies/downloads/#java21
#     3b. Download the x64 Compressed Archive version (jdk-21_linux-x64_bin.tar.gz)
# 
#     ODB and OUD from eDelivery:
#     3c. Login to https://eDelivery.oracle.com
#     3d. Search on "Oracle Database Enterprise Edition"
#     3e. Add "DLP:Oracle Database Enterprise Edition 19.3.0.0.0" to cart
#     3f. Search on "Oracle Fusion Middleware 14c Infrastructure"
#     3g. Add "Oracle Fusion Middleware 14c Infrastructure 14.2.1.0.0" to cart
#     3h. Click on "Continue"
#     3i. Agree to license terms and click "Continue"
#     3j. Click on checkbox next to and select Linux x86-64 platform of the 
#         following and click "Continue"
#           * Oracle Database 19.3.0.0.0 - Long Term Release
#           * Oracle Fusion Middleware Infrastructure 14.1.2.0.0
#     3k. Click on the following two ZIP files to download respective software:
#         + V982063-01.zip - Oracle Database 19.3.0.0.0
#         + V1045135-01.zip - Oracle Fusion Middleware 14c (14.1.2.0.0)
# 
#  4. Download the OUD POC kit from https://securefiles.oracle.com/documents/link/LD4CDF9D04C1FA05EB607A77E2954B1313B769D91242/fileview/DBFA071A9AAABE6811C0BD1E7BC9EF0CF23B9B0A3802/_oudpockit-2025032514.zip
# 
#  5. Download ODB 19c patches and place in /u01/bits
#         https://updates.oracle.com/download/28186730.html (p28186730_139427_Generic.zip)
# 
#  6. Once the above steps are complete, the /u01/bits should contain the following files:
#     * jdk-21_linux-x64_bin.tar.gz
#     * V982063-01.zip
#     * V1045135-01.zip
#     * p28186730_139427_Generic.zip
#     * oudpockit-2025032514.zip
# 
#  7. Extract the OUD POC Kit into the poc directory:
#     $ unzip -d /u01/. /u01/bits/oudpockit-2025032514.zip
# 
###############################################################################

###############################################################################
# Step 1: Extract and install OUD
###############################################################################
cd "${curdir}"
./manage_install.sh install oud ${dbgFlag}

###############################################################################
# Step 2: Setup administrative web service (OUDSM)
#   Note that setup of the OUDSM is not required to setup OUD instances.
###############################################################################
./manage_oudsm.sh setup ${dbgFlag}

###############################################################################
# Step 3: Generate 10,000 user entries
###############################################################################
./manage_data.sh genall -n enterprise -N 10000 ${dbgFlag}

###############################################################################
# Step 4: Setup first OUD instance
###############################################################################
./manage_oud.sh setup --suffix "${suffix}" --batch ${samples}/my.batch --schema ${samples}/my.schema --data ${curdir}/cfg/enterprise.ldif ${dbgFlag}

###############################################################################
# Step 5: Setup second OUD instance
###############################################################################
./manage_oud.sh setup --pnum 2 --suffix "${suffix}" --batch ${samples}/my.batch --schema ${samples}/my.schema --supplier ${localHost}:1444 ${dbgFlag}

# Show replication status of OUD topology
./manage_oud.sh rstatus ${dbgFlag}  # [--advanced] [--disp <view>]

###############################################################################
# Step 6: Setup load balancing proxy
###############################################################################
./manage_proxy.sh setup -n enterprise --suffix "${suffix}" --nodes "${localHost}:1389:1636,${localHost}:2389:2636" ${dbgFlag}

###############################################################################
# Step 7: Demo LDAP Searches
###############################################################################
./demo_search.sh -n enterprise ${dbgFlag}
./demo_search.sh -n enterprise -p 1390 ${dbgFlag}

###############################################################################
# Step 8: Demo REST/SCIM
###############################################################################
./demo_rest.sh -n enterprise ${dbgFlag}
./demo_rest.sh -n enterprise -p 1433 ${dbgFlag}

###############################################################################
# Step 9: Deinstall OUD proxy
###############################################################################
./manage_proxy.sh deinstall

###############################################################################
# Step 10: Demo bulk load CSV data into OUD
###############################################################################
./manage_csv2ldif.sh --overwrite --csvFile ${samples}/test.csv --suffix "ou=People,${suffix}" ${dbgFlag}
./demo_bulkloadldif.sh --nodupcheck -f ${samples}/test.ldif -h ${localHost} -p 1389 -j ${curdir}/cfg/...pw ${dbgFlag}

###############################################################################
# Step 11: Prepare custom schema for OUD
###############################################################################
# Prepare an individual schema file
./demo_prepschema.sh --schema ${samples}/das.schema

# Prepare all schema files in a specific directory
#./demo_prepschema.sh --schemadir ${curdir}/var/ds1/config/schema

# Prepare the schema from a source directory
#./demo_prepschema.sh -h $(hostname -f) -p 2389

###############################################################################
# Step 12: Demonstrate backup/restore/export/import
###############################################################################
./manage_oud.sh backup --backupdir ${tmpdir}/oud${pnum}-${now}
./manage_oud.sh restore --backupdir ${tmpdir}/oud${pnum}-${now}
./manage_oud.sh export --ldiffile ${tmpdir}/oud${pnum}-${now}.ldif
./manage_oud.sh import --ldiffile ${tmpdir}/oud${pnum}-${now}.ldif

###############################################################################
# Step 13: Setup SLAMD for load generation testing
###############################################################################
# Setup SLAMD server, client, and client monitor
./manage_slamd.sh setup slamd

# Create info file based on make-ldif template to inform the load generations
# DIT, user, group, and group membership spans
./manage_slamd.sh mksvcinfo -n enterprise

# Start a performance analysis baseline campaign
./manage_slamd.sh brun --campaign baseline -h $(hostname -f) -p 1389 -C 3

# Check the status of running jobs
./manage_slamd.sh blist

# Wait for a while for some data to be processed
sleep 600

# Generate reports of the completed jobs
./manage_slamd.sh breports

# Display the job results summary for the latest campaign
./manage_slamd.sh bsummary

###############################################################################
# Step 14: Demonstrate ODSEE to OUD migration with OUD Replication Gateway
###############################################################################
# Requisite: If installed on RedHat/Oracle Linux, the following packages
# are required for ODSEE:
if [ "${olv}" == '7' ]
then
   sudo -n yum install -y ksh unzip libzip libzip.i686 libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel compat-db47 compat-libcap1.x86_64 compat-libstdc++-33.x86_64 compat-libstdc++-33.i686 libstdc++.i686 compat-libcap1 compat-libstdc++-33

   # Install OUD and gen data
   ./manage_data.sh genall -n inetorg --rm

   # Setup ODSEE topology
   ./manage_odsee.sh setup --pnum 1 -n inetorg
   ./manage_odsee.sh setup --pnum 2 -n inetorg --supplier $(hostname -f):1393
   ./manage_odsee.sh mod --pnum 1

   # Setup OUD topology
   ./manage_oud.sh setup --pnum 1 -n inetorg 
   ./manage_oud.sh setup --pnum 2 -n inetorg --supplier $(hostname -f):1444:1989

   # Setup replication gateway
   ./manage_replgw.sh setup

   # Initialize OUD from ODSEE data
   ./manage_replgw.sh export
   ./manage_replgw.sh init
   ./manage_replgw.sh rstatus
   ./manage_replgw.sh test

   # Remove replication gateway and ODSEE instances
   ./manage_replgw.sh deinstall
   ./manage_odsee.sh deinstall
fi

###############################################################################
# Step 15: Demonstrate how to setup an OUD instance that emulates AD instance
###############################################################################
# Remove existing OUD instances
./manage_oud.sh deinstall

# Copy make-ldif template and custom schema to config directory
cp ${samples}/ad.* ${cfgdir}

# Generate AD data using the make-ldif template
./manage_data.sh genall -n ad --dnfilter cn=user --rm

# Setup the OUD instance
./manage_oud.sh setup -n ad --nobatch

###############################################################################
# Step 16: Demonstrate how to map uid to samAccountName
###############################################################################
# Setup the OUD instance
./manage_oud.sh deinstall
./manage_oud.sh setup --pnum 1 -n ad --batch ${samples}/map_uid2samaccountname.batch

# Show that uid is returned with value of samAccountName but samAccountName is
# not returned
${oudmwdir}/oud1/OUD/bin/ldapsearch -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(cn=user1)' uid samAccountName
${oudmwdir}/oud1/OUD/bin/ldapsearch -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(uid=user1)' uid samAccountName
${oudmwdir}/oud1/OUD/bin/ldapsearch -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(samAccountName=user1)' uid samAccountName

###############################################################################
# Step 17: Demonstrate how to map uid to samAccountName
###############################################################################
# Setup the OUD instance
./manage_oud.sh deinstall
./manage_oud.sh setup --pnum 1 -n ad --batch ${samples}/map_uid2samaccountname_and_add_samAccountName.batch

# Show that uid and samAccountName are returned where uid has the value of 
# samAccountName
${oudmwdir}/oud1/OUD/bin/ldapsearch -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(cn=user1)' uid samAccountName
${oudmwdir}/oud1/OUD/bin/ldapsearch -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(uid=user1)' uid samAccountName
${oudmwdir}/oud1/OUD/bin/ldapsearch -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(samAccountName=user1)' uid samAccountName

###############################################################################
# Step 18: Demonstrate in place OUD 12cPS4 to OUD 14c upgrade
###############################################################################
${oudmwdir}/demo_oud14c_upgrade.sh existinghome

###############################################################################
# Step 19: Demonstrate swing migration of OUD 12cPS4 to OUD 14c
###############################################################################
${oudmwdir}/demo_oud14c_upgrade.sh swing

###############################################################################
# Supplemental OUD POC Command Refernce:
#
#    Add --pnum <n> to stop/start a specific OUD or OUD Proxy instance.
#
# Stop/Start all OUD directory server instances on local host:
#    ./manage_oud.sh stop
#    ./manage_oud.sh start
#
# Stop/Start OUD directory proxy server instances on local host:
#    ./manage_proxy.sh stop
#    ./manage_proxy.sh start
#
# Stop/Start OUDSM:
#    ./manage_oudsm.sh stop
#    ./manage_oudsm.sh start
#
# Setup all OUD POC Kit services to restart on OS reboot
#    ./manage_init.sh enable
#
# All scripts leverage the common management scripts so that any one script
# can install and patch OUD and setup in consistent manner.
#
###############################################################################

###############################################################################
# Interesting Demonstrations
###############################################################################
# Demonstrate Enterprise User Security
./demo_eus.sh

# Show replication status
./manage_oud.sh rstatus --pnum 10 -z

# Demonstrate database name resolution
./demo_tns.sh

#On all hosts, make sure that requisite ports are open on the local firewall
#and that the network ingress/egress rules permit the same ports be open
#between all OUD/TNS hosts:

sudo firewall-cmd --permanent --zone=public --add-port=10444/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10389/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10636/tcp
sudo firewall-cmd --permanent --zone=public --add-port=10989/tcp
sudo firewall-cmd --reload

# Demonstrate how to expand the EUS or TNS OUD topology by adding 
# additional instances

# On subsequent hosts, run:
#./manage_eus.sh expand --pnum 20 --supplier <first_host_fqdn>:10444:10989

# Or, run the the following to setup a second instance on the first host
./manage_eus.sh expand --pnum 30 --supplier $(hostname -f):10444:10989

# Show that the second OUD instance is in sync with the first OUD
# instance through replication status.
./manage_oud.sh rstatus --pnum 10 -z
