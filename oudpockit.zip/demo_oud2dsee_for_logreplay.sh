#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
accesslog="$1"

if [ -e "${accesslog}" ]
then
   if [ -s "${accesslog}" ]
   then
      true
   else
      echo "ERROR: access log is empty"
      echo "USAGE: ${0} <access_log_file>"
      exit 1
   fi
else
   echo "ERROR: access log does not exist"
   echo "USAGE: ${0} <access_log_file>"
   exit 1
fi

echo "Processing OUD access log: ${accesslog}"
grep -h ' BIND REQ '   ${accesslog} |sed -e "s/ BIND REQ//g"   -e "s/ dn=/ - BIND dn=/g"     -e "s/type=SIMPLE/method=128/g" > ${accesslog}.bind
grep -h ' UNBIND REQ ' ${accesslog} |sed -e "s/ UNBIND REQ//g" -e "s/ dn=/ - UNBIND dn=/g"   -e "s/type=SIMPLE//g"          > ${accesslog}.unbind
grep -h ' SEARCH REQ ' ${accesslog} |sed -e "s/ SEARCH REQ//g" -e "s/ base=/ - SRCH base=/g" -e "s/scope=sub/scope=2/g" -e "s/scope=one/scope=1/g" -e "s/scope=base/scope=0/g" > ${accesslog}.search
grep -h ' MODIFY REQ ' ${accesslog} |sed -e "s/ MODIFY REQ//g" -e "s/ dn=/ - MOD dn=/g"      -e "s/type=synchronization//g" > ${accesslog}.modify
grep -h ' MODRDN REQ ' ${accesslog} |sed -e "s/ MODRDN REQ//g" -e "s/ dn=/ - MODDN dn=/g"    -e "s/type=synchronization//g" > ${accesslog}.modrdn
grep -h ' MODDN REQ '  ${accesslog} |sed -e "s/ MODRDN REQ//g" -e "s/ dn=/ - MODRDN dn=/g"   -e "s/type=synchronization//g" > ${accesslog}.moddn
grep -h ' ADD REQ '    ${accesslog} |sed -e "s/ ADD REQ//g"    -e "s/ dn=/ - ADD dn=/g"      -e "s/type=synchronization//g" > ${accesslog}.add
grep -h ' DELETE REQ ' ${accesslog} |sed -e "s/ DELETE REQ//g" -e "s/ dn=/ - DEL dn=/g"      -e "s/type=synchronization//g" > ${accesslog}.delete

cat ${accesslog}.[mads]* |sort > ${accesslog}-dsee

rm -f ${accesslog}.[mads]*

echo -e "DSEE conforming access log file:\n${accesslog}-dsee"
