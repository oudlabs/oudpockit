#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Documentation references:
#   OL 7/8 systemd service definitions
#   https://www.freedesktop.org/software/systemd/man/systemd.service.html
###############################################################################
###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

findpager
cat << EOF | ${pgcmd}
NAME
     ${cmd} [enable|disable|start|stop|status] [options]

SYNOPSIS
     Start all OUD POC Kit services after reboot.

     Enable OS initialization
        ${cmd} enable

     Disable OS initialization
        ${cmd} disable

     Stop OUD Kit instances
        ${cmd} stop

     Start OUD Kit instances
        ${cmd} start

     Show service status of ODS service
        ${cmd} status

DESCRIPTION
     Sample script for setup restart on OS reboot.

OPTIONS
         -z     Debug mode
EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            step) steps=$1;shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set default variable values
###############################################################################
initLog="${logdir}/init-${now}.log"

###############################################################################
# Enable OS init
###############################################################################
enable_init() {
   lookupos
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ "${me}" == 'root' ]
   then
      let steps++
      echo "Step ${steps} - Add ODS init to host init" | tee -a ${initLog}
      case ${os} in
         'SunOS') if [ -h /etc/init.d/ods   ];then true;else ln -s ${curdir}/${cmd} /etc/init.d/ods;fi
                  if [ -h /etc/rc2.d/S99ods ];then true;ln -s ${curdir}/${cmd} /etc/rc2.d/S99ods;fi
                  if [ -h /etc/rc3.d/S99ods ];then true;ln -s ${curdir}/${cmd} /etc/rc3.d/S99ods;fi
                  if [ -h /etc/rc5.d/S99ods ];then true;ln -s ${curdir}/${cmd} /etc/rc5.d/S99ods;fi
                  if [ -h /etc/rc6.d/S99ods ];then true;ln -s ${curdir}/${cmd} /etc/rc6.d/S99ods;fi
                  if [ -h /etc/rc0.d/K01ods ];then true;ln -s ${curdir}/${cmd} /etc/rc0.d/K01ods;fi
                  if [ -h /etc/rc1.d/K01ods ];then true;ln -s ${curdir}/${cmd} /etc/rc1.d/K01ods;fi
                  if [ -h /etc/rc6.d/K01ods ];then true;ln -s ${curdir}/${cmd} /etc/rc6.d/K01ods;fi
                  ;;
         'Linux') case ${olv} in
                     5) if [ -h /etc/init.d/ods ];then true;else ln -s ${curdir}/${cmd} /etc/init.d/ods; chkconfig --add ods;fi;;
                     6) if [ -h /etc/init.d/ods ];then true;else ln -s ${curdir}/${cmd} /etc/init.d/ods; chkconfig --add ods;fi;;
                   7|8|9) if [ "${dbg}" == 'true' ];then set -x;fi
                        # If OL7 or OL8 or OL9 setup 
                        # Create systemd service config
                        if [ -e '/usr/lib/systemd/system/ods.service' ] && [ -h '/etc/systemd/system/multi-user.target.wants/ods.service' ]
                        then
                           true
                        else
                           if [ "${dbg}" == 'true' ];then set -x;fi

                           # Add to multi-user.target (e.g. init run level 3)
                           cp ${cfgdir}/ods.service /usr/lib/systemd/system >> ${initLog} 2>&1
                           rc=$?
                           #ln -s /usr/lib/systemd/system/ods.service /usr/lib/systemd/system/ods.service >> ${initLog} 2>&1
                           #rc=$?
                           ln -s /usr/lib/systemd/system/ods.service /etc/systemd/system/multi-user.target.wants/ods.service >> ${initLog} 2>&1
                           rc=$?

                           # Add manage_init.sh and dependent scripts to the SELinux policy
                           sudo semanage fcontext -a -t bin_t "${curdir}(/.*)?" >> ${initLog} 2>&1
                           rc=$?

                           sudo /sbin/restorecon -R -v ${curdir} >> ${initLog} 2>&1
                           rc=$?

                           # Reload service config
                           /usr/bin/sudo -n systemctl daemon-reload >> ${initLog} 2>&1
                           rc=$?

                           # Enable service config
                           /usr/bin/sudo -n systemctl enable ods.service >> ${initLog} 2>&1
                           rc=$?
                           /usr/bin/sudo -n systemctl daemon-reload >> ${initLog} 2>&1
                           rc=$?

                           # Start
                           /usr/bin/sudo -n systemctl start ods.service >> ${initLog} 2>&1
                           rc=$?

                        fi
                        ;;
                  esac
                  ;;
      esac
   else
      # Create service definition
      cat > ${cfgdir}/ods.service <<EOF
[Unit]
Description=ODS Services
After=local-fs-pre.target network.target syslog.target
ConditionDirectoryNotEmpty=|${cfgdir}

[Service]
Type=forking
User=${me}
Group=${myg}
WorkingDirectory=${curdir}
ExecStart=${curdir}/${cmd} start
TimeoutStartSec=300
ExecStop=${curdir}/${cmd} stop
TimeoutStopSec=300
SuccessExitStatus=0 143
Restart=no

[Install]
WantedBy=multi-user.target
EOF
      sudo -n ${curdir}/${cmd} enable --step ${steps} ${dbgFlag}
      rc=$?
   fi
   set +x
}

###############################################################################
# Disable OS init
###############################################################################
disable_init() {
   lookupos
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ "${me}" == 'root' ]
   then
      let steps++
      echo "Step ${steps} - Remove ODS init from host init" | tee -a ${initLog}
      case $os in
         'SunOS') if [ -h /etc/init.d/ods   ];then rm -f /etc/init.d/ods;fi
                  if [ -h /etc/rc2.d/S99ods ];then rm -f /etc/rc2.d/S99ods;fi
                  if [ -h /etc/rc3.d/S99ods ];then rm -f /etc/rc3.d/S99ods;fi
                  if [ -h /etc/rc5.d/S99ods ];then rm -f /etc/rc5.d/S99ods;fi
                  if [ -h /etc/rc6.d/S99ods ];then rm -f /etc/rc6.d/S99ods;fi
                  if [ -h /etc/rc0.d/K01ods ];then rm -f /etc/rc0.d/K01ods;fi
                  if [ -h /etc/rc1.d/K01ods ];then rm -f /etc/rc1.d/K01ods;fi
                  if [ -h /etc/rc6.d/K01ods ];then rm -f /etc/rc6.d/K01ods;fi
                  ;;
         'Linux') case ${olv} in
                     5) if [ -h /etc/init.d/ods ];then chkconfig --del ods;rm -f /etc/init.d/ods;fi;;
                     6) if [ -h /etc/init.d/ods ];then chkconfig --del ods;rm -f /etc/init.d/ods;fi;;
                   7|8|9) # If OL7 or OL8 setup 
                        # Stop, Disable and remove
                        /usr/bin/sudo -n systemctl stop ods.service >> ${initLog} 2>&1
                        rc=$?

                        /usr/bin/sudo -n systemctl disable ods.service >> ${initLog} 2>&1
                        rc=$?

                        rm -f /etc/systemd/system/multi-user.target.wants/ods.service /usr/lib/systemd/system/ods.service >> ${initLog} 2>&1
                        rc=$?

                        # Reload service config
                        /usr/bin/sudo -n systemctl daemon-reload >> ${initLog} 2>&1
                        rc=$?
                        ;;
                  esac
                  ;;
      esac
   else
      if [ -z "${steps}" ];then steps=0;fi
      sudo -n ${curdir}/${cmd} disable --step ${steps} ${dbgFlag}
      rc=$?
      let steps++
   fi
   set +x
}

###############################################################################
# Start OUD Kit instances
###############################################################################
start_init() {
   ${curdir}/manage_db.sh start
   ${curdir}/manage_oud.sh start
   ${curdir}/manage_proxy.sh start
   ${curdir}/manage_oudsm.sh start

   #${curdir}/manage_oid.sh start
   #${curdir}/manage_oidsm.sh start

   exit 0
}

###############################################################################
# Stop OUD Kit instances
###############################################################################
stop_init() {
   ${curdir}/manage_oudsm.sh stop
   ${curdir}/manage_db.sh stop
   ${curdir}/manage_proxy.sh stop
   ${curdir}/manage_oud.sh stop

   #${curdir}/manage_oidsm.sh stop
   #${curdir}/manage_oid.sh stop

   exit 0
}

###############################################################################
# Show ODS status
###############################################################################
show_status() {
   lookupos
   if [ "${dbg}" == 'true' ];then set -x;fi
   let steps++
   echo "Step ${steps} - Show ODS services status" | tee -a ${initLog}
   case ${os} in
      'SunOS') true;;
      'Linux') case ${olv} in
                  5) true;;
                  6) true;;
                7|8|9) systemctl status ods.service;;
               esac
   esac
}

###############################################################################
# Run subcommand
###############################################################################
case ${subcmd} in
    'enable') enable_init;;
   'disable') disable_init;;
     'start') start_init;;
      'stop') stop_init;;
    'status') show_status;;
           *) showUsage;;
esac
