#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            suffix) suffix="$1";shift;;
            domain) domain="$1";shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            n) templateName="$1";shift;;
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
            N) numDBs=$1;shift;;
        esac;;
    esac
done

###############################################################################
# Set default variables
###############################################################################
if [ -z "${templateName}" ];then templateName="inetorg";fi
steps=0

###############################################################################
# Confirm presence of requisite files
###############################################################################
if [ "${templateName}" != 'inetorg' ]
then
   if [ -e "${cfgdir}/${templateName}.schema" ] 
   then
      true
   else
      echo "ERROR: The custom schema file does not exist:"
      echo "   ${cfgdir}/${templateName}.schema"
      echo "   You may can generate with for inetorg template name:"
      echo "   ${curdir}/manage_data.sh genall -n ${templateName} -N 100000 --rm"
      exit 1
   fi
fi

if [ -e "${cfgdir}/${templateName}.ldif" ]
then
   true
else
   echo "ERROR: The custom schema file does not exist:"
   echo "   ${cfgdir}/${templateName}.ldif"
   echo "   You may can generate with for inetorg template name:"
   echo "   ${curdir}/manage_data.sh genall -n ${templateName} -N 100000 --rm"
   exit 1
fi

###############################################################################
# Check requisites
###############################################################################
ck4pkgs=$(rpm -q ksh unzip libzip libzip.i686 libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel compat-db47 compat-libcap1.x86_64 compat-libstdc++-33.x86_64 compat-libstdc++-33.i686 libstdc++.i686 compat-libcap1 compat-libstdc++-33|grep "not installed")

if [ -n "${ck4pkgs}" ]
then
   echo "ERROR: Make sure that that all of the following requisite packagesare installed"
   echo "   ksh unzip libzip libzip.i686 libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel compat-db47 compat-libcap1.x86_64 compat-libstdc++-33.x86_64 compat-libstdc++-33.i686 libstdc++.i686 compat-libcap1 compat-libstdc++-33"
   exit 1
fi

# Optional packages
# rsync snapper psmisc net-tools lsof xauth libXrender libXtst perl-CPAN  perl-JSON-PP krb5-server krb5-server-ldap krb5-workstation 

###############################################################################
# Check to see if alredy setup
###############################################################################
if [ -d "${curdir}/dsee7/var/ds1" ]
then
   echo "ERROR: ODSEE instance already setup"
   exit 1
fi

###############################################################################
# Extract and install ODSEE software
###############################################################################
if [ -e "${curdir}/dsee7/bin/dsadm" ]
then
   true
else
   if [ -e "{swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Extract ODSEE 11g (V35071-01.zip)"
      mkdir -p "${swdir}/odsee" 2> /dev/null
      cd "${swdir}/odsee"
      unzip -oq "${bitsdir}/V35071-01.zip"
      rc=$?
      if [ "${rc}" != 0 ]
      then
         echo "ERROR: Extraction of V35071-01.zip failed"
         exit 1
      fi
   fi

   if [ -e "${swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip" ]
   then
      let steps++
      echo "Step: ${steps} - Install ODSEE 11g"
      cd ${curdir}
      unzip -oq "${swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip"
      rc=$?
      if [ "${rc}" != 0 ]
      then
         echo "ERROR: Extraction of sun-dsee7.zip failed"
         exit 1
      fi
   fi
fi

###############################################################################
# Extract and install ODSEE patches
###############################################################################
cd "${bitsdir}"
patches=$(ls -1 p*_111170_Linux-x86-64.zip 2> /dev/null|sed -e "s/^p//g" -e "s/_111170_Linux-x86-64.zip//g")
for patch in ${patches}
do
   # Extract patch
   if [ -d "${swdir}/odsee/${patch}" ]
   then
      true
   else
      mkdir -p "${swdir}/odsee/${patch}" 2> /dev/null
      cd "${swdir}/odsee/${patch}"
      unzip -oq "${bitsdir}/p${patch}_111170_Linux-x86-64.zip"
      rc=$?
      tar -zxf dsee*.tar.gz 2> /dev/null
      rc=$?
   fi

   # Install patch
   if [ -e "${curdir}/dsee7/patch.${patch}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Install patch ${patch}"
      unzip -oq "${swdir}/odsee/${patch}/sun-dsee7.zip"
      rc=$?
      if [ "${rc}" == 0 ]
      then
         touch "${curdir}/dsee7/patch.${patch}"
      else
         echo "ERROR: Failed to install patch ${patch}"
         exit 1
      fi
   fi
done

###############################################################################
# Setup first DSEE instance
###############################################################################
let steps++
echo "Step: ${steps} - Create ODSEE instance (ds1)"
${curdir}/dsee7/bin/dsadm create -w "${jPW}" -p 1393 -P 1640 ${curdir}/dsee7/var/ds1 >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?
let steps++
echo "Step: ${steps} - Start ODSEE instance (ds1)"
${curdir}/dsee7/bin/dsadm start ${curdir}/dsee7/var/ds1 >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?

# Configure DSEE
#${curdir}/dsee7/bin/dsconf set-server-prop -i -e -c -w "${jPW}" -h ${localHost} -p 1393 ssl-rsa-cert-name:dsee-cert >> ${logdir}/ds1-setup-${now}.log 2>&1
#rc=$?

let steps++
echo "Step: ${steps} - Create suffix on (ds1)"
${curdir}/dsee7/bin/dsconf create-suffix -i -e -c -w "${jPW}" -h ${localHost} -p 1393 ${suffix} >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?

let steps++
echo "Step: ${steps} - Enable replication on (ds1)"
${curdir}/dsee7/bin/dsconf enable-repl -i -e -c -w "${jPW}" -h ${localHost} -p 1393 --repl-id 100 master "${suffix}" >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?
${curdir}/dsee7/bin/dsconf set-server-prop -i -e -c -w "${jPW}" -h ${localHost} -p 1393 def-repl-manager-pwd-file:"${jPW}" >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?

# Load custom schema (eus:1393)                                         
if [ "${templateName}" != 'inetorg' ]
then
   let steps++
   echo "Step: ${steps} - Load custom schema on (ds1)"
   ${oudmwdir}/oud/bin/ldapmodify -h ${localHost} -p 1393 -D 'cn=Directory Manager' -j "${jPW}" -ac -f ${cfgdir}/${templateName}.schema >> ${logdir}/ds1-setup-${now}.log 2>&1
   rc=$?
fi

# Restart ODSEE DS instance (eus:1393)                                  
let steps++
echo "Step: ${steps} - Restart ODSEE on (ds1)"
${curdir}/dsee7/bin/dsadm stop ${curdir}/dsee7/var/ds1 >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?
${curdir}/dsee7/bin/dsadm start ${curdir}/dsee7/var/ds1 >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?

# Import data into first DSEE instance
let steps++
echo "Step: ${steps} - Import data into (ds1)"
${curdir}/dsee7/bin/dsconf import -i -e -c -w "${jPW}" -h ${localHost} -p 1393 -i ${cfgdir}/${templateName}.ldif "${suffix}" >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?

###############################################################################
# Setup second DSEE instance
###############################################################################
let steps++
echo "Step: ${steps} - Create ODSEE instance (ds1)"
${curdir}/dsee7/bin/dsadm create -w "${jPW}" -p 2393 -P 2640 ${curdir}/dsee7/var/ds2 >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?
let steps++
echo "Step: ${steps} - Start ODSEE instance (ds1)"
${curdir}/dsee7/bin/dsadm start ${curdir}/dsee7/var/ds2 >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?
# Configure DSEE
#${curdir}/dsee7/bin/dsconf set-server-prop -i -e -c -w "${jPW}" -h ${localHost} -p 2393 ssl-rsa-cert-name:dsee-cert >> ${logdir}/ds2-setup-${now}.log 2>&1
#rc=$?

let steps++
echo "Step: ${steps} - Create suffix on (ds1)"
${curdir}/dsee7/bin/dsconf create-suffix -i -e -c -w "${jPW}" -h ${localHost} -p 2393 ${suffix} >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?

let steps++
echo "Step: ${steps} - Enable replication on (ds1)"
${curdir}/dsee7/bin/dsconf enable-repl -i -e -c -w "${jPW}" -h ${localHost} -p 2393 --repl-id 200 master "${suffix}" >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?
${curdir}/dsee7/bin/dsconf set-server-prop -i -e -c -w "${jPW}" -h ${localHost} -p 2393 def-repl-manager-pwd-file:"${jPW}" >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?

let steps++
echo "Step: ${steps} - Load custom schema on ds1)"
# Load custom schema (eus:2393)                                         
${oudmwdir}/oud/bin/ldapmodify -h ${localHost} -p 2393 -D 'cn=Directory Manager' -j "${jPW}" -ac -f ${curdir}/samples/enterprise.schema >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?

# Restart ODSEE DS instance
let steps++
echo "Step: ${steps} - Restart ODSEE on (ds2)"
${curdir}/dsee7/bin/dsadm stop ${curdir}/dsee7/var/ds2 >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?
${curdir}/dsee7/bin/dsadm start ${curdir}/dsee7/var/ds2 >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?

# Setup replication agreements
let steps++
echo "Step: ${steps} - Setup replication agreements between ds1 and ds2"
${curdir}/dsee7/bin/dsconf create-repl-agmt -i -e -c -w "${jPW}" -h "${localHost}" -p 1393 "${suffix}" ${localHost}:2393 >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?
${curdir}/dsee7/bin/dsconf accord-repl-agmt -i -e -c -w "${jPW}" -h "${localHost}" -p 1393 "${suffix}" ${localHost}:2393 >> ${logdir}/ds1-setup-${now}.log 2>&1

rc=$?
${curdir}/dsee7/bin/dsconf create-repl-agmt -i -e -c -w "${jPW}" -h "${localHost}" -p 2393 "${suffix}" ${localHost}:1393 >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?
${curdir}/dsee7/bin/dsconf accord-repl-agmt -i -e -c -w "${jPW}" -h "${localHost}" -p 2393 "${suffix}" ${localHost}:1393 >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?

let steps++
echo "Step: ${steps} - Initialize ds2 from ds1"
${curdir}/dsee7/bin/dsconf init-repl-dest -i -e -c -w "${jPW}" -h "${localHost}" -p 1393 "${suffix}" ${localHost}:2393 >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?

# Ensure that PWP is at DS6 compat mode
let steps++
echo "Step: ${steps} - Set password policy to DS6-mode"
${curdir}/dsee7/bin/dsconf pwd-compat -i -e -c -w "${jPW}" -h "${localHost}" -p 1393 to-DS6-migration-mode >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?

${curdir}/dsee7/bin/dsconf pwd-compat -i -e -c -w "${jPW}" -h "${localHost}" -p 1393 to-DS6-mode >> ${logdir}/ds1-setup-${now}.log 2>&1
rc=$?

${curdir}/dsee7/bin/dsconf pwd-compat -i -e -c -w "${jPW}" -h "${localHost}" -p 2393 to-DS6-migration-mode >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?

${curdir}/dsee7/bin/dsconf pwd-compat -i -e -c -w "${jPW}" -h "${localHost}" -p 2393 to-DS6-mode >> ${logdir}/ds2-setup-${now}.log 2>&1
rc=$?

export INSTANCE_NAME=replgw1
#${oudmwdir}/oud/oud-replication-gateway-setup --cli --hostName "${localHost}" --adminConnectorPort 1446 --replicationPortForLegacy 1368 --useJavaKeystore ${cfgdir}/"${localHost}"/keystore --gatewayKeyStorePasswordFile ${cfgdir}/"${localHost}"/keystore.pin --gatewayCertNickname server-cert --secureReplicationLegacy --clientAuthenticationToLegacy --rootUserDN 'cn=Directory Manager' --rootUserPasswordFile "${jPW}" --baseDN "${suffix}" --hostNameLegacy "${localHost}" --portLegacy 1640 --bindDNLegacy 'cn=Directory Manager' --bindPasswordFileLegacy "${jPW}" --hostNameNg "${localHost}" --portNg ${adminPort} --bindDNNg 'cn=Directory Manager' --bindPasswordFileNg "${jPW}" --replicationPortNg ${replPort} --adminUID admin --adminPasswordFile "${jPW}" --trustAll --no-prompt --doNotMonitorUsingDsccLegacy --noPropertiesFile

# Setup replication gateway
set -x
${oudmwdir}/oud/oud-replication-gateway-setup --cli --hostName "${localHost}" --adminConnectorPort 1446 --replicationPortForLegacy 1368 --generateSelfSignedCertificate --gatewayCertNickname server-cert --clientAuthenticationToLegacy --secureReplicationLegacy --skipPortCheck --rootUserDN 'cn=Directory Manager' --rootUserPasswordFile "${jPW}" --baseDN "${suffix}" --hostNameLegacy "${localHost}" --portLegacy 1640 --bindDNLegacy 'cn=Directory Manager' --bindPasswordFileLegacy "${jPW}" --hostNameNg "${localHost}" --portNg ${adminPort} --bindDNNg 'cn=Directory Manager' --bindPasswordFileNg "${jPW}" --replicationPortNg ${replPort} --adminUID admin --adminPasswordFile "${jPW}" --trustAll --no-prompt --doNotMonitorUsingDsccLegacy --noPropertiesFile
rc=$?

# Export data in opends format
rm -f "${cfgdir}/dseeout.ldif" 2> /dev/null
${curdir}/dsee7/bin/dsconf export -f opends-export -i -e -c -h "${localHost}" -p 1393 -D 'cn=Directory Manager' -w "${jPW}" "${suffix}" ${cfgdir}/dseeout.ldif
rc=$?

# Pre-process LDIF before importing into OUD
# Pre-initialize directory
${oudmwdir}/oud/bin/dsreplication pre-external-initialization --hostName "${localHost}" --port ${adminPort} --adminUID admin --adminPasswordFile "${jPW}" --baseDN "${suffix}" --trustAll --no-prompt --noPropertiesFile
rc=$?

# Import data
${oudmwdir}/oud/bin/import-ldif --hostname "${localHost}" --port ${adminPort} --bindDN 'cn=admin,cn=Administrators,cn=admin data' --bindPasswordFile "${jPW}" --includeBranch "${suffix}" --ldifFile ${cfgdir}/dseeout.ldif --clearBackend --trustAll --noPropertiesFile --skipFile ${logdir}/replgw1-import-skipfile.log --rejectFile ${logdir}/replgw1-import-rejectfile.log
rc=$?

# Post-initialize directory
${oudmwdir}/oud/bin/dsreplication post-external-initialization --hostName "${localHost}" --port ${adminPort} --adminUID admin --adminPasswordFile "${jPW}" --baseDN "${suffix}" --trustAll --no-prompt --noPropertiesFile
rc=$?


# Initialize other directory server instances from first OUD instance
${oudmwdir}/oud/bin/dsreplication initialize --hostSource "${localHost}" --portSource ${adminPort} --hostDestination "${localHost}" --portDestination 2444 --baseDN "${suffix}" --adminUID admin --adminPasswordFile "${jPW}" --no-Prompt -X
rc=$?
