#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
firstUser=$(head -1 "${cfgdir}/inetorg.dn")
firstUserRDN=$(head -1 "${cfgdir}/inetorg.rdn")
firstAdmin="uid=admin1,ou=Admins,${suffix}"
secondAdmin="uid=admin1,ou=Admins,${suffix}"
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show user via REST"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
   curl -sk "https://${firstUser}:${bPW}@${localHost}:${restPort}/rest/v1/directory/${firstUser}?&scope=base&filter=objectClass=inetOrgPerson&attributes=dn"|python -mjson.tool
   rc=$?
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show the corresponding access log entry"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
grep " BIND " ${oudmwdir}/oud1/OUD/logs/access|tail -2

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Disable user via REST"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="

cat > /tmp/payload <<EOF
{
  "msgType": "urn:ietf:params:rest:schemas:oracle:oud:1.0:ModifyRequest",
  "operations":
  [
    {
      "opType": "replace",
      "attribute": "ds-pwp-account-disabled",
      "values": ["true"]
    }
  ]
}
EOF

set -x
curl -sk -X PATCH -H 'Content-type:application/json' -d "@/tmp/payload" "https://${bDN}:${bPW}@${localHost}:${restPort}/rest/v1/directory/${firstUser}"|python -mjson.tool
rc=$?
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show disabled user via REST"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
   curl -sk "https://${firstUser}:${bPW}@${localHost}:${restPort}/rest/v1/directory/${firstUser}?&scope=base&filter=objectClass=inetOrgPerson&attributes=dn"
   rc=$?
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show the corresponding access log entry"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
grep " BIND " ${oudmwdir}/oud1/OUD/logs/access|tail -2

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show disabled user via LDAP search"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
${oudmwdir}/oud/bin/ldapsearch -h ${localHost} -Z -X -p ${ldapsPort} -D "${firstUser}" -j "${jPW}" -b "${firstUser}" -s sub 'objectClass=inetorgperson' dn
rc=$?
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show the corresponding access log entry"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
grep " BIND " ${oudmwdir}/oud1/OUD/logs/access|tail -2

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Enable user via LDAP search"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
cat > /tmp/payload <<EOF
{
  "msgType": "urn:ietf:params:rest:schemas:oracle:oud:1.0:ModifyRequest",
  "operations":
  [
    {
      "opType": "replace",
      "attribute": "ds-pwp-account-disabled",
      "values": ["false"]
    }
  ]
}
EOF

   curl -sk -X PATCH -H 'Content-type:application/json' -d "@/tmp/payload" "https://${bDN}:${bPW}@${localHost}:${restPort}/rest/v1/directory/${firstUser}"|python -mjson.tool
   rc=$?


echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show user via LDAP search"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
   curl -sk "https://${firstUser}:${bPW}@${localHost}:${restPort}/rest/v1/directory/${firstUser}?&scope=base&filter=objectClass=inetOrgPerson&attributes=dn"|python -mjson.tool
   rc=$?
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show the corresponding access log entry"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
grep " BIND " ${oudmwdir}/oud1/OUD/logs/access|tail -2

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show successful bind via ldapsearch"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
${lsrch} -h ${localHost} -Z -X -p ${ldapsPort} -D "${firstAdmin}" -j ${jPW} -b ${suffix} -s sub ${firstUserRDN} dn
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show the corresponding access log entry"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
grep " BIND " ${oudmwdir}/oud1/OUD/logs/access|tail -2

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Set ${firstUserRDN} ds-pwp-account-disabled to true via ldapmodify"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
${lmod} -h ${localHost} -Z -X -p ${ldapsPort} -D "${firstAdmin}" -j ${jPW} <<EOF
dn: ${firstUser}
changeType: modify
replace: ds-pwp-account-disabled
ds-pwp-account-disabled: true 
EOF
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show successful bind via ldapsearch"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
${lsrch} -h ${localHost} -Z -X -p ${ldapsPort} -D "${firstAdmin}" -j ${jPW} -b ${suffix} -s sub ${firstUserRDN} dn
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show the corresponding access log entry"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
grep " BIND " ${oudmwdir}/oud1/OUD/logs/access|tail -2

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Set ${firstUserRDN} ds-pwp-account-disabled to false via ldapmodify"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
${lmod} -h ${localHost} -Z -X -p ${ldapsPort} -D "${firstAdmin}" -j ${jPW} <<EOF
dn: ${firstUser}
changeType: modify
replace: ds-pwp-account-disabled
ds-pwp-account-disabled: false 
EOF
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show successful bind via ldapsearch"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
set -x
${lsrch} -h ${localHost} -Z -X -p ${ldapsPort} -D "${firstAdmin}" -j ${jPW} -b ${suffix} -s sub ${firstUserRDN} dn
set +x

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= Show the corresponding access log entry"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
grep " BIND " ${oudmwdir}/oud1/OUD/logs/access|tail -2
