#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
cmdArg2=$2
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Range globbing specification at https://docs.ldap.com/ldap-sdk/docs/javadoc/index.html?com/unboundid/util/ValuePattern.html
###############################################################################
srate="${curdir}/slamd/tools/searchrate.sh"
arate="${curdir}/slamd/tools/authrate.sh"
mrate="${curdir}/slamd/tools/modrate.sh"
addrate="${curdir}/slamd/tools/addrate.sh"

##############################################################################
# Show usage
##############################################################################
showUsage() {

   findpager
cat << EOF | ${pgcmd}
Demo SLAMD

The ${cmd} script simplifies use of SLAMD job management and and running *rate
commands for standardized load generation campaigns.

SYNOPSIS
      ${cmd} <command> [Options]

GLOBAL OPTIONS
   -z                          Debug mode

   -n or --template <name>     Template name

   -t or --templateFile <file> Template file including path

   -h or --host "<host>"       Directory server host

   -p or --port "<port>"       Directory server port

   -Z or --ssl                 Use SSL/TLS when connecting

   -S or --suffix "<suffix>"   Directory server base suffix

   -s or --schema "<file>"     Schema file

COMANDS

   =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
   =-= Commands to benchmark ODS+ instances with SLAMD
   =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

      setup [type]             Setup SLAMD according to the following types:

                               slamd - Server, Client, and Monitor
                               slamdsvr - Server
                               slamdcli - Client
                               slamdmon - Client Monitor

      deinstall [type]         Setup SLAMD according to the following types:

                               slamd - Server, Client, and Monitor
                               slamdsvr - Server
                               slamdcli - Client
                               slamdmon - Client Monitor

      start [type]             Start SLAMD according to the following types:

                               slamd - Server, Client, and Monitor
                               slamdsvr - Server
                               slamdcli - Client
                               slamdmon - Client Monitor

      stop [type]              Stop SLAMD according to the following types:

                               slamd - Server, Client, and Monitor
                               slamdsvr - Server
                               slamdcli - Client
                               slamdmon - Client Monitor

      brun [--campaign <name>] Run a benchmark campaign (Default: baseline)
                               Campaings:
                                  baseline - baseline performance profile
                                  ssl - baseline ssl performance profile
                                  scaling - cores performance profile
                                  kpi - Key performance indicators
                                  searchrate - Searchrate returning all attributes
                                  searchrate5 - Searchrate returning 5 attributes
                                  searchrateo - Searchrate returning operational attributes
                                  searchratem - Searchrate returning isMemberOf
                                  searchratemy - Searchrate returning my groups
                                  searchratemem - Searchrate determining group membership
                                  authrate - Authrate returning all attributes
                                  authrate5 - Authrate returning 5 attributes
                                  authrateo - Authrate returning operational attributes
                                  modrateu - Modrate of unindexed attribute (description)
                                  modrate1i - Modrate of attribute (givenName) with one index
                                  modrate2i - Modrate of attribute (cn) with two indexes
                                  adddel - AddDelete rate
                                  srcmod - SearchMod rate
                                  mix1 - MixedLoad with 70 10 10 5 5 
                                  mix2 - MixedLoad with 80 0 20 0 0 
                                  playback - Replay all operations from access log file
                                    [ --log </<path>/access_log_file> ]
                                    Default Log File: ${cfgdir}/access
                                  playbackread - Replay all read-oriented operations from access log file
                                    [ --log </<path>/access_log_file> ]
                                    Default Log File: ${cfgdir}/access
                                  playbackwrite - Replay all read-oriented operations from access log file
                                    [ --log </<path>/access_log_file> ]
                                    Default Log File: ${cfgdir}/access

      blist                    List all running and pending jobs

      bcancel                  Cancel all running and pending jobs

      breports                 Generate PDF and txt reports

      bsummary [-a <option>]   Summarize reports where options include:
                                  last - (Default) Summarize campaign results
                                         for the most recent campaign.
                                  list - List available campaigns
                                  all  - Summarize campaign results for all 
                                         campaigns
                                  <campaign> - Summarize campaign results for
                                         a specific campaign.
       bruniaas -C 10 --cli 1 --dr 2 -n enterprise -N 1000000 --arch amd --cores 4 --mem 63 --ad uYkY:US-ASHBURN-AD-1 --subnet ocid1.subnet.oc1.iad.aaaaaaaa2bxrcm4bv2ppb64kmwizdru6m5ft3l6ouyoh3x2irpgkl54ajkzq --compartment ocid1.compartment.oc1..aaaaaaaaxky7uzkyj4ws7yrdauqlagbewaelkrv5mozqzbl6xhp5zpnklypa

       benchtns [<options>]    Benchmark TNS data
                               Options: 
                                  -T <threads> 
                                  -p <port> 
                                  -M <rate> 
                                  -N <num_dbs> 
                                  --suffix "<suffix>"

   SLAMD Benchmark Command Options:

   --slamdHost <host>          - SLAMD host (Default: ${slamdHost}
   --slamdPort <port>          - SLAMD port (Default: ${slamdPort}
   --jobDesc "<description>"   - SLAMD job description (Default: <OSVersion>)
                                 Note: No spaces or special characters in
                                 description.
   --jobDuration <N>           - SLAMD job duration (Default: 10 minutes)
   --interval <N>              - SLAMD benchmark job stat interval
                                 Defualt stat interval: 10 seconds

   =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
   =-= Commands to demonstrate BASIC searchrate/authrate/modrate performance:
   =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

      Options for all *rate commands:
         -p <port>             - Port of target directory server 
                                 Default: port of first instance

         --ssl                 - Use TLSv1.2 connection to specified port

         -C <clients>          - Number of clients
                                 Default: 10

         -T <threads>          - Number of threads per client
                                 Default: 1

         -m <modulateOps>      - Throttle throughput to m ops per second
                                 Default: 10

         -A "<a1> <a2> ..."    - Attributes to return
                                 Default: * (all attributes)

         -D "<bindDN>"         - Bind DN
                                 Default: First user from data

         -w "<bindPW>"         - Bind password
                                 Default: $bPW

      searchrate [opts]        - Presence search rate

      bsearchrate [opts]       - Base suffix search rate

      addrate [opts]           - Add rate

      delrate [opts]           - Delete rate

      gsearchrate [opts]       - Group search rate

      glsearchrate [opts]      - List available groups

       isearchrate [opts]      - List members of a group using isMemberOf

      ulsearchrate [opts]      - List members of a group without using isMemberOf

      authrate [opts]          - Demonstrate authentication rate where

      modrate [opts]           - Demonstrate modification rate where
                                  Note that schema must support description 
                                  attr because description is what modrate 
                                  modifies.

EXAMPLES

   bruniaas \
      -C 10 \
      --cli 1 \
      --dr 2 \
      -n enterprise \
      -N 1000000 \
      --arch amd \
      --cores 4 \
      --mem 63 \
      --ad uYkY:US-ASHBURN-AD-1 \
      --subnet ocid1.subnet.oc1.iad.aaaaaaaa2bxrcm4bv2ppb64kmwizdru6m5ft3l6ouyoh3x2irpgkl54ajkzq \
      --compartment ocid1.compartment.oc1..aaaaaaaaxky7uzkyj4ws7yrdauqlagbewaelkrv5mozqzbl6xhp5zpnklypa

EOF

   exit 0
}

##############################################################################
# Report the status of SLAMD
##############################################################################
statusSlamdServer() {
   if [ -d "${curdir}/slamd" ] && [ -e "${curdir}/slamd/conf/server.xml" ] && [ -e "${cfgdir}/.slamd-server" ]
   then
      ck4svr=$(ps -ef 2> /dev/null | grep "slamd\/conf"|grep -v grep)
      ck4svrucb=$(ps auxww 2> /dev/null| grep "slamd\/conf"|grep -v grep)
      if [ -n "${ck4svr}" ] || [ -n "${ck4svrucb}" ];then ck='UP';else ck='DOWN';fi
      let steps++
      echo "Step: ${steps} - SLAMD Server status: ${ck}"
   fi
}

statusSlamdClient() {
   if [ -d "${curdir}/slamd-client" ] && [ -e "${curdir}/slamd-client/slamd-client.conf" ] && [ -e "${cfgdir}/.slamd-client" ]
   then
      ck4cli=$(ps auxwww 2> /dev/null | grep "com.slamd.tools.CommandLineClient "|grep -v grep)
      if [ -n "${ck4cli}" ];then ck='UP';else ck='DOWN';fi
      let steps++
      echo "Step: ${steps} - SLAMD Client status: ${ck}"
   fi
}

statusSlamdMonitor() {
   if [ -d "${curdir}/slamd-monitor-client" ] && [ -e "${curdir}/slamd-monitor-client/slamd-monitor-client.conf" ] && [ -e "${cfgdir}/.slamd-monitor" ]
   then
      ck4mon=$(ps auxwww 2> /dev/null | grep "CommandLineResourceMonitorClient "|grep -v grep)
      if [ -n "${ck4mon}" ];then ck='UP';else ck='DOWN';fi
      let steps++
      echo "Step: ${steps} - SLAMD Client Monitor status: ${ck}"
   fi
}

statusSlamd() {
   statusSlamdServer
   statusSlamdClient
   statusSlamdMonitor
}

status_slamd() {
   case "${cmdArg2}" in
         'slamd') statusSlamd;;
      'slamdsvr') statusSlamdServer;;
      'slamdcli') statusSlamdClient;;
      'slamdmon') statusSlamdMonitor;;
               *) statusSlamd;;
   esac
}

##############################################################################
# Request SLAMD clients
##############################################################################
addSlamdLogPlaybackClass() {
   confirmPlayback=$(curl -s "http://${slamdHost}:${slamdPort}/slamd/?sec=job&subsec=schedule_new_job"|grep -i 'Directory Server Log Playback')
   while [ -z "${confirmPlayback}" ]
   do
      if [ -z "${confirmPlayback}" ]
      then
         let steps++
         printf "%-4s%s\n" "Step: ${steps}" " - Add Log Playback Class to SLAMD server"
      fi

      # Wait for a few seconds to make sure Server is ready to receive request
      if [ "$debug" == 'on' ];then echo;set -x;fi
      sleep 2
      curl --max-time 600 --connect-timeout 600 -s -o "${logdir}/slamd-addclass-${now}.log" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=add_job_class\
\&job_class=com.slamd.dslogplay.LogPlaybackJobClass\
\&submit=Add%20Job%20Class
      rc=$?
      set +x
      confirmPlayback=$(curl -s "http://${slamdHost}:${slamdPort}/slamd/?sec=job&subsec=schedule_new_job"|grep -i 'Directory Server Log Playback')

   done

}

##############################################################################
# Request SLAMD clients
##############################################################################
slamdRequestClients() {
   num="$1";if [ -z "${num}" ];then num='3';fi

   confirmClients=''
   while [ -z "${confirmClients}" ]
   do
      # Wait for a few seconds to make sure Server is ready to receive request
      if [ "$debug" == 'on' ];then echo;set -x;fi
      sleep 2
      curl --max-time 600 --connect-timeout 600 -s -o "${logdir}/slamd-client-${now}.log" http://${slamdHost}:${slamdPort}/slamd/\?sec=status\
\&subsec=connect\
\&client_id=${localHost}\
\&job_num_clients=${num}\
\&submit=Create%20Clients
      rc=$?
      set +x
      confirmClients=$(grep "has accepted the request and is in the process of creating .* new client connections" ${logdir}/slamd-client-${now}.log 2> /dev/null)
   done

   let steps++
   printf "%-4s%s\n" "Step: ${steps}" " - Request ${clients} clients for ${cname}"
}

##############################################################################
# Start SLAMD
##############################################################################
startSlamdServer() {
   if [ "$(hostname)" != "${localHost}" ];then sudo -n hostnamectl set-hostname ${localHost};fi

   if [ -e "${cfgdir}/.slamd-server" ]
   then
      true
   else
      if [ -d "${curdir}/slamd" ] && [ -e "${curdir}/slamd/conf/server.xml" ] && [ -d "${curdir}/slamd/webapps/slamd/WEB-INF/db" ]
      then
         touch "${cfgdir}/.slamd-server"
      else
         echo "ERROR: SLAMD Server not setup"
         exit 1
      fi
   fi

   if [ -d "${curdir}/slamd" ] && [ -e "${curdir}/slamd/conf/server.xml" ] && [ -e "${cfgdir}/.slamd-server" ] 
   then
      ck4svr=$(ps -ef 2> /dev/null | grep "slamd\/conf"|grep -v grep)
      if [ -z "${ck4svr}" ]
      then
         if [ -d "${curdir}/slamd/temp" ];then true; else mkdir -p "${curdir}/slamd/temp";fi
         # Startup SLAMD server
         let steps++
         echo "Step: ${steps} - Start SLAMD Server"
         if [ "$debug" == 'on' ];then echo;set -x;fi
         ${curdir}/slamd/bin/startup.sh >> ${logdir}/slamd-server-${now}.log 2>&1
         rc=$?;set +x
         echo "    SLAMD Server: http://${localHost}:${slamdPort}/slamd"
      fi
      # Give a few seconds so it will be fully up for clients to connect
      sleep 10
   fi
}

startSlamdClient() {
   if [ -e "${cfgdir}/.slamd-client" ]
   then
      true
   else
      if [ -d "${curdir}/slamd-client" ] && [ -e "${curdir}/slamd-client/slamd-client.conf" ] && [ -n "${slamdHost}" ] && [ -n  "${slamdPort}" ]
      then
         echo -e "slamdHost=${slamdHost}\nslamdPort=${slamdPort}" > "${cfgdir}/.slamd-client"
      else
         echo "ERROR: SLAMD Client not setup"
         exit 1
      fi
   fi

   if [ -d "${curdir}/slamd-client" ] && [ -e "${curdir}/slamd-client/slamd-client.conf" ] && [ -e "${cfgdir}/.slamd-client" ]
   then
      . "${cfgdir}/.slamd-client"
      ck4cli=$(ps -ef 2> /dev/null | grep start-client-manager.sh|grep -v grep)
      if [ -z "${ck4cli}" ]
      then
         # Startup SLAMD client
         let steps++
         echo "Step: ${steps} - Start SLAMD Client"
         if [ "$debug" == 'on' ];then echo;set -x;fi
         ${curdir}/slamd-client/start-client-manager.sh >> ${logdir}/slamd-client-${now}.log 2>&1 &
         set +x
      fi
   fi

   slamdRequestClients ${clients}
}

startSlamdMonitor() {
   if [ -e "${cfgdir}/.slamd-monitor" ]
   then
      true
   else
      if [ -d "${curdir}/slamd-monitor-client" ] && [ -e "${curdir}/slamd-monitor-client/slamd-monitor-client.conf" ] && [ -n "${slamdHost}" ] && [ -n  "${slamdPort}" ]
      then
         echo -e "slamdHost=${slamdHost}\nslamdPort=${slamdPort}" > "${cfgdir}/.slamd-monitor"
      else
         echo "ERROR: SLAMD Monitor not setup"
         exit 1
      fi
   fi

   if [ -d "${curdir}/slamd-monitor-client" ] && [ -e "${curdir}/slamd-monitor-client/slamd-monitor-client.conf" ] && [ -e "${cfgdir}/.slamd-monitor" ]
   then
      . "${cfgdir}/.slamd-monitor"
      ck4mon=$(ps -ef 2> /dev/null | grep start-monitor-client.sh|grep -v grep)
      if [ -z "${ck4mon}" ]
      then
         # Startup SLAMD client
         let steps++
         echo "Step: ${steps} - Start SLAMD Monitor"
         if [ "$debug" == 'on' ];then echo;set -x;fi
         ${curdir}/slamd-monitor-client/start-monitor-client.sh >> ${logdir}/slamd-monitor-${now}.log 2>&1 &
         rc=$?;set +x
      fi
   fi
}

startSlamd() {
   startSlamdServer
   startSlamdClient
   startSlamdMonitor
}

start_slamd() {
   case "${cmdArg2}" in
         'slamd') startSlamd;;
      'slamdsvr') startSlamdServer;;
      'slamdcli') startSlamdClient;;
      'slamdmon') startSlamdMonitor;;
               *) startSlamd
   esac
}

##############################################################################
# Stop SLAMD
##############################################################################
stopSlamdClient() {
   if [ -d "${curdir}/slamd-client" ] && [ -e "${curdir}/slamd-client/slamd-client.conf" ] && [ -e "${cfgdir}/.slamd-client" ]
   then
      pids=$(ps -ef 2> /dev/null | egrep "slamd-client-manager|slamd-client"|grep -v grep|awk '{ print $2 }')
      if [ -n "${pids}" ]
      then
         # Stop SLAMD client
         let steps++
         echo "Step: ${steps} - Stop SLAMD Client"
         kill -9 ${pids}
      fi
   fi
}

stopSlamdMonitor() {
   if [ -d "${curdir}/slamd-monitor-client" ] && [ -e "${curdir}/slamd-monitor-client/slamd-monitor-client.conf" ] && [ -e "${cfgdir}/.slamd-monitor" ]
   then
      pids=$(ps -ef 2> /dev/null | grep "slamd-monitor-client"|grep -v grep|awk '{ print $2 }')
      if [ -n "${pids}" ]
      then
         # Stop SLAMD client
         let steps++
         echo "Step: ${steps} - Stop SLAMD Monitor"
         kill -9 ${pids}
      fi
   fi
}

stopSlamdServer() {
   if [ -d "${curdir}/slamd" ] && [ -e "${curdir}/slamd/conf/server.xml" ] && [ -e "${cfgdir}/.slamd-server" ]
   then
      pids=$(ps -ef 2> /dev/null | grep "slamd\/conf"|grep -v grep|awk '{ print $2 }')
      if [ -n "${pids}" ]
      then
         # Startup SLAMD server
         let steps++
         echo "Step: ${steps} - Stop SLAMD Server"
         ${curdir}/slamd/bin/shutdown.sh >> ${logdir}/slamd-server-${now}.log 2>&1
         kill -9 ${pids}
      fi
   fi
}

stopSlamd() {
   stopSlamdServer
   stopSlamdClient
   stopSlamdMonitor
}

stop_slamd() {
   case "${cmdArg2}" in
         'slamd') stopSlamd;;
      'slamdsvr') stopSlamdServer;;
      'slamdcli') stopSlamdClient;;
      'slamdmon') stopSlamdMonitor;;
               *) stopSlamd;;
   esac
}

###############################################################################
# Download and build SLAMD
###############################################################################
build_slamd() {
   if [ -e "${swdir}/slamd.zip" ] && [ -d "${curdir}/slamd_build" ]
   then
      true
   elif [ -z "${swapflag}" ]
   then
      set +x
      if [ -e "${cfgdir}/.steps.install" ];then steps=$(cat ${cfgdir}/.steps.install);fi
      lookupos
      case ${os} in
        'Linux') ck4gitrpm=$(rpm -q git|grep "^git-")
                 if [ -z "${ck4gitrpm}" ]
                 then
                    # Make sure yum install isn't already running
                    ck4yum=$(ps -ef|grep yum|grep install)
                    while [ -n "${ck4yum}" ]
                    do
                       ck4yum=$(ps -ef|grep yum|grep install)
                       sleep 1
                    done
                    let steps++
                    echo "Step: ${steps} - Install git"
                    sudo -n yum install -y git >> ${logdir}/slamd-setup-${now}.log 2>&1
                    rc=$?
                 fi
                 ;;
        'SunOS') ck4gitrpm=$(pkg list git|grep git)
                 if [ -z "${ck4gitrpm}" ]
                 then
                    let steps++
                    echo "Step: ${steps} - Install git"
                    sudo -n pkg install git >> ${logdir}/slamd-setup-${now}.log 2>&1
                 fi
                 ;;
      esac

      ck4gitbin=$(git --version 2> /dev/null)
      if [ -z "${ck4gitbin}" ]
      then
         echo "Error: git appears to be missing.  Please install and try again."
         exit 1
      fi

      # Make sure Java 8 is installed
      if [ -n "${JAVA_HOME}" ]
      then
         true
      else
         if [ "$debug" == 'on' ];then set -x;fi
         ${curdir}/manage_jdk.sh setup ${steps}
         rc=$?
         if [ ${rc} -ne 0 ];then exit 1;fi
         let steps++
         set +x

#         if [ -z "${JAVA_HOME}" ];then JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
      fi

      if [ -d  "${curdir}/slamd_build/.git" ]
      then
         cd "${curdir}/slamd_build" >> ${logdir}/slamd-setup-${now}.log 2>&1
      else
         let steps++
         echo "Step: ${steps} - Initialize local git repo"
         if [ "$debug" == 'on' ];then set -x;fi
         mkdir -p "${curdir}/slamd_build/" >> ${logdir}/slamd-setup-${now}.log 2>&1
         cd "${curdir}/slamd_build"
         git init >> ${logdir}/slamd-setup-${now}.log 2>&1
         rc=$?
         set +x
      fi

      # Checkout the SLAMD code
      if [ -d  "${curdir}/slamd_build/slamd/build.sh" ]
      then
         true
      else
         let steps++
         echo "Step: ${steps} - Clone SLAMD from GitHub"
         if [ "$debug" == 'on' ];then set -x;fi
         git clone https://github.com/dirmgr/slamd.git >> ${logdir}/slamd-setup-${now}.log 2>&1
         rc=$?
         set +x
      fi

      # Build the SLAMD code
      ck4build=$(ls -1 ${curdir}/slamd_build/slamd/build/package/slamd-[0-9]*.zip 2> /dev/null)
      if [ -z "${ck4build}" ]
      then
         let steps++
         echo "Step: ${steps} - Build SLAMD"
         if [ "$debug" == 'on' ];then set -x;fi
         cd "${curdir}/slamd_build/slamd"
         ${curdir}/slamd_build/slamd/build.sh >> ${logdir}/slamd-setup-${now}.log 2>&1
         rc=$?
         set +x
      fi

      # Copy builds into swdir
      let steps++
      echo "Step: ${steps} - Copy SLAMD to ${swdir}"
      if [ "$debug" == 'on' ];then set -x;fi
      cd "${curdir}/slamd_build/slamd/build/package"
      cp slamd-[0-9]*.zip ${swdir}/slamd.zip >> ${logdir}/slamd-setup-${now}.log 2>&1
      cp slamd-client-[0-9]*.zip ${swdir}/slamd-client.zip >> ${logdir}/slamd-setup-${now}.log 2>&1
      cp slamd-monitor-client-[0-9]*.zip ${swdir}/slamd-monitor-client.zip >> ${logdir}/slamd-setup-${now}.log 2>&1
      set +x
   fi
   set +x
}

##############################################################################
# SLAMD security and scope parameters
##############################################################################
make_service_info_file() {
   let steps++
   infoFileName=$(basename ${infoFile})
   echo "Step: ${steps} - Make service info file ${infoFileName} from ${templateName} template"
   if [ -e "${cfgdir}/${templateName}.tmpl" ]
   then
      head -10 ${cfgdir}/${templateName}.tmpl|grep "^#" > ${infoFile} 2> /dev/null
      if [ -n "${myTemplateName}" ];then cat ${infoFile} > ${cfgdir}/slamd.info;fi
   else
      echo "ERROR: template file (${cfgdir}/${templateName}.tmpl) not found."
      exit 1
   fi
}

##############################################################################
# Get search spans from service info template
##############################################################################
getSearchSpans() {
   #suffix|${suffix}
   #Type |rdn|Search Base      |pFix|firstNum |lastNum
   #urate|uid|ou=People,$suffix|user|${firstUNum}|${lastUNum}
   #grate|cn|ou=Groups,$suffix|group|${firstUNum}|${lastUNum}
   #mrate|uid|ou=Groups,$suffix|user|${firstUNum}|${lastUNum}
   #uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}

   # Set *Rate suffix
   rateSuffix=$(head -7 "${infoFile}" 2> /dev/null|grep "^#suffix"|cut -d'|' -f2)

   # Users / Subscribers
   uRdn=$(head -7 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f2)
   uBase=$(head -7 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f3)
   uPrefix=$(head -7 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f4)
   uFirst=$(head -7 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f5)
   uLast=$(head -7 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f6)
   if [ -n "${lspan}" ];then uLast=$((${uFirst}+${lspan}));fi
   uSpan="${uFirst}-${uLast}"
   firstUser="${uRdn}=${uPrefix}${uFirst},${uBase}"
   firstUserRdn="${uRdn}=${uPrefix}${uFirst}"
   lastUser="${uRdn}=${uPrefix}${uLast},${uBase}"
   lastUserSchema="${uPrefix}${uLast}"
   secondUser="${uRdn}=${uPrefix}$((${uFirst}+1)),${uBase}"

   # Groups
   gRdn=$(head -7 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f2)
   gBase=$(head -7 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f3)
   gPrefix=$(head -7 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f4)
   gFirst=$(head -7 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f5)
   gLast=$(head -7 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f6)
   gSpan="${gFirst}-${gLast}"

   # Group Members
   mRdn=$(head -7 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f2)
   mBase=$(head -7 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f3)
   mPrefix=$(head -7 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f4)
   mFirst=$(head -7 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f5)
   mLast=$(head -7 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f6)
   mSpan="${mFirst}-${mLast}"

   # Admin User
   aRdn=$(head -7 "${infoFile}" 2> /dev/null|grep "^#uadmin"|cut -d'|' -f2)
   aBase=$(head -7 "${infoFile}" 2> /dev/null|grep "^#uadmin"|cut -d'|' -f3)
   aPrefix=$(head -7 "${infoFile}" 2> /dev/null|grep "^#uadmin"|cut -d'|' -f4)
   aFirst=$(head -7 "${infoFile}" 2> /dev/null|grep "^#uadmin"|cut -d'|' -f5)

   if [ -z "${myBindDN}" ];then firstAdmin="${aRdn}=${aPrefix}${aFirst},${aBase}";fi

   ckuSpan=$(echo ${uSpan}|sed -e "s/,//g")
   if [ -n "$ckuSpan" ];then searchSpan="${uSpan}";fi

   if [ -z "${uFirst}" ]
   then
      if [ "${subcmd}" == 'breports' ] || [ "${subcmd}" == 'bsummary' ] || [ "${subcmd}" == 'bpurgeall' ]
      then
         true
      else
         echo "Error: Create and update ${infoFile} for your directory service"
         exit 1
      fi
   fi
}

##############################################################################
# SLAMD security and scope parameters
##############################################################################
# param_security_method=[None|SSL|StartTLS]
# param_scope=
#   singleLevel:  Only Immediate Subordinates of the Search Base
#   Whole Subtree:  The Search Base Entry and All Its Subordinates
#   Subordinate Subtree:  All Subordinates of the Search Base Entry
##############################################################################
# Create job SLAMD folder
##############################################################################
slamdReqCheck() {
   if [ -s "${infoFile}" ] || [ "${subcmd}" == 'breports' ] || [ "${subcmd}" == 'bsummary' ] || [ "${subcmd}" == 'bpurgeall' ] || [ "${campaign}" == 'playback' ] || [ "${campaign}" == 'playbackread' ] || [ "${campaign}" == 'playbackwrite' ]
   then
      true
   else
      if [ -e "${templateFile}" ]
      then
         head -7 "${templateFile}" |grep "^#" > ${infoFile}
      else
         echo "Error: Directory service info file ${infoFile} does not exist"
         echo "Run \"${0} mksvcinfo\" to make the file."
         echo "Once the file exists, update with details of the directory service."
         exit 1
      fi
   fi
}

##############################################################################
# Create job SLAMD folder
##############################################################################
slamdCreateJobFolder() {
   if [ "${jobFolder}" != 'Unclassified' ]
   then
      printf "%-4s%-30s%-25s" "${steps}" 'Create Job Folder' 'N/A'
      ${curdir}/slamd/tools/create-folder.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/" -f "${jobFolder}" > /dev/null 2>&1
      if [ $? -eq 0 ];then echo;else echo "Error creating folder";fi
      let steps++
   fi
}

##############################################################################
# Get all SLAMD job IDs
##############################################################################
getSlamdJobIds() {
   unset JAVA_TOOL_OPTIONS
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/?sec=job\&subsec=view_running
   readarray -t runningSlamdJobList < <(grep NAME=\"job_id ${jobResultFile}|sed -e "s/.*VALUE=\"//g" -e "s/\"><.*//g")
   rm -f "${jobResultFile}"
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/?sec=job\&subsec=view_pending
   readarray -t pendingSlamdJobList < <(grep NAME=\"job_id ${jobResultFile}|sed -e "s/.*VALUE=\"//g" -e "s/\"><.*//g")
   rm -f "${jobResultFile}"
   slamdJobIds=( "${runningSlamdJobList[@]}" "${pendingSlamdJobList[@]}" )
}

##############################################################################
# List SLAMD Jobs
##############################################################################
slamdListJobs() {
   unset JAVA_TOOL_OPTIONS
   getSlamdJobIds
   if [ ${#slamdJobIds[*]} -ge 1 ]
   then
      j=1
      printf "%-4s%-30s%-20s%-25s\n" "Job" "Descripton" "State" "JobID"
      printf "%-4s%-30s%-20s%-25s\n" "---" "-----------------------------" "-------------------" "--------------------------"
      for (( i=0; i< ${#slamdJobIds[*]}; i++ ))
      do
         jobData=$(${curdir}/slamd/tools/get-job.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/" -j ${slamdJobIds[${i}]})
         jobType=$(echo "${jobData}"|grep "^Job Type:"|sed -e "s/^Job Type:  //g")
         jobDesc=$(echo "${jobData}"|grep "^Job Description:"|sed -e "s/^Job Description:  //g")
         jobState=$(echo "${jobData}"|grep "^Job State:"|sed -e "s/^Job State:  //g")
         printf "%-4s%-30s%-20s%-25s\n" "${j}" "${jobDesc}" "${jobState}" "${slamdJobIds[${i}]}"
         let j++
      done

   else
      echo "No jobs in the queue"
   fi
}

##############################################################################
# Get last SLAMD Job ID
##############################################################################
slamdGetLastJobId() {
   getSlamdJobIds
   lastSlamdJobId=($(echo ${slamdJobIds[*]}|tr ' ' "\n"|tail -1))
   if [ -z "${lastSlamdJobId}" ];then lastSlamdJobId="None";fi
}


##############################################################################
# Cancel All SLAMD Jobs
##############################################################################
slamdCancelJobs() {
   getSlamdJobIds
   for (( i=0; i< ${#slamdJobIds[*]}; i++ ))
   do
      echo -e "${slamdJobIds[${i}]} - \c"
      ${curdir}/slamd/tools/cancel-job.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/" -j ${slamdJobIds[${i}]}
   done
   # Make sure the AddDel job finishes
   getSlamdJobIds
   for (( i=0; i< ${#slamdJobIds[*]}; i++ ))
   do
      echo -e "${slamdJobIds[${i}]} - \c"
      ${curdir}/slamd/tools/cancel-job.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/" -j ${slamdJobIds[${i}]}
   done
}

##############################################################################
# Purge specific campaign
##############################################################################
slamdPurgeCampaign() {
   if [ -d "${curdir}/slamd/reports/${campaign}" ]
   then
      echo -e "Deleting ${d} - \c"
      ${curdir}/slamd/tools/delete-folder.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/" -d -f ${campaign}
      rm -fr "${curdir}/slamd/reports/${campaign}" 2> /dev/null
   else
      echo -e "ERROR: Campaign ${campaign} not foud."
   fi
   exit
   
#
#   getSlamdJobIds
#   for d in $(${curdir}/slamd/tools/list-folders.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/"|grep -v Unclassified)
#   do
#      echo -e "Deleting ${d} - \c"
#   done
}

##############################################################################
# Purge All SLAMD Data
##############################################################################
slamdPurgeAllData() {
   getSlamdJobIds
   for d in $(${curdir}/slamd/tools/list-folders.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/"|grep -v Unclassified)
   do
      echo -e "Deleting ${d} - \c"
      ${curdir}/slamd/tools/delete-folder.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/" -d -f ${d}
   done
}

##############################################################################
# Purge SLAMD Logs
##############################################################################
slamdPurgeLogs() {
   echo -e "Deleting all SLAMD log files"
   rm -fr ${curdir}/logs/slamd* ${curdir}/slamd/logs/*
}

##############################################################################
# List SLAMD job folders
##############################################################################
listSlamdJobFolders() {
   unset JAVA_TOOL_OPTIONS
   ${curdir}/slamd/tools/list-folders.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/"
}

##############################################################################
# Get SLAMD jobs by folder
##############################################################################
getJobsByFolder() {
   folder="$1"

   if [ -z "${folder}" ]
   then
      echo "Error: Must provide folder id"
      exit 1
   fi

   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/?sec=job\
\&subsec=view_completed\
\&job_folder=${folder}

   jobs=$(grep 'NAME="job_id" VALUE="' ${jobResultFile}|sed -e "s/.*VALUE=\"//g" -e "s/\".*//g")

   rm -f "${jobResultFile}"
}

##############################################################################
# Null SLAMD Job
##############################################################################
slamdNullJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   rm -f "${jobResultFile}" 2> /dev/null

   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/?sec=job\
\&job_disabled=on\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.utility.NoOpJob\
\&job_folder=${jobFolder}\
\&job_thread_startup_delay=0\
\&job_monitor_clients=\
\&job_start_time=${now}\
\&job_wait_for_clients=on\
\&job_clients=\
\&time_between_startups=0\
\&job_stop_time=\
\&validate_schedule=1\
\&num_copies=1\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_num_clients=${clients}\
\&job_threads_per_client=${threads}\
\&job_duration=${jobDuration}%20second\
\&stat_interval=${statInterval}%20seconds\
\&job_description=Null%20Job\
\&job_comments=NullJob\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   printf "%-4s%-30s%-25s\n" "${steps}" "Null Job" "${jobId}"
   let steps++
   rm -f "${jobResultFile}"
}

##############################################################################
# Prime SLAMD Job
##############################################################################
slamdPrimeJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   primeDuration=$((${jobDuration}+10))
   rm -f "${jobResultFile}"
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.PrimeWithSearchesJob\
\&job_start_time=${now}\
\&job_stop_time=\
\&job_duration=${primeDuration}%20minutes\
\&job_description=PrimeJob\
\&job_thread_startup_delay=0\
\&job_folder=${jobFolder}\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_monitor_clients_if_available=${monitor}\
\&job_clients=\
\&job_comments=PrimeJob\
\&job_threads_per_client=${threads}\
\&job_num_clients=${clients}\
\&stat_interval=${statInterval}%20seconds\
\&param_ldaphost=${dsHost}\
\&param_ldapport=${dsPort}\
\&param_rangestart=${uFirst}\
\&param_rangestop=${uLast}\
\&param_binddn="${firstAdmin}"\
\&param_bindpw="${bPW}"\
\&param_searchbase="${suffix}"\
\&param_blind_trust=on\
\&param_timelimit=0\
\&param_valueprefix=user\
\&param_attrname=uid\
\&time_between_startups=0\
\&param_valuesuffix=\
\&param_maxRate=-1\
\&param_usessl=${sslOn}\
\&param_blind_trust=on\
\&param_ssltrustpw=\
\&param_sslkeystore=\
\&validate_schedule=1\
\&num_copies=1\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&param_ssltruststore=\
\&param_sslkeypw=\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}"
   printf "%-4s%-30s%-25s\n" "${steps}" "Prime Job" "${jobId}"
   let steps++
}

##############################################################################
# SearchRate SLAMD Job
##############################################################################
slamdSearchRateJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   myAttrs="$1"
   case ${myAttrs} in
            '*') myAttrs='';jobAttrs='all attrs';;
          '1.1') jobAttrs='1 attr';;
   'isMemberOf') jobAttrs='isMemberOf';;
              *) attrNum=$(echo ${myAttrs}|wc -w)
                 jobAttrs="${attrNum} attrs"
                 myAttrs=$(echo ${myAttrs}|sed -e "s/ /%20/g")
                 ;;
   esac
   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="SearchRate%20${jobDesc}"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.BasicSearchRateJob\
\&submit=Schedule%20Job\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_thread_startup_delay=0\
\&job_monitor_clients_if_available=${monitor}\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_clients=\
\&time_between_startups=0\
\&job_stop_time=\
\&validate_schedule=1\
\&num_copies=1\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_num_clients=${clients}\
\&job_threads_per_client=${threads}\
\&job_duration=${jobDuration}%20minutes\
\&stat_interval=${statInterval}%20seconds\
\&job_description=${jobDesc}\
\&job_comments=SearchRate\
\&param_address=${dsHost}\
\&param_port=${dsPort}\
\&param_security_method=${useSSL}\
\&param_blind_trust=on\
\&param_bind_dn="${firstAdmin}"\
\&param_bind_password="${bPW}"\
\&param_baseDN="${uBase}"\
\&param_base_dn_pattern="${uBase}"\
\&param_scope=Whole%20Subtree:%20%20The%20Search%20Base%20Entry%20and%20All%20Its%20Subordinates\
\&param_attributes="${myAttrs}"\
\&param_filter_pattern="${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D"\
\&param_warm_up_duration=60\
\&param_cool_down_duration=60\
\&param_threshold=-1\
\&param_maxRate=-1\
\&param_maxRateDuration=0\
\&param_sizeLimit=0\
\&param_timeLimit=0\
\&param_timeBetweenRequests=0

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "SearchRate (${jobAttrs})" "${jobId}"
   let steps++
}

##############################################################################
# SearchRateSSL SLAMD Job
##############################################################################
slamdSearchRateSSLJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   myAttrs="$1"
   case ${myAttrs} in
            '*') myAttrs='';jobAttrs='all attrs';;
          '1.1') jobAttrs='1 attr';;
   'isMemberOf') jobAttrs='isMemberOf';;
              *) attrNum=$(echo ${myAttrs}|wc -w)
                 jobAttrs="${attrNum} attrs"
                 myAttrs=$(echo ${myAttrs}|sed -e "s/ /%20/g")
                 ;;
   esac
   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="SearchRate%20${jobDesc}%20SSL"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.BasicSearchRateJob\
\&validate_schedule=1\
\&num_copies=1\
\&make_copies_interdependent=false\
\&time_between_startups=0\
\&job_clients=\
\&job_monitor_clients=\
\&job_thread_startup_delay=0\
\&job_folder=${jobFolder}\
\&job_description=${jobDesc}\
\&job_start_time=${now}\
\&job_stop_time=\
\&job_duration=${jobDuration}%20minutes\
\&job_num_clients=${clients}\
\&job_monitor_clients_if_available=${monitor}\
\&job_wait_for_clients=on\
\&job_threads_per_client=${threads}\
\&stat_interval=${statInterval}%20seconds\
\&param_address=${dsHost}\
\&param_port=${dsPort}\
\&param_bind_dn="${firstAdmin}"\
\&param_bind_password="${bPW}"\
\&param_baseDN="${uBase}"\
\&param_base_dn_pattern="${uBase}"\
\&param_scope=Whole%20Subtree:%20%20The%20Search%20Base%20Entry%20and%20All%20Its%20Subordinates\
\&param_attributes="${myAttrs}"\
\&param_filter_pattern="${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D"\
\&param_warm_up_duration=60\
\&param_cool_down_duration=60\
\&param_threshold=-1\
\&param_maxRate=-1\
\&param_maxRateDuration=0\
\&param_sizeLimit=0\
\&param_timeLimit=0\
\&param_timeBetweenRequests=0\
\&job_comments=SearchRate%20SSL\
\&submit=Schedule+Job\
\&job_dependency=${dependency}\
\&param_security_method=SSL\
\&param_blind_trust=on\
\&param_ssltruststore=${CATrustStore}\
\&param_ssltrustpw="${bPW}"\
\&param_sslkeystore=${curdir}/certs/t58cap-5431/keystore\
\&param_sslkeypw="${bPW}"

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "SearchRate SSL (${jobAttrs})" "${jobId}"
   let steps++
}


##############################################################################
# WhatAreMyGroups SLAMD Job
# Lookup all groups for which uid is a member without using isMemberOf
##############################################################################
slamdWhatAreMyGroupsJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   myAttrs="dn"
   jobAttrs="dn"
   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="WhatAreMyGroups%20${jobDesc}"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.BasicSearchRateJob\
\&submit=Schedule%20Job\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_thread_startup_delay=0\
\&job_monitor_clients_if_available=${monitor}\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_clients=\
\&time_between_startups=0\
\&job_stop_time=\
\&validate_schedule=1\
\&num_copies=1\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_num_clients=${clients}\
\&job_threads_per_client=${threads}\
\&job_duration=${jobDuration}%20minutes\
\&stat_interval=${statInterval}%20seconds\
\&job_description=${jobDesc}\
\&job_comments=SearchRate\
\&param_address=${dsHost}\
\&param_port=${dsPort}\
\&param_security_method=${useSSL}\
\&param_blind_trust=on\
\&param_bind_dn="${firstAdmin}"\
\&param_bind_password="${bPW}"\
\&param_baseDN="${mBase}"\
\&param_base_dn_pattern="${mBase}"\
\&param_scope=Whole%20Subtree:%20%20The%20Search%20Base%20Entry%20and%20All%20Its%20Subordinates\
\&param_attributes="${myAttrs}"\
\&param_filter_pattern="member=${mRdn}=${mPrefix}%5B${mFirst}-${mLast}%5D,${uBase}"\
\&param_warm_up_duration=60\
\&param_cool_down_duration=60\
\&param_threshold=-1\
\&param_maxRate=-1\
\&param_maxRateDuration=0\
\&param_sizeLimit=0\
\&param_timeLimit=0\
\&param_timeBetweenRequests=0

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "WhatAreMyGroups (${jobAttrs})" "${jobId}"
   let steps++
}

##############################################################################
# AmIMember SLAMD Job
# Determine if user is a member of a specific group
##############################################################################
slamdAmIMemberJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   myAttrs="dn"
   jobAttrs="dn"
   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="AmIMember%20${jobDesc}"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.BasicSearchRateJob\
\&submit=Schedule%20Job\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_thread_startup_delay=0\
\&job_monitor_clients_if_available=${monitor}\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_clients=\
\&time_between_startups=0\
\&job_stop_time=\
\&validate_schedule=1\
\&num_copies=1\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_num_clients=${clients}\
\&job_threads_per_client=${threads}\
\&job_duration=${jobDuration}%20minutes\
\&stat_interval=${statInterval}%20seconds\
\&job_description=${jobDesc}\
\&job_comments=SearchRate\
\&param_address=${dsHost}\
\&param_port=${dsPort}\
\&param_security_method=${useSSL}\
\&param_blind_trust=on\
\&param_bind_dn="${firstAdmin}"\
\&param_bind_password="${bPW}"\
\&param_baseDN="${mBase}"\
\&param_base_dn_pattern="${mBase}"\
\&param_scope=Whole%20Subtree:%20%20The%20Search%20Base%20Entry%20and%20All%20Its%20Subordinates\
\&param_attributes="${myAttrs}"\
\&param_filter_pattern="(%26(${gRdn}=${gPrefix}%5B${gFirst}-${gLast}%5D)(member=${uRdn}=${uPrefix}%5B${mFirst}-${mLast}%5D,${uBase}))"\
\&param_warm_up_duration=60\
\&param_cool_down_duration=60\
\&param_threshold=-1\
\&param_maxRate=-1\
\&param_maxRateDuration=0\
\&param_sizeLimit=0\
\&param_timeLimit=0\
\&param_timeBetweenRequests=0

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "AmIMember (${jobAttrs})" "${jobId}"
   let steps++
}

##############################################################################
# AuthRate SLAMD Job
##############################################################################
slamdAuthRateJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   myAttrs="$1"
   case ${myAttrs} in
       '*') myAttrs='';jobAttrs='all attrs';;
     '1.1') jobAttrs='1 attr';;
         *) attrNum=$(echo ${myAttrs}|wc -w)
            jobAttrs="${attrNum} attrs"
            myAttrs=$(echo ${myAttrs}|sed -e "s/ /%20/g")
            ;;
   esac

# There appears to be a bug with SLAMD processing of this pattern
# that results into expanding each match to its own authrate job
#\&param_bind_dn_pattern="${uRdn}=${uPrefix}[${uFirst}-${uLast}],${uBase}"\

   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="AuthRate%20${jobDesc}"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.BasicBindRateJob\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_duration=${jobDuration}%20minutes\
\&job_description=${jobDesc}\
\&param_security_method=${useSSL}\
\&param_blind_trust=on\
\&param_bind_dn_pattern="${uRdn}=${uPrefix}${uFirst},${uBase}"\
\&param_bind_password="${bPW}"\
\&param_baseDN="${uBase}"\
\&param_base_dn_pattern="${uBase}"\
\&param_scope=Whole%20Subtree:%20%20The%20Search%20Base%20Entry%20and%20All%20Its%20Subordinates\
\&param_attributes="${myAttrs}"\
\&param_address=${dsHost}\
\&param_port=${dsPort}\
\&param_security_method=${useSSL}\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_thread_startup_delay=0\
\&stat_interval=${statInterval}%20seconds\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_monitor_clients_if_available=${monitor}\
\&param_warm_up_duration=60\
\&param_cool_down_duration=60\
\&job_clients=\
\&time_between_startups=0\
\&param_percentage=50\
\&job_comments=AuthRate\
\&param_maxRateDuration=0\
\&job_threads_per_client=${threads}\
\&param_maxRate=-1\
\&param_timeBetweenAuths=0\
\&param_userPW=${bPW}\
\&job_stop_time=\
\&param_filter_pattern="${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D"\
\&param_authType=Simple\
\&job_num_clients=${clients}\
\&param_threshold=-1\
\&validate_schedule=1\
\&num_copies=1\
\&param_bind_dn="${firstAdmin}"\
\&param_bind_password="${bPW}"\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "AuthRate (${jobAttrs})" "${jobId}"
   let steps++
}

##############################################################################
# ModRate SLAMD Job
##############################################################################
slamdModRateJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   modAttr="$1"
   if [ -z "${modAttr}" ];then modAttr=description;fi
   length="$2"
   if [ -z "${length}" ];then length=80;fi
   modType="$3"
   if [ -z "${modType}" ];then modType='Unindexed';fi

   jobDesc=$(echo ${modType}|sed -e "s/ /%20/g")
   jobDesc="ModRate%20${jobDesc}"

   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.BasicModifyRateJob\
\&job_description=${jobDesc}\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_thread_startup_delay=0\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_monitor_clients_if_available=${monitor}\
\&job_clients=\
\&job_comments=ModRate\
\&job_threads_per_client=${threads}\
\&job_stop_time=\
\&job_num_clients=${clients}\
\&job_duration=${jobDuration}%20minutes\
\&param_character_set=abcdefghijklmnopqrstuvwxyz1234567890\
\&param_address=${dsHost}\
\&param_port=${dsPort}\
\&param_security_method=${useSSL}\
\&param_blind_trust=on\
\&stat_interval=${statInterval}%20seconds\
\&param_modify_attribute=${modAttr}\
\&param_warm_up_duration=60\
\&param_cool_down_duration=60\
\&time_between_startups=0\
\&param_timeBetweenRequests=0\
\&param_percentage=50\
\&param_maxRateDuration=0\
\&param_maxRate=-1\
\&sec=job\
\&param_threshold=-1\
\&validate_schedule=1\
\&param_entry_dn_pattern=${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D,${uBase}\
\&num_copies=1\
\&param_value_length=${length}\
\&param_number_of_values=1\
\&param_bind_password=${bPW}\
\&param_bind_dn=${firstAdmin}\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "ModRate (${modType})" "${jobId}"
   let steps++
}

##############################################################################
# AddDelRate SLAMD Job
##############################################################################
slamdAddDelRateJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   numUsersToAdd="$1"
   getSearchSpans
   if [ -z "${numUsersToAdd}" ];then numUsersToAdd=10000;fi

   myUFirst=$((${uFirst}*2))
   myULast=$((${myUFirst}+${numUsersToAdd}))

   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="AddDelRate%20${jobDesc}"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.AddAndDeleteRateJob\
\&job_description=${jobDesc}\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_stop_time=\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_thread_startup_delay=0\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_monitor_clients_if_available=${monitor}\
\&job_clients=\
\&job_comments=AddDelJob\
\&job_threads_per_client=${threads}\
\&job_num_clients=1\
\&job_duration=\
\&param_templateLines="objectClass:%20top%0DobjectClass:%20person%0DobjectClass:%20organizationalPerson%0DobjectClass:%20inetOrgPerson%0Duid:%20%3CentryNumber%3E%0Dsn:%20%3Crandom:alpha:10%3E%0DgivenName:%20%3Crandom:alpha:8%3E%0Dcn:%20{givenName}%20{sn}%0Dinitials:%20{givenName:1}%3Crandom:alpha:1%3E{sn:1}%0DemployeeNumber:%20{uid}%0Dmail:%20{uid}@${domain}%0DuserPassword:%20password%0DtelephoneNumber:%20%3Crandom:telephone%3E%0DhomePhone:%20%3Crandom:telephone%3E%0Dmobile:%20%3Crandom:telephone%3Epager:%20%3Crandom:telephone%3Estreet:%20%3Crandom:numeric:5%3E%20%3Crandom:alpha:10%3E%20Street%0Dl:%20%3Crandom:alpha:10%3E%0Dst:%20%3Crandom:alpha:2%3E%0DpostalCode:%20%3Crandom:numeric:5%3E"\
\&param_processingType=Perform%20all%20adds,%20then%20perform%20all%20deletes\
\&param_securityMethod=${useSSL}\
\&param_blind_trust=on\
\&param_addresses=${dsHost}:${dsPort}\
\&param_bindDN="${firstAdmin}"\
\&param_bindPW="${bPW}"\
\&param_first=${myUFirst}\
\&param_last=${myULast}\
\&stat_interval=${statInterval}%20seconds\
\&time_between_startups=0\
\&param_timeBetweenAddsAndDels=10\
\&param_timeBetweenRequests=0\
\&param_maxRateDuration=0\
\&param_rdnAttr=${uRdn}\
\&param_maxRate=-1\
\&param_threshold=-1\
\&validate_schedule=1\
\&num_copies=1\
\&param_bind_dn=${firstAdmin}\
\&param_bind_password=${bPW}\
\&param_baseDN=${uBase}\
\&param_base_dn_pattern="${uBase}"\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "AddDelRate" "${jobId}"
   let steps++
}

##############################################################################
# SearchAndMod SLAMD Job
##############################################################################
slamdSearchAndModJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"

   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="SearchAndMod%20${jobDesc}"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.BasicSearchAndModifyRateJob\
\&job_description=${jobDesc}\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_stop_time=\
\&job_thread_startup_delay=0\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&param_security_method=${useSSL}\
\&param_blind_trust=on\
\&param_address=${dsHost}\
\&param_port=${dsPort}\
\&stat_interval=${statInterval}%20seconds\
\&param_modify_attribute=description\
\&param_character_set=abcdefghijklmnopqrstuvwxyz1234567890\
\&param_base_dn_pattern=${uBase}\
\&param_scope=Whole%20Subtree:%20%20The%20Search%20Base%20Entry%20and%20All%20Its%20Subordinates\
\&param_attributes_to_return=\
\&job_monitor_clients_if_available=${monitor}\
\&param_warm_up_duration=60\
\&job_clients=\
\&time_between_startups=0\
\&param_timeBetweenRequests=0\
\&param_percentage=50\
\&job_comments=SearchAndMod\
\&param_maxRateDuration=0\
\&job_threads_per_client=${threads}\
\&param_maxRate=-1\
\&param_sizeLimit=0\
\&param_filter_pattern="${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D"\
\&job_num_clients=${clients}\
\&param_threshold=-1\
\&validate_schedule=1\
\&num_copies=1\
\&param_value_length=80\
\&param_number_of_values=1\
\&param_bind_dn="${firstAdmin}"\
\&param_bind_password="${bPW}"\
\&param_baseDN="${uBase}"\
\&job_duration=${jobDuration}%20minutes\
\&param_cool_down_duration=60\
\&param_timeLimit=0\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "SearchAndMod" "${jobId}"
   let steps++
}

##############################################################################
# Mixed SLAMD Job
##############################################################################
slamdMixedLoadJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"

   searchLoad="$1";if [ -z "${searchLoad}" ];then searchLoad='70';fi
   authLoad="$2";if [ -z "${authLoad}" ];then authLoad='10';fi
   modLoad="$3";if [ -z "${modLoad}" ];then modLoad='10';fi
   addLoad="$4";if [ -z "${addLoad}" ];then addLoad='5';fi
   delLoad="$5";if [ -z "${delLoad}" ];then delLoad='5';fi
  
   if [ "${searchLoad}" == '0' ];then searchTxt='';else searchTxt=${searchLoad}S;fi
   if [ "${authLoad}" == '0' ];then authTxt='';else authTxt=${authLoad}A;fi
   if [ "${modLoad}" == '0' ];then modTxt='';else modTxt=${modLoad}M;fi
   if [ "${addLoad}" == '0' ];then addTxt='';else addTxt=${addLoad}Add;fi
   if [ "${delLoad}" == '0' ];then delTxt='';else delTxt=${delLoad}Del;fi

   jobDesc=$(echo ${searchTxt} ${authTxt} ${modTxt} ${addTxt} ${delTxt}|sed -e "s/ /%20/g")
   jobDesc="Mixed%20${jobDesc}"

   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.MixedLoadJob\
\&job_description=${jobDesc}\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_stop_time=\
\&job_thread_startup_delay=0\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_monitor_clients_if_available=${monitor}\
\&job_clients=\
\&job_comments=Mixed\
\&job_threads_per_client=${threads}\
\&job_num_clients=${clients}\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_duration=${jobDuration}%20minutes\
\&param_attributes=\
\&param_addresses=${dsHost}:${dsPort}\
\&param_securityMethod=${useSSL}\
\&param_blind_trust=on\
\&stat_interval=${statInterval}%20seconds\
\&param_cleanUp=on\
\&param_templateLines="objectClass:%20top%0DobjectClass:%20person%0DobjectClass:%20organizationalPerson%0DobjectClass:%20inetOrgPerson%0Duid:%20%3CentryNumber%3E%0Dsn:%20%3Crandom:alpha:10%3E%0DgivenName:%20%3Crandom:alpha:8%3E%0Dcn:%20{givenName}%20{sn}%0Dinitials:%20{givenName:1}%3Crandom:alpha:1%3E{sn:1}%0DemployeeNumber:%20{uid}%0Dmail:%20{uid}@${domain}%0DuserPassword:%20password%0DtelephoneNumber:%20%3Crandom:telephone%3E%0DhomePhone:%20%3Crandom:telephone%3E%0Dmobile:%20%3Crandom:telephone%3Epager:%20%3Crandom:telephone%3Estreet:%20%3Crandom:numeric:5%3E%20%3Crandom:alpha:10%3E%20Street%0Dl:%20%3Crandom:alpha:10%3E%0Dst:%20%3Crandom:alpha:2%3E%0DpostalCode:%20%3Crandom:numeric:5%3E"\
\&param_scope=Whole%20Subtree\
\&param_attribute=description\
\&param_searchWeight=${searchLoad}\
\&param_bindWeight=${authLoad}\
\&param_modifyWeight=${modLoad}\
\&param_addWeight=${addLoad}\
\&param_deleteWeight=${delLoad}\
\&param_modifyDNWeight=0\
\&param_compareWeight=0\
\&param_bindDN="${firstAdmin}"\
\&param_bindPW="${bPW}"\
\&param_dn1="${firstAdmin}"\
\&param_dn2="${firstAdmin}"\
\&param_dn1Percentage=50\
\&param_warmUpTime=60\
\&time_between_startups=0\
\&param_timeBetweenRequests=0\
\&param_maxRateDuration=0\
\&param_rdnAttr=${uRdn}\
\&param_maxRate=-1\
\&param_userPW=${bPW}\
\&param_filter1="${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D"\
\&param_filter2="${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D"\
\&param_filter1Percentage=50\
\&param_maxOpsPerThread=0\
\&param_threshold=-1\
\&validate_schedule=1\
\&param_dn1=${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D,${uBase}\
\&param_dn2=${uRdn}=${uPrefix}%5B${uFirst}-${uLast}%5D,${uBase}\
\&num_copies=1\
\&param_length=80\
\&param_bind_dn="${firstAdmin}"\
\&param_bind_password="${bPW}"\
\&param_opsBeforeReconnect=0\
\&param_coolDownTime=60\
\&param_baseDN="${uBase}"\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   jobDesc=$(echo ${jobDesc}|sed -e "s/%20/ /g")
   printf "%-4s%-30s%-25s\n" "${steps}" "Mixed Load" "${jobId}"
   let steps++
}

##############################################################################
# SiteMinder SLAMD Job
##############################################################################
slamdSiteMinderJob() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"

   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="SiteMinder%20${jobDesc}"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.jobs.ldap.SiteMinderJob\
\&job_description=${jobDesc}\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_stop_time=\
\&job_thread_startup_delay=0\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_monitor_clients_if_available=${monitor}\
\&job_clients=\
\&job_comments=SiteMinderJob\
\&job_threads_per_client=${threads}\
\&job_num_clients=${clients}\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_duration=${jobDuration}%20minutes\
\&job_description=SiteMinderJob\
\&param_binddn="${firstAdmin}"\
\&param_bindpw="${bPW}"\
\&stat_interval=${statInterval}%20seconds\
\&param_warm_up=60\
\&param_blind_trust=on\
\&param_delay=0\
\&param_login_id_value=${uPrefix}%5B${uFirst}-${uLast}%5D\
\&param_search_base=${uBase}\
\&param_time_limit=0\
\&param_securityMethod=${useSSL}\
\&param_blind_trust=on\
\&param_ldap_host=${dsHost}\
\&param_ldap_port=${dsPort}\
\&param_mod_attrs=description\
\&param_attr3=cn\
\&param_attr2=sn\
\&param_attr1=givenName\
\&time_between_startups=0\
\&param_maxRateDuration=0\
\&param_share_conns=on\
\&param_maxRate=-1\
\&param_login_id_pw=${bPW}\
\&param_ssltrustpw=\
\&param_sslkeystore=\
\&validate_schedule=1\
\&num_copies=1\
\&param_login_data_file=\
\&param_cool_down=60\
\&param_ssltruststore=\
\&param_login_id_attr=${uRdn}\
\&param_sslkeypw=\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   rm -f "${jobResultFile}" 2> /dev/null
   printf "%-4s%-30s%-25s\n" "${steps}" "SiteMinder" "${jobId}"
   let steps++
}

##############################################################################
# Lookup processor info
##############################################################################
Psradm() {
   cores="$1"
   if [ -z "${sudoFlag}" ]
   then
      vcpus=$(sudo -n psrinfo | tail -1  | awk '{print $1}')
      if [ -z "${cores}" ]  || [[ ${cores} -ge ${vcpus} ]] 
      then
         sudo -n psradm -n -a
      else
         vmax=`expr ${cores} \* 8`
         pid=`expr ${vmax} - 1` 
         sudo -n psradm -n 0-${pid} ; psradm -f ${vmax}-${vcpus}
      fi
   else
      echo "Must have sudo -n privilege to run processor information commands"
   fi
}


##############################################################################
# Disconnect SLAMD clients
##############################################################################
slamdDisconnectAll() {
   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"
   rm -f "${jobResultFile}" 2> /dev/null
   cliHosts="$1";if [ -z "${cliHosts}" ];then cliHosts=${slamdHost};fi

   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/?sec=status\
\&subsec=disconnect_all\
\&client_id=${cliHosts}\
\&confirmed=yes

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   printf "%-4s%s\n" "${steps}" "Disconnect Job : All Clients disconnected"
   sleep 180
   let steps++
   rm -f "${jobResultFile}"
}


##############################################################################
# Enable first SLAMD Job
##############################################################################
enableFirstSlamdJob() {
   firstSlamdJobId="$1"
   if [ -z "${firstSlamdJobId}" ]
   then
      echo "Error: No job id specified to start"
      exit 1
   else
      printf "%-4s%-30s%-25s" "${steps}" 'Enable first job' 'N/A'
      ${curdir}/slamd/tools/enable-job.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/" -j ${firstSlamdJobId} > /dev/null 2>&1
      if [ $? -eq 0 ];then echo;else echo "Error enabling job";fi
   fi
}

##############################################################################
# Simple ldapsearch
##############################################################################
ldapSearch() {
   unset JAVA_TOOL_OPTIONS

   # Make sure OUD instance exists
   if [ "${subcmd}" == 'demo' ] || [ "${subcmd}" == 'augment' ]
   then
      ckOudReqNum 1 10
   fi

   # Find ldap* commands
   whereIsL

   # Define searchSpan
   getSearchSpans

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN=$firstAdmin;fi

   base=$(echo $args|cut -d'|' -f1);if [ -z "$base" ];then base="$suffix";fi
   type=$(echo $args|cut -d'|' -f2);if [ -z "$type" ];then type='base';fi
   filter=$(echo $args|cut -d'|' -f3);if [ -z "$filter" ];then filter='objectClass=*';fi
   attrs=$(echo $args|cut -d'|' -f4|sed -e "s/[;:]/ /g")
   if [ -z "$type" ];then attrs='';fi
   if [ "$debug" == 'on' ];then set -x;fi
   $lsrch -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" \
      -b "$base" -s $type "$filter" $attrs 2>&1
   set +x
}

##############################################################################
# Simple secure ldapsearch
##############################################################################
ldapSecureSearch() {
   unset JAVA_TOOL_OPTIONS

   # Make sure OUD instance exists
   if [ "${subcmd}" == 'demo' ] || [ "${subcmd}" == 'augment' ]
   then
      ckOudReqNum 1 10
   fi

   # Find ldap* commands
   whereIsL

   # Define searchSpan
   getSearchSpans

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN=$firstAdmin;fi
   if [ -n "${bindSPort}" ];then securePort="${bindSPort}"; else securePort="${dsPort}";fi

   base=$(echo $args|cut -d'|' -f1);if [ -z "$base" ];then base="$suffix";fi
   type=$(echo $args|cut -d'|' -f2);if [ -z "$type" ];then type='base';fi
   filter=$(echo $args|cut -d'|' -f3);if [ -z "$filter" ];then filter='objectClass=*';fi
   attrs=$(echo $args|cut -d'|' -f4|sed -e "s/[;:]/ /g")
   if [ -z "$type" ];then attrs='';fi
   if [ "$debug" == 'on' ];then set -x;fi
   #$lsrch -h ${dsHost} -Z -P ${CATrustStore} -p ${dsPort} -D "$bDN" -j "${jPW}" \
   $lsrch -h ${dsHost} -Z -X -p ${dsPort} -D "$bDN" -j "${jPW}" \
      -b "$base" -s $type "$filter" $attrs 2>&1
   set +x
}

##############################################################################
# Simple modify
##############################################################################
ldapModify() {
   unset JAVA_TOOL_OPTIONS

   # Make sure OUD instance exists
   if [ "${subcmd}" == 'demo' ] || [ "${subcmd}" == 'augment' ]
   then
      ckOudReqNum 1 10
   fi

   # Find ldap* commands
   whereIsL

   # Define searchSpan
   getSearchSpans

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN=$firstAdmin;fi

   if [ -s "${ldifFile}" ]
   then
      true
   else
      echo "Error: LDIF file (${ldifFile}) is empty."
      exit 1
   fi
   
   ck4chtype=$(cat ${ldifFile} | grep -i changetype)
   if [ -z "${ck4chtype}" ]
   then
      echo "Error: LDIF file (${ldifFile}) has no changes specified."
      exit 1
   fi

   if [ "$debug" == 'on' ];then set -x;fi
   ${lmod} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -w "$bPW" -f $ldifFile 2>&1
   set +x
}

##############################################################################
# Demo modify
##############################################################################
demoModify() {
   unset JAVA_TOOL_OPTIONS

   # No need to tune OUD instance for this demo
   noTuneFlag=' --noTune '

   # Make sure OUD instance exists
   ckOudReqNum 1 10

   if [ "$debug" == 'on' ];then set -x;fi
   ldifFile="${curdir}/kit/ldif/test.ldif"
   cat > ${ldifFile} << EOF
dn: ou=test,${suffix}
changetype: add
objectClass: organizationalUnit
ou: test
description: This is a test

dn: ou=test,${suffix}
changetype: modify
replace: description
description: This is only a test

dn: ou=test,${suffix}
changetype: delete
EOF
   set +x

   ldapModify
}

##############################################################################
# Kill *rate pids
##############################################################################
killRateCmds() {
   # Wait for java procs to start up
   sleep 2
   # Ensure that the *rate command tops
   pids="$(ps -ef 2> /dev/null|egrep -i 'searchrate|authrate|modrate|addrate|delrate'|egrep -v "grep|qa"|awk '{ print $2 }'|egrep -v "^$$$"|sort -rn)"
   pids=$(echo $pids)
   trap "kill -1 $pids > /dev/null 2>&1" SIGINT SIGHUP SIGQUIT
   wait
}

##############################################################################
# Ensure target host is accessible
##############################################################################
tcpPing() {
   unset JAVA_TOOL_OPTIONS

   tcpHost="$1"
   if [ -z "${tcpHost}" ];then tcpHost=${dsHost};fi

   pingRemoteHost=$(ping -c 3 ${tcpHost} 2>&1  | grep -i unreachable)
   if [ -n "${pingRemoteHost}" ] && [ "${cmd}" != 'cfgnet' ]
   then
      echo "ERROR: $host is not available.  Check networking"
      exit 1
   fi
}

##############################################################################
# Ensure target host is accessible
##############################################################################
ldapPing() {
   unset JAVA_TOOL_OPTIONS

   ldapHost="$1"
   if [ -z "${ldapHost}" ];then ldapHost=${dsHost};fi

   # Make sure the host is up
   tcpPing "${ldapHost}"

   # Define searchSpan
   getSearchSpans

   # Determine how long that it takes to just run the ldapsearch command (e.g. JRE start time)
   if [ "${cmd}" == 'ldapping' ]
   then
      START_TIME=`echo $(($(date +%s%N)/1000000))`
      ${lsrch} > /dev/null 2>&1
      END_TIME=`echo $(($(date +%s%N)/1000000))`
      CMD_START_TIME=$((${END_TIME} - ${START_TIME}))

      # Measure the response time and factor out JRE start time
      START_TIME=`echo $(($(date +%s%N)/1000000))`
   fi
   pingRemoteHost=$(${lsrch} -h ${ldapHost} ${sslopts} -p ${dsPort} -b 'cn=schema' -s base "objectClass=*" dn 2> /dev/null)
   END_TIME=`echo $(($(date +%s%N)/1000000))`
   if [ "${cmd}" == 'ldapping' ]
   then
      ELAPSED_TIME=$((${END_TIME} - ${START_TIME} - ${CMD_START_TIME}))
      if [ ${ELAPSED_TIME} -lt 0 ];then ELAPSED_TIME=1;fi
   fi

   if [ -z "${pingRemoteHost}" ]
   then
      echo "ERROR: LDAP server ${ldapHost}:${dsPort} is not available."
      exit 0
   fi

   # If called via ldapping sub-command, return a response
   if [ "${cmd}" == 'ldapping' ]
   then
      echo "LDAP server ${ldapHost}:${dsPort} is UP with response time of ${ELAPSED_TIME}ms"
      exit 0
   fi
}

##############################################################################
# Log Playback Job All Operations
##############################################################################
slamdLogPlayback() {
   # Make sure Log Playback is enabled
   addSlamdLogPlaybackClass

   now=$(date +'%Y%m%d%H%M%S')
   dependency="${jobId}"

   # Confirm that log file exists
   if [ "$debug" == 'on' ];then set -x;fi
   if [ -e "${logFile}" ]
   then
      true
   else
      echo "ERROR: Access log file does not exist"
      echo "  logFile: ${logFile}"
      exit 1
   fi
   set +x

   if [ -z "${modAttr}" ];then modAttr='description';fi

   if [ "$debug" == 'on' ];then set -x;fi
   jobDesc=$(echo ${jobAttrs}|sed -e "s/ /%20/g")
   jobDesc="LogPlayback(${playType})%20${jobDesc}"
   rm -f "${jobResultFile}" 2> /dev/null
   curl --max-time 600 --connect-timeout 600 -s -o "${jobResultFile}" http://${slamdHost}:${slamdPort}/slamd/\?sec=job\
\&subsec=schedule_new_job\
\&job_class=com.slamd.dslogplay.LogPlaybackJobClass\
\&param_log_files=${logFile}\
\&param_replay_order=${orderFlag}\
\&job_description=${jobDesc}\
\&param_address=${dsHost}\
\&param_port=${dsPort}\
\&param_use_ssl=${sslOn}\
\&param_bind_dn="${firstAdmin}"\
\&param_bind_password="${bPW}"\
\&param_replay_adds=${playWrites}\
\&param_replay_binds=on\
\&param_replay_compares=${playReads}\
\&param_replay_deletes=${playWrites}\
\&param_replay_modifies=${playWrites}\
\&param_replay_searches=${playReads}\
\&param_bind_operation_password="${bPW}"\
\&param_modify_attr=${modAttr}\
\&param_add_missing_deletes=on\
\&param_delete_existing_add=on\
\&param_ops_between_disconnects=1000\
\&param_time_between_requests=0\
\&job_folder=${jobFolder}\
\&job_start_time=${now}\
\&job_stop_time=\
\&job_thread_startup_delay=0\
\&job_monitor_clients=\
\&job_wait_for_clients=on\
\&job_monitor_clients_if_available=${monitor}\
\&job_clients=\
\&job_comments=ReplayAccessLog\
\&job_threads_per_client=${threads}\
\&job_num_clients=${clients}\
\&make_copies_interdependent=false\
\&job_dependency=${dependency}\
\&job_duration=${jobDuration}%20minutes\
\&job_description=SiteMinderJob\
\&param_binddn="${firstAdmin}"\
\&param_bindpw="${bPW}"\
\&stat_interval=${statInterval}%20seconds\
\&param_warm_up=60\
\&param_blind_trust=on\
\&param_delay=0\
\&param_login_id_value=${uPrefix}%5B${uFirst}-${uLast}%5D\
\&param_search_base=${uBase}\
\&param_time_limit=0\
\&param_securityMethod=${useSSL}\
\&param_blind_trust=on\
\&param_ldap_host=${dsHost}\
\&param_ldap_port=${dsPort}\
\&param_mod_attrs=description\
\&param_attr3=cn\
\&param_attr2=sn\
\&param_attr1=givenName\
\&time_between_startups=0\
\&param_maxRateDuration=0\
\&param_share_conns=on\
\&param_maxRate=-1\
\&param_login_id_pw=${bPW}\
\&param_ssltrustpw=\
\&param_sslkeystore=\
\&validate_schedule=1\
\&num_copies=1\
\&param_login_data_file=\
\&param_cool_down=60\
\&param_ssltruststore=\
\&param_login_id_attr=${uRdn}\
\&param_sslkeypw=\
\&submit=Schedule%20Job

   jobResult=$(cat ${jobResultFile}|tr -d '[\n\r]'|sed -e "s/.*START INFO MESSAGE -->//g" -e "s/END INFO MESSAGE.*//g" -e "s/.*warning\">//g" -e "s/<BR>.*//g")
   jobId=$(echo ${jobResult}|sed -e "s/.*job //g" -e "s/ for exe.*//g")
   if [ "$debug" == 'on' ]
   then
      echo "Job result file: ${jobResultFile}"
      echo "Job result file contents:"
      cat "${jobResultFile}"
   else
      rm -f "${jobResultFile}" 2> /dev/null
   fi
   set +x

   printf "%-4s%-30s%-25s\n" "${steps}" "Log Playback Job" "${jobId}"
   let steps++
}

##############################################################################
# Presence SearchRate
##############################################################################
demoPresenceSearchRate() {
   unset JAVA_TOOL_OPTIONS

   # Install SLAMD
   install_slamd

   # Verify LDAP host is up
   ldapPing

   # Define searchSpan
   getSearchSpans

   if [ -n "${myDnFile}" ] && [ -e "${dnFile}" ]
   then 
      searchSpan="[${fileOrder}:${dnFile}]"
   else 
      searchSpan="${uRdn}=${uPrefix}[${searchSpan}],${uBase}"
   fi

   if [ "${replayOrder}" == 'sequential' ]
   then
      searchSpan=$(echo ${searchSpan}|sed -e "s/-/${rateOrder}/g")
   fi

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN=$firstAdmin;fi

   echo " - User presence searchrate"
   echo " -    base=${searchSpan}"
   echo " -    filter=(objectClass=*)"
   echo " -    attrs=${attrsInfo}"
   echo " -    BindDN=${bDN}"
   echo " -    Threads=${threads}"
   echo " -    Ops per connection=${cratio}"
   echo " -    Target rate: ${modulateOps}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${srate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" \
      --intervalDuration ${statInterval} \
      --iterationsBeforeReconnect ${cratio} \
      -b "${searchSpan}" -s base -t $threads -r ${modulateOps} -I ${maxOps} -f '(objectClass=*)' ${attrs} 2>&1 &

   set +x 
   killRateCmds
}

##############################################################################
# Base SearchRate
##############################################################################
demoBaseSearchRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Verify LDAP host is up
   ldapPing

   # Define searchSpan
   getSearchSpans

   if [ -n "${myRdnFile}" ] && [ -e "${rdnFile}" ]
   then 
      searchSpan="[${fileOrder}:${rdnFile}]"
   else 
      searchSpan="${uRdn}=${uPrefix}[${searchSpan}]"
   fi

   if [ "${replayOrder}" == 'sequential' ]
   then
      searchSpan=$(echo ${searchSpan}|sed -e "s/-/${rateOrder}/g")
   fi

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN=$firstAdmin;fi

   echo " - User base searchrate"
   echo " -    base=${uBase}"
   echo " -    filter=${searchSpan}"
   echo " -    attrs=${attrsInfo}"
   echo " -    BindDN=${bDN}"
   echo " -    Threads=${threads}"
   echo " -    Ops per connection=${cratio}"
   echo " -    Target rate: ${modulateOps}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${srate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" --intervalDuration ${statInterval} --iterationsBeforeReconnect ${cratio} -b "${uBase}" -f "${searchSpan}" -s sub -t $threads -r ${modulateOps} -I ${maxOps} ${attrs} 2>&1 &
   set +x

   killRateCmds
}

##############################################################################
# Bench TNS
##############################################################################
demoBenchTNS() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Verify LDAP host is up
   ldapPing

   # Define searchSpan
   getSearchSpans

   lastDB=$((${numUsers}-1))
   if [ ${lastDB} -eq 0 ];then lastDB=1;fi

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN=$firstAdmin;fi

   echo " - User base searchrate"
   echo " -    base=cn=mydb[1-${lastDB}],ou=Databases,cn=OracleContext,${suffix}"
   echo " -    filter=objectClass=*"
   echo " -    attrs=objectclass,orclNetDescString,orclNetDescName,orclVersion"
   echo " -    BindDN='' (anonymous)"
   echo " -    Threads=${threads}"
   echo " -    Ops per connection=1"
   echo " -    Target rate: ${modulateOps}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${srate}  -h ${dsHost} ${sslopts} -p ${dsPort} -D '' --intervalDuration ${statInterval} --iterationsBeforeReconnect 1 -b "cn=mydb[1-${lastDB}],ou=Databases,cn=OracleContext,${suffix}" -s base -t ${threads} -r ${modulateOps} --filter 'objectClass=*' -A objectclass -A orclNetDescString -A orclNetDescName -A orclVersion 2>&1 &
   set +x

   killRateCmds
}

##############################################################################
# Group SearchRate
##############################################################################
demoGroupSearchRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Verify LDAP host is up
   ldapPing

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   if [ -n "${rdnFile}" ] && [ -e "${rdnFile}" ]
   then 
      searchSpan="${fileOrder}:${rdnFile}"
      seedVal1='(%s)'
   elif [ -n "${uBase}" ]
   then 
      seedVal1="${uRdn}=${uPrefix}%s"
   fi

   echo " - Base user searchrate"
   echo " -    base=${uBase}"
   echo " -    filter=${uRdn}=${uPrefix}[${searchSpan}]"
   echo " -    attrs=${attrsInfo}"
   echo " -    BindDN=${bDN}"
   echo " -    Target rate: ${modulateOps}"
   echo " -    Ops to Perform=${maxOps}"
   echo " -    Threads=${threads}"
   echo " -    Ops per connection=${cratio}"
   echo " -    User search span: ${searchSpan}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${srate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" --intervalDuration ${statInterval} --iterationsBeforeReconnect ${cratio} -b "${uBase}" -f "${uRdn}=${uPrefix}[${searchSpan}]" -s sub -t $threads -r ${modulateOps} -I ${maxOps} ${attrs} 2>&1 &
   set +x

   killRateCmds
}

##############################################################################
# Group List SearchRate
##############################################################################
demoGroupListSearchRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Verify LDAP host is up
   ldapPing

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   if [ -n "${uBase}" ]
   then 
      seedVal1="${uRdn}=${uPrefix}%s,${uBase}"
   else
      searchSpan="$rdnFile"
      seedVal1='%s'
      gBase="ou=Groups,$rateSuffix"
   fi

   echo " - Group list searchrate"
   echo " -    base=${gBase}"
   echo " -    filter=(objectClass=groupOfNames)"
   echo " -    attrs=${attrsInfo}"
   echo " -    BindDN=${bDN}"
   echo " -    Threads=${threads}"
   echo " -    Ops per connection=${cratio}"
   echo " -    Target rate: ${modulateOps}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${srate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "${bDN}" -j "${jPW}" \
      --intervalDuration ${statInterval} --iterationsBeforeReconnect ${cratio} \
      -b "${gBase}" -s sub -t $threads -r ${modulateOps} -I ${maxOps} -f "(objectClass=groupOfNames)" ${attrs} 2>&1
   set +x

   killRateCmds
}

##############################################################################
# Groups by User without isMemberOf SearchRate
##############################################################################
demoListUsersGroups() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   if [ -n "${uBase}" ]
   then 
      seedVal1="(member=${uRdn}=${uPrefix}%s,${uBase})"
      searchSpan="${mFirst},${mLast}"
   else
      searchSpan="[${fileOrder}:${rdnFile}]"
      seedVal1='(member=%s)'
      uBase="ou=People,$rateSuffix"
   fi

   echo " - Lookup group memberships without using isMemberOf"
   echo " -    base=${gBase}"
   echo " -    filter=${seedVal1}"
   echo " -    attrs=${attrsInfo}"
   echo " -    BindDN=${bDN}"
   echo " -    Threads=${threads}"
   echo " -    Ops per connection=${cratio}"
   echo " -    Target rate=${modulateOps}"
   echo " -    User search span: ${searchSpan}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${srate} -h ${dsHost} ${sslopts} -p ${dsPort} -g "$rMode(${searchSpan})" -D "$bDN" -j "${jPW}" \
      --intervalDuration ${statInterval} --iterationsBeforeReconnect ${cratio} \
      -b "${gBase}" -s sub -t $threads -r ${modulateOps} -I ${maxOps} -f "$seedVal1" ${attrs} 2>&1 
   set +x

   killRateCmds
}

##############################################################################
# isMemberOf SearchRate
##############################################################################
demoSearchIsMemberOf() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   if [ -n "${uBase}" ]
   then 
      seedVal1="(${uRdn}=${uPrefix}%s)"
   else
      searchSpan="[${fileOrder}:${rdnFile}]"
      seedVal1='(%s)'
      uBase="ou=People,$rateSuffix"
   fi

   echo " - Lookup group memberships using isMemberOf"
   echo " -    base=${uBase}"
   echo " -    filter=${seedVal1}"
   echo " -    attrs=isMemberOf"
   echo " -    BindDN=${bDN}"
   echo " -    Threads=${threads}"
   echo " -    Ops per connection=${cratio}"
   echo " -    Target rate=${modulateOps}"
   echo " -    User search span: ${searchSpan}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${srate} -h ${dsHost} ${sslopts} -p ${dsPort} -g "$rMode($searchSpan)" -D "$bDN" -j "${jPW}" \
      --intervalDuration ${statInterval} --iterationsBeforeReconnect ${cratio} \
      -b "${uBase}" -s sub -t $threads -r ${modulateOps} -I ${maxOps} -f "${seedVal1}" isMemberOf 2>&1 
   set +x

   killRateCmds
}

##############################################################################
# Base AuthRate
##############################################################################
demoAuthRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   if [ -n "${rdnFile}" ] && [ -e "${rdnFile}" ]
   then 
      searchSpan="${fileOrder}:${rdnFile}"
   fi

   # Verify LDAP host is up
   ldapPing

   if [ "${replayOrder}" == 'sequential' ]
   then
      searchSpan=$(echo ${searchSpan}|sed -e "s/-/${rateOrder}/g")
   fi

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   echo " - User authentication rate"
   echo " -    base=${uBase}"
   echo " -    BindDN=${uRdn}=${uPrefix}[${searchSpan}],${uBase}"
   echo " -    Target rate=${modulateOps}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${arate} -B -h ${dsHost} ${sslopts} -p ${dsPort} --intervalDuration ${statInterval} -b "${uRdn}=${uPrefix}[${searchSpan}],${uBase}" \
      --credentials "${bPW}" -t $threads -r ${modulateOps} -I ${maxOps} --filter '(objectClass=*)' ${attrs} 2>&1 &

   set +x

   killRateCmds
}

##############################################################################
# Base AuthRate
##############################################################################
demoSearchBindRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   if [ -n "${rdnFile}" ] && [ -e "${rdnFile}" ]
   then 
      searchSpan="${fileOrder}:${rdnFile}"
   fi

   # Verify LDAP host is up
   ldapPing

   if [ "${replayOrder}" == 'sequential' ]
   then
      searchSpan=$(echo ${searchSpan}|sed -e "s/-/${rateOrder}/g")
   fi

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   echo " - User authentication rate"
   echo " -    base=${uBase}"
   echo " -    BindDN=${uRdn}=${uPrefix}[${searchSpan}],${uBase}"
   echo " -    Target rate=${modulateOps}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${arate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" -b "${uBase}" \
      --intervalDuration ${statInterval} \
      -f "(${uRdn}=${uPrefix}[${searchSpan}])" -s sub --credentials "${bPW}" \
      -t $threads -r ${modulateOps} -I ${maxOps} ${attrs} 2>&1 &

   set +x

   killRateCmds
}

##############################################################################
# BindRate
##############################################################################
demoBindRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Verify LDAP host is up
   ldapPing

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   echo " - User authentication rate"
   echo " -    base=${uBase}"
   echo " -    BindDN=${uRdn}=${uPrefix}[${uFirst}-${uLast}],${uBase}"
   echo " -    Target rate=${modulateOps}"
   if [ "$debug" == 'on' ];then set -x;fi
   ${arate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" --bindOnly -b "${uRdn}=${uPrefix}[${uFirst}-${uLast}],${uBase}" \
      --intervalDuration ${statInterval} \
      -f "(${uRdn}=${uPrefix}[${uFirst}-${uLast}])" -s sub --credentials "${bPW}" \
      -t $threads -r ${modulateOps} -I ${maxOps} ${attrs} 2>&1 &

   set +x

   killRateCmds
}

##############################################################################
# ModRate
##############################################################################
demoModRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Verify LDAP host is up
   ldapPing

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   if [ "${rateOrder}" != '-' ]
   then
      searchSpan=$(echo ${searchSpan}|sed -e "s/-/${rateOrder}/g")
   fi

   if [ "${replayOrder}" == 'sequential' ]
   then
      searchSpan=$(echo ${searchSpan}|sed -e "s/-/${rateOrder}/g")
   fi

   if [ -n "${uBase}" ]
   then 
      seedVal1="${uRdn}=${uPrefix}[${searchSpan}],${uBase}"
   else
      searchSpan="$rdnFile"
      seedVal1="${uRdn}=${uPrefix}[${searchSpan}]"
   fi

   mrateAttr=$(echo "${mrateAttr},"|cut -d',' -f1)
   if [ -z "${mrateAttr}" ];then mrateAttr='description';fi

   if [ -z "${strSize}" ];then strSize=20;fi

   echo " - Modification rate of ${mrateAttr} attribute of users"
   echo " -    attribute being modified=${mrateAttr}"

   if [ -n "${strValue}" ]
   then
      echo " -    string value=${strValue}"
   else
      echo " -    string length=${strSize}"
   fi

   echo " -    Modulated Rate=${modulateOps}"
   echo " -    Ops to Perform=${maxOps}"
   echo " -    Threads=${threads}"
   echo " -    Ops per connection=${cratio}"
   if [ "$debug" == 'on' ];then set -x;fi

   if [ -n "${strValue}" ]
   then
      ${mrate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" --entryDN "${seedVal1}" \
         --intervalDuration ${statInterval} \
         --iterationsBeforeReconnect ${cratio} \
         -t ${threads} -r ${modulateOps} -I ${maxOps} --attribute "${mrateAttr}" --valuePattern ${strValue} 2>&1
   else
      ${mrate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" --entryDN "${seedVal1}" \
         --intervalDuration ${statInterval} \
         --iterationsBeforeReconnect ${cratio} \
         -t ${threads} -r ${modulateOps} -I ${maxOps} --attribute "${mrateAttr}" --valueLength ${strSize} 2>&1
   fi

   set +x

   killRateCmds
}

##############################################################################
# ModAllEntriesTwice
##############################################################################
modAll() {
   unset JAVA_TOOL_OPTIONS

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   numModUsers=$(((${uLast} - ${uFirst} + 1)*2))
   numModGroups=$(((${gLast} - ${gFirst} + 1)*2))

   # Verify LDAP host is up
   ldapPing

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   mrateAttr=$(echo "${mrateAttr},"|cut -d',' -f1)
   if [ -z "${mrateAttr}" ];then mrateAttr='description';fi

   echo " - Modify ${mrateAttr} of every user and group twice"
   if [ "$debug" == 'on' ];then set -x;fi
   ${mrate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" --entryDN "${uRdn}=${uPrefix}[${uFirst}-${uLast}],${uBase}" \
      --intervalDuration ${statInterval} \
      --iterationsBeforeReconnect ${cratio} \
      -t ${threads} -r ${modulateOps} -I ${numModUsers} --attribute "${mrateAttr}" --valueLength ${strSize} 2>&1

   ${mrate} -h ${dsHost} ${sslopts} -p ${dsPort} -D "$bDN" -j "${jPW}" --entryDN "cn=g[${gFirst}-${gLast}],${gBase}" \
      --intervalDuration ${statInterval} \
      --iterationsBeforeReconnect ${cratio} \
      -t ${threads} -r ${modulateOps} -I ${numModGroups} --attribute "${mrateAttr}" --valueLength ${strSize} 2>&1

   set +x

   killRateCmds
}

##############################################################################
# New AddRate Demo
##############################################################################
demoAddRate2() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Make user template
   cat > $curdir/kit/makeldif/addrate-user.tmpl << EOF
dn: uid=user%s,${suffix}
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: user%1\$s
sn: <last>
givenName: <first>
cn: {givenName} {sn}
userPassword: ${bPW}
mail: user%1\$s@${domain}
telephoneNumber: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
mobile: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
title: <list:Contributor:Manager:Director:Vice President:President:CEO:CIO:Administrative Assistant>

EOF

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   let steps++
   echo "Step: ${steps} - Adding $((${clients}*${numUsers})) users via ${clients} addrate clients"

   start=1
   end=$((${start}+${numUsers}))

   # Capture start time in seconds

   c=1
   while [ ${c} -le ${clients} ]
   do
      if [ "$debug" == 'on' ];then set -x;fi
      ${addrate} ${sslopts} -h ${dsHost}:${dsPort} -D "$bDN" -j "${jPW}" \
      --intervalDuration ${statInterval} \
         --iterationsBeforeReconnect ${cratio} \
         -l "$curdir/kit/makeldif/addrate-user.tmpl" \
         -c 1 -t 1 -r ${modulateOps} -m ${numUsers} \
         -g "inc(${start},${end})" 2>&1 &
      set +x
      start=$((${start}+${numUsers}))
      end=$((${end}+${numUsers}))
      let c++
   done  

   sleep 2 
   pids="$(ps -ef 2> /dev/null|egrep 'addrate'|egrep -v "grep|qa"|awk '{ print $2 }'|egrep -v "^$$$"|sort -rn)"
   pids=$(echo $pids)

   trap "kill -1 $pids > /dev/null 2>&1" SIGINT SIGHUP SIGQUIT
   wait

   # Capture end time in seconds
   # Determine the time delta
   # Display the run time human readable format (printf)

   let steps++
   echo "Step: ${steps} - Stopping load"

   killRateCmds
}

##############################################################################
# AddRate
##############################################################################
demoAddRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Verify LDAP host is up
   ldapPing

   # Make user template
   cat > $curdir/kit/makeldif/addrate-user.tmpl << EOF
dn: uid=user%s,${suffix}
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: user%1\$s
sn: <last>
givenName: <first>
cn: {givenName} {sn}
userPassword: ${bPW}
mail: user%1\$s@${domain}
telephoneNumber: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
mobile: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
title: <list:Contributor:Manager:Director:Vice President:President:CEO:CIO:Administrative Assistant>

EOF

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

#-l, --templateFile {file}
#    The path to the template file containing LDIF entry template along with
#    Java style format string syntax specifying generated data formatting as in
#    'dn: uid=user.%d,ou=people,${suffix}'

   echo " - Add rate for adding users"

   if [ "$debug" == 'on' ];then set -x;fi
   $addrate ${sslopts} -h ${dsHost}:${dsPort} -D "$bDN" -w "$bPW" \
      -l "$curdir/kit/makeldif/addrate-user.tmpl" \
      -c 1 -t 1 -r ${modulateOps} -I ${maxOps} \
      -g "inc(1,${maxOps})" 2>&1

   set +x

   killRateCmds
}

##############################################################################
# Delete Rate
##############################################################################
demoDelRate() {
   unset JAVA_TOOL_OPTIONS

   if [ -n "$1" ];then port=$1;fi

   # Install SLAMD
   install_slamd

   # Define searchSpan
   getSearchSpans

   # Verify LDAP host is up
   ldapPing

   # Use actual user rather than rootdn
   if [ -n "$bindDN" ]; then bDN=$bindDN;else bDN="$firstAdmin";fi

   if [ -n "${uBase}" ]
   then 
      seedVal1="${uRdn}=${uPrefix}%s,${uBase}"
   else
      searchSpan="$rdnFile"
      seedVal1='%s'
   fi

   nFirst=$(echo ${uFirst}|tr -dc '[:digit:]')
   nLast=$(echo ${uLast}|tr -dc '[:digit:]')
   maxOps=$((${nLast} - ${nFirst}))

   echo " - Delete rate for removing users"
   if [ "$debug" == 'on' ];then set -x;fi
   $delrate ${sslopts} -h ${dsHost}:${dsPort} -D "$bDN" -w "$bPW" -g "inc(${searchSpan})" -b "${seedVal1}" \
      -c 1 -t 1 -r ${modulateOps} -I ${maxOps} 2>&1
   set +x

   killRateCmds
}

##############################################################################
# Parse arguments
##############################################################################
cmdinput=$@

# If no arguments are provided, show usage
if [ -z "${subcmd}" ] || [ "${subcmd}" == 'help' ];then showUsage;fi
if [ "${subcmd}" == 'changelog' ];then showChangeLog;fi
if [ "${subcmd}" == 'vmchecklist' ];then showVMChecklist;fi
useSSL='None'
sslOn='off'
sslopts=''
norm='false'

while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            pnum) myPnum="$1";pnum="${myPnum}";shift;;
            nosudo) sudoFlag=' --nosudo';;
            host) myHost=$1; shift;;
            port) myPort=$1; shift;;
            ssl) useSSL='SSL';sslOn='on';sslopts=' -Z -X ';;
            suffix) mySuffix=$1;suffix=$1; shift;;
            rateDN) rateDN=$1; shift;;
            template) myTemplateName=$1; shift;;
            schema) mySchemaFile=$1; shift;;
            log) myLogFile=$1; shift;;
            order) replayOrder=$1; shift;;
            dnfile) myDnFile=$1; shift;;
            rdnfile) myRdnFile=$1; shift;;
            templ) templateFile=$1; shift;;
            ldifFile'ldiffile') myLdifFile=$1; shift;;
            args) args=$1; shift;;
            rMode) if [ "$1" == 's' ];then rMode=inc;else rMode=rand;fi;shift;;
            bakdir) bakDir=$1; shift;;
            slamdHost) myAdminHost=$1; shift;;
            slamdPort) mySlamdPort=$1; shift;;
            slamdReports) slamdReports=$1; shift;;
            cliHosts) cliHosts=$1; shift;;
            interval) statInterval=$1; shift;;
            jobFolder) jobFolder=$1; shift;;
            jobDuration) jobDuration=$1; shift;;
            jobDesc) jobDesc=$1; shift;;
            campaign) myCampaign=$1; shift;;
            filter) searchFilter=$1; shift;;
            debug) debug=on;debugFlag=' -z';;
            benchFile) benchFile=$1; shift;;
            nextStep) mySteps=$1; shift;;
            runLocal|runlocal) runLocal='yes';;
            phase) phase=$1; shift;;
            subnet) subnet="$1";shift;;
            compartment) compartment="$1";shift;;
            cli) cli="$1";shift;;
            dr) dr="$1";shift;;
            rs) rs="$1";shift;;
            ds) ds="$1";shift;;
            ad) availabilityDomain="$1";shift;;
            bm) bm='true';;
            arch) arch="$1";shift;;
            cores) cores="$1";shift;;
            mem) mem="$1";shift;;
            monitor) monitor='on';;
            norm) norm='true';;
            norm) norm='true';;
            ratio) cratio="$1";shift;;
            rspan) rspan="$1";shift;;
            lspan) lspan="$1";shift;;
            ocios) ociOS="$1";shift;;
            strsz) strSize="$1";shift;;
            strvalue) strValue="$1";shift;;
            14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            z) debug=on;debugFlag=' -z';;
            h) myHost=$1; shift;;
            p) myPort=$1; shift;;
            Z) useSSL='SSL';sslOn='on';sslopts=' -Z -X ';;
            D) myBindDN=$1; shift;;
            w) bindPW=$1;bPW=$1; shift;;
            j) bindPWfile=$1; shift;;
            C) clients=$1; shift;;
            T) threads=$1; shift;;
            M) myModulateOps=$1;modulateOps=$1; shift;;
            m) myMaxOps=$1;maxOps=$1; shift;;
            A) attrs=$1; mrateAttr=$1;shift;;
            r) rateDN=$1; shift;;
            S) mySuffix=$1;suffix=$1; shift;;
            s) mySchemaFile=$1; shift;;
            t) templateFile=$1; shift;;
            n) myTemplateName=$1; shift;;
            u) templUserFile=$1; shift;;
            l) myLdifFile=$1; shift;;
            W) mySwDir=$1; shift;;
            a) args=$1; shift;;
            q) disclaimOnce=1;addQ=' -q ';;
            P) prePurge=true;prePurgeFlag=' -P ';;
            N) myNumUsers=$1;shift;;
            g) numGroups=$1; prePurge=true;shift;;
            G) numMembers=$1; prePurge=true;shift;;
        esac;;
    esac
done
setfmwenv

##############################################################################
# Initialize key variables
##############################################################################
if [ -n "${myHost}" ];then dsHost="${myHost}";else dsHost=${localHost};fi

if [ -z "${pnum}" ];then pnum=1;fi
if [ -n "${myPort}" ];then dsPort="${myPort}";else dsPort=${pnum}389;fi

if [ -z "${bm}" ];then bm='false';fi
if [ -z "${arch}" ];then arch='amd';fi
if [ -z "${cores}" ];then cores='1';fi
if [ -z "${mem}" ];then mem='15';fi

if [ -z "${cratio}" ];then cratio='1000';fi
if [ -z "${rspan}" ];then rspan='1000';fi

if [ -z "${monitor}" ];then monitor='off';fi

if [ -n "${myBindDN}" ];then bindDN="${myBindDN}";bDN="${myBindDN}"; firstAdmin="${myBindDN}";fi

h=$(echo ${dsHost}|cut -d'.' -f1)

# Correct the second argument in case it has a dash in it
ckArg2=$(echo "${cmdArg2}"| grep -- -|egrep -v "backup-|restore-|export-|import-")
if [ -n "${ckArg2}" ] || [ -z "${cmdArg2}" ];then cmdArg2='all';fi

if [ -z "${myOuid}" ];then myOuid="${ouid}";fi
if [ -n "${etcOuid}" ];then ouid="${etcOuid}";fi
if [ -n "${myOuid}" ];then ouid="${myOuid}";fi

if [ -n "${etcOgid}" ];then ogid="${etcOgid}";fi
if [ -n "${myOgid}" ];then ogid="${myOgid}";fi

if [ -n "${myInitPort}" ];then initPort="${myInitPort}";fi
if [ -z "${initPort}" ];then initPort='1';fi
initPort=$(echo ${initPort}|sed -e "s/389//g" -e "s/444//g" -e "s/636//g")

TMP="${tmpDir}";TMP_DIR="${TMP}";TMPDIR="${TMP}";TEMP="${TMP}";IBMTMP="${TMP}"
JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS} -Djava.io.tmpdir=$TMP"
export TMP TMP_DIR TMPDIR TEMP IBMTMP

if [ -n "${etcAdminHost}" ];then slamdHost="${etcAdminHost}";fi
if [ -n "${myAdminHost}" ];then slamdHost="${myAdminHost}";fi
if [ -z "${slamdHost}" ];then slamdHost="${localHost}";fi

if [ -n "${mySlamdPort}" ];then slamdPort="${mySlamdPort}";fi
if [ -z "${slamdPort}" ];then slamdPort=8080;fi
if [ -z "${statInterval}" ];then statInterval=10;fi
if [ -z "${jobDuration}" ];then jobDuration=11;fi
if [ -n "${myCampaign}" ];then campaign="${myCampaign}";fi
if [ -z "${campaign}" ];then campaign='baseline';fi
if [ -z "${cliHosts}" ];then cliHosts=${slamdHost};fi
if [ -z "${jobResultFile}" ];then jobResultFile="${logdir}/slamd-job-${now}";fi
if [ -z "${slamdReports}" ];then slamdReports="${curdir}/slamd/reports";fi

if [ -n "$myNetSvc" ];then netsvc="${myNetSvc}";fi
if [ -n "$myNumUsers" ];then numUsers=${myNumUsers};fi

if [ "${templateName}" == 'tns' ];then netsvc=" --netsvc ";fi
if [ "${templateName}" == 'eus' ];then netsvc=' --integration eus ';fi
if [ -n "${myTemplateName}" ];then templateName=${myTemplateName};fi
if [ -z "${templateName}" ];then templateName='enterprise';fi
if [ -n "${myTemplateName}" ];then infoFile="${cfgdir}/${myTemplateName}.info"; else infoFile="${cfgdir}/slamd.info";fi

if [ -n "${myRdnFile}" ];then rdnFile="${myRdnFile}";else rdnFile="${cfgdir}/${templateName}.rdn";fi
if [ -n "${myDnFile}" ];then dnFile="${myDnFile}";else dnFile="${cfgdir}/${templateName}.dn";fi

if [ "$(echo ${suffix}|tr '[:upper:]' '[:lower:]')" == 'cn=oraclecontext' ]
then
   templateName='dipcontext'
   numUsers=1
fi

if [ -n "${sshport}" ];then sshport=22;fi
if [ -n "$mySchemaFile" ];then schemaFile="${mySchemaFile}";else schemaFile="${cfgdir}/$templateName.schema";fi
if [ -n "$myLogFile" ];then logFile="${myLogFile}";else logFile="${cfgdir}/access";fi
if [ -z "$initSchema" ];then initSchema=$schemaFile;fi
if [ -z "$templateFile" ];then templateFile=$curdir/kit/makeldif/$templateName.tmpl;fi
if [ -z "$templUserFile" ];then templUserFile=$curdir/kit/makeldif/$templateName-user.tmpl;fi
if [ -z "$indexFile" ];then indexFile=$curdir/kit/makeldif/$templateName.idx;fi
if [ -n "$myLdifFile" ];then ldifFile="$myLdifFile";else ldifFile=$curdir/kit/ldif/$templateName.ldif;fi
if [ -z "$initLDIF" ];then initLDIF=$ldifFile;fi
if [ -z "$rdnAttr" ];then rdnAttr='uid';fi
if [ -z "$oudPrefix" ];then oudPrefix='oud';fi
if [ -z "$cryptAttrs" ];then cryptAttrs='userSSN';fi
if [ -z "$indexLimit" ];then indexLimit=10000;fi
#if [ -z "$attrs" ];then attrs='*';fi
if [ -z "${attrs}" ]
then
   attrs=""
   attrsInfo="*"
else
   attrsInfo="${attrs}"
   attrs=$(echo ${attrs}|sed -e "s/ / --attribute /g" -e "s/^/--attribute /g")
fi
if [ -z "$numGroups" ];then numGroups=100;fi
if [ -z "$numMembers" ];then numMembers=100;fi
if [ -z "$oudGroupId" ];then oudGroupId=1;fi
if [ -z "$enableAudit" ];then enableAudit=false;fi
if [ -z "$disableAccess" ];then disableAccess=false;fi
if [ -z "$suid" ];then suid='root';fi
if [ -z "$useAdSchema" ];then useAdSchema=false;fi
if [ -z "$myDbMem" ];then myDbMem=4096;fi
if [ -z "${svrId}" ];then svrId=1;fi
if [ -z "${benchFile}" ];then benchFile="$curdir/kit/makeldif/${templateName}.bench";fi
if [ -z "${mySteps}" ];then mySteps=0;fi

if [ -n "${myDbType}" ];then dbType=${myDbType};elif [ -z "${dbType}" ];then dbType='db';fi

if [ -z "${bakDir}" ];then bakDir="${curdir}/kit/bak";fi
if [ -z "${phase}" ];then phase=1;fi

if [ -z "${replayOrder}" ];then replayOrder='random';fi
case ${replayOrder} in
   'random') orderFlag='Replay%20in%20Random%20Order';rateOrder='-';fileOrder="file";;
   'sequential') orderFlag='Replay%20Once%20in%20Sequential%20Order';rateOrder=':';fileOrder="sequentialfile";;
   'seqonce') orderFlag='Replay%20Once%20in%20Sequential%20Order';;
   'seqrepeat') orderFlag='Replay%20in%20Sequential%20Order%20Repeatedly';;
esac
if [ -z "${rateOrder}" ];then rateOrder='file';fi
if [ -z "${fileOrder}" ];then fileOrder='sequentialfile';fi

if [ -z "${playReads}" ];then playReads='on';fi
if [ -z "${playWrites}" ];then playWrites='on';fi
if [ -z "${playType}" ];then playType='all';fi

if [ -z "${myCampaign}" ];then myCampaign="${args}";fi
if [ -z "${myCampaign}" ];then myCampaign='last';fi

if [ -n "${ociOS}" ];then ociOS="${ociOS}";else ociOS='ol8';fi

# Set user, group and member counts based on numUsers
lastU=$((${numUsers}-1))
firstUNum=$((${numUsers}*10))
lastUNum=$((${firstUNum}+${numUsers}-1))
firstGNum=$((${numGroups}*10))
lastGNum=$((${firstGNum}+${numGroups}-1))
#firstMNum=$((${numMembers}*10))
#lastMNum=$((${firstMNum}+${numMembers}))
firstMNum=${firstUNum}
lastMNum=$((${firstMNum}+${numMembers}-1))
firstANum=1
lastANum=1

if [ -z "$rateDN" ]
then 
   if [ -n "$templateFile" ]
   then
      rateDN="$rdnAttr="
   else
      rateDN="uid=user"
   fi
fi


##############################################################################
# Set default values for *rate commands
##############################################################################
if [ -z "${cli}" ];then cli=1;fi
if [ -z "${dr}" ];then dr=2;fi
if [ -z "${rs}" ];then rs=0;fi
if [ -z "${ds}" ];then ds=0;fi

if [ -z "${clients}" ];then clients=10;fi
percli=$(echo ${clients}|awk '{ printf "%.0f", $1/c+1 }' c=${cli} )
clicores=$(echo ${cores}|awk '{ print int($1/4+1) }' )
clicores=2
if [ -z "${threads}" ];then threads=1;fi
if [ -z "${myModulateOps}" ];then modulateOps=100;fi
if [ -z "${myMaxOps}" ];then maxOps=1000000;fi
if [ -z "${bDN}" ];then bDN="$firstUser";fi
if [ -z "${bindPW}" ];then bindPW="$bPW";fi
if [ -n "${bindPWfile}" ];then jPW="${bindPWfile}";bPW=$(cat ${jPW});fi
if [ -z "${jPW}" ];then jPW="${cfgdir}/...pw";fi
if [ -z "${availabilityDomain}" ];then availabilityDomain='uYkY:US-ASHBURN-AD-1';fi
if [ -z "${supplier}" ];then export supplier='';fi

##############################################################################
# Extract SLAMD software
##############################################################################
extractSlamd() {
   # Extract SLAMD server software
   if [ -d "${curdir}/slamd" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Extract SLAMD software"
      if [ -e "${curdir}/slamd/conf/server.xml" ]
      then
         true
      else
         if [ -e "${swdir}/slamd.zip" ]
         then
            if [ "$debug" == 'on' ];then echo;set -x;fi
            cd "${curdir}"
            unzip -oq ${swdir}/slamd.zip >> ${logdir}/slamd-setup-${now}.log 2>&1
            rc=$?
            set +x
         else
            echo "Error: ${swdir}/slamd.zip missing"
            exit 1
         fi
      fi
   fi

   # Extract SLAMD client software
   if [ -e "${curdir}/slamd-client/slamd-client.conf" ]
   then
      true
   else
      if [ -e "${swdir}/slamd-client.zip" ]
      then
         if [ "$debug" == 'on' ];then echo;set -x;fi
         cd "${curdir}"
         unzip -oq ${swdir}/slamd-client.zip >> ${logdir}/slamd-setup-${now}.log 2>&1
         rc=$?
         set +x
      else
         echo "Error: ${swdir}/slamd-client.zip missing"
         exit 1
      fi
   fi

   # Extract SLAMD monitor client software
   if [ -d "${curdir}/slamd-monitor-client" ]
   then
      true
   else
      if [ -e "${curdir}/slamd-monitor-client/slamd-monitor-client.conf" ]
      then
         true
      else
         if [ -e "${swdir}/slamd-monitor-client.zip" ]
         then
            if [ "$debug" == 'on' ];then echo;set -x;fi
            cd "${curdir}"
            unzip -oq ${swdir}/slamd-monitor-client.zip >> ${logdir}/slamd-setup-${now}.log 2>&1
            rc=$?
            set +x
         else
            echo "Error: ${swdir}/slamd-monitor-client.zip missing"
            exit 1
         fi
      fi
   fi
}

##############################################################################
# Install SLAMD
##############################################################################
install_slamd() {
   # Build SLAMD software
   build_slamd

   # Extract SLAMD software
   extractSlamd
}

##############################################################################
# Setup SLAMD Server
##############################################################################
setupSlamdServer() {
   if [ "$(hostname)" != "${localHost}" ];then sudo -n hostnamectl set-hostname ${localHost};fi

   # Install SLAMD
   install_slamd

   # Configure SLAMD server
   if [ -e "${curdir}/slamd/conf/server.xml.tmpl" ]
   then
      true
   elif [ -e "${curdir}/slamd/conf/server.xml" ]
   then
      mv ${curdir}/slamd/conf/server.xml ${curdir}/slamd/conf/server.xml.tmpl
   fi
   sed -e "s/8080/${slamdPort}/g" "${curdir}/slamd/conf/server.xml.tmpl" > "${curdir}/slamd/conf/server.xml"

   # Set server marker
   touch "${cfgdir}/.slamd-server"

   startSlamdServer

   # Create database
   if [ -d "${curdir}/slamd/webapps/slamd/WEB-INF/db" ]
   then
      true
   else
      if [ "$debug" == 'on' ];then echo;set -x;fi
      curl --max-time 600 --connect-timeout 600 -s -d "confirmed=Create Database&type=multipart/form-data" http://${slamdHost}:${slamdPort}/slamd/index.html >> ${logdir}/slamd-setup-${now}.log 2>&1
      rc=$?
      set +x
      sleep 3
   fi
}

##############################################################################
# Setup SLAMD Client
##############################################################################
setupSlamdClient() {
   # Confirm that hostname matches FQDN or client won't start
   myHost=$(hostname)
   if [ "${myHost}" != "${localHost}" ]
   then
      echo "ERROR: Hostname must match FQDN hostname. Run the following to update hostname:"
      echo " sudo -n hostnamectl set-hostname ${localHost}"
      exit 1
   fi   

   # Install SLAMD
   install_slamd

   # Have to start and stop in order to avoid slamd-client.conf from getting
   # overwritten the first time the SLAMD client starts
   # Configure SLAMD client
   if [ -e "${curdir}/slamd-client/slamd-client.conf.tmpl" ]
   then
      true
   elif [ -e "${curdir}/slamd-client/slamd-client.conf" ]
   then
      mv ${curdir}/slamd-client/slamd-client.conf ${curdir}/slamd-client/slamd-client.conf.tmpl
   fi
   sed -e "s/SLAMD_ADDRESS=slamd.*/SLAMD_ADDRESS=${slamdHost}/g" ${curdir}/slamd-client/slamd-client.conf.tmpl > ${curdir}/slamd-client/slamd-client.conf

   # Set client marker
   echo -e "slamdHost=${slamdHost}\nslamdPort=${slamdPort}" > "${cfgdir}/.slamd-client"

   startSlamdClient
}

##############################################################################
# Setup SLAMD Monitor
##############################################################################
setupSlamdMonitor() {
   # Install SLAMD
   install_slamd

   # Configure SLAMD client
   if [ -e "${curdir}/slamd-monitor-client/slamd-monitor-client.conf.tmpl" ]
   then
      true
   elif [ -e "${curdir}/slamd-monitor-client/slamd-monitor-client.conf" ]
   then
      mv ${curdir}/slamd-monitor-client/slamd-monitor-client.conf ${curdir}/slamd-monitor-client/slamd-monitor-client.conf.tmpl
   fi
   sed -e "s/SLAMD_ADDRESS=slamd.example.com.*/SLAMD_ADDRESS=${slamdHost}/g" ${curdir}/slamd-monitor-client/slamd-monitor-client.conf.tmpl > ${curdir}/slamd-monitor-client/slamd-monitor-client.conf

   # Set client marker
   echo -e "slamdHost=${slamdHost}\nslamdPort=${slamdPort}" > "${cfgdir}/.slamd-monitor"

   startSlamdMonitor
}

##############################################################################
# Run setup routines
##############################################################################
setup_slamd() {
   ${curdir}/manage_install.sh install jdk ${fmwFlag}
   case "${cmdArg2}" in
       'slamd') setupSlamdServer;setupSlamdClient;setupSlamdMonitor;;
    'slamdsvr') setupSlamdServer;;
    'slamdcli') setupSlamdClient;;
    'slamdmon') setupSlamdMonitor;;
             *) echo -e "Error: Invalid command.\nRun "${curdir}/${cmd} --help" to see proper usage.";exit 1;;
   esac
}

##############################################################################
# Run baseline SLAMD performance campaign
##############################################################################
slamdRunCampaign() {
   unset JAVA_TOOL_OPTIONS

   # load info file
   getSearchSpans

   if [ -z "${jobFolder}" ]
   then
      jobFolder="${now}-${campaign}"
   fi
   jobFolderEnc=$(echo "${now}-${campaign}"|base64)

   case ${campaign} in
           'baseline') true;;
                'ssl') true;;
            'scaling') true;;
                'kpi') true;;
         'searchrate') true;;
        'searchrate5') true;;
        'searchrateo') true;;
        'searchratem') true;;
       'searchratemy') true;;
      'searchratemem') true;;
           'authrate') true;;
          'authrate5') true;;
          'authrateo') true;;
           'modrateu') true;;
          'modrate1i') true;;
          'modrate2i') true;;
             'adddel') true;;
             'srcmod') true;;
               'mix1') true;;
               'mix2') true;;
         'siteminder') true;;
           'playback') true;;
       'playbackread') true;;
      'playbackwrite') true;;
                    *) echo "Error: Campaign ${campaign} not valid"
                       exit 1
                       ;;
   esac

   # Test inputs before running jobs
   errmsg=''
   if [ -z "${firstUser}" ];then errmsg="${errmsg}\nFirst user missing";fi
   if [ -z "${firstAdmin}" ];then errmsg="${errmsg}\nAdmin user missing";fi
   if [ -z "${suffix}" ];then errmsg="${errmsg}\nSuffix missing";fi

   if [ -n "${errmsg}" ]
   then
      echo -e "Error: Must provide all input parameters\n${errmsg}"
      exit 1
   fi

   echo "Starting ${campaign} SLAMD campaign on ${dsHost}:${dsPort}"
   echo "Clients: ${clients}           Threads per client: ${threads}         Job duration: ${jobDuration} min"
   printf "%-4s%-30s%-25s\n" "Job" "Description" "JobID"
   printf "%-4s%-30s%-25s\n" '---' '-----------------------------' '------------------------'

   # Create a folder specificially for this run
   
   slamdCreateJobFolder

   # Get last jobId from the running and pending queues
   slamdGetLastJobId

   # Queue up Job1, a disabled Null job
   slamdNullJob "${lastSlamdJobId}"
   firstSlamdJobId=${jobId}

   case ${campaign} in
          'baseline') slamdPrimeJob
                      slamdSearchRateJob '*'
                      slamdSearchRateJob 'sn givenName uid mail telephoneNumber'
                      slamdSearchRateJob '1.1'
                      slamdSearchRateJob 'isMemberOf'
                      slamdWhatAreMyGroupsJob 
                      slamdAmIMemberJob 
                      slamdAuthRateJob '*'
                      slamdAuthRateJob 'sn givenName uid mail telephoneNumber'
                      slamdAuthRateJob '1.1'
                      slamdModRateJob 'description' '80' 'Unindexed'
                      slamdModRateJob 'givenName' '80' 'EqIndexed'
                      slamdModRateJob 'cn' '80' 'EqAndPresIndexed'
                      slamdAddDelRateJob '10000'
                      slamdSearchAndModJob
                      slamdMixedLoadJob '70' '10' '10' '5' '5'
                      slamdMixedLoadJob '80' '0' '20' '0' '0'
                      slamdSiteMinderJob
                      ;;
               'ssl') for clients in 1 50 100 200 250
                      do
                         slamdDisconnectAll
                         slamdRequestClients ${clients}

                         dsPort=${ldapPort}
                         if [ $clients -eq 1 ]; then slamdPrimeJob ; fi
                         slamdSearchRateJob '1.1'
                         slamdSearchRateJob '*'

                         ## Now switching to SSL
                         dsPort=${ldapsPort}
                         slamdSearchRateSSLJob '1.1'
                         slamdSearchRateSSLJob '*'

                         numjobs=5
                         sleep `expr ${jobDuration} \* 60 \* ${numjobs} `  # Wait to avoid disconnecting clients 
                      done 
                      ;;
           'scaling') for cores in  1 2 4 8 12 16 20 24 28 32 64
                      do 
                         slamdDisconnectAll
    
                         Psradm ${cores} 
    
                         threads=1
                         clients=`expr $cores \* 5 ` 
                         slamdRequestClients ${clients}
    
                         if [ $cores -eq 1 ]; then slamdPrimeJob ;fi
                         slamdSearchRateJob '1.1'
                         slamdSearchRateJob '*'
                         slamdAuthRateJob '1.1'
                         slamdAuthRateJob '*'
                         slamdModRateJob 'description' '80' 'Unindexed'
                         slamdModRateJob 'givenName' '80' 'EqIndexed'
                         slamdSearchAndModJob
                         slamdMixedLoadJob '70' '10' '10' '5' '5'
                         slamdMixedLoadJob '80' '0' '20' '0' '0'
 
                         numjobs=10
                         sleep `expr ${jobDuration} \* 60 \* ${numjobs} `  # Wait to avoid disconnecting clients 
                      done
                      Psradm
                      ;;
               'kpi') slamdPrimeJob
                      slamdSearchRateJob '*'
                      slamdModRateJob 'description' '80' 'Unindexed'
                      ;;
        'searchrate') slamdSearchRateJob '*';;
       'searchrate5') slamdSearchRateJob 'sn givenName uid mail telephoneNumber';;
       'searchrateo') slamdSearchRateJob '1.1';;
       'searchratem') slamdSearchRateJob 'isMemberOf';;
      'searchratemy') slamdWhatAreMyGroupsJob ;;
     'searchratemem') slamdAmIMemberJob ;;
          'authrate') slamdAuthRateJob '*';;
         'authrate5') slamdAuthRateJob 'sn givenName uid mail telephoneNumber';;
         'authrateo') slamdAuthRateJob '1.1';;
          'modrateu') slamdModRateJob 'description' '80' 'Unindexed';;
         'modrate1i') slamdModRateJob 'givenName' '80' 'EqIndexed';;
         'modrate2i') slamdModRateJob 'cn' '80' 'EqAndPresIndexed';;
            'adddel') slamdAddDelRateJob '10000';;
         'searchmod') slamdSearchAndModJob;;
              'mix1') slamdMixedLoadJob '70' '10' '10' '5' '5';;
              'mix2') slamdMixedLoadJob '80' '0' '20' '0' '0';;
        'siteminder') slamdSiteMinderJob;;
          'playback') playType='all'; playWrites='on'; playReads='on'; slamdLogPlayback;;
      'playbackread') playType='reads';playWrites='off'; playReads='on'; slamdLogPlayback;;
     'playbackwrite') playType='writes';playWrites='on'; playReads='off'; slamdLogPlayback;;
   esac
   # Start sequence by enabling the first Null job
   enableFirstSlamdJob ${firstSlamdJobId}
}

##############################################################################
# Generate combined SLAMD benchmark PDF report
##############################################################################
slamdGenPdfReports() {
   unset JAVA_TOOL_OPTIONS
   for d in $(${curdir}/slamd/tools/list-folders.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/"|grep -v Unclassified)
   do
      if [ -d "${slamdReports}/${d}" ]
      then
         true
      else
         mkdir -p "${slamdReports}/${d}"
      fi

      getJobsByFolder "${d}"

      for id in ${jobs}
      do
         slamdPdfReport="${slamdReports}/${d}/${id}.pdf"
         if [ -e "${slamdPdfReport}" ]
         then
            true
         else
            echo "Generating report ${slamdPdfReport}"
            curl --max-time 600 --connect-timeout 600 -s -o "${slamdPdfReport}" http://${slamdHost}:${slamdPort}/slamd/?sec=job\
\&subsec=generate_report\
\&report_generator=com.slamd.report.PDFReportGenerator\
\&job_id=${id}\
\&confirmed=1\
\&param_include_schedule_config=on\
\&param_include_job_config=on\
\&param_include_stats=on\
\&param_include_monitor_config=on\
\&param_include_graphs=on\
\&param_require_stats=on\
\&param_include_optimizing_iterations=on\
\&param_view_in_browser=off\
\&subit=Continue
         fi
      done
   done
}

##############################################################################
# Generate combined SLAMD benchmark TXT report
##############################################################################
slamdGenTxtReports() {
   unset JAVA_TOOL_OPTIONS
   for d in $(${curdir}/slamd/tools/list-folders.sh -h ${slamdHost} -p ${slamdPort} -u "/slamd/"|grep -v Unclassified)
   do
      if [ -d "${slamdReports}/${d}" ]
      then
         true
      else
         mkdir -p "${slamdReports}/${d}"
      fi

      getJobsByFolder "${d}"

      for id in ${jobs}
      do
         slamdTxtReport="${slamdReports}/${d}/${id}.txt"
         if [ -e "${slamdTxtReport}" ]
         then
            true
         else
            echo "Generating report ${slamdTxtReport}"
            curl --max-time 600 --connect-timeout 600 -s -o "${slamdTxtReport}" http://${slamdHost}:${slamdPort}/slamd/?sec=job\
\&subsec=generate_report\
\&report_generator=com.slamd.report.TextReportGenerator\
\&job_id=${id}\
\&confirmed=1\
\&param_include_schedule_config=off\
\&param_include_job_config=off\
\&param_include_stats=on\
\&param_include_monitor_config=off\
\&param_include_graphs=off\
\&param_require_stats=off\
\&param_include_optimizing_iterations=off\
\&subit=Continue

         fi
      done
   done
}

##############################################################################
# List campaigns
##############################################################################
slamdListCampaigns() {
   unset JAVA_TOOL_OPTIONS
   whichCampaign="${myCampaign}"
   if [ -z "${whichCampaign}" ];then whichCampaign='last';fi
   echo "Campaings:"
   printf "%-35s%-20s\n" 'Campaign'    'Size'
   cd "${slamdReports}"
   for c in $(ls -1d [2-9]* 2> /dev/null)
   do
      size=$(du -hs ${c}|awk '{ print $1 }')
      printf "%-35s%-20s\n" "${c}" "${size}"
   done
   
   exit
}

##############################################################################
# Generate SLAMD benchmark summary
##############################################################################
slamdGenSummary() {
   unset JAVA_TOOL_OPTIONS
   whichCampaign="${myCampaign}"
   if [ -d "${slamdReports}" ];then true; else mkdir -p "${slamdReports}" 2> /dev/null;fi
   cd "${slamdReports}"
   if [ -z "${whichCampaign}" ];then whichCampaign='last';fi
   case ${whichCampaign} in
      'list') echo "Campaings:";ls -1td [2-9]* 2> /dev/null;exit;;
      'last') campaigns=$(ls -1td [2-9]* 2> /dev/null|head -1);;
       'all') campaigns=$(ls -1td [2-9]* 2> /dev/null);;
           *) campaigns=${whichCampaign};;
   esac
 
   for campaign in ${campaigns}
   do
      echo -e "\nCampaign: ${campaign}"
      printf "%-30s%-8s%2s%-7s%2s%-10s%-2s%-20s\n" ''    ''        '' 'Avg' ''  'Total'  ''     ''
      printf "%-30s%-8s%2s%-7s%2s%-10s%-2s%-20s\n" 'Job' 'Ops/Sec' '' 'RT(ms)' '' 'Ops' ' ' 'Result'
      printf "%-30s%-8s%2s%-7s%2s%-10s%-2s%-20s\n" '----------------------------' '--------' '' '-------' '' '----------' ' ' '-----------------------------------'
      for report in $(ls -1rt ${slamdReports}/${campaign}/*.txt 2> /dev/null)
      do
         rData=$(cat "${report}")
         rDesc=$(echo "${rData}"|grep "^Job Description:  " | sed -e "s/.*Job Description:  //g")
         rAvg=$(echo "${rData}"|grep "Avg/Second:"|sed -e "s/.*Avg\/Second://g" -e "s/;//g"|awk '{ print $1 }' | head -1)
         rRes=$(echo "${rData}"|grep "Avg Duration:"|sed -e "s/.*Avg Duration://g" -e "s/;//g"|awk '{ print $1 }' | head -1)
         rCode=$(echo "${rData}"|egrep "^Result Codes|^Search Result|^Modify Result|^Add Result|^Delete Result"|cut -d'(' -f2-|sed -e "s/^/(/g"|tr -d '[\n\r]')
         #echo "DEBUG ${rData}"|egrep '%'
         rCnt=$(echo "${rData}"|grep " Count:"|sed -e "s/.*Count:  //g" -e "s/;.*//g"|head -1)
         if [ -z "${rCode}" ];then rCode='N/A';fi
         if [ -n "${rAvg}" ]
         then
            printf "%-30s%'8.0f%2s%'7.0f%2s%'10.0f%-2s%-20s\n" "${rDesc}" "${rAvg}" ' ' "${rRes}" ' ' "${rCnt}" '  ' "${rCode}"|sed -e "s/\....%)/%)/g" -e "s/(Delete Result Codes --//g"
         fi

         ck4ratios=$(grep -h 'Operation Ratios' ${report})
         if [ -n "${ck4ratios}" ];then echo "${ck4ratios}";fi
      done
   done
}

##############################################################################
# Uninstall SLAMD
##############################################################################
deinstallSlamdServer() {
   if [ -d "${curdir}/slamd" ] && [ -e "${curdir}/slamd/conf/server.xml" ] && [ -e "${cfgdir}/.slamd-server" ]
   then
      stopSlamdServer
      let steps++
      echo "Step: ${steps} - Deinstall SLAMD Server"
      # Rename the config file
      mv ${curdir}/slamd/conf/server.xml ${curdir}/slamd/conf/server.xml.${now}
      # Remove the slamd db
      rm -fr ${curdir}/slamd/webapps/slamd/WEB-INF/db

      # Remove server marker
      rm -f "${cfgdir}/.slamd-server"

      rm -fr ${curdir}/slamd
   fi
}

##############################################################################
# Deinstall SLAMD client
##############################################################################
deinstallSlamdClient() {
   if [ -d "${curdir}/slamd-client" ] && [ -e "${curdir}/slamd-client/slamd-client.conf" ] && [ -e "${cfgdir}/.slamd-client" ]
   then
      stopSlamdClient
      let steps++
      echo "Step: ${steps} - Deinstall SLAMD Client"
      mv "${curdir}/slamd-client/slamd-client.conf" "${curdir}/slamd-client/slamd-client.conf.${now}" 

      # Remove client marker
      rm -f "${cfgdir}/.slamd-client"

      rm -fr ${curdir}/slamd-client
   fi
}

##############################################################################
# Deinstall SLAMD client monitor
##############################################################################
deinstallSlamdMonitor() {
   if [ -d "${curdir}/slamd-monitor-client" ] && [ -e "${curdir}/slamd-monitor-client/slamd-monitor-client.conf" ] && [ -e "${cfgdir}/.slamd-monitor" ]
   then
      stopSlamdMonitor
      let steps++
      echo "Step: ${steps} - Deinstall SLAMD Monitor"
      mv "${curdir}/slamd-monitor-client/slamd-monitor-client.conf" "${curdir}/slamd-monitor-client/slamd-monitor-client.conf.${now}" 

      # Remove monitor marker
      rm -f "${cfgdir}/.slamd-monitor"

      rm -fr ${curdir}/slamd-monitor-client
   fi
}

##############################################################################
# Deinstall SLAMD
##############################################################################
deinstall_slamd() {
   case "${cmdArg2}" in
         'slamd') deinstallSlamdMonitor;deinstallSlamdClient;deinstallSlamdServer;;
      'slamdsvr') deinstallSlamdServer;;
      'slamdcli') deinstallSlamdClient;;
      'slamdmon') deinstallSlamdMonitor;;
               *) deinstallSlamdMonitor;deinstallSlamdClient;deinstallSlamdServer
   esac
}

##############################################################################
# Run end-to-end campaign
##############################################################################
run_on_iaas() {

   # If SLAMD Server is not yet setup on this host, set it up.
   # Otherwise, just restart the SLAMD server to clear out all
   # stale clients
   if [ -e "${curdir}/slamd/conf/server.xml.tmpl" ]
   then
      echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      echo      "=-= Restart SLAMD server to clear stale client connections"
      echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      ${curdir}/manage_slamd.sh stop slamdsvr  --slamdHost ${slamdHost} --slamdPort ${slamdPort} 2>&1 | tee -a ${logdir}/slamd-ctl-svr${x}-${now}.log
      ${curdir}/manage_slamd.sh start slamdsvr --slamdHost ${slamdHost} --slamdPort ${slamdPort} 2>&1 | tee -a ${logdir}/slamd-ctl-svr${x}-${now}.log
   else
      echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      echo      "=-= Setup SLAMD server instance"
      echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      ${curdir}/manage_slamd.sh setup slamdcli -C ${percli} --slamdHost ${slamdHost} --slamdPort ${slamdPort} 2>&1 | tee -a ${logdir}/slamd-setup-cli${x}-${now}.log
   fi

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Show OCI existing infrastructure before starting campaign"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${curdir}/manage_oci.sh list --compartment ${compartment}

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Setup OCI infrastructure for ${campaign} campaign"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   x=1
   while [ ${x} -le ${dr} ]
   do
      ssh-keygen -R ouddr${x} -f "$HOME/.ssh/known_hosts" >> ${logdir}/ssh-${now}.log 2>&1 
      ${curdir}/manage_oci.sh launch --name ouddr${x} --role dr --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} --ocios ${ociOS} &
      let x++
   done

   x=1
   while [ ${x} -le ${ds} ]
   do
      ssh-keygen -R oudds${x} -f "$HOME/.ssh/known_hosts" >> ${logdir}/ssh-${now}.log 2>&1
      ${curdir}/manage_oci.sh launch --name oudds${x} --role ds --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} --ocios ${ociOS} &
      let x++
   done

   x=1
   while [ ${x} -le ${rs} ]
   do
      ssh-keygen -R oudrs${x} -f "$HOME/.ssh/known_hosts" >> ${logdir}/ssh-${now}.log 2>&1
      ${curdir}/manage_oci.sh launch --name oudrs${x} --role rs --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} --ocios ${ociOS} &
      let x++
   done

   x=1
   while [ ${x} -le ${cli} ]
   do
      ssh-keygen -R cli${x} -f "$HOME/.ssh/known_hosts" >> ${logdir}/ssh-${now}.log 2>&1
      ${curdir}/manage_oci.sh launch --name cli${x} --role client --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${clicores} --mem 15 --tag ${now} --ocios ${ociOS} &
      let x++
   done

   # Wait for all compute instance launches to complete
   wait

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Show OCI resource allocation for this ${campaign} campaign"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   grep -h  PrivateIP  ${cfgdir}/oci-*-${now}.resources|uniq
   grep -vh PrivateIP ${cfgdir}/oci-*-${now}.resources

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Setup SLAMD client instance(s)"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   x=1
   while [ ${x} -le ${cli} ]
   do
      echo "Setup SLAMD client cli${x}"
      ssh -qp 22 -o StrictHostKeyChecking=no opc@cli${x} "${curdir}/manage_slamd.sh setup slamdcli -C ${percli} --slamdHost ${slamdHost} --slamdPort ${slamdPort}" 2>&1 | tee -a ${logdir}/oud-setup-cli${x}-${now}.log
      rc=$?
      ssh -qp 22 -o StrictHostKeyChecking=no opc@cli${x} "${curdir}/manage_slamd.sh setup slamdmon --slamdHost ${slamdHost} --slamdPort ${slamdPort}" 2>&1 | tee -a ${logdir}/oud-setup-cli${x}-${now}.log
      rc=$?
      let x++
   done

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Setup OUD instance(s)"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ldifSize=''
   r=0
   dbPeakSize[${r}]="ouddr1|0"
   x=1
   while [ ${x} -le ${dr} ]
   do
      if [ ${x} -eq 1 ]
      then
         echo -e "Setup OUD Directory Server with Replication Server ouddr${x}"
         ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "${curdir}/manage_data.sh genall -n ${templateName} -N ${numUsers} --rm" 2>&1 | tee -a ${logdir}/oud-setup-ouddr${x}-${now}.log
         rc=$?
         if [ ${rc} -ne 0 ];then echo "ERROR: Data Generation failed";exit 1;fi
         ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "${curdir}/manage_oud.sh setup --pnum 1 -n ${templateName} --noroles --schema ${curdir}/samples/${templateName}.schema" --data ${cfgdir}/${templateName}.ldif 2>&1 | tee -a ${logdir}/oud-setup-ouddr${x}-${now}.log 
         rc=$?
         if [ ${rc} -ne 0 ];then echo "ERROR: OUD Setup failed";exit 1;fi
         supplier=$(getent hosts ouddr1|awk '{ print $2 }')
      else
         echo -e "\nSetup OUD Directory Server with Replication Server ouddr${x}"
         ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "${curdir}/manage_data.sh genbatch -n ${templateName} --rm" 2>&1 | tee -a ${logdir}/oud-setup-ouddr${x}-${now}.log
         rc=$?
         if [ ${rc} -ne 0 ];then echo "ERROR: Data Generation failed";exit 1;fi
         if [ -n "${jmem}" ]
         then
            ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "${curdir}/manage_oud.sh setup --pnum 1 -n ${templateName} --jmem ${jmem} --noroles --schema ${curdir}/samples/${templateName}.schema --supplier ${supplier}:${adminPort}" 2>&1 |tee -a ${logdir}/oud-setup-ouddr${x}-${now}.log
            rc=$?
            if [ ${rc} -ne 0 ];then echo "ERROR: OUD Setup failed";exit 1;fi
         else
            echo "ERROR: Cannot determine optimal JVM sizing for ouddr${x}"
         fi
      fi

      # Determine LDIF size
      if [ -z "${ldifSize}" ]
      then
         ldifSize=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr1 "du -ms ${cfgdir}/${templateName}.ldif 2> /dev/null"|awk '{ print $1 }')
         if [ -z "${ldifSize}" ];then ldifSize=4096;fi
         jmem=$(echo ${ldifSize}|awk '{ print int($1*2.5+2048) }')
         if [ -z "${jmem}" ];then jmem=4096;fi
      fi

      # Determine the initial init db size
      dbsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "du -ms ${oudmwdir}/oud1/OUD/db 2> /dev/null"|awk '{ print $1 }')
      if [ -z "${dbsz}" ];then dbsz=0;fi
      clsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "du -ms ${oudmwdir}/oud1/OUD/changelogDb 2> /dev/null"|awk '{ print $1 }')
      dbpk=$(echo "${dbPeakSize[${r}]}"|cut -d'|' -f2)
      if [ -z "${dbpk}" ];then dbpk=0;fi
      if [ ${dbsz} -gt ${dbpk} ];then dbPeakSize[${r}]="ouddr${x}|${dbsz}";fi
      dbPreSize[${r}]="ouddr${x}|${dbsz}"
      clPreSize[${r}]="ouddr${x}|${clsz}"
      let r++
      let x++
   done

   x=1
   while [ ${x} -le ${ds} ]
   do
      echo -e "\nSetup OUD Directory Server oudds${x}"
      ssh -qp 22 -o StrictHostKeyChecking=no opc@oudds${x} "${curdir}/manage_data.sh genbatch -n ${templateName} --rm" 2>&1 | tee -a ${logdir}/oud-setup-oudds${x}-${now}.log
      rc=$?
      if [ -n "${jmem}" ]
      then
        ssh -qp 22 -o StrictHostKeyChecking=no opc@oudds${x} "${curdir}/manage_oud.sh setup --pnum 1 -n ${templateName} --jmem ${jmem} --noroles --schema ${curdir}/samples/${templateName}.schema --supplier ${supplier}:${adminPort}" 2>&1 |tee -a ${logdir}/oud-setup-oudds${x}-${now}.log
        rc=$?
      else
         echo "ERROR: Cannot determine optimal JVM sizing for oudds${x}"
      fi

      # Determine the initial init db size
      dbsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@oudds${x} "du -ms ${oudmwdir}/oud1/OUD/db 2> /dev/null"|awk '{ print $1 }')
      if [ -z "${dbsz}" ];then dbsz=0;fi
      clsz='N/A'
      dbPreSize[${r}]="oudds${x}|${dbsz}"
      dbpk=$(echo "${dbPeakSize[${r}]}"|cut -d'|' -f2)
      if [ -z "${dbpk}" ];then dbpk=0;fi
      if [ ${dbsz} -gt ${dbpk} ];then dbPeakSize[${r}]="ouddr${x}|${dbsz}";fi
      clPreSize[${r}]="oudds${x}|${clsz}"
      let r++
      let x++
   done

   x=1
   while [ ${x} -le ${rs} ]
   do
      echo -e "\nSetup OUD Replication Server oudrs${x}"
      ssh -qp 22 -o StrictHostKeyChecking=no opc@oudrs${x} "${curdir}/manage_data.sh genbatch -n ${templateName} --rm" 2>&1 | tee -a ${logdir}/oud-setup-oudrs${x}-${now}.log
      rc=$?
      if [ -n "${jmem}" ]
      then
         ssh -qp 22 -o StrictHostKeyChecking=no opc@oudrs${x} "${curdir}/manage_oud.sh setup --pnum 1 -n ${templateName} --jmem ${jmem} --noroles --schema ${curdir}/samples/${templateName}.schema --supplier ${supplier}:${adminPort}" 2>&1 |tee -a ${logdir}/oud-setup-oudrs${x}-${now}.log
         rc=$?
      else
         echo "ERROR: Cannot determine optimal JVM sizing for oudrs${x}"
      fi

      # Determine the initial init db size
      dbsz='N/A'
      clsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@oudrs${x} "du -ms ${oudmwdir}/oud1/OUD/changelogDb 2> /dev/null"|awk '{ print $1 }')
      dbPreSize[${r}]="oudrs${x}|${dbsz}"
      clPreSize[${r}]="oudrs${x}|${clsz}"
      let r++
      let x++
   done


   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Show replication status"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr1 "${curdir}/manage_oud.sh rstatus" 2>&1 | tee -a ${logdir}/oud-setup-${now}.log
   rc=$?

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Prepare SLAMD for ${campaign} campaign"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   # Generate local template file
   ${curdir}/manage_data.sh gentempl -n ${templateName} -N ${numUsers} --rm 

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Start ${campaign} campaign"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   # Make service info file from template
   ${curdir}/manage_slamd.sh mksvcinfo -n ${templateName}

   ${curdir}/manage_slamd.sh brun --campaign baseline -h ${supplier} -p ${ldapPort} -C ${clients}

   # Wait for campaign to complete
   r=0
   ckdone=''
   addStarted='false'
   addDone='false'
   while [ "${ckdone}" != 'No jobs in the queue' ]
   do
      sleep 60
      ckdone=$(${curdir}/manage_slamd.sh blist)

      # Determine peak DB size
      ck4add=$(echo "${ckdone}"|grep "(Running)"|awk '{ print $2 }')
      if [ "${ck4add}" == "AddDelRate" ];then addStarted='true';fi
      if [ "${addStarted}" == 'true' ] && [ "${ckdone}" != "AddDeleteRate" ]
      then
         # Determine the post-campaign DB size
         #r=0
         x=1
         while [ ${x} -le ${dr} ]
         do
            # Determine the initial post-campaign DB size
            dbsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "du -ms ${oudmwdir}/oud1/OUD/db 2> /dev/null"|awk '{ print $1 }')
            if [ -z "${dbsz}" ];then dbsz=0;fi
            clsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "du -ms ${oudmwdir}/oud1/OUD/changelogDb 2> /dev/null"|awk '{ print $1 }')
            if [ -z "${clsz}" ];then clsz=0;fi
            dbPostSize[${r}]="ouddr${x}|${dbsz}"
            dbpk=$(echo "${dbPeakSize[${r}]}"|cut -d'|' -f2)
            if [ -z "${dbpk}" ];then dbpk=0;fi
            if [ ${dbsz} -gt ${dbpk} ];then dbPeakSize[${r}]="ouddr${x}|${dbsz}";fi
            clPostSize[${r}]="ouddr${x}|${clsz}"
            let x++
         done

         x=1
         while [ ${x} -le ${ds} ]
         do
            # Determine the initial post-campaign DB size
            dbsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@oudds${x} "du -ms ${oudmwdir}/oud1/OUD/db 2> /dev/null"|awk '{ print $1 }')
            if [ -z "${dbsz}" ];then dbsz=0;fi
            clsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@oudds${x} "du -ms ${oudmwdir}/oud1/OUD/changelogDb 2> /dev/null"|awk '{ print $1 }')
            if [ -z "${clsz}" ];then clsz=0;fi
            dbPostSize[${r}]="oudds${x}|${dbsz}"
            dbpk=$(echo "${dbPeakSize[${r}]}"|cut -d'|' -f2)
            if [ -z "${dbpk}" ];then dbpk=0;fi
            if [ ${dbsz} -gt ${dbpk} ];then dbPeakSize[${r}]="ouddr${x}|${dbsz}";fi
            clPostSize[${r}]="oudds${x}|${clsz}"
            let x++
         done

         x=1
         while [ ${x} -le ${rs} ]
         do
            # Determine the initial post-campaign changelogDb size
            clsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@oudrs${x} "du -ms ${oudmwdir}/oud1/OUD/changelogDb 2> /dev/null"|awk '{ print $1 }')
            dbPostSize[${r}]="oudrs${x}|${dbsz}"
            clPostSize[${r}]="oudrs${x}|${clsz}"
            let x++
         done
      fi
   done

   # Determine the post-campaign DB size
   #r=0
   x=1
   while [ ${x} -le ${dr} ]
   do
      # Determine the initial post-campaign DB size
      dbsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "du -ms ${oudmwdir}/oud1/OUD/db 2> /dev/null"|awk '{ print $1 }')
      if [ -z "${dbsz}" ];then dbsz=0;fi
      clsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@ouddr${x} "du -ms ${oudmwdir}/oud1/OUD/changelogDb 2> /dev/null"|awk '{ print $1 }')
      if [ -z "${clsz}" ];then clsz=0;fi
      dbpk=$(echo "${dbPeakSize[${r}]}"|cut -d'|' -f2)
      if [ -z "${dbpk}" ];then dbpk=0;fi
      if [ ${dbsz} -gt ${dbpk} ];then dbPeakSize[${r}]="ouddr${x}|${dbsz}";fi
      dbPostSize[${r}]="ouddr${x}|${dbsz}"
      clPostSize[${r}]="ouddr${x}|${clsz}"
      let r++
      let x++
   done

   x=1
   while [ ${x} -le ${ds} ]
   do
      # Determine the initial post-campaign DB size
      dbsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@oudds${x} "du -ms ${oudmwdir}/oud1/OUD/db 2> /dev/null"|awk '{ print $1 }')
      clsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@oudds${x} "du -ms ${oudmwdir}/oud1/OUD/changelogDb 2> /dev/null"|awk '{ print $1 }')
      dbPostSize[${r}]="oudds${x}|${dbsz}"
      clPostSize[${r}]="oudds${x}|${clsz}"
      let r++
      let x++
   done

   x=1
   while [ ${x} -le ${rs} ]
   do
      # Determine the initial post-campaign changelogDb size
      clsz=$(ssh -qp 22 -o StrictHostKeyChecking=no opc@oudrs${x} "du -ms ${oudmwdir}/oud1/OUD/changelogDb 2> /dev/null"|awk '{ print $1 }')
      dbPostSize[${r}]="oudrs${x}|${dbsz}"
      clPostSize[${r}]="oudrs${x}|${clsz}"
      let r++
      let x++
   done

   if [ "${norm}" == 'false' ]
   then
      campaigndir=$(${curdir}/manage_slamd.sh bsummary|grep "^Campaign:"|awk '{ print $2 }')
      x=1
      while [ ${x} -le ${cli} ]
      do
         mkdir -p "${logdir}/${campaigndir}/cli${x}"
         rsync -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' opc@cli${x}:${logdir}/. ${logdir}/${campaigndir}/cli${x}/.
         let x++
      done

      echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      echo      "=-= Archive logs and decommission infrastructure used by ${campaign} campaign"
      echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      x=1
      while [ ${x} -le ${dr} ]
      do
         mkdir -p "${logdir}/${campaigndir}/ouddr${x}"
         rsync -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' opc@ouddr${x}:${logdir}/. ${logdir}/${campaigndir}/ouddr${x}/.
         ${curdir}/manage_oci.sh terminate --name ouddr${x} &
         let x++
      done

      x=1
      while [ ${x} -le ${ds} ]
      do
         mkdir -p "${logdir}/${campaigndir}/oudds${x}"
         rsync -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' opc@oudds${x}:${logdir}/. ${logdir}/${campaigndir}/oudds${x}/.
         ${curdir}/manage_oci.sh terminate --name oudds${x} &
         let x++
      done

      x=1
      while [ ${x} -le ${rs} ]
      do
         mkdir -p "${logdir}/${campaigndir}/oudrs${x}"
         rsync -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' opc@oudrs${x}:${logdir}/. ${logdir}/${campaigndir}/oudrs${x}/.
         ${curdir}/manage_oci.sh terminate --name oudrs${x} &
         let x++
      done

      x=1
      while [ ${x} -le ${cli} ]
      do
         ${curdir}/manage_oci.sh terminate --name cli${x} &
         let x++
      done

      # Wait for all compute terminations to complete
      wait
   fi

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Generate SLAMD reports from ${campaign} campaign"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${curdir}/manage_slamd.sh breports

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Show ${campaign} campaign summary"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${curdir}/manage_slamd.sh bsummary -a last

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Show pre-campaign and post-campaing OUD DB sizes"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   printf "%-7s%-9s%-9s%-9s%-9s%-9s%-9s\n" ""         "LDIF" "Init"    "Peak"    "Mature"  "Init"    "Mature"
   printf "%-7s%-9s%-9s%-9s%-9s%-9s%-9s\n" "OUD"      "Size" "DB Size" "DB Size" "DB Size" "CL Size" "CL Size"
   printf "%-7s%-9s%-9s%-9s%-9s%-9s%-9s\n" "Instance" "(MB)" "(MB)"    "(MB)"    "(MB)"    "(MB)"    "(MB)"
   x=0
   while [ ${x} -le ${r} ]
   do
      inst=$(echo ${dbPreSize[${x}]}|cut -d'|' -f1)
      dbpre=$(echo ${dbPreSize[${x}]}|cut -d'|' -f2)
      dbpeak=$(echo ${dbPeakSize[${x}]}|cut -d'|' -f2)
      dbpost=$(echo ${dbPostSize[${x}]}|cut -d'|' -f2)
      clpre=$(echo ${clPreSize[${x}]}|cut -d'|' -f2)
      clpost=$(echo ${clPostSize[${x}]}|cut -d'|' -f2)
      if [ -n "${inst}" ];then printf "%-7s%-9s%-9s%-9s%-9s%-9s%-9s\n" "${inst}" "${ldifSize}" "${dbpre}" "${dbpeak}" "${dbpost}"  "${clpre}"  "${clpost}";fi
      let x++
   done
}

##############################################################################
# Stop all campaigns that are in progress and decommission the infrastructure
##############################################################################
terminate_jobs() {
   pids=$(ps -ef|grep manage_slamd.sh|grep brun|awk '{ print $2 }')
   if [ -n "${pids}" ]
   then
      echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      echo      "=-= Cancel active SLAMD campagin(s)"
      echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      kill -9 ${pids}
   fi

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Cancel all running and pending SLAMD jobs"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   slamdCancelJobs

   decommision_infrastructure
}

##############################################################################
# Run end-to-end campaign
##############################################################################
decommision_infrastructure() {
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Archive logs and decommission infrastructure used by ${campaign} campaign"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   x=1
   while [ ${x} -le ${dr} ]
   do
      mkdir -p "${logdir}/${campaigndir}/ouddr${x}"
      rsync -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' opc@ouddr${x}:${logdir}/. ${logdir}/${campaigndir}/ouddr${x}/.
      ${curdir}/manage_oci.sh terminate --name ouddr${x} &
      let x++
   done

   x=1
   while [ ${x} -le ${ds} ]
   do
      mkdir -p "${logdir}/${campaigndir}/oudds${x}"
      rsync -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' opc@oudds${x}:${logdir}/. ${logdir}/${campaigndir}/oudds${x}/.
      ${curdir}/manage_oci.sh terminate --name oudds${x} &
      let x++
   done

   x=1
   while [ ${x} -le ${rs} ]
   do
      mkdir -p "${logdir}/${campaigndir}/oudrs${x}"
      rsync -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' opc@oudrs${x}:${logdir}/. ${logdir}/${campaigndir}/oudrs${x}/.
      ${curdir}/manage_oci.sh terminate --name oudrs${x} &
      let x++
   done

   x=1
   while [ ${x} -le ${cli} ]
   do
      ${curdir}/manage_oci.sh terminate --name cli${x} &
      let x++
   done

   # Wait for all compute terminations to complete
   wait
}

##############################################################################
# Monitor connection ratio for the last 1,000 log entrires
##############################################################################
watch_conn_ratio() {
   alog="${oudmwdir}/oud1/OUD/logs/access"
   while true
   do
      c=$(tail -${rspan} ${alog}|grep -c ' CONNECT ')
      r=$(tail -${rspan} ${alog}|grep -c ' REQ ')
      ra=$((${r}/${c}))
      echo "Connections=${c}  Requests=${r}   Ratio=${ra}"
      sleep 10
   done
}

##############################################################################
# Prep for genload/genproxyload
##############################################################################
prepload() {
   # Setup a bad trust store for invalid auth attempt
   if [ -e "${cfgdir}/badt" ]
   then
      true
   else
      ${curdir}/manage_certs.sh gencert -h test.example.com --step ${steps} >> ${logdir}/loadem-${now}.log 2>&1
      cp ${cfgdir}/certs/test.example.com/test.example.com.jks ${cfgdir}/badt >> ${logdir}/loadem-${now}.log 2>&1
      $JAVA_HOME/bin/keytool -delete -alias root-ca-chain  -keystore "${cfgdir}/badt" -storetype JKS -storepass "${bPW}" >> ${logdir}/loadem-${now}.log 2>&1
   fi

   # Setup large data set to periodically add and remove
   if [ -e "${cfgdir}/2k.ldif" ]
   then
      true
   else
      if [ -e "${cfgdir}/inetorg.ldif" ]
      then
         mkdir ${cfgdir}/inetorg.backup-${now}
         mv ${cfgdir}/inetorg.* ${cfgdir}/inetorg.backup-${now}
      fi

      ${curdir}/manage_data.sh genall -n inetorg -N 2000 --rm
      mv ${cfgdir}/inetorg.ldif ${cfgdir}/2k.ldif
      mv ${cfgdir}/inetorg.dn ${cfgdir}/2k.dn

      # Restore original inetorg files
      if [ -d "${cfgdir}/inetorg.backup-${now}" ]
      then
         mv ${cfgdir}/inetorg.* ${cfgdir}/inetorg.backup-${now}
         mv ${cfgdir}/inetorg.backup-${now}/* ${cfgdir}
      fi
   fi
   
   # Add nefarious admin user
   if [ -e "${cfgdir}/badadmin" ]
   then
      true
   else
      cat > ${cfgdir}/badadmin <<EOF
dn: cn=baddy,cn=Root DNs,cn=config
ds-cfg-alternate-bind-dn: cn=baddy
sn: Bad
cn: baddy
userpassword: ${bPW}
objectClass: ds-cfg-root-dn-user
objectClass: top
objectClass: organizationalPerson
objectClass: person
objectClass: inetOrgPerson
givenName: Baddy
EOF
   fi

   # Add nefarious user
   if [ -e "${cfgdir}/baduser" ]
   then
      true
   else
      cat > ${cfgdir}/baduser <<EOF
dn: cn=baddy,${suffix}
sn: Bad
cn: baddy
userpassword: ${bPW}
objectClass: top
objectClass: organizationalPerson
objectClass: person
objectClass: inetOrgPerson
givenName: Baddy
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search
ds-privilege-name: modify-acl
ds-privilege-name: bypass-acl
ds-privilege-name: server-restart
ds-privilege-name: server-shutdown
ds-privilege-name: update-schema
EOF
   fi
}

##############################################################################
# Apply constant lightweight load to OUD1 for EM/OMC monitoring
##############################################################################
genload() {
   prepload

   echo "Start light mixed load to OUD${pnum}"
   q=0
   while true
   do
      maxTime=$((RANDOM % 60 + 60))

      # Add baddy users to show privilege escalation/lateral movement
      ${oudmwdir}/oud/bin/ldapmodify -h ${dsHost} -Z -X -p ${pnum}444 -D "${bDN}" -j "${jPW}" -a -c -f ${cfgdir}/badadmin >> ${logdir}/loadem-${now}.log 2>&1
      ${oudmwdir}/oud/bin/ldapdelete -h ${dsHost} -Z -X -p ${pnum}636 -D "cn=baddy" -j "${jPW}" "cn=baddy,${suffix}" >> ${logdir}/loadem-${now}.log 2>&1
      ${oudmwdir}/oud/bin/ldapmodify -h ${dsHost} -Z -X -p ${pnum}636 -D "cn=baddy" -j "${jPW}" -a -c -f ${cfgdir}/baduser >> ${logdir}/loadem-${now}.log 2>&1

      if [ "$debug" == 'on' ];then echo;set -x;fi 
      timeout ${maxTime} ${curdir}/${cmd} searchrate --host ${dsHost} -n ${templateName} --interval 60 -p ${pnum}389 -M $(( RANDOM % 10 )) -m 200 >> ${logdir}/loadem-${now}.log 2>&1 &
      timeout ${maxTime} ${curdir}/${cmd} modrate    --host ${dsHost} -n ${templateName} --interval 60 -p ${pnum}389 -M $(( RANDOM % 10 )) -m 100 >> ${logdir}/loadem-${now}.log 2>&1 &
      timeout ${maxTime} ${curdir}/${cmd} authrate   --host ${dsHost} -n ${templateName} --interval 60 -p ${pnum}389 -M $(( RANDOM % 10 )) -m 100 >> ${logdir}/loadem-${now}.log 2>&1 &

      timeout ${maxTime} ${curdir}/manage_tshark.sh test --host ${dsHost} --pnum ${pnum} >> ${logdir}/loadem-${now}.log 2>&1 &

      # User exfiltration
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub uid=* > /dev/null 2>&1 &

      # Un-indexed search
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub objectClass=top > /dev/null 2>&1 &

      # Search with page control
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub --simplePageSize 250 objectClass=inetOrgPerson dn > /dev/null 2>&1 &

      # Search with getEffectiveRights control
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub -J effectiverights "(uid=admin1)" aclRights > /dev/null 2>&1 &

      # Bad authentications
      timeout ${maxTime} ${curdir}/${cmd} authrate --host ${dsHost} -n ${templateName} --interval 60 -p ${pnum}389 -M 1 -m 1000000 -w "badpassword" >> ${logdir}/loadem-${now}.log 2>&1 &

      # Perform encrypted search with bad trust store
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -p ${pnum}636 -D "${bDN}" -j "${jPW}" -P "${cfgdir}/badt" --trustStorePassword "${bPW}"  -b cn=schema -s base objectClass=top dn >> ${logdir}/loadem-${now}.log 2>&1 &

      # Add or delete a 2k users
      if [ ${q} -eq 10 ]
      then
         timeout ${maxTime} ${oudmwdir}/oud/bin/ldapmodify -h ${dsHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" -a -c -f "${cfgdir}/2k.ldif" >> ${logdir}/loadem-${now}.log 2>&1 &
      elif [ ${q} -eq 20 ]
      then
         timeout ${maxTime} ${oudmwdir}/oud/bin/ldapdelete -h ${dsHost} -Z -X -p ${pnum}636 -D "${bDN}" -j "${jPW}" -c -f "${cfgdir}/2k.dn" >> ${logdir}/loadem-${now}.log 2>&1 &
         q=1
      fi

      sleep ${maxTime}

      pids=$(ps -ef 2> /dev/null|egrep -i 'com.unboundid.ldap.sdk.examples|searchrate|authrate|modrate|addrate|delrate|manage_slamd.sh|ldapsearch|ldapmodify|ldapdelete'|egrep -v "grep"|awk '{ print $2 }'|grep -v $$)
      trap "kill -9 ${pids}" SIGKILL SIGINT SIGHUP SIGQUIT
      wait
      let q++
      rm -f ${logdir}/loadem-*.log
   done
}

##############################################################################
# Apply constant lightweight load to PROXY1 for EM/OMC monitoring
##############################################################################
genproxyload() {
   prepload

   echo "Start light mixed load to PROXY${pnum}"
   q=0
   while true
   do
      maxTime=$((RANDOM % 60 + 60))

      # Add baddy users to show privilege escalation/lateral movement
      ${oudmwdir}/oud/bin/ldapmodify -h ${dsHost} -Z -X -p ${pnum}445 -D "${bDN}" -j "${jPW}" -a -c -f ${cfgdir}/badadmin >> ${logdir}/loadem-${now}.log 2>&1
      ${oudmwdir}/oud/bin/ldapdelete -h ${dsHost} -Z -X -p ${pnum}637 -D "cn=baddy" -j "${jPW}" "cn=baddy,${suffix}" >> ${logdir}/loadem-${now}.log 2>&1
      ${oudmwdir}/oud/bin/ldapmodify -h ${dsHost} -Z -X -p ${pnum}637 -D "cn=baddy" -j "${jPW}" -a -c -f ${cfgdir}/baduser >> ${logdir}/loadem-${now}.log 2>&1

      if [ "$debug" == 'on' ];then echo;set -x;fi 
      timeout ${maxTime} ${curdir}/${cmd} searchrate --host ${dsHost} -n ${templateName} --interval 60 -p ${pnum}390 -M $(( RANDOM % 10 )) -m 200 >> ${logdir}/loadem-${now}.log 2>&1 &
      timeout ${maxTime} ${curdir}/${cmd} modrate    --host ${dsHost} -n ${templateName} --interval 60 -p ${pnum}390 -M $(( RANDOM % 10 )) -m 100 >> ${logdir}/loadem-${now}.log 2>&1 &
      timeout ${maxTime} ${curdir}/${cmd} authrate   --host ${dsHost} -n ${templateName} --interval 60 -p ${pnum}390 -M $(( RANDOM % 10 )) -m 100 >> ${logdir}/loadem-${now}.log 2>&1 &

#      timeout ${maxTime} ${curdir}/manage_tshark.sh test --host ${dsHost} --pnum ${pnum} >> ${logdir}/loadem-${now}.log 2>&1 &

      # User exfiltration
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${pnum}637 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub uid=* > /dev/null 2>&1 &

      # Un-indexed search
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${pnum}637 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub objectClass=top > /dev/null 2>&1 &

      # Search with page control
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${pnum}637 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub --simplePageSize 250 objectClass=inetOrgPerson dn > /dev/null 2>&1 &

      # Search with getEffectiveRights control
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${pnum}637 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub -J effectiverights "(uid=admin1)" aclRights > /dev/null 2>&1 &

      # Bad authentications
      timeout ${maxTime} ${curdir}/${cmd} authrate --host ${dsHost} -n ${templateName} --interval 60 -p ${pnum}390 -M 1 -m 1000000 -w "badpassword" >> ${logdir}/loadem-${now}.log 2>&1 &

      # Perform encrypted search with bad trust store
      timeout ${maxTime} ${oudmwdir}/oud/bin/ldapsearch -T -h ${dsHost} -Z -p ${pnum}637 -D "${bDN}" -j "${jPW}" -P "${cfgdir}/badt" --trustStorePassword "${bPW}"  -b cn=schema -s base objectClass=top dn >> ${logdir}/loadem-${now}.log 2>&1 &

      # Add or delete a 2k users
      if [ ${q} -eq 10 ]
      then
         timeout ${maxTime} ${oudmwdir}/oud/bin/ldapmodify -h ${dsHost} -Z -X -p ${pnum}637 -D "${bDN}" -j "${jPW}" -a -c -f "${cfgdir}/2k.ldif" >> ${logdir}/loadem-${now}.log 2>&1 &
      elif [ ${q} -eq 20 ]
      then
         timeout ${maxTime} ${oudmwdir}/oud/bin/ldapdelete -h ${dsHost} -Z -X -p ${pnum}637 -D "${bDN}" -j "${jPW}" -c -f "${cfgdir}/2k.dn" >> ${logdir}/loadem-${now}.log 2>&1 &
         q=1
      fi

      sleep ${maxTime}

      pids=$(ps -ef 2> /dev/null|egrep -i 'com.unboundid.ldap.sdk.examples|searchrate|authrate|modrate|addrate|delrate|manage_slamd.sh|ldapsearch|ldapmodify|ldapdelete'|egrep -v "grep"|awk '{ print $2 }'|grep -v $$)
      trap "kill -9 ${pids}" SIGKILL SIGINT SIGHUP SIGQUIT
      wait
      let q++
      rm -f ${logdir}/loadem-*.log
   done
}

##############################################################################
# Apply constant lightweight load for EM/OMC monitoring
##############################################################################
stopload() {
   echo "Stop load"
   ps -ef|egrep -i "timeout|manage_slamd.sh genload|com.unboundid.ldap.sdk.examples.|ldapsearch|ldapmodify|ldapdelete"|awk '{ print $2 }'|grep -v "^$$$"| xargs -n 1 kill
}

##############################################################################
# Make DN list file
##############################################################################
mkDnFile() {
   if [ -e "${cfgdir}/${templateName}.ldif" ]
   then
      echo "Make DN list file"
      grep "^dn: " ${cfgdir}/${templateName}.ldif |sed -e "s/^dn: //g" > ${dnFile}
   else
      echo "ERROR: LDIF file does not exist"
      exit 1
   fi
}

##############################################################################
# Make RDN list file
##############################################################################
mkRdnFile() {
   if [ -e "${cfgdir}/${templateName}.ldif" ]
   then
      echo "Make RDN list file"
      grep "^dn: " ${cfgdir}/${templateName}.ldif|sed -e "s/^dn: //g"|cut -d',' -f1 > ${rdnFile}
   else
      echo "ERROR: LDIF file does not exist"
      exit 1
   fi
}

###############################################################################
# Check requisites
###############################################################################
if [ "${subcmd}" != 'mksvcinfo' ] && [ "${subcmd}" != 'bruniaas' ] && [ "${subcmd}" != 'setup' ] && [ "${subcmd}" != 'start' ] && [ "${subcmd}" != 'stop' ] && [ "${subcmd}" != 'deinstall' ] && [ "${subcmd}" != 'status' ] && [ "${subcmd}" != 'blist' ] && [ "${subcmd}" != 'clist' ]
then
   slamdReqCheck
fi

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
        'install') install_slamd;;
          'setup') setup_slamd;;
      'deinstall') deinstall_slamd;;
         'status') status_slamd;;
           'stop') stop_slamd;;
          'start') start_slamd;;
           'brun') slamdRunCampaign;;
          'blist') slamdListJobs;;
          'clist') slamdListCampaigns;;
        'bcancel') slamdCancelJobs;;
         'cpurge') slamdPurgeCampaign;;
      'bpurgeall') slamdPurgeAllData;;
     'bpurgelogs') slamdPurgeLogs;;
       'breports') slamdGenTxtReports;;
    'bpdfreports') slamdGenPdfReports;;
    'btxtreports') slamdGenTxtReports;;
       'bsummary') slamdGenSummary;;
      'mksvcinfo') make_service_info_file;;
     'searchrate') demoPresenceSearchRate;;
    'bsearchrate') demoBaseSearchRate;;
    'gsearchrate') demoGroupSearchRate;;
   'glsearchrate') demoGroupListSearchRate;;
   'ulsearchrate') demoListUsersGroups;;
    'isearchrate') demoSearchIsMemberOf;;
        'modrate') demoModRate;;
        'addrate') demoAddRate2;;
        'delrate') demoDelRate;;
       'bindrate') demoBindRate;;
       'authrate') demoAuthRate;;
 'searchbindrate') demoSearchBindRate;;
         'search') ldapSearch;;
   'securesearch') ldapSecureSearch;;
       'bruniaas') run_on_iaas;;
      'terminate') terminate_jobs;;
    'decommision') decommision_infrastructure;;
     'watchratio') watch_conn_ratio;;
    'addplayback') addSlamdLogPlaybackClass;;
        'genload') genload;;
   'genproxyload') genproxyload;;
       'stopload') stopload;;
       'mkdnfile') mkDnFile;;
      'mkrdnfile') mkRdnFile;;
       'benchtns') demoBenchTNS;;
     'addclients') slamdRequestClients ${clients};;
                *) showUsage;;

esac

# Optimize "SearchRate all attrs"
#sec" VALUE="job">
#subsec" VALUE="optimize">
#job_class" VALUE="com.slamd.jobs.ldap.BasicSearchRateJob">
#optimization_algorithm" VALUE="com.slamd.job.SingleStatisticOptimizationAlgorithm">
#job_description" VALUE="SearchRate all attrs"
#include_thread"></TD>
#display_in_read_only"></TD>
#job_start_time" VALUE="20210511130640"
#job_duration" VALUE="11 minutes"
#time_between_startups" VALUE="0"
#job_num_clients" VALUE="20"
#job_monitor_clients_if_available=${monitor}
#job_threads_min" VALUE="1"
#job_threads_max" VALUE=""
#thread_increment" VALUE="1"
#job_thread_startup_delay" VALUE="0"
#stat_interval" VALUE="10 seconds"
#max_non_improving" VALUE="1"
#re_run_best"></TD>
#re_run_duration" VALUE=""
#optimization_param_min_pct_improvement" VALUE="0.0"
#param_address" VALUE="ouddr2.sub01271548250.eastvcn.oraclevcn.com"
#param_port" VALUE="${ldapPort}"
#param_bind_dn" VALUE="uid=admin1,ou=Admins,${suffix}"
#param_bind_password" VALUE="${bPW}"
#param_base_dn_pattern" VALUE="ou=People,${suffix}"
#param_filter_pattern" VALUE="uid=user[5000000-5499999]"
#param_warm_up_duration" VALUE="60"
#param_cool_down_duration" VALUE="60"
#confirmed" VALUE="Test Job Parameters">
#confirmed" VALUE="Schedule">
#confirmed" VALUE="Cancel">
