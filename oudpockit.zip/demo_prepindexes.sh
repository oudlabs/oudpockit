#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# The purpose of this demo is to prepare source schema for loading into OUD
###############################################################################
unset JAVA_TOOL_OPTIONS
batchFile="${cfgdir}/indexes-${now}.batch"
useSSL=''
schemaFiles=( )
dseFile=''

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [options]

SYNOPSIS
     Prepare index configuration file:
        ${cmd} --schema /<path>/<schema_file> [Options]

     Prepare all schema files in a directory:
        ${cmd} --schemadir /<schema_directory> [Options]

     Prepare schema from source directory server from LDAP query:
        ${cmd} -h <host> -p <ldap_port> [-Z] [Options]

DESCRIPTION
     Custom schema preparation tool for migrating to OUD.

OPTIONS
     Options
     The following options are supported:

         --debug [-z]            Debug mode

         --norm                  Do not remove the temporary files from 

         --in                    List schema to be added to OUD

         --out                   List schema filtered out from being added to OUD

         --schema /<dir>/<file>  Custom schema file

         --schemadir /<dir>      Directory containing multiple schema files

         --host [-h]             Host of the source directory

         --port [-p]             LDAP port of the source directory

         --useSSL [-Z]           Use SSL/TLS connection to source directory

         --sdn                   Source directory DN
                                 Default: Anonymous DN

         --spw                   Source directory password file

EOF

   exit 1
}
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
   OPT=$1
   shift
   case $OPT in
       --*) case ${OPT:2} in
           help) showUsage;;
           swdir) swdir="$1";shift;;
           bitsdir) bitsdir="$1";shift;;
           schema) schemaIn="$1";shift;;
           dse) dseFile="$1";shift;;
           schemadir) schemaDirIn="$1";shift;;
           indexlimit) indexlimit="$1";shift;;
           host) dsHost="$1";shift;;
           port) dsPort="$1";shift;;
           sdn) srcDN="$1";shift;;
           spw) srcPW="$1";shift;;
           useSSL) useSSL='-Z -X';;
           debug) dbg="true";dbgFlag=' -z ';;
           14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
       esac;;
       -*) case ${OPT:1} in
           h) dsHost="$1";shift;;
           p) dsPort="$1";shift;;
           Z) useSSL='-Z -X';;
           H) showUsage;;
           z) dbg="true";dbgFlag=' -z ';;
       esac;;
   esac
done

if [ -z "${schemaIn}" ];then schemaIn="${tmpdir}/mySchema-v0-${now}.ldif";fi
if [ -z "${indexlimit}" ];then indexlimit=10000;fi
sName=$(basename ${schemaIn})

###############################################################################
# If host/port provided, retrieve the schema via ldapsearch
###############################################################################
if [ -n "${dsHost}" ] && [ -n "${dsPort}" ]
then
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_install.sh install oud --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag} --step ${steps}
   set +x

   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Retrieve custom schema from directory server (${dsHost}:${dsPort})"
   if [ "${dbg}" == 'true' ];then set -x;fi

   # Check for most common schema
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} -b "cn=schema" -s base '(|(objectClass=ldapSubEntry)(objectClass=subSchema)(cn=schema)(cn=subSchemaSubentry)(cn=subschema))' attributeTypes objectClasses attributeType objectClass 2> /dev/null |egrep -i "^obj|^attr"|grep -i " NAME " > ${schemaIn}
   rc=$?
   set +x

   # Check for OID schema
   if [ -s "${schemaIn}" ]
   then
      true
   else

      if [ -n "${srcDN}" ] && [ -s "${srcPW}" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} ${oidCreds} -D "${srcDN}" -j "${srcPW}" -b "cn=subSchemaSubentry" -s base '(|(objectClass=ldapSubEntry)(objectClass=subSchema)(cn=schema)(cn=subSchemaSubentry)(cn=subschema))' attributeTypes objectClasses attributeType objectClass 2>&1 |egrep -i "^obj|^attr|deny anonymous bind"|egrep -i " NAME |deny anonymous bind" > ${schemaIn}
         rc=$?
         set +x
      else
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} ${oidCreds} -b "cn=subSchemaSubentry" -s base '(|(objectClass=ldapSubEntry)(objectClass=subSchema)(cn=schema)(cn=subSchemaSubentry)(cn=subschema))' attributeTypes objectClasses attributeType objectClass 2>&1 |egrep -i "^obj|^attr|deny anonymous bind"|egrep -i " NAME |deny anonymous bind" > ${schemaIn}
         rc=$?
         set +x
      fi

      ck4anon=$(grep 'Server is Configured to Deny Anonymous Binds' ${schemaIn})
      if [ ${rc} -ne 0 ] && [ -s "${schemaIn}" ] && [ -n "${ck4anon}" ] 
      then
         echo "ERROR: OID is configured to deny anonymous bind.  Please provide"
         echo "   --sdn <binddn> --spw <bindpw_file>"
         exit 1
      elif [ ${rc} -ne 0 ] && [ -e "${schemaIn}" ] && [ -z "${ck4anon}" ] && [ -n "${srcDN}" ] && [ -n "${srcPW}" ] 
      then
         echo "ERROR: Invalid OID credentials"
         echo "   --sdn <binddn> --spw <bindpw_file>"
         exit 1
      fi
   fi

   # Check for OpenLDAP schema
   if [ -s "${schemaIn}" ]
   then
      true
   else
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${lsrch} -T -h ${dsHost} ${useSSL} -p ${dsPort} -b "cn=subschema" -s base '(|(objectClass=ldapSubEntry)(objectClass=subSchema)(cn=schema)(cn=subSchemaSubentry)(cn=subschema))' attributeTypes objectClasses attributeType objectClass 2> /dev/null |egrep -i "^obj|^attr"|grep -i " NAME " > ${schemaIn}
      rc=$?
      set +x
   fi

   if [ -s "${schemaIn}" ]
   then
      schemaFiles[0]="${schemaIn}"
   else
      echo "Error: Input schema file (${sName}) from ldapsearch is empty."
      exit 1
   fi
fi

# Handle specifying a schema directory
if [ -n "${dseFile}" ]
then
   # Extract all existing indexes from OUD's config.ldif
   egrep -i "cn=Index,cn=|ds-cfg-index-type" ${oudmwdir}/oud1/OUD/config/config.ldif|sed -e "s/dn: ds-cfg-attribute=/BBOOLLidx:/g" -e "s/ds-cfg-index-type: /|/g" -e "s/,cn=Index,cn=/|/g" -e "s/,.*//g"|tr -d '[\n\r]'|sed -e "s/BBOOLLidx:/\n/g"|grep '|' > ${schemaIn}.dest

   # Extract all equality, presence, and substring indexes from dse.ldif
   egrep -i "cn=ldbm database|nsIndexType:" ${dseFile}|sed -e "s/^dn: cn=/idx:/g" -e "s/,cn=.*ldbm.*//g" -e "s/, cn=.*ldbm.*//g" -e "s/nsIndexType: /|/g" -e "s/^idx:/BBOOLLidx:/g"|egrep "^BBOOLLidx:|^\|"|tr -d '[\n\r]'|sed -e "s/BBOOLLidx:/\n/g"|egrep -i "\|eq||\|pres\|sub"|sed -e "s/|eq/|equality/g" -e "s/|sub/|substring/g" -e "s/|pres/|presence/g" > ${schemaIn}
   schemaFiles[0]="${schemaIn}"

   # Extract VLV indexes from dse.ldif

elif [ -n "${schemaDirIn}" ]
then
   if [ -d "${schemaDirIn}" ]
   then
      readarray -t schemaFiles <<< $(ls -1 ${schemaDirIn}/* 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")
   else
      echo "Schema directory is not a directory."
      exit 1
   fi
else
   # Handle specifying a specific schema file
   if [ -e "${schemaIn}" ]
   then
      if [ -s "${schemaIn}" ]
      then
         schemaFiles[0]="${schemaIn}"
      else
         echo "Error: schema file (${schemaIn}) is empty"
         exit 1
      fi
   else
      echo "Error: schema file (${schemaIn}) does not exist"
      exit 1
   fi
fi

###############################################################################
# Confirm that custom schema exists
###############################################################################
if [ ${#schemaFiles[*]} -eq 0 ]
then
   echo "Error: No custom schema found"
   exit 1
fi


###############################################################################
# Determine list of attributes with indexes from schema files
###############################################################################
if [ ${#schemaFiles[*]} -gt 1 ]
then
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "DEMO --> Deriving indexing from schema of ${#schemaFiles[*]} attributes"
fi
a=0
attrs=( )
for (( x=0; x< ${#schemaFiles[*]}; x++ ))
do
   newattrs=$(cat "${schemaFiles[${x}]}"|egrep -i "presence|equality|substring|ordering"|grep -v 2.16.840.1.113894.104.1.19|sed -e "s/^.*NAME '//g" -e "s/'.*//g" -e "s/^/ /g"|tr -d '[\n\r]')
   for attr in ${newattrs}
   do
      attrs[${a}]="${attr}"
      let a++
   done
done

# Sort and uniq the attribute list
attrs=($(echo "${attrs[@]}"|tr ' ' '\n'|sort|uniq|cut -d'|' -f1|tr '\n' ' '))

###############################################################################
# Determine indexes per attr
###############################################################################
echo -e "Processing attributes\c"
show10='true'
show20='true'
show30='true'
show40='true'
show50='true'
show60='true'
show70='true'
show80='true'
show90='true'
for (( a=0; a< ${#attrs[*]}; a++ ))
do
   if [ ${a} -gt 0 ]
   then
      pct=$(echo "scale=1; 100*(${a}/${#attrs[*]})"|bc)
      if [ ${pct} == '10.0' ] && [ ${show10} == 'true' ];then echo -e ".10%\c";show10='false';fi
      if [ ${pct} == '20.0' ] && [ ${show20} == 'true' ];then echo -e ".20%\c";show20='false';fi
      if [ ${pct} == '30.0' ] && [ ${show30} == 'true' ];then echo -e ".30%\c";show30='false';fi
      if [ ${pct} == '40.0' ] && [ ${show40} == 'true' ];then echo -e ".40%\c";show40='false';fi
      if [ ${pct} == '50.0' ] && [ ${show50} == 'true' ];then echo -e ".50%\c";show50='false';fi
      if [ ${pct} == '60.0' ] && [ ${show60} == 'true' ];then echo -e ".60%\c";show60='false';fi
      if [ ${pct} == '70.0' ] && [ ${show70} == 'true' ];then echo -e ".70%\c";show70='false';fi
      if [ ${pct} == '80.0' ] && [ ${show80} == 'true' ];then echo -e ".80%\c";show80='false';fi
      if [ ${pct} == '90.0' ] && [ ${show90} == 'true' ];then echo -e ".90%\c";show90='false';fi
   fi
  
   presence=''
   equality=''
   substring=''
   ordering=''
   indexAction="create-local-db-index"
   for (( x=0; x< ${#schemaFiles[*]}; x++ ))
   do
      ck4pr=$(egrep "'${attrs[${a}]}'|^${attrs[${a}]}\|" ${schemaFiles[${x}]}|grep -i presence)
      ck4existingpr=$(grep -i "${attrs[${a}]}|userRoot" ${schemaIn}.dest|grep -i presence)
      if [ -n "${ck4existingpr}" ];then indexAction="set-local-db-index-prop";fi
      if [ -n "${ck4pr}" ] && [ -z "${ck4existingpr}" ];then presence=' --set index-type:presence';fi

      ck4eq=$(egrep "'${attrs[${a}]}'|^${attrs[${a}]}\|" ${schemaFiles[${x}]}|grep -i equality)
      ck4existingpr=$(grep -i "${attrs[${a}]}|userRoot" ${schemaIn}.dest|grep -i equality)
      if [ -n "${ck4existingpr}" ];then indexAction="set-local-db-index-prop";fi
      if [ -n "${ck4eq}" ] && [ -z "${ck4existingpr}" ];then equality=' --set index-type:equality';fi

      ck4su=$(egrep "'${attrs[${a}]}'|^${attrs[${a}]}\|" ${schemaFiles[${x}]}|grep -i substring)
      ck4existingpr=$(grep -i "${attrs[${a}]}|userRoot" ${schemaIn}.dest|grep -i substring)
      if [ -n "${ck4existingpr}" ];then indexAction="set-local-db-index-prop";fi
      if [ -n "${ck4su}" ] && [ -z "${ck4existingpr}" ];then substring=' --set index-type:substring';fi

      ck4or=$(egrep "'${attrs[${a}]}'|^${attrs[${a}]}\|" ${schemaFiles[${x}]}|grep -i ordering)
      ck4existingpr=$(grep -i "${attrs[${a}]}|userRoot" ${schemaIn}.dest|grep -i ordering)
      if [ -n "${ck4existingpr}" ];then indexAction="set-local-db-index-prop";fi
      if [ -n "${ck4or}" ] && [ -z "${ck4existingpr}" ];then ordering=' --set index-type:ordering';fi
   done
   echo "${indexAction} --element-name userRoot --index-name ${attrs[${a}]} --set index-entry-limit:${indexlimit} ${presence}${equality}${substring}${ordering}" >> ${batchFile}
done
echo ".100% done"

if [ -e "${batchFile}" ]
then
   echo "Index batch configuration file: ${batchFile}"
else
   echo "No indexes were discovered from the schema provided"
fi
