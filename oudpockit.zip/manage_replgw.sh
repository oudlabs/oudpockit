#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [setup|deinstall|start|stop|rstatus|export|init|test] [options]

SYNOPSIS
     Setup OUD Replication Gateway
        ${cmd} setup --suffix <suffix> [other optons]

     Start OUD Replication Gateway instance
        ${cmd} start [ --pnum <n> ]
        Default: Start all OUD Replication Gateway instances

     Stop OUD Replication Gateway instance
        ${cmd} stop [ --pnum <n> ]
        Default: Stop all OUD Replication Gateway instances

     Deinstall OUD Replication Gateway Instance
        ${cmd} deinstall --pnum <n> [optons]

     Show OUD Replication Gateway replication status
        ${cmd} rstatus --pnum <n> [optons]

     Export data in opends format from ODSEE
        ${cmd} export [options]

     Initialize OUD instances from ODSEE data
        ${cmd} init [options]

     Test replication between ODSEE and OUD
        ${cmd} test [options]
EOF

   exit 1
}
###############################################################################
# Parse arguments
###############################################################################
useSSL='false'
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            pnum) pnum="$1";shift;;
            suffix) suffix="$1";shift;;
            'dseehost'|'dseeHost') dseeHost="$1";shift;;
            'dseeport'|'dseePort') dseePort="$1";shift;;
            'oudhost'|'oudHost') oudHost="$1";shift;;
            'oudport'|'oudPort') oudPort="$1";shift;;
            'oudadmin'|'oudAdmin') oudAdminPort="$1";shift;;
            'oudrepl'|'oudRepl') oudReplPort="$1";shift;;
            'dsee2host'|'dsee2Host') dsee2Host="$1";shift;;
            'dsee2port'|'dsee2Port') dsee2Port="$1";shift;;
            'oud2host'|'oud2Host') oud2Host="$1";shift;;
            'oud2port'|'oud2Port') oud2Port="$1";shift;;
            file) ldifFile="$1";shift;;
            'usessl'|'useSSL') useSSL='true';;
            ktype) ktype="$1";shift;;
            kstore) kstore="$1";shift;;
            kpin) kpin="$1";shift;;
            help) showUsage;;
            14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set default variables
###############################################################################
if [ -z "${pnum}" ];then pnum=1;fi
if [ -z "${dseeHost}" ];then dseeHost=${localHost};fi
if [ -z "${dseePort}" ];then dseePort=1393;fi
if [ -z "${oudHost}" ];then oudHost=${localHost};fi
if [ -z "${oudAdminPort}" ];then oudAdminPort=1444;fi
if [ -z "${oudPort}" ];then oudPort=1389;fi
if [ -z "${oudReplPort}" ];then oudReplPort=1989;fi
if [ -z "${dsee2Host}" ];then dsee2Host=${localHost};fi
if [ -z "${dsee2Port}" ];then dsee2Port=2393;fi
if [ -z "${oud2Host}" ];then oud2Host=${localHost};fi
if [ -z "${oud2AdminPort}" ];then oud2AdminPort=2444;fi
if [ -z "${oud2Port}" ];then oud2Port=2389;fi
if [ -z "${file}" ];then ldifFile="${cfgdir}/dseeout.ldif";fi
if [ "${useSSL}" == 'true' ];then sslOpts="-Z -X";fi
if [ -z "${ktype}" ];then ktype='p12';fi
if [ "${ktype}" == 'jks' ];then kstore="${cfgdir}/${oudprefix}${pnum}.jks";kpin="${cfgdir}/${oudprefix}${pnum}.pin";fi
if [ "${ktype}" == 'p12' ];then kstore="${cfgdir}/${localHost}.p12";kpin="${cfgdir}/${localHost}.pin";fi
pemfile="${cfgdir}/${localHost}.pem"

steps=0

###############################################################################
# Extract and install OUD software
###############################################################################
install_oud() {
   let steps++
   echo "Step: ${steps} - Install OUD"
   ${curdir}/manage_install.sh install oud --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag} --step ${steps}
}

###############################################################################
# Stop Replication Gateway instance
###############################################################################
stop_replgw() {
   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d replgw[1-9]* 2> /dev/null|sed -e "s/replgw//g")
      for node in ${nodes}
      do
         let steps++
         echo -e "Step: ${steps} - Stop Replication Gateway instance (replgw${node})\c" | tee -a  ${logdir}/replgw-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/replgw${node}/OUD/bin/stop-ds >> ${logdir}/replgw-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      done
   else
      if [ -e "${oudmwdir}/replgw${pnum}/OUD/bin/stop-ds" ]
      then
         let steps++
         echo -e "Step: ${steps} - Stop Replication Gateway instance (replgw${pnum})\c" | tee -a  ${logdir}/replgw-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/replgw${pnum}/OUD/bin/stop-ds >> ${logdir}/replgw-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.replgw.stop
}

###############################################################################
# Start Replication Gateway instance
###############################################################################
start_replgw() {
   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d replgw[1-9]* 2> /dev/null|sed -e "s/replgw//g")
      for node in ${nodes}
      do
         let steps++
         echo -e "Step: ${steps} - Start Replication Gateway instance (replgw${node})\c" | tee -a  ${logdir}/replgw-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/replgw${node}/OUD/bin/start-ds >> ${logdir}/replgw-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      done
   else
      if [ -e "${oudmwdir}/replgw${pnum}/OUD/bin/start-ds" ]
      then
         let steps++
         echo -e "Step: ${steps} - Start Replication Gateway instance (replgw${pnum})\c" | tee -a  ${logdir}/replgw-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/replgw${pnum}/OUD/bin/start-ds >> ${logdir}/replgw-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.replgw.start
}

###############################################################################
# Setup OUD
###############################################################################
setup_replgw() {
   # Make sure OUD is installed
   install_oud

   cat > ${cfgdir}/tls.properties <<EOF
tls_protocols=TLSv1.3,TLSv1.2,TLSv1.1,TLSv1
cipher_suite_sequence=SSL_NULL_WITH_NULL_NULL,SSL_RSA_WITH_NULL_MD5,SSL_RSA_WITH_NULL_SHA,SSL_RSA_EXPORT_WITH_RC4_40_MD5,SSL_RSA_WITH_RC4_128_MD5,SSL_RSA_WITH_RC4_128_SHA,SSL_RSA_EXPORT_WTIH_RC2_CBC_40_MD5,SSL_RSA_WITH_IDEA_CBC_SHA,SSL_RSA_EXPORT_WITH_DES40_CBC_SHA,SSL_RSA_WITH_DES_CBC_SHA,SSL_RSA_WITH_3DES_EDE_CBC_SHA,SSL_DH_DSS_EXPORT_WITH_DES40_CBC_SHA,SSL_DH_DSS_WITH_DES_CBC_SHA,SSL_DH_DSS_WITH_3DES_EDE_CBC_SHA,SSL_DH_RSA_EXPORT_WITH_DES40_CBC_SHA,SSL_DH_RSA_WITH_DES_CBC_SHA,SSL_DH_RSA_WITH_3DES_EDE_CBC_SHA,SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA,SSL_DHE_DSS_WITH_DES_CBC_SHA,SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA,SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA,SSL_DHE_RSA_WITH_DES_CBC_SHA,SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA,SSL_DH_anon_EXPORT_WITH_RC4_40_MD5,SSL_DH_anon_WITH_RC4_128_MD5,SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA,SSL_DH_anon_WITH_DES_CBC_SHA,SSL_DH_anon_WITH_3DES_EDE_CBC_SHA,TLS_PSK_WITH_NULL_SHA,TLS_DHE_PSK_WITH_NULL_SHA,TLS_RSA_PSK_WITH_NULL_SHA,TLS_RSA_WITH_AES_128_CBC_SHA,TLS_DH_DSS_WITH_AES_128_CBC_SHA,TLS_DH_RSA_WITH_AES_128_CBC_SHA,TLS_DHE_DSS_WITH_AES_128_CBC_SHA,TLS_DHE_RSA_WITH_AES_128_CBC_SHA,TLS_DH_anon_WITH_AES_128_CBC_SHA,TLS_RSA_WITH_AES_256_CBC_SHA,TLS_DH_DSS_WITH_AES_256_CBC_SHA,TLS_DH_RSA_WITH_AES_256_CBC_SHA,TLS_DHE_DSS_WITH_AES_256_CBC_SHA,TLS_DHE_RSA_WITH_AES_256_CBC_SHA,TLS_DH_anon_WITH_AES_256_CBC_SHA,TLS_RSA_WITH_NULL_SHA256,TLS_RSA_WITH_AES_128_CBC_SHA256,TLS_RSA_WITH_AES_256_CBC_SHA256,TLS_DH_DSS_WITH_AES_128_CBC_SHA256,TLS_DH_RSA_WITH_AES_128_CBC_SHA256,TLS_DHE_DSS_WITH_AES_128_CBC_SHA256,TLS_RSA_WITH_CAMELLIA_128_CBC_SHA,TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA,TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA,TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA,TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA,TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA,TLS_DHE_RSA_WITH_AES_128_CBC_SHA256,TLS_DH_DSS_WITH_AES_256_CBC_SHA256,TLS_DH_RSA_WITH_AES_256_CBC_SHA256,TLS_DHE_DSS_WITH_AES_256_CBC_SHA256,TLS_DHE_RSA_WITH_AES_256_CBC_SHA256,TLS_DH_anon_WITH_AES_128_CBC_SHA256,TLS_DH_anon_WITH_AES_256_CBC_SHA256,TLS_RSA_WITH_CAMELLIA_256_CBC_SHA,TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA,TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA,TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA,TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA,TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA,TLS_PSK_WITH_RC4_128_SHA,TLS_PSK_WITH_3DES_EDE_CBC_SHA,TLS_PSK_WITH_AES_128_CBC_SHA,TLS_PSK_WITH_AES_256_CBC_SHA,TLS_DHE_PSK_WITH_RC4_128_SHA,TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA,TLS_DHE_PSK_WITH_AES_128_CBC_SHA,TLS_DHE_PSK_WITH_AES_256_CBC_SHA,TLS_RSA_PSK_WITH_RC4_128_SHA,TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA,TLS_RSA_PSK_WITH_AES_128_CBC_SHA,TLS_RSA_PSK_WITH_AES_256_CBC_SHA,TLS_RSA_WITH_SEED_CBC_SHA,TLS_DH_DSS_WITH_SEED_CBC_SHA,TLS_DH_RSA_WITH_SEED_CBC_SHA,TLS_DHE_DSS_WITH_SEED_CBC_SHA,TLS_DHE_RSA_WITH_SEED_CBC_SHA,TLS_DH_anon_WITH_SEED_CBC_SHA,TLS_RSA_WITH_AES_128_GCM_SHA256,TLS_RSA_WITH_AES_256_GCM_SHA384,TLS_DHE_RSA_WITH_AES_128_GCM_SHA256,TLS_DHE_RSA_WITH_AES_256_GCM_SHA384,TLS_DH_RSA_WITH_AES_128_GCM_SHA256,TLS_DH_RSA_WITH_AES_256_GCM_SHA384,TLS_DHE_DSS_WITH_AES_128_GCM_SHA256,TLS_DHE_DSS_WITH_AES_256_GCM_SHA384,TLS_DH_DSS_WITH_AES_128_GCM_SHA256,TLS_DH_DSS_WITH_AES_256_GCM_SHA384,TLS_DH_anon_WITH_AES_128_GCM_SHA256,TLS_DH_anon_WITH_AES_256_GCM_SHA384,TLS_PSK_WITH_AES_128_GCM_SHA256,TLS_PSK_WITH_AES_256_GCM_SHA384,TLS_DHE_PSK_WITH_AES_128_GCM_SHA256,TLS_DHE_PSK_WITH_AES_256_GCM_SHA384,TLS_RSA_PSK_WITH_AES_128_GCM_SHA256,TLS_RSA_PSK_WITH_AES_256_GCM_SHA384,TLS_PSK_WITH_AES_128_CBC_SHA256,TLS_PSK_WITH_AES_256_CBC_SHA384,TLS_PSK_WITH_NULL_SHA256,TLS_PSK_WITH_NULL_SHA384,TLS_DHE_PSK_WITH_AES_128_CBC_SHA256,TLS_DHE_PSK_WITH_AES_256_CBC_SHA384,TLS_DHE_PSK_WITH_NULL_SHA256,TLS_DHE_PSK_WITH_NULL_SHA384,TLS_RSA_PSK_WITH_AES_128_CBC_SHA256,TLS_RSA_PSK_WITH_AES_256_CBC_SHA384,TLS_RSA_PSK_WITH_NULL_SHA256,TLS_RSA_PSK_WITH_NULL_SHA384,TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256,TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256,TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256,TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256,TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256,TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256,TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256,TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256,TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256,TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256,TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256,TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256,TLS_EMPTY_RENEGOTIATION_INFO_SCSV,TLS_AES_128_GCM_SHA256,TLS_AES_256_GCM_SHA384,TLS_FALLBACK_SCSV,TLS_ECDH_ECDSA_WITH_NULL_SHA,TLS_ECDH_ECDSA_WITH_RC4_128_SHA,TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA,TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA,TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_ECDSA_WITH_NULL_SHA,TLS_ECDHE_ECDSA_WITH_RC4_128_SHA,TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA,TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA,TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA,TLS_ECDH_RSA_WITH_NULL_SHA,TLS_ECDH_RSA_WITH_RC4_128_SHA,TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA,TLS_ECDH_RSA_WITH_AES_128_CBC_SHA,TLS_ECDH_RSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_RSA_WITH_NULL_SHA,TLS_ECDHE_RSA_WITH_RC4_128_SHA,TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,TLS_ECDH_anon_WITH_NULL_SHA,TLS_ECDH_anon_WITH_RC4_128_SHA	No,TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA,TLS_ECDH_anon_WITH_AES_128_CBC_SHA,TLS_ECDH_anon_WITH_AES_256_CBC_SHA,TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA,TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA,TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA,TLS_SRP_SHA_WITH_AES_128_CBC_SHA,TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA,TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA,TLS_SRP_SHA_WITH_AES_256_CBC_SHA,TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA,TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA,TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384,TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256,TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_PSK_WITH_RC4_128_SHA,TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA,TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA,TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA,TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256,TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384,TLS_ECDHE_PSK_WITH_NULL_SHA,TLS_ECDHE_PSK_WITH_NULL_SHA256,TLS_ECDHE_PSK_WITH_NULL_SHA384,TLS_RSA_WITH_ARIA_128_CBC_SHA256,TLS_RSA_WITH_ARIA_256_CBC_SHA384,TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256,TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384,TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256,TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384,TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256,TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384,TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256,TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384,TLS_DH_anon_WITH_ARIA_128_CBC_SHA256,TLS_DH_anon_WITH_ARIA_256_CBC_SHA384,TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256,TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384,TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256,TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384,TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256,TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384,TLS_RSA_WITH_ARIA_128_GCM_SHA256,TLS_RSA_WITH_ARIA_256_GCM_SHA384,TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256,TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384,TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256,TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384,TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256,TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384,TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256,TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384,TLS_DH_anon_WITH_ARIA_128_GCM_SHA256,TLS_DH_anon_WITH_ARIA_256_GCM_SHA384,TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384,TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256,TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384,TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256,TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384,TLS_PSK_WITH_ARIA_128_CBC_SHA256,TLS_PSK_WITH_ARIA_256_CBC_SHA384,TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256,TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384,TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256,TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384,TLS_PSK_WITH_ARIA_128_GCM_SHA256,TLS_PSK_WITH_ARIA_256_GCM_SHA384,TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256,TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384,TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256,TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384,TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256,TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384,TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256,TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384,TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256,TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384,TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256,TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384,TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256,TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384,TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256,TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384,TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256,TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384,TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256,TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384,TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256,TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384,TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256,TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384,TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384,TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256,TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384,TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256,TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384,TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256,TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384,TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256,TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384,TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256,TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384,TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256,TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384,TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256,TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384,TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256,TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384,TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256,TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384,TLS_RSA_WITH_AES_128_CCM,TLS_RSA_WITH_AES_256_CCM,TLS_DHE_RSA_WITH_AES_128_CCM,TLS_DHE_RSA_WITH_AES_256_CCM,TLS_RSA_WITH_AES_128_CCM_8,TLS_RSA_WITH_AES_256_CCM_8,TLS_DHE_RSA_WITH_AES_128_CCM_8,TLS_DHE_RSA_WITH_AES_256_CCM_8,TLS_PSK_WITH_AES_128_CCM,TLS_PSK_WITH_AES_256_CCM,TLS_DHE_PSK_WITH_AES_128_CCM,TLS_DHE_PSK_WITH_AES_256_CCM,TLS_PSK_WITH_AES_128_CCM_8,TLS_PSK_WITH_AES_256_CCM_8,TLS_DHE_PSK_WITH_AES_128_CCM_8,TLS_DHE_PSK_WITH_AES_256_CCM_8,TLS_ECDHE_ECDSA_WITH_AES_128_CCM,TLS_ECDHE_ECDSA_WITH_AES_256_CCM,TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8,TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8,TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256,TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256,TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256,TLS_PSK_WITH_CHACHA20_POLY1305_SHA256,TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256,TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256,TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256
EOF

#   # Update default java.properties for ldapsearch
#   ck4tls=$(grep ldapsearch ${oudmwdir}/oud/config/java.properties 2> /dev/null)
#   if [ -z "${ck4tls}" ]
#   then
#      cp ${oudmwdir}/oud/config/java.properties ${cfgdir}/java.properties.template.${now}
#      cat >> ${oudmwdir}/oud/config/java.properties <<EOF
#ldapsearch.java-args=-client -Dcustom.config.location=${cfgdir}/tls.properties
#ldapmodify.java-args=-client -Dcustom.config.location=${cfgdir}/tls.properties
#ldapcompare.java-args=-client -Dcustom.config.location=${cfgdir}/tls.properties
#ldapdelete.java-args=-client -Dcustom.config.location=${cfgdir}/tls.properties
#EOF
#      ${oudmwdir}/oud/bin/dsjavaproperties > /dev/null 2>&1
#   fi

   # Make sure cert exists
   ${curdir}/manage_certs.sh gencert -h ${localHost} --step ${steps}

   # Add TLSv1.3 and TLSv1.2 to Administrative port of OUD1
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${dcfg} set-administration-connector-prop \
      --connector-name LDAP \
      --add ssl-protocol:TLSv1.3 \
      --add ssl-protocol:TLSv1.2 \
      --hostName ${localHost} \
      --port 1444 \
      --bindDN "${bDN}" \
      --bindPasswordFile "${jPW}" \
      --no-prompt \
      --trustAll \
      --noPropertiesFile \
      >> ${logdir}/oud-setup-${now}.log 2>&1
   rc=$?
   set +x


   let steps++
   echo "Step: ${steps} - Setup Replication Gateway (replgw${pnum})" 
   if [ "${dbg}" == 'true' ];then set -x;fi
   export INSTANCE_NAME=replgw${pnum}
#   export OPENDS_JAVA_ARGS=" -Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true -Dcustom.config.location=${cfgdir}/tls.properties "

   if [ "${useSSL}" == 'false' ]
   then
         ${oudmwdir}/oud/oud-replication-gateway-setup \
            --cli \
            --hostName "${localHost}" \
            --adminConnectorPort ${pnum}446 \
            --replicationPortForLegacy ${pnum}368 \
            --skipPortCheck \
            --rootUserDN "${bDN}" \
            --rootUserPasswordFile "${jPW}"  \
            --baseDN "${suffix}" \
            --hostNameLegacy "${dseeHost}" \
            --portLegacy ${dseePort} \
            --bindDNLegacy "${bDN}" \
            --bindPasswordFileLegacy "${jPW}"  \
            --hostNameNg "${oudHost}" \
            --portNg ${oudAdminPort} \
            --bindDNNg "${bDN}" \
            --bindPasswordFileNg "${jPW}"  \
            --replicationPortNg ${oudReplPort} \
            --adminUID admin \
            --adminPasswordFile "${jPW}"  \
            --trustAll \
            --no-prompt \
            --doNotMonitorUsingDsccLegacy \
            --noPropertiesFile \
            > ${logdir}/replgw-setup-${now}.log 2>&1
         rc=$?
   else
      if [ "${ktype}" == 'jks' ] && [ -e "${kstore}" ] && [ -e "${kpin}" ]
      then
         ${oudmwdir}/oud/oud-replication-gateway-setup \
            --cli \
            --hostName "${localHost}" \
            --adminConnectorPort ${pnum}446 \
            --replicationPortForLegacy ${pnum}368 \
            --useJavaKeystore ${kstore} \
            --gatewayKeyStorePasswordFile ${kpin} \
            --gatewayKeyPasswordFile ${kpin} \
            --gatewayCertNickname server-cert \
            --doNotUpdateTrustStoreWithLegacyCertsArg \
            --secureReplicationLegacy \
            --skipPortCheck \
            --rootUserDN "${bDN}" \
            --rootUserPasswordFile "${jPW}"  \
            --baseDN "${suffix}" \
            --hostNameLegacy "${dseeHost}" \
            --portLegacy ${dseePort} \
            --bindDNLegacy "${bDN}" \
            --bindPasswordFileLegacy "${jPW}"  \
            --hostNameNg "${oudHost}" \
            --portNg ${oudAdminPort} \
            --bindDNNg "${bDN}" \
            --bindPasswordFileNg "${jPW}"  \
            --replicationPortNg ${oudReplPort} \
            --adminUID admin \
            --adminPasswordFile "${jPW}"  \
            --trustAll \
            --no-prompt \
            --doNotMonitorUsingDsccLegacy \
            --noPropertiesFile \
            > ${logdir}/replgw-setup-${now}.log 2>&1
         rc=$?
      elif [ "${ktype}" == 'p12' ] && [ -e "${kstore}" ] && [ -e "${kpin}" ]
      then
#            --clientAuthenticationFromLegacy \
#            --clientAuthenticationToLegacy \
#            --certFileForClientAuthenticationToLegacy ${kstore} \
         ${oudmwdir}/oud/oud-replication-gateway-setup \
            --cli \
            --hostName "${localHost}" \
            --adminConnectorPort ${pnum}446 \
            --replicationPortForLegacy ${pnum}368 \
            --usePkcs12keyStore ${kstore} \
            --gatewayKeyStorePasswordFile ${kpin} \
            --gatewayKeyPasswordFile ${kpin} \
            --gatewayCertNickname server-cert \
            --doNotUpdateTrustStoreWithLegacyCertsArg \
            --secureReplicationLegacy \
            --skipPortCheck \
            --rootUserDN "${bDN}" \
            --rootUserPasswordFile "${jPW}"  \
            --baseDN "${suffix}" \
            --hostNameLegacy "${dseeHost}" \
            --portLegacy ${dseePort} \
            --bindDNLegacy "${bDN}" \
            --bindPasswordFileLegacy "${jPW}"  \
            --hostNameNg "${oudHost}" \
            --portNg ${oudAdminPort} \
            --bindDNNg "${bDN}" \
            --bindPasswordFileNg "${jPW}"  \
            --replicationPortNg ${oudReplPort} \
            --adminUID admin \
            --adminPasswordFile "${jPW}"  \
            --trustAll \
            --no-prompt \
            --doNotMonitorUsingDsccLegacy \
            --noPropertiesFile \
            > ${logdir}/replgw-setup-${now}.log 2>&1
         rc=$?
      elif [ "${ktype}" == 'none' ]
      then
         ${oudmwdir}/oud/oud-replication-gateway-setup \
            --cli \
            --hostName "${localHost}" \
            --adminConnectorPort ${pnum}446 \
            --replicationPortForLegacy ${pnum}368 \
            --generateSelfSignedCertificate  \
            --gatewayCertNickname server-cert \
            --doNotUpdateTrustStoreWithLegacyCertsArg \
            --secureReplicationLegacy \
            --skipPortCheck \
            --rootUserDN "${bDN}" \
            --rootUserPasswordFile "${jPW}"  \
            --baseDN "${suffix}" \
            --hostNameLegacy "${dseeHost}" \
            --portLegacy ${dseePort} \
            --bindDNLegacy "${bDN}" \
            --bindPasswordFileLegacy "${jPW}"  \
            --hostNameNg "${oudHost}" \
            --portNg ${oudAdminPort} \
            --bindDNNg "${bDN}" \
            --bindPasswordFileNg "${jPW}"  \
            --replicationPortNg ${oudReplPort} \
            --adminUID admin \
            --adminPasswordFile "${jPW}"  \
            --trustAll \
            --no-prompt \
            --doNotMonitorUsingDsccLegacy \
            --noPropertiesFile \
            > ${logdir}/replgw-setup-${now}.log 2>&1
         rc=$?
      fi
   fi
}

###############################################################################
# Export from ODSEE
###############################################################################
export_from_odsee() {
   let steps++
   echo "Step: ${steps} - Export data in opends format from ODSEE"
   if [ "${dbg}" == 'true' ];then set -x;fi
   rm -f "${ldifFile}" 2> /dev/null
   ${curdir}/dsee7/bin/dsconf export -f opends-export -i -e -c -h "${localHost}" -p 1393 -D "${bDN}" -w "${jPW}"  "${suffix}" "${ldifFile}" > ${logdir}/replgw-export-${now}.log 2>&1
   rc=$?
   set +x

   echo -e "Copy the following LDIF export to the OUD host:\n ${ldifFile}"
}

###############################################################################
# Initialize OUD
###############################################################################
initialize_oud() {
   let steps++
   echo "Step: ${steps} - INIT: Pre-initialize first OUD instance"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${oudmwdir}/oud/bin/dsreplication pre-external-initialization --hostName "${oudHost}" --port ${oudAdminPort} --adminUID admin --adminPasswordFile "${jPW}"  --baseDN "${suffix}" --trustAll --no-prompt --noPropertiesFile > ${logdir}/replgw-init-${now}.log 2>&1
   rc=$?
   set +x

   let steps++
   echo "Step: ${steps} - INIT: Import LDIF into first OUD instance"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${oudmwdir}/oud/bin/import-ldif --hostname "${oudHost}" --port ${oudAdminPort} --bindDN 'cn=admin,cn=Administrators,cn=admin data' --bindPasswordFile "${jPW}"  --includeBranch "${suffix}" --ldifFile "${ldifFile}" --clearBackend --trustAll --noPropertiesFile --skipFile "${logdir}/replgw${pnum}-import-skipfile.log" --rejectFile "${logdir}/replgw${pnum}-import-rejectfile.log" >> ${logdir}/replgw-init-${now}.log 2>&1
   rc=$?
   set +x

   let steps++
   echo "Step: ${steps} - INIT: Post-initialize first OUD instance"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${oudmwdir}/oud/bin/dsreplication post-external-initialization --hostName "${oudHost}" --port ${oudAdminPort} --adminUID admin --adminPasswordFile "${jPW}"  --baseDN "${suffix}" --trustAll --no-prompt --noPropertiesFile >> ${logdir}/replgw-init-${now}.log 2>&1
   rc=$?
   set +x

   let steps++
   echo "Step: ${steps} - INIT: Initialize other OUD instances"
   if [ "${dbg}" == 'true' ];then set -x;fi
   #${oudmwdir}/oud/bin/dsreplication initialize-all --hostname "${oudHost}" -X --port ${oudAdminPort} 
   ${oudmwdir}/oud/bin/dsreplication initialize -X --hostSource ${oudHost} --portSource ${oudAdminPort} --hostDestination ${oud2Host} --portDestination ${oud2AdminPort} --baseDN "${suffix}" --adminUID admin --adminPasswordFile "${jPW}"  --no-prompt >> ${logdir}/replgw-init-${now}.log 2>&1
   rc=$?
   set +x
}

###############################################################################
# Deinstall Replication Gateway
###############################################################################
deinstall_replgw() {
   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d replgw[1-9]* 2> /dev/null|sed -e "s/replgw//g")
      for node in ${nodes}
      do
         if [ -e "${oudmwdir}/replgw${node}/OUD/uninstall" ]
         then
            let steps++
            echo "Step: ${steps} - Deinstall Replication Gateway instance (replgw${node})" | tee -a  ${logdir}/replgw-deinstall-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            export OPENDS_JAVA_ARGS=' -Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true '
            ${oudmwdir}/replgw${node}/OUD/uninstall \
               -i \
               -a \
               -I "${bDN}" \
               -j "${jPW}" \
               -X \
               -h ${localHost} \
               --no-prompt \
               --noPropertiesFile \
               >> ${logdir}/replgw-deinstall-${now}.log 2>&1
           rc=$?
           set +x
         fi

         if [ -e "${oudmwdir}/replgw${node}/OUD/uninstall" ]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${oudmwdir}/replgw${node}/OUD/bin/stop-ds >> ${logdir}/replgw-deinstall-${now}.log 2>&1
            rc=$?
            rm -fr ${oudmwdir}/replgw${node}
            rc=$?
            set +x
         fi
      done
   else
      if [ -e "${oudmwdir}/replgw${pnum}/OUD/uninstall" ]
      then
         let steps++
         echo "Step: ${steps} - Deinstall Replication Gateway instance (replgw${pnum})" | tee -a  ${logdir}/replgw-deinstall-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         export OPENDS_JAVA_ARGS=' -Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true '
         ${oudmwdir}/replgw${pnum}/OUD/uninstall \
            -i \
            -a \
            -I "${bDN}" \
            -j "${jPW}" \
            -X \
            -h ${localHost} \
            --no-prompt \
            --noPropertiesFile \
            >> ${logdir}/replgw-deinstall-${now}.log 2>&1
         rc=$?
         set +x
      fi

      if [ -e "${oudmwdir}/replgw${pnum}/OUD/uninstall" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/replgw${pnum}/OUD/bin/stop-ds >> ${logdir}/replgw-deinstall-${now}.log 2>&1
         rc=$?
         rm -fr ${oudmwdir}/replgw${pnum}
         rc=$?
         set +x
      fi
   fi
}

###############################################################################
# Test bi-directionality of replication gateway
###############################################################################
test_replgw() {

   testu=$(date +'%Y%m%d%H%M%S')
   echo -e "Add user ${testu} to DSEE1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lmod} ${sslOpts} -p ${dseePort} -h ${dseeHost} -D "${bDN}" -j "${jPW}" -a >> ${logdir}/replgw-test-1-${now}.log 2>&1 << EOF
dn: ou=test${testu},${suffix}
objectClass: organizationalunit
objectClass: top
ou: test${testu}
description: test${testu}
EOF
   rc=$?;set +x
   if [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   sleep 5

   echo -e " --> Verify that user ${testu} is on DSEE1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lcmp} ${sslOpts} -p ${dseePort} -h ${dseeHost} -D "${bDN}" -j "${jPW}" "ou:test${testu}" "ou=test${testu},${suffix}" >> ${logdir}/replgw-test-2-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 6 ] || [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} is on DSEE2 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lcmp} ${sslOpts} -p ${dsee2Port} -h ${dsee2Host} -D "${bDN}" -j "${jPW}" "ou:test${testu}" "ou=test${testu},${suffix}" >> ${logdir}/replgw-test-3-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 6 ] || [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} is on OUD1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lcmp} ${sslOpts} -p ${oudPort} -h ${oudHost} -D "${bDN}" -j "${jPW}" "ou:test${testu}" "ou=test${testu},${suffix}" >> ${logdir}/replgw-test-4-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 6 ] || [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} is on OUD2 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lcmp} ${sslOpts} -p ${oud2Port} -h ${oud2Host} -D "${bDN}" -j "${jPW}" "ou:test${testu}" "ou=test${testu},${suffix}" >> ${logdir}/replgw-test-5-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 6 ] || [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   newval=$(date +'%Y%m%d%H%M%SNEWVAL')
   echo -e "Modify user ${testu} on OUD1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lmod} ${sslOpts} -p ${oudPort} -h ${oudHost} -D "${bDN}" -j "${jPW}" -a >> ${logdir}/replgw-test-6-${now}.log 2>&1 << EOF
dn: ou=test${testu},${suffix}
changetype: modify
replace: description
description: $newval
EOF
   rc=$?;set +x
   if [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} is modified on DSEE1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lcmp} ${sslOpts} -p ${dseePort} -h ${dseeHost} -D "${bDN}" -j "${jPW}" "description:$newval" "ou=test${testu},${suffix}" >> ${logdir}/replgw-test-7-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 6 ] || [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} is modified on DSEE2 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lcmp} ${sslOpts} -p ${dsee2Port} -h ${dsee2Host} -D "${bDN}" -j "${jPW}" "description:$newval" "ou=test${testu},${suffix}" >> ${logdir}/replgw-test-8-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 6 ] || [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e "Delete user ${testu} from DSEE1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${ldel} ${sslOpts} -p ${dseePort} -h ${dseeHost} -D "${bDN}" -j "${jPW}" "ou=test${testu},${suffix}" >> ${logdir}/replgw-test-9-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} was deleted from DSEE2 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lsrch} ${sslOpts} -p ${dsee2Port} -h ${dsee2Host} -D "${bDN}" -j "${jPW}" -s base -b "ou=test${testu},${suffix}" ou=test${testu} >> ${logdir}/replgw-test-10-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 32 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} was deleted from OUD1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lsrch} ${sslOpts} -p ${oudPort} -h ${oudHost} -D "${bDN}" -j "${jPW}" -s base -b "ou=test${testu},${suffix}" ou=test${testu} >> ${logdir}/replgw-test-11-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 32 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} was deleted from OUD2 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lsrch} ${sslOpts} -p ${oud2Port} -h ${oud2Host} -D "${bDN}" -j "${jPW}" -s base -b "ou=test${testu},${suffix}" ou=test${testu} >> ${logdir}/replgw-test-12-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 32 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   newval=$(date +'%Y%m%d%H%M%SNEWVAL')
   testu=$(date +'%Y%m%d%H%M%S')
   echo -e "Add user ${testu} to OUD1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lmod} ${sslOpts} -p ${oudPort} -h ${oudHost} -D "${bDN}" -j "${jPW}" -a >> ${logdir}/replgw-test-13-${now}.log 2>&1 << EOF
dn: uid=${testu},${suffix}
objectClass: top
objectClass: organizationalperson
objectClass: inetorgperson
uid: ${testu}
cn: Test User
sn: User
givenName: Test
userPassword: ${bPW}
EOF
   rc=$?;set +x
   if [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} is added on OUD2 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lsrch} ${sslOpts} -p ${oud2Port} -h ${oud2Host} -D "${bDN}" -j "${jPW}" -s sub -b "${suffix}" uid=${testu} >> ${logdir}/replgw-test-14-${now}.log 2>&1
   rc=$?;set +x
   if [ -s "${logdir}/replgw-test-14-${now}.log" ] && [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} is added on DSEE1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lsrch} ${sslOpts} -p ${dseePort} -h ${dseeHost} -D "${bDN}" -j "${jPW}" -s sub -b "${suffix}" uid=${testu} >> ${logdir}/replgw-test-15-${now}.log 2>&1
   rc=$?;set +x
   if [ -s "${logdir}/replgw-test-15-${now}.log" ] && [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e " --> Verify that user ${testu} is added on DSEE2 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${lsrch} ${sslOpts} -p ${dsee2Port} -h ${dsee2Host} -D "${bDN}" -j "${jPW}" -s sub -b "${suffix}" uid=${testu} >> ${logdir}/replgw-test-16-${now}.log 2>&1
   rc=$?;set +x
   if [ -s "${logdir}/replgw-test-16-${now}.log" ] && [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"

   echo -e "Delete user ${testu} from DSEE1 \c"
   if [ "${dbg}" == 'true' ];then echo;set -x;fi
   ${ldel} ${sslOpts} -p ${dseePort} -h ${dseeHost} -D "${bDN}" -j "${jPW}" "uid=${testu},${suffix}" >> ${logdir}/replgw-test-17-${now}.log 2>&1
   rc=$?;set +x
   if [ $rc -eq 0 ];then ck='[OK]';else ck='[WARN]';fi;echo "${ck}"
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
          'setup') setup_replgw;;
           'stop') stop_replgw;;
          'start') start_replgw;;
         'export') export_from_odsee;;
           'init') initialize_oud;;
      'deinstall') deinstall_replgw;;
           'test') test_replgw;;
        'rstatus') ${curdir}/manage_oud.sh rstatus ${dbgFlag};;
                *) showUsage;;
esac
