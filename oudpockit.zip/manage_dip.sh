#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

   findpager
   cat << EOF | ${pgcmd}
NAME
     ${cmd} [ setup | start | stop | deinstall ]

SYNOPSIS
     Setup OUDSM
        ${cmd} setup

     Start OUD instance
        ${cmd} start

     Stop OUD instance
        ${cmd} stop

     Un-install OUD instance
        ${cmd} deinstall
EOF

   exit 1

}

###############################################################################
# Parse arguments
###############################################################################
integration=''
force=''
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            swdir) swdir="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            jh) export JAVA_HOME="$1";PATH="$JAVA_HOME:$PATH";shift;;
            ktype) ktype="$1";shift;;
            kstore) kstore="$1";shift;;
            kpin) kpin="$1";shift;;
            fmwi) fmwi="$1";shift;;
            fmwo) fmwo="$1";shift;;
            step) steps="$1";shift;;
            nosudo) sudoFlag=' --nosudo';;
            14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            D) bDN="$1";;
            j) jPW="$1";;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -n "${adPW}" ];then if [ -e "${adPW}" ];then adPW=$(cat ${adPW});fi;fi

###############################################################################
# Address error introduced by JDK security enhancement
#   There is an error with the certificate presented by the server <host>:1444. 
#   Details: java.security.cert.CertificateException: No subject alternative 
#      names present
export WL_ARGS='-Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true'

###############################################################################
# Create requisite directories and response files
###############################################################################
make_cfg_files() {
   if [ -e "${cfgdir}/oraInventory.loc" ]
   then
      true
   else
      cat > ${cfgdir}/oraInventory.loc <<EOF
inventory_loc=${cfgdir}/oraInventory
inst_group=${me}
EOF
   fi

   if [ -e "${cfgdir}/dip-fmw12c.rsp" ]
   then
      true
   else
      cat > ${cfgdir}/dip-fmw12c.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${dipmwdir}
INSTALL_TYPE=Fusion Middleware Infrastructure
EOF
   fi

   if [ -e "${cfgdir}/ouddip12c-shared.rsp" ]
   then
      true
   else
      cat > ${cfgdir}/ouddip12c-shared.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${dipmwdir}
INSTALL_TYPE=Collocated Oracle Unified Directory Server (Managed through WebLogic server)
EOF
   fi

   if [ -e "${cfgdir}/ouddip12c.py" ]
   then
      true
   else
      cat > ${cfgdir}/ouddip12c.py <<EOF
setTopologyProfile('Compact')
selectTemplate("Basic WebLogic Server Domain")
loadTemplates()
cd(r'/Security/base_domain/User/weblogic')
cmo.setPassword("${bPW}")
writeDomain('${dipmwdir}/domains/dip')
closeTemplate()
readDomain('${dipmwdir}/domains/dip')
cd('Servers/AdminServer')
cmo.setListenPort(${dipHttpPort})
cmo.setListenAddress('')
create('AdminServer','SSL')
cd('SSL/AdminServer')
cmo.setEnabled(true)
cmo.setListenPort(${Port})
updateDomain()
closeDomain()
readDomain('${dipmwdir}/domains/dip')
selectTemplate('Oracle Unified Directory Services Manager')
loadTemplates()
updateDomain()
closeDomain()
readDomain('${dipmwdir}/domains/dip')
selectTemplate('Oracle Unified Directory')
loadTemplates()
updateDomain()
closeDomain()
EOF
   fi

   if [ -e "${cfgdir}/ouddip12c-addSSL.py" ]
   then
      true
   else
      cat > ${cfgdir}/ouddip12c-addSSL.py <<EOF
connect('weblogic',"${bPW}",'t3://${localHost}:${dipHttpPort}')
dumpStack()
edit()
startEdit()
cd('/Servers/AdminServer')
cmo.setKeyStores('CustomIdentityAndCustomTrust')
activate()

startEdit()
cmo.setCustomIdentityKeyStoreFileName("${cfgdir}/keystore")
cmo.setCustomIdentityKeyStoreType('JKS')
set('CustomIdentityKeyStorePassPhrase', "${bPW}")
cmo.setCustomTrustKeyStoreFileName("${cfgdir}/truststore")
cmo.setCustomTrustKeyStoreType('JKS')
set('CustomTrustKeyStorePassPhrase', "${bPW}")
activate()

startEdit()
cd('/Servers/AdminServer/SSL/AdminServer')
cmo.setServerPrivateKeyAlias('server-cert')
set('ServerPrivateKeyPassPhrase', "${bPW}")
cmo.setEnabled(true)
cmo.setListenPort(${Port})
cmo.setJSSEEnabled(true)
save()
activate()
dumpStack()
disconnect()
exit()
EOF
   fi

}

###############################################################################
# Wait for WebLogic to start
###############################################################################
wait4wls() {
   log=$1
   if [ -n "$2" ];then for (( b=1; b<= $2; b++ ));do echo -e "^H\c";done;fi
   for (( t=1; t<= 120; t++ ))
   do
      isWlsUp=$(grep "in RUNNING mode" $log 2> /dev/null)
      if [ -n "${isWlsUp}" ]
      then
         break
      elif [ -n "$(grep "Server state changed to FAILED" $log 2> /dev/null)" ]
      then
         echo -e "Startup Failed"
         exit
      else
         echo -e ".\c"
         sleep 30
      fi
   done
   echo -e "done"
   bdiff=$(($2-$t-4+1))
   if [ -n "$2" ];then for (( b=1; b<= $bdiff; b++ ));do echo -e " \c";done;fi
}

#############################################################################################################
# Stop OUDSM
#############################################################################################################
stop_dip() {
   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   if [ -e "${dipmwdir}/domains/dip/bin/stopWebLogic.sh" ]
   then
      true
      let steps++
      echo -e "Step: ${steps} - Stop WebLogic for OUDSM.\c" | tee -a  ${logdir}/dip-ctl-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dipmwdir}/domains/dip/bin/stopWebLogic.sh >> ${logdir}/dip-ctl-${now}.log 2>&1
      rc=$?
      set +x
      echo -e ".\c"

      # Stop ODS NodeManager
      # The only supported way to stop the NodeManager is to kill the pid
      odsnmpid=$(ps -ef 2> /dev/null|egrep "startNodeManager|common\/nodemanager"|grep "${dipmwdir}"|egrep -v "grep|manage_dip"|awk '{ print $2 }'|egrep -v "^$$$"|sort -rn)
      odsnmpiducb=$(${ucbps} auxww 2> /dev/null|egrep "startNodeManager|common\/nodemanager"|grep "${dipmwdir}"|egrep -v "grep|manage_dip"|awk '{ print $2 }'|egrep -v "^$$$"|sort -rn)
      if [ -n "$odsnmpid" ] || [ -n "$odsnmpiducb" ]
      then
         echo "$odsnmpid" |xargs -n1 kill 2> /dev/null
      fi

      ps -ef | grep domains\/dip|egrep -v "grep|manage_dip"|awk '{ print $2 }' | xargs -n1 kill 2> /dev/null

      echo -e ".done"
   else
      exit 0
   fi
}

#############################################################################################################
# Start OUDSM
#############################################################################################################
start_dip() {

   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   if [ -e "${dipmwdir}/domains/dip/startWebLogic.sh" ]
   then
      let steps++
      echo -e "Step: ${steps} - Start WebLogic for OUDSM.\c" | tee -a  ${logdir}/dip-ctl-${now}.log
      now=$(date +'%Y%m%d%H%M%S')
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dipmwdir}/domains/dip/startWebLogic.sh ${WL_ARGS} >> ${logdir}/dip-ctl-${now}.log 2>&1 &
      wait4wls "${logdir}/dip-ctl-${now}.log"
      ${dipmwdir}/domains/dip/bin/startNodeManager.sh >> ${logdir}/dip-ctl-${now}.log 2>&1 &
      set +x

      let steps++
      echo "Step: ${steps} - Open browser to https://${localHost}:${dipHttpsPort}/dip" | tee -a  ${logdir}/oud-install-${now}.log
   else
      exit 0
   fi
}

#############################################################################################################
# Deinstall OUDSM
#############################################################################################################
deinstall_dip() {
   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   if [ -d "${dipmwdir}/domains/dip" ]
   then
      stop_dip
      let steps++
      echo -e "Step: ${steps} - Deinstall OUDSM domain.\c" | tee -a  ${logdir}/dip-ctl-${now}.log
      rm -fr "${dipmwdir}/domains/dip"
      echo -e ".done"
   fi
   echo ${steps} > ${cfgdir}/.steps.dip
}

#############################################################################################################
# Setup WebLogic for OUDSM
#############################################################################################################
setup_dip() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -e "${dipmwdir}/domains/dip/startWebLogic.sh" ]
   then
      let steps++
      echo "Step: ${steps} - WebLogic and OUDSM appear to already be setup.  Restarting OUDSM." | tee -a  ${logdir}/oud-install-${now}.log
      stop_dip
      start_dip
   else
      # Make configuration files
      make_cfg_files

      # Install OUDSM
      rm ${cfgdir}/.steps.install.fmw.dip 2> /dev/null
      rm ${cfgdir}/.steps.install.dip 2> /dev/null
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_install.sh install dip --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag} --step ${steps}
      set +x
      if [ -e "${cfgdir}/.steps.install.dip" ];then steps=$(cat ${cfgdir}/.steps.install.dip);fi

      # Confirm that FMW is installed
      if [ -e "${dipmwdir}/oracle_common/common/bin/wlst.sh" ]
      then
         true
      else
         echo "ERROR: Fusion Middleware not installed"
         exit 1
      fi

      # Make sure JAVA_HOME is set
      if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi
      if [ -n "${JAVA_HOME}" ];then PATH="${JAVA_HOME}/bin:$PATH";fi
      if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      export MW_HOME="${dipmwdir}"
      export JAVA_OPTIONS=" -Dweblogic.security.SSL.minimumProtocolVersion=TLSv1 -Dweblogic.ssl.JSSEEnabled=true -Dweblogic.security.SSL.trustedCAKeyStore=${CATrustStore}"

      ${MW_HOME}/oracle_common/common/bin/wlst.sh ${cfgdir}/ouddip12c.py >> ${logdir}/setup-dip-${now}.log 2>&1
      rc=$?
      set +x
      let steps++
      echo -e "Step: ${steps} - Start WebLogic.\c" | tee -a  ${logdir}/oud-install-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dipmwdir}/domains/dip/startWebLogic.sh ${WL_ARGS} >> ${logdir}/setup-dip-${now}.log 2>&1 &
      ${dipmwdir}/domains/dip/bin/startNodeManager.sh >> ${logdir}/setup-dip-${now}.log 2>&1 &
      wait4wls "${logdir}/setup-dip-${now}.log"
      set +x

      if [ -e "${cfgdir}/truststore" ] 
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${wlsRoot}/wlserver/common/bin/wlst.sh ${cfgdir}/oidsm12c-addSSL.py >> ${logdir}/setup-dip-${now}.log 2>&1
         rc=$?
         set +x

         ## Add Custom Keystore to Nodemanager
         cat ${MW_HOME}/domains/dip/nodemanager/nodemanager.properties | sed -e "s/^ListenAddress.*/ListenAddress=0.0.0.0/g" > ${MW_HOME}/domains/dip/nodemanager/nodemanager.properties.${now}
         cat ${cfgdir}/ouddip12c-nodemanager.properties >> ${MW_HOME}/domains/dip/nodemanager/nodemanager.properties.${now}
         cat ${MW_HOME}/domains/dip/nodemanager/nodemanager.properties.${now} > ${MW_HOME}/domains/dip/nodemanager/nodemanager.properties

         now=$(date +'%Y%m%d%H%M%S')
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${dipmwdir}/domains/dip/bin/stopWebLogic.sh >> ${logdir}/dip-ctl-${now}.log 2>&1
         ${dipmwdir}/domains/dip/startWebLogic.sh ${WL_ARGS} >> ${logdir}/dip-ctl-${now}.log 2>&1 &
         wait4wls "${logdir}/setup-dip-${now}.log"
         set +x
      fi
   fi

   let steps++
   echo "Step: ${steps} - Open browser to https://${localHost}:${dipHttpsPort}/dip" | tee -a  ${logdir}/oud-install-${now}.log
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
             'setup') setup_dip;;
         'deinstall') deinstall_dip;;
              'stop') stop_dip;;
             'start') start_dip;;
                   *) showUsage;;
esac
