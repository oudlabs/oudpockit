#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

useSSL=''
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            useSSL) useSSL='-Z -X';;
            pnum) pnum="$1";shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            n) templateName="$1";shift;;
            Z) useSSL='-Z -X';;
            p) myPort="$1";shift;;
            A) myAttrs="$1";shift;;
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -z "${pnum}" ];then pnum=1;fi
if [ -z "${myAttrs}" ];then myAttrs='dn';fi

if [ "${pnum}" == '0' ]
then
      ldapPort=389 
      httpsPort=443
      adminPort=444
      httpsAdminPort=555
      ldapsPort=636
      replPort=989
else
      ldapPort=${pnum}389 
      httpsPort=${pnum}443
      adminPort=${pnum}444
      httpsAdminPort=${pnum}555
      ldapsPort=${pnum}636
      replPort=${pnum}989
fi

if [ -n "${myPort}" ];then ldapPort=${myPort};fi

###############################################################################
# Usage
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
if [ -e "${cfgdir}/${templateName}.dn" ]
then
   true
else
   echo "DN file (${cfgdir}/${templateName}.dn) does not exist."
   echo "Usage: ${cmd} [-n <template>]"
   exit 1
fi

firstUserDN=$(head -1 ${cfgdir}/${templateName}.dn)
firstUser=$(echo ${firstUserDN}|cut -d',' -f1|sed -e "s/ $//g")

echo "DEMO --> Base Search:"
set -x
${lsrch} -h ${localHost} ${useSSL} -p ${ldapPort} -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub "${firstUser}" ${myAttrs}
set +x

echo "DEMO --> Presenece Search:"
set -x
${lsrch} -h ${localHost} ${useSSL} -p ${ldapPort} -D "${bDN}" -j "${jPW}" -b "${firstUserDN}" -s sub "objectClass=top"  ${myAttrs}
set +x
