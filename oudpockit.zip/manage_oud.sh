#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

   findpager
   cat << EOF | ${pgcmd}
NAME
     ${cmd} [setup|deinstall|start|stop|apply|rstatus] [options]

SYNOPSIS
     Setup first OUD Instance
        ${cmd} setup --suffix <suffix> [other optons]

     Setup second and following OUD Instance on other hosts
        ${cmd} setup --suffix <suffix> --supplier <host:aPort:rPort> [optons] 

     Start OUD instance
        ${cmd} start [ --pnum <n> ]
        Default: Start all OUD instances

     Stop OUD instance
        ${cmd} stop [ --pnum <n> ]
        Default: Stop all OUD instances

     Apply custom batch configuration file to OUD instance
        ${cmd} apply --batch <file>

     Install OUD instance
        ${cmd} deinstall [ --pnum <n> ]

     Show OUD replication status
        ${cmd} rstatus [ --disp <view> ] [ --advanced ]

     Perform binary backup
        ${cmd} backup --backupdir <dir> [--pnum <number> --be <backend>]

     Perform restore backup
        ${cmd} restore --backupdir <dir> [--pnum <number> --be <backend>]

     Perform LDIF export
        ${cmd} export --ldiffile <file> [--pnum <number> --be <backend>]

     Perform LDIF import
        ${cmd} import --ldiffile <file> [--pnum <number> --be <backend>]

     Push a file or directory from source to remote host
        ${cmd} push --ruser <user_id> --rhost <host> --lpath <file|dir> --rpath <file|dir>

     Add ou=status backend
        ${cmd} addstatus --pnum <n>

     Delete ou=status backend
        ${cmd} delstatus --pnum <n>

     Set ou=status description value to instanceIsUp
        ${cmd} enablestatus --pnum <n>

     Set ou=status description value to instanceIsDown
        ${cmd} disablestatus --pnum <n>

     Show ou=status description value
        ${cmd} checkstatus --pnum <n>

DESCRIPTION
     Sample script for managing Oracle Unified Directory (OUD) instances

OPTIONS
     Setup Options
     The following options are supported:

         --pnum <n>              OUD and port number prefix
                                 Default: 1

         --suffix <suffix>       Suffix used for proxy passthrough

         --supplier <host:aPort:rPort>  OUD host, admin port, and replication port 
                                 from which to initialize replica

         --ds                    Create instance of directory server only role

         --rs                    Create instance of the replication server only role

         --readonly              Put directory server in read-only mode

         --fifo                  Add FIFO cache to each backend

         --pfile <file>          Fully qualified path to password file
                                 Default: ${curdir}/...pw

         --jh <dir>              JAVA_HOME directory if not already specified in env

         --ktype <type>          Type of key type: none, jks, p12
                                 Default: none - Create a self signed cert

         --kstore <file>         Fully qualified path of keystore file
                                 Default: ${curdir}/keystore
                                 
         --kpin <file>           Fully qualified path of keystore pin file
                                 Default: ${curdir}/keystore.pin

         --swdir <dir>           Directory of the extracted software

         --batch <file>          Supplemental configuration to add to lb config

         --fmwi <file>           Fusion Middleware Infrastructure jar file
                                 Default: ${curdir}/fmw_12.2.1.4.0_infrastructure_generic.jar

         --fmwo <file>           Fusion Middleware OUD jar file
                                 Default: ${curdir}/fmw_12.2.1.4.0_oud_generic.jar

         --schema <file>         Fully qualified path of schema LDIF fie
                                 Default: ${curdir}/schema.ldif

         --data <file>           Fully qualified path of data LDIF  fie
                                 Default: ${curdir}/data.ldif

         --force                 Force deinstall

         --integration <option>  Integration options: eus

         --nobatch               No batch configuration file

         --noinit                No initialization

         --norest                Disable REST/SCIM interfaces

         --noroles               Don't load Roles schema

         --norepl                Don't enable replication

         --noreplenc             No replication encryption

         --prefix <text>         OUD instance name prefix
                                 Default: oud

EOF

   exit 1
}

###############################################################################
# Make batch file
###############################################################################
gen_nsrole_schema() {
   cat > ${cfgdir}/nsRoles.schema <<EOF
dn: cn=schema
changetype: modify
add: attributeTypes
attributeTypes: ( 2.16.840.1.113730.3.1.574 NAME 'nsRole' DESC 'Sun ONE defined attribute type' SYNTAX 1.3.6.1.4.1.1466.115.121.1.12 NO-USER-MODIFICATION USAGE directoryOperation X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

dn: cn=schema
changetype: modify
add: attributeTypes
attributeTypes: ( 1.3.6.1.4.1.42.2.27.9.1.10 NAME 'nsRoleScopeDn' DESC 'Sun ONE defined attribute type' SYNTAX 1.3.6.1.4.1.1466.115.121.1.12 SINGLE-VALUE X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

dn: cn=schema
changetype: modify
add: attributeTypes
attributeTypes: ( 2.16.840.1.113730.3.1.575 NAME 'nsRoleDN' DESC 'Sun ONE defined attribute type' SYNTAX 1.3.6.1.4.1.1466.115.121.1.12 USAGE directoryOperation X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

dn: cn=schema
changetype: modify
add: attributeTypes
attributeTypes: ( 2.16.840.1.113730.3.1.576 NAME 'nsRoleFilter' DESC 'Sun ONE defined attribute type' SYNTAX 1.3.6.1.4.1.1466.115.121.1.26 SINGLE-VALUE X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

dn: cn=schema
changetype: modify
add: objectClasses
objectClasses: ( 2.16.840.1.113730.3.2.93 NAME 'nsRoleDefinition' DESC 'Sun ONE defined objectclass' SUP ldapSubEntry MAY ( description ) X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

dn: cn=schema
changetype: modify
add: objectClasses
objectClasses: ( 2.16.840.1.113730.3.2.94 NAME 'nsSimpleRoleDefinition' DESC 'Sun ONE defined objectclass' SUP nsRoleDefinition X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

dn: cn=schema
changetype: modify
add: objectClasses
objectClasses: ( 2.16.840.1.113730.3.2.95 NAME 'nsComplexRoleDefinition' DESC 'Sun ONE defined objectclass' SUP nsRoleDefinition X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

dn: cn=schema
changetype: modify
add: objectClasses
objectClasses: ( 2.16.840.1.113730.3.2.97 NAME 'nsFilteredRoleDefinition' DESC 'Sun ONE defined objectclass' SUP nsComplexRoleDefinition MUST ( nsRoleFilter ) X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

dn: cn=schema
changetype: modify
add: objectClasses
objectClasses: ( 1.3.6.1.4.1.42.2.27.9.2.9 NAME 'nsNestedRoleDefinition' DESC 'Sun ONE defined objectclass' SUP nsComplexRoleDefinition MUST ( nsRoleDN ) MAY ( nsRoleScopeDN) X-DS-USE 'internal' X-ORIGIN 'Sun ONE Directory Server' )

EOF
}

###############################################################################
# Make batch file
###############################################################################
gen_batch_files() {

   if [ -z  "${compatBatchFile}" ]
   then
      cat >> ${cfgdir}/oud-${now}.compat <<EOF
# Add necessary compatibility features
set-global-configuration-prop --set check-schema:true
set-global-configuration-prop --set allow-attribute-name-exceptions:false
set-global-configuration-prop --set invalid-attribute-syntax-behavior:accept
set-global-configuration-prop --set single-structural-objectclass-behavior:accept

# Add virtual nsRole
create-virtual-attribute --type is-member-of --name nsRole --set attribute-type:nsRole --set enabled:true

EOF
   fi

   if [ -z  "${batchFile}" ]
   then
      cat >> ${cfgdir}/oud-${now}.batch <<EOF
# Indexes
create-local-db-index --element-name ${backend} --index-name employeeNumber --set index-entry-limit:10000 --set index-type:equality
set-local-db-index-prop --element-name ${backend} --index-name employeeNumber --set index-entry-limit:10000 --add index-type:ordering

# Maximize group caching
set-entry-cache-prop --cache-name Group\ Cache --set max-memory-percent:100

# Allow pre-encoded passwords
set-password-policy-prop  --policy-name Default\ Password\ Policy  --set allow-pre-encoded-passwords:true

# Encrypted Attributes
set-data-encryption-prop --set attribute-encryption-include:description --set enabled:true --set encrypted-suffix:${suffix}

# End User Password Policy
create-password-validator --validator-name LengthMin8 --set min-password-length:8 --type length-based --set enabled:true
create-password-validator --validator-name EndUserValidator --type character-set --set use-any-of:3 --set allow-unclassified-characters:false --set enabled:true --set character-set:2:ABCDEFGHIJKLMNOPQRSTUVWXYZ --set character-set:2:abcdefghijklmnopqrstuvwxyz --set character-set:2:1234567890 --set character-set:2:"!@#$%^&*()_-+={[}]|\:;\"'<,>.?"
create-password-policy --policy-name EndUserPolicy --set password-validator:LengthMin8 --set max-password-age:7776000\ s --set lockout-failure-count:5 --set password-history-count:5 --set default-password-storage-scheme:Salted\ SHA-512 --set password-attribute:userpassword --set lockout-soft-duration:3600\ s --type generic

# Privileged User Password Policy
create-password-validator --validator-name LengthMin15 --set min-password-length:15 --type length-based --set enabled:true
create-password-validator --validator-name PrivUserValidator --set use-any-of:4 --set allow-unclassified-characters:false --type character-set --set enabled:true --set character-set:2:ABCDEFGHIJKLMNOPQRSTUVWXYZ --set character-set:2:abcdefghijklmnopqrstuvwxyz --set character-set:2:1234567890 --set character-set:2:"!@#$%^&*()_-+={[}]|\:;\"'<,>.?"
create-password-policy --policy-name PrivUserPolicy --set password-validator:LengthMin15 --set max-password-age:2592000\ s --set lockout-failure-count:3 --set password-history-count:20 --set default-password-storage-scheme:Salted\ SHA-512 --set password-attribute:userpassword --set lockout-duration:0\ s --type generic

# Allow pre-encoded passwords
set-password-policy-prop  --policy-name Default\ Password\ Policy  --set allow-pre-encoded-passwords:true
set-password-policy-prop  --policy-name EndUserPolicy  --set allow-pre-encoded-passwords:true
set-password-policy-prop  --policy-name PrivUserPolicy  --set allow-pre-encoded-passwords:true

# Audit Log Masks
set-log-publisher-prop --publisher-name File-Based\ Audit\ Logger --set mask-passwords:true --set masked-attribute:description
create-plugin --set type:employeeNumber --set enabled:true --type unique-attribute --plugin-name Unique_employeeNumber

EOF
   fi
}

###############################################################################
# Check replication status
###############################################################################
replication_status() {
   if [ -n "${pnum}" ]
   then
      if [ ${pnum} -eq 0 ]
      then
         pnum=$(cd "${oudmwdir}";ls -1d ${oudprefix}[0-9]* 2> /dev/null|sed -e "s/${oudprefix}//g"|grep [0-9]|head -1)
         adminPort="${pnum}444"
         ldapPort="${pnum}389"
      fi
      if [ ${pnum} -eq 0 ]
      then
         adminPort="444"
         ldapPort="389"
      fi
   fi

   # Make sure OUD instance is up
   pingOud ${ldapPort}

   let steps++
   echo "Step: ${steps} - Show replication status" | tee -a  ${logdir}/oud-rstatus-${now}.log
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -n "${basedn}" ]
   then
      ${drepl} status ${radv} --basedn "${basedn}" --dataToDisplay ${rdisp} --hostname ${localHost} --port ${adminPort} --portProtocol auto-detect --adminPasswordFile "${jPW}" --bindDN "${bDN}" --trustAll --no-prompt --connectTimeout 1000000 --readTimeout 1000000
      rc=$?;set +x
   else
      ${drepl} status ${radv} --dataToDisplay ${rdisp} --hostname ${localHost} --port ${adminPort} --portProtocol auto-detect --adminPasswordFile "${jPW}" --bindDN "${bDN}" --trustAll --no-prompt --connectTimeout 1000000 --readTimeout 1000000
      rc=$?;set +x
   fi
}

###############################################################################
# Initialize all replicas
###############################################################################
init_all() {
   if [ "${noinit}" == 'false' ]
   then
      if [ -z "${supplierReplPort}" ];then snum=$(echo "${supplierPort}"|sed -e "s/44[45]$//g");supplierReplPort=${snum}989;fi
      let steps++
      echo "Step: ${steps} - Initalize all replicas from ${oudSupplier}"| tee -a  ${logdir}/oud-install-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${drepl} initialize-all \
         --hostname ${supplierHost} \
         --port ${supplierPort} \
         --baseDN "${suffix}" \
         --adminUID admin \
         --adminPasswordFile "${jPW}" \
         --trustAll \
         --no-prompt
      rc=$?
      set +x
   fi
}

###############################################################################
# Deinstall OUD
###############################################################################
deinstall_oud() {
   if [ -z "${pnum}" ];then pnum=0;fi

   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d ${oudprefix}[0-9]* 2> /dev/null|sed -e "s/${oudprefix}//g")
      for node in ${nodes}
      do
         if [ -e "${oudmwdir}/${oudprefix}${node}/OUD/uninstall" ]
         then
            let steps++
            echo "Step: ${steps} - Delete OUD instance (${oudprefix}${node})" | tee -a  ${logdir}/oud-deinstall-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            export OPENDS_JAVA_ARGS=' -Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true '
            ${oudmwdir}/${oudprefix}${node}/OUD/uninstall \
               -n \
               -i \
               -a \
               -I "admin" \
               -j "${jPW}" \
               -X \
               -h ${localHost} \
               --noPropertiesFile \
               >> ${logdir}/oud-deinstall-${now}.log 2>&1 <<EOF
${bPW}
f
EOF
           rc=$?
           set +x
           if [ ${rc} -ne 0 ]
           then
              echo -e "ERROR: Deinstall failed. See log\n ${logdir}/oud-deinstall-${now}.log"
              exit 1
           fi
         fi

         if [ -e "${oudmwdir}/${oudprefix}${node}/OUD/uninstall" ]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${oudmwdir}/${oudprefix}${node}/OUD/bin/stop-ds >> ${logdir}/oud-deinstall-${now}.log 2>&1
            rc=$?
            rm -fr ${oudmwdir}/${oudprefix}${node}
            rc=$?
            set +x
         fi
      done
   else
      if [ -e "${oudmwdir}/${oudprefix}${pnum}/OUD/uninstall" ]
      then
         let steps++
         echo "Step: ${steps} - Delete OUD instance (${oudprefix}${pnum})" | tee -a  ${logdir}/oud-deinstall-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         export OPENDS_JAVA_ARGS=' -Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true '
         ${oudmwdir}/${oudprefix}${pnum}/OUD/uninstall \
            -n \
            -i \
            -a \
            -I "admin" \
            -j "${jPW}" \
            -X \
            -h ${localHost} \
            --noPropertiesFile \
            >> ${logdir}/oud-deinstall-${now}.log 2>&1 <<EOF
${bPW}
f
EOF
         rc=$?
         set +x
      else
         echo "OUD instance ${oudprefix}${pnum} does not exist"
         exit 0
      fi

      if [ -e "${oudmwdir}/${oudprefix}${pnum}/OUD/uninstall" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds >> ${logdir}/oud-deinstall-${now}.log 2>&1
         rc=$?
         rm -fr ${oudmwdir}/${oudprefix}${pnum}
         rc=$?
         set +x
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.deinstall.oud
}

###############################################################################
# Apply compatibilitycustom batch configuration file if one exists
###############################################################################
apply_compatibility_batch() {
   if [ "${nobatch}" == 'true' ] || [ "${notune}" == 'true' ]
   then
      true
   elif [ -e  "${compatBatchFile}" ]
   then
      let steps++
      echo "Step: ${steps} - Apply compatbility batch configuration to OUD instance (${localH}:${adminPort})" | tee -a  ${logdir}/oud-setup-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dcfg} \
         --batchFilePath ${compatBatchFile} \
         --hostName ${localHost} \
         --port ${adminPort} \
         --bindDN "${bDN}" \
         --bindPasswordFile "${jPW}" \
         --no-prompt \
         --trustAll \
         --noPropertiesFile \
         >> ${logdir}/oud-setup-${now}.log 2>&1
      rc=$?
      set +x
   fi
}

###############################################################################
# Apply custom batch configuration file if one exists
###############################################################################
apply_custom_batch() {
   if [ "${nobatch}" == 'true' ]
   then
      true
   elif [ -e  "${batchFile}" ]
   then
      let steps++
      echo "Step: ${steps} - Apply custom batch configuration" | tee -a  ${logdir}/oud-setup-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dcfg} \
         --batchFilePath ${batchFile} \
         --hostName ${localHost} \
         --port ${adminPort} \
         --bindDN "${bDN}" \
         --bindPasswordFile "${jPW}" \
         --no-prompt \
         --trustAll \
         --noPropertiesFile \
         >> ${logdir}/oud-setup-${now}.log 2>&1
      rc=$?;set +x

      # Enable read-only if specified
      if [ "${isreadonly}" == 'true' ]
      then
         let steps++
         echo "Step: ${steps} - Set to read-only mode for client writes" | tee -a  ${logdir}/oud-setup-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${dcfg} \
            set-global-configuration-prop --set writability-mode:internal-only \
            --hostName ${localHost} \
            --port ${adminPort} \
            --bindDN "${bDN}" \
            --trustAll \
            --noPropertiesFile \
            >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
f
EOF

         rc=$?
#            --bindPasswordFile "${jPW}" \
#            --no-prompt \
         set +x
      fi

      # Add FIFO cache if specified
      if [ "${fifo}" == 'true' ]
      then
         let steps++
         echo "Step: ${steps} - Add FIFO cache to userRoot backend" | tee -a  ${logdir}/oud-setup-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${dcfg} \
            set-entry-cache-prop --cache-name "Group Cache" --set max-memory-percent:10 --set cache-level:3 \
            --hostName ${localHost} \
            --port ${adminPort} \
            --bindDN "${bDN}" \
            --trustAll \
            --noPropertiesFile \
            >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
f
EOF
         rc=$?
#            --bindPasswordFile "${jPW}" \
#            --no-prompt \
         ${dcfg} \
            set-workflow-element-prop --element-name userRoot --set group-membership-caching-threshold:10000 \
            --hostName ${localHost} \
            --port ${adminPort} \
            --bindDN "${bDN}" \
            --trustAll \
            --noPropertiesFile \
            >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
f
EOF
         rc=$?
#            --bindPasswordFile "${jPW}" \
#            --no-prompt \
         ${dcfg} \
            create-entry-cache --type fifo --cache-name userRoot-fifoEC --set max-entries:1000000 --set max-memory-percent:10 --set cache-level:2 --set enabled:true --set entry-cache-workflow-element:userRoot \
            --hostName ${localHost} \
            --port ${adminPort} \
            --bindDN "${bDN}" \
            --trustAll \
            --noPropertiesFile \
            >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
f
EOF
         rc=$?;set +x
#            --bindPasswordFile "${jPW}" \
#            --no-prompt \
      fi
   elif [ -e  ${cfgdir}/oud-${now}.batch ]
   then
      let steps++
      echo "Step: ${steps} - Apply base batch configuration to OUD instance (${oudprefix}${node})" | tee -a  ${logdir}/oud-setup-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dcfg} \
         --batchFilePath ${cfgdir}/oud-${now}.batch \
         --hostName ${localHost} \
         --port ${adminPort} \
         --bindDN "${bDN}" \
         --bindPasswordFile "${jPW}" \
         --no-prompt \
         --trustAll \
         --noPropertiesFile \
         >> ${logdir}/oud-setup-${now}.log 2>&1
      rc=$?;set +x
   fi
}

###############################################################################
# Purge replica
###############################################################################
purge_replica() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${drepl} verify \
      --hostname ${supplierHost} \
      --port ${supplierPort} \
      --portProtocol auto-detect \
      --replicationServer ${localHost}:${replPort} \
      --replicationServer ${localHost}:2989 \
      --serverToRemove ${localHost}:2444 \
      --adminUID admin \
      --adminPasswordFile "${jPW}" \
      --no-prompt \
      --trustAll
   rc=$?;set +x
}

###############################################################################
# Stop OUD instance
###############################################################################
stop_oud() {
   if [ -z "${pnum}" ];then pnum=0;fi
   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d ${oudprefix}[0-9]* 2> /dev/null|sed -e "s/${oudprefix}//g")
      for node in ${nodes}
      do
         let steps++
         echo -e "Step: ${steps} - Stop OUD instance (${oudprefix}${node})\c" | tee -a  ${logdir}/oud-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${node}/OUD/bin/stop-ds >> ${logdir}/oud-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      done
   else
      if [ -e "${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds" ]
      then
         let steps++
         echo -e "Step: ${steps} - Stop OUD instance (${oudprefix}${pnum})\c" | tee -a  ${logdir}/oud-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds >> ${logdir}/oud-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.oud.stop
}


###############################################################################
# Start OUD instance
###############################################################################
start_oud() {
   if [ -z "${pnum}" ];then pnum=0;fi
   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d ${oudprefix}[0-9]* 2> /dev/null|sed -e "s/${oudprefix}//g")
      for node in ${nodes}
      do
         let steps++
         echo -e "Step: ${steps} - Start OUD instance (${oudprefix}${node})\c" | tee -a  ${logdir}/oud-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${node}/OUD/bin/start-ds >> ${logdir}/oud-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      done
   else
      if [ -e "${oudmwdir}/${oudprefix}${pnum}/OUD/bin/start-ds" ]
      then
         let steps++
         echo -e "Step: ${steps} - Start OUD instance (${oudprefix}${pnum})\c" | tee -a  ${logdir}/oud-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/start-ds >> ${logdir}/oud-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.oud.start
}

###############################################################################
# Upgrade OUD instance
###############################################################################
upgrade_oud() {
   stop_oud
   if [ -z "${pnum}" ];then pnum=0;fi
   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d ${oudprefix}[0-9]* 2> /dev/null|sed -e "s/${oudprefix}//g")
      for node in ${nodes}
      do
         let steps++
         echo -e "Step: ${steps} - Upgrade OUD instance (${oudprefix}${node})\c" | tee -a  ${logdir}/oud-upgrade-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${node}/OUD/bin/start-ds --upgrade >> ${logdir}/oud-upgrade-${now}.log 2>&1
         rc=$?
         echo
         set +x
      done
   else
      let steps++
      echo -e "Step: ${steps} - Upgrade OUD instance (${oudprefix}${pnum})\c" | tee -a  ${logdir}/oud-upgrade-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/start-ds --upgrade >> ${logdir}/oud-upgrade-${now}.log 2>&1
      rc=$?
      echo
      set +x
   fi
}

###############################################################################
# Setup OUD
###############################################################################
setup_oud() {
   if [ -z "${pnum}" ];then pnum=1;fi

   # Handle special circumstance of running OUD on ports 389, 636, 444, and 989
   if [ "${pnum}" == "0" ]
   then
      lookupos
      case ${os} in
         'Linux') case ${olv} in
                  5) pycmd="python";echo "RedHat/Oracle Linux version 5 is not supported.";exit 1;;
                  '7'|'8'|'9') 
                      echo net.ipv4.ip_unprivileged_port_start=389| sudo tee -a /etc/sysctl.conf 2>&1 > /dev/null && sudo sysctl -p /etc/sysctl.conf 2>&1 > ${logdir}/oud-setup-${now}.log
                      # Block all ports but those used by OUD in the privileged range of 1 to 2024.
                      sudo iptables -I INPUT -p tcp --dport 390:442 -j DROP
                      sudo iptables -I INPUT -p udp --dport 390:442 -j DROP
                      sudo iptables -I INPUT -p tcp --dport 445:554 -j DROP
                      sudo iptables -I INPUT -p udp --dport 445:554 -j DROP
                      sudo iptables -I INPUT -p tcp --dport 556:635 -j DROP
                      sudo iptables -I INPUT -p udp --dport 556:635 -j DROP
                      sudo iptables -I INPUT -p tcp --dport 637:887 -j DROP
                      sudo iptables -I INPUT -p udp --dport 637:887 -j DROP
                      sudo iptables -I INPUT -p tcp --dport 889:988 -j DROP
                      sudo iptables -I INPUT -p udp --dport 889:988 -j DROP
                      sudo iptables -I INPUT -p tcp --dport 990:1024 -j DROP
                      sudo iptables -I INPUT -p udp --dport 990:1024 -j DROP
                     ;;
                  esac
                  ;;
      esac

      # Manually set ports
      ldapPort=389
      httpsPort=443
      adminPort=444
      httpsAdminPort=555
      ldapsPort=636
      replPort=989
   fi

   if [ -e  "${oudmwdir}/${oudprefix}${pnum}/OUD/bin/start-ds" ]
   then
      echo "OUD instance ${oudprefix}${pnum} already exists"
      exit 0
   fi

   # Install OUD
   rm ${cfgdir}/.steps.install.oud 2> /dev/null
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_install.sh install oud --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag} --step ${steps}
   set +x
   if [ -e "${cfgdir}/.steps.install.oud" ];then steps=$(cat ${cfgdir}/.steps.install.oud);fi

   # Make sure ports are not already in use
   node=$(grep "ds-cfg-listen-port: ${adminPort}$" ${oudmwdir}/${oudprefix}*/OUD/config/config.ldif 2> /dev/null|sed -e "s/^.*${oudprefix}//g" -e "s/\/OUD.*//g")
   if [ -n "${node}" ];then echo "ERROR: OUD instance already exists with port ${adminPort}";exit 1;else node=${pnum};fi

   # Setup pnum to 1 if no OUD instances exist
   cd "${oudmwdir}" 2> /dev/null
   cnum=$(ls -1d ${oudprefix}[0-9]* 2> /dev/null|sed -e "s/${oudprefix}//g"|tail -1)
   if [ -n "${cnum}" ];then pnum=${cnum};let pnum++;else pnum=1;fi
   if [ -n "${myPnum}" ];then pnum=${myPnum};fi

   # Check inputs
   if [ -z "${suffix}" ];then showUsage "Must specify --suffix <suffix>";fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -z "${supplierReplPort}" ];then snum=$(echo "${supplierPort}"|sed -e "s/44[45]$//g");supplierReplPort=${snum}989;fi

   if [ -n "${supplierHost}" ] && [ -n "${supplierPort}" ]
   then
      ckAdmin=$(test_port ${supplierHost} ${supplierPort})
      ckREPL=$(test_port ${supplierHost} ${supplierReplPort})

      ckDown=$(echo ${ckAdmin} ${ckREPL}|grep DOWN)
      if [ -n "${ckDown}" ]
      then
         echo "Error: The supplier appears to be down or blocked by firewall."
         echo "Verify supplier is up and supplier's host-based firewall allows these  ports:"
         echo "   firewall-cmd --permanent --zone=public --add-port=${adminPort}/tcp"
         echo "   firewall-cmd --permanent --zone=public --add-port=${ldapPort}/tcp"
         echo "   firewall-cmd --permanent --zone=public --add-port=${ldapsPort}/tcp"
         echo "   firewall-cmd --permanent --zone=public --add-port=${replPort}/tcp"
         echo "   firewall-cmd --reload"
         exit 1
      fi
   fi

   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   export JAVA_HOME
   PATH=${JAVA_HOME}/bin:$PATH

   # Generate sample batch file
   gen_batch_files

   # Setup OUD storage instance
   if [ -e  "${oudmwdir}/${oudprefix}${pnum}/OUD/config/config.ldif" ]
   then
      true
   else
      # Make sure cert exists
      ${curdir}/manage_certs.sh gencert -h ${localHost} ${fmwFlag} --step ${steps}


      let steps++
      echo "Step: ${steps} - Setup OUD storage instance (${oudprefix}${node})" | tee -a  ${logdir}/oud-setup-${now}.log
      export INSTANCE_NAME="${oudprefix}${pnum}"
      if [ "${ktype}" == 'jks' ] && [ -e "${kstore}" ] && [ -e "${kpin}" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         if [ "${fmwVersion}" == '12c' ] || [ "${fmwVersion}" == '12cPS4' ] || [ "${fmwVersion}" == '12cPS3' ]
         then
            ${oudmwdir}/oud/oud-setup \
               --cli \
               ${integrationOption} \
               --instancePath ${oudmwdir}/${oudprefix}${pnum}/OUD \
               --adminConnectorPort ${adminPort} \
               --ldapPort ${ldapPort} \
               --ldapsPort ${ldapsPort} \
               ${restOptions} \
               --baseDN "${suffix}" \
               --rootUserDN "${bDN}" \
               --addBaseEntry \
               --enableStartTLS \
               --useJavaKeystore ${kstore} \
               --keyStorePasswordFile ${kpin} \
               --certNickname server-cert \
               --hostName ${localHost} \
               --noPropertiesFile \
               >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
${bPW}
2
2
yes
1
EOF
             rc=$?;set +x
          elif [ "${fmwVersion}" == '14c' ]
          then
            ${oudmwdir}/oud/oud-setup \
               --cli \
               ${integrationOption} \
               --instancePath ${oudmwdir}/${oudprefix}${pnum}/OUD \
               --adminConnectorPort ${adminPort} \
               --ldapPort ${ldapPort} \
               --ldapsPort ${ldapsPort} \
               ${restOptions} \
               --baseDN "${suffix}" \
               --rootUserDN "${bDN}" \
               --addBaseEntry \
               --enableStartTLS \
               --useJavaKeystore ${kstore} \
               --keyStorePasswordFile ${kpin} \
               --certNickname server-cert \
               --hostName ${localHost} \
               --noPropertiesFile \
               >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
${bPW}
2
2
yes
1
EOF
             rc=$?;set +x
          fi

#            --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -server\ -XX:MaxTenuringThreshold=1\ -XX:+UseConcMarkSweepGC\ -XX:CMSInitiatingOccupancyFraction=70\ -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark\ -Djdk.tls.maxHandshakeMessageSize=36864 \
#            --offlineToolsTuning -Xms2g\ -Xmx2g\ -XX:+UseCompressedOops\ -server\ -Xmn512m\ -XX:+UseParallelGC\ -XX:+UseNUMA \

#            --no-prompt \
#            --rootUserPasswordFile "${jPW}" \


# -XX:+DisableExplicitGC

# Opt2
#            --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -server\ -XX:MaxTenuringThreshold=1\ -XX:+UseConcMarkSweepGC\ -XX:CMSInitiatingOccupancyFraction=70\ -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark\ -Djdk.tls.maxHandshakeMessageSize=36864 \

# PSR
#            --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -server\ -XX:MaxTenuringThreshold=1\ -XX:+UseConcMarkSweepGC\ -XX:CMSInitiatingOccupancyFraction=70\ -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark \
# Opt1
#            --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -XX:+UseCompressedOops\ -server\ -XX:MaxTenuringThreshold=1\ -XX:+UseConcMarkSweepGC\ -XX:CMSInitiatingOccupancyFraction=70\ -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark\ -Djdk.tls.maxHandshakeMessageSize=36864 \

         if [ ${rc} -ne 0 ];then echo -e "ERROR setting up OUD instance.\nReview ${logdir}/oud-setup-${now}.log";exit 1;fi
         set +x
      elif [ "${ktype}" == 'p12' ] && [ -e "${kstore}" ] && [ -e "${kpin}" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         if [ "${fmwVersion}" == '12c' ] || [ "${fmwVersion}" == '12cPS4' ] || [ "${fmwVersion}" == '12cPS3' ]
         then
            ${oudmwdir}/oud/oud-setup \
               --cli \
               ${integrationOption} \
               --instancePath ${oudmwdir}/${oudprefix}${pnum}/OUD \
               --adminConnectorPort ${adminPort} \
               --ldapPort ${ldapPort} \
               --ldapsPort ${ldapsPort} \
               ${restOptions} \
               --baseDN "${suffix}" \
               --rootUserDN "${bDN}" \
               --addBaseEntry \
               --enableStartTLS \
               --usePkcs12keyStore ${kstore} \
               --keyStorePasswordFile ${kpin} \
               --certNickname server-cert \
               --hostName ${localHost} \
               --noPropertiesFile \
               >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
${bPW}
yes
1
EOF
             rc=$?
          elif [ "${fmwVersion}" == '14c' ]
          then
            ${oudmwdir}/oud/oud-setup \
               --cli \
               ${integrationOption} \
               --instancePath ${oudmwdir}/${oudprefix}${pnum}/OUD \
               --adminConnectorPort ${adminPort} \
               --ldapPort ${ldapPort} \
               --ldapsPort ${ldapsPort} \
               ${restOptions} \
               --baseDN "${suffix}" \
               --rootUserDN "${bDN}" \
               --addBaseEntry \
               --enableStartTLS \
               --usePkcs12keyStore ${kstore} \
               --keyStorePasswordFile ${kpin} \
               --certNickname server-cert \
               --hostName ${localHost} \
               --noPropertiesFile \
               >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
${bPW}





EOF
             rc=$?
          fi

#            --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -server\ -XX:MaxTenuringThreshold=1\ -XX:+UseConcMarkSweepGC\ -XX:CMSInitiatingOccupancyFraction=70\ -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark\ -Djdk.tls.maxHandshakeMessageSize=36864 \
#            --offlineToolsTuning -Xms2g\ -Xmx2g\ -XX:+UseCompressedOops\ -server\ -Xmn512m\ -XX:+UseParallelGC\ -XX:+UseNUMA \

#            --no-prompt \
#            --rootUserPasswordFile "${jPW}" \
         if [ ${rc} -ne 0 ];then echo -e "ERROR setting up OUD instance.\nReview ${logdir}/oud-setup-${now}.log";exit 1;fi
         set +x
      elif [ "${ktype}" == 'none' ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi

         #      --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -server\ -XX:MaxTenuringThreshold=1\ -XX:+UseConcMarkSweepGC\ -XX:CMSInitiatingOccupancyFraction=70\ -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark\ -Djdk.tls.maxHandshakeMessageSize=36864 \

         if [ "${fmwVersion}" == '12c' ] || [ "${fmwVersion}" == '12cPS4' ] || [ "${fmwVersion}" == '12cPS3' ]
         then
            #   --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -server \ 
            #   --offlineToolsTuning -Xms2048m\ -Xmx2048m\ -XX:+UseCompressedOops\ -server\ -Xmn512m\ -XX:+UseParallelGC\ -XX:+UseNUMA \
            ${oudmwdir}/oud/oud-setup \
               --cli \
               ${integrationOption} \
               --instancePath ${oudmwdir}/${oudprefix}${pnum}/OUD \
               --adminConnectorPort ${adminPort} \
               --ldapPort ${ldapPort} \
               --ldapsPort ${ldapsPort} \
               ${restOptions} \
               --baseDN "${suffix}" \
               --rootUserDN "${bDN}" \
               --addBaseEntry \
               --enableStartTLS \
               --generateSelfSignedCertificate \
               --certNickname server-cert \
               --hostName ${localHost} \
               --noPropertiesFile \
               >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
${bPW}
RSA
SHA256withRSA
3072
yes
1
EOF
             rc=$?
          elif [ "${fmwVersion}" == '14c' ]
          then
            #   --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -server\ -XX:MaxTenuringThreshold=1\ -XX:+UseConcMarkSweepGC\ -XX:CMSInitiatingOccupancyFraction=70\ -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark\ -Djdk.tls.maxHandshakeMessageSize=36864 \
            #   --serverTuning -Xms${jmem}m\ -Xmx${jmem}m\ -Xmn${xmn}g\ -server \
            #   --offlineToolsTuning -Xms2048m\ -Xmx2048m\ -XX:+UseCompressedOops\ -server\ -Xmn512m\ -XX:+UseParallelGC\ -XX:+UseNUMA \

            ${oudmwdir}/oud/oud-setup \
               --cli \
               ${integrationOption} \
               --instancePath ${oudmwdir}/${oudprefix}${pnum}/OUD \
               --adminConnectorPort ${adminPort} \
               --ldapPort ${ldapPort} \
               --ldapsPort ${ldapsPort} \
               ${restOptions} \
               --baseDN "${suffix}" \
               --rootUserDN "${bDN}" \
               --addBaseEntry \
               --enableStartTLS \
               --generateSelfSignedCertificate \
               --certNickname server-cert \
               --hostName ${localHost} \
               --noPropertiesFile \
               >> ${logdir}/oud-setup-${now}.log 2>&1 <<EOF
${bPW}
${bPW}
RSA
SHA256withRSA
3072
2
2
yes
1
EOF
             rc=$?
          fi

#            --no-prompt \
#            --rootUserPasswordFile "${jPW}" \
         if [ ${rc} -ne 0 ];then echo -e "ERROR setting up OUD instance.\nReview ${logdir}/oud-setup-${now}.log";exit 1;fi
         set +x
      else
         if [ -e "${kstore}" ]
         then
            true
         else
            echo -e "\nError: Key store (${kstore}) does not exist. "
         fi
         if [ -e "${kpin}" ]
         then
            true
         else
            echo -e "\nError: Key store pin (${kpin}) does not exist. "
         fi
         case ${ktype} in
            'none') true;;
             'jks') true;;
             'p12') true;;
                 *) echo;showUsage "Invalid keystore type (${ktype})";;
         esac
      fi
   fi

   # Copy in custom plugins
   for (( x=0; x< ${#plugins[*]}; x++ ))
   do
      if [ -s "${plugins[${x}]}" ]
      then
         let steps++
         echo -e "Step: ${steps} - Copying custom plugin (${plugins[${x}]}) into OUD instance library path" | tee -a  ${logdir}/oud-setup-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         cp "${plugins[${x}]}" "${oudmwdir}/${oudprefix}${pnum}/OUD/lib/."
         rc=$?;set +x
      fi
   done

   if [ "${notune}" == 'true' ]
   then
      true
   else
      if [ -n "${jmem}" ]
      then
         let steps++
         echo -e "Step: ${steps} - Tune JVM to LDIF size with dstune" | tee -a  ${logdir}/oud-setup-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?;set +x
         if [ "${dbg}" == 'true' ];then set -x;fi
         #${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dstune mem-based --memory 4g --targetTool import-ldif --no-prompt >> ${logdir}/oud-setup-${now}.log 2>&1
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dstune set-runtime-options --targetTool import-ldif --no-prompt --value "-Xms${importJmem}g -Xmx${importJmem}g -Xmn${importXmn}g -server -XX:+UseCompressedOops -XX:+UseParallelGC -XX:+UseNUMA" >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?;set +x
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dstune mem-based --memory ${jmem}m --targetTool server --no-prompt >> ${logdir}/oud-setup-${now}.log 2>&1
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dsjavaproperties >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?;set +x
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/start-ds >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?;set +x
      else
         let steps++
         echo -e "Step: ${steps} - Tune import-ldif with dstune" | tee -a  ${logdir}/oud-setup-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?;set +x
         # Increase import-ldif to jmem size so that import will work
         if [ "${dbg}" == 'true' ];then set -x;fi
         #${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dstune mem-based --memory 4g --targetTool import-ldif --no-prompt >> ${logdir}/oud-setup-${now}.log 2>&1
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dstune set-runtime-options --targetTool import-ldif --no-prompt --value "-Xms${importJmem}g -Xmx${importJmem}g -Xmn${importXmn}g -server -XX:+UseCompressedOops -XX:+UseParallelGC -XX:+UseNUMA" >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?;set +x
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dsjavaproperties >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?;set +x

         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/start-ds >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?;set +x
      fi
   fi

#   if [ -n "${jmem}" ] && [ ${jmem} -gt 4096 ]
#   then
#      # Tune OUD instance
#      if [ -e  "${oudmwdir}/${oudprefix}${pnum}/OUD/config/config.ldif" ]
#      then
#         let steps++
#         echo -e "Step: ${steps} - Tune OUD instance (${oudprefix}${pnum})\c" | tee -a  ${logdir}/oud-setup-${now}.log
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds >> ${logdir}/oud-setup-${now}.log 2>&1
#         rc=$?;set +x
#         echo -e ".\c"
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dstune mem-based --memory ${jmem}m --targetTool server --no-prompt >> ${logdir}/oud-setup-${now}.log 2>&1
#         rc=$?;set +x
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dstune list --no-prompt >> ${logdir}/oud-setup-${now}.log 2>&1
#         rc=$?;set +x
#         echo -e ".\c"
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/dsjavaproperties >> ${logdir}/oud-setup-${now}.log 2>&1
#         rc=$?;set +x
#         echo -e ".\c"
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/start-ds >> ${logdir}/oud-setup-${now}.log 2>&1
#         rc=$?;set +x
#         echo -e ".done"
#      fi
#   fi

   # Load nsRole Schema
   gen_nsrole_schema

   # Load nsRole schema
   #if [ -z "${oudSupplier}" ] && [ -e "${cfgdir}/nsRoles.schema" ] && [ "${disableRoles}" != 'true' ]
   if [ -e "${cfgdir}/nsRoles.schema" ] && [ "${disableRoles}" != 'true' ]
   then
      let steps++
      echo "Step: ${steps} - Load nsRole schema" | tee -a  ${logdir}/load-schema-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${cfgdir}/nsRoles.schema" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${lmod} -Z -X -p ${adminPort} -h ${localHost} -D "${bDN}" -j "${jPW}" -c -f "${cfgdir}/nsRoles.schema" >> ${logdir}/load-schema-${now}.log 2>&1 <<EOF
${bPW}
f
EOF
         rc=$?
         set +x
      fi
   fi

   # Apply batch configuration
   apply_compatibility_batch

   # Load custom Schema
   #if [ -z "${oudSupplier}" ] && [ -e "${schemaFile}" ]
   cd "${curdir}"
   if [ -e "${schemaFile}" ]
   then
      let steps++
      echo "Step: ${steps} - Load custom schema" | tee -a  ${logdir}/load-schema-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${lmod} -Z -X -p ${adminPort} -h ${localHost} -D "${bDN}" -j "${jPW}" -c -f "${schemaFile}" >> ${logdir}/load-schema-${now}.log 2>&1 <<EOF
${bPW}
f
EOF
      rc=$?
      set +x
   fi

#   # If database cache specified, add to batch file
#   if [ -n "${dbc}" ] && [ -n "${batchFile}" ]
#   then
#      echo "set-workflow-element-prop --element-name ${backend} --set db-cache-size:${dbc}\ mib" >> ${batchFile}
#   fi

   # Apply batch configuration
   apply_custom_batch

   if [ "${norepl}" != 'true' ]
   then
      if [ -z "${oudSupplier}" ]
      then
         let steps++
         echo "Step: ${steps} - Enable replication server" | tee -a  ${logdir}/oud-setup-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         idn=$(( RANDOM % 10000 + 10000))
         ${dcfg} create-replication-server \
            --provider-name Multimaster\ Synchronization \
            --set replication-port:${replPort} \
            --set replication-server-id:${idn} \
            --type generic \
            --hostName ${localHost} \
            --port ${adminPort} \
            --bindDN "${bDN}" \
            --bindPasswordFile "${jPW}" \
            --no-prompt \
            --trustAll \
            --noPropertiesFile \
            >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?
         set +x

         idn=$(( RANDOM % 10000 + 10000))
         ${dcfg} create-replication-domain \
            --provider-name Multimaster\ Synchronization \
            --set base-dn:${suffix} \
            --set replication-server:${localHost}:${replPort} \
            --set server-id:${idn} \
            --type generic \
            --domain-name "${suffix}" \
            --hostName ${localHost} \
            --port ${adminPort} \
            --bindDN "${bDN}" \
            --bindPasswordFile "${jPW}" \
            --no-prompt \
            --trustAll \
            --noPropertiesFile \
            >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?
         set +x

#         if [ "${dbg}" == 'true' ];then set -x;fi
#         ${dcfg} set-crypto-manager-prop \
#            --set ssl-encryption:true \
#            --hostName ${localHost} \
#            --port ${adminPort} \
#            --bindDN "${bDN}" \
#            --bindPasswordFile "${jPW}" \
#            --trustAll \
#            --no-prompt \
#            --noPropertiesFile \
#            >> ${logdir}/oud-setup-${now}.log 2>&1
#         rc=$?
#         set +x

      else
         # If replication role is Directory Server and Replication Server
         if [ "${role}" == 'DSRS' ]
         then
            let steps++
            echo "Step: ${steps} - Enable DS+RS replication from supplier ${supplierH}" | tee -a  ${logdir}/oud-setup-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${drepl} enable \
               ${replEnc} \
               --host1 ${supplierHost} \
               --port1 ${supplierPort} \
               --bindDN1 "${bDN}" \
               --bindPasswordFile1 "${jPW}" \
               --bindPasswordFile2 "${jPW}" \
               --replicationPort1 ${supplierReplPort} \
               --host2 ${localHost} \
               --port2 ${adminPort} \
               --bindDN2 "${bDN}" \
               --replicationPort2 ${replPort} \
               --baseDN "${suffix}" \
               --adminUID admin \
               --adminPasswordFile "${jPW}" \
               --trustAll \
               --noPropertiesFile \
               --no-prompt \
               >> ${logdir}/oud-setup-${now}.log 2>&1
            rc=$?
            set +x
         # If replication role is just Replication Server
         elif [ "${role}" == 'RS' ]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${drepl} enable \
               ${replEnc} \
               --host1 ${supplierHost} \
               --port1 ${supplierPort} \
               --bindDN1 "${bDN}" \
               --bindPasswordFile1 "${jPW}" \
               --replicationPort1 ${supplierReplPort} \
               --host2 ${localHost} \
               --port2 ${adminPort} \
               --bindDN2 "${bDN}" \
               --bindPasswordFile2 "${jPW}" \
               --replicationPort2 ${replPort} \
               --onlyReplicationServer2 \
               --baseDN "${suffix}" \
               --adminUID admin \
               --adminPasswordFile "${jPW}" \
               --trustAll \
               --no-prompt \
               --noPropertiesFile \
               >> ${logdir}/oud-setup-${now}.log 2>&1
            rc=$?;set +x
         # If replication role is just Directory Server
         elif [ "${role}" == 'DS' ]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${drepl} enable \
               --host1 ${supplierHost} \
               --port1 ${supplierPort} \
               --bindDN1 "${bDN}" \
               --bindPasswordFile1 "${jPW}" \
               --host2 ${localHost} \
               --port2 ${adminPort} \
               --bindDN2 "${bDN}" \
               --bindPasswordFile2 "${jPW}" \
               --noReplicationServer2 \
               --baseDN "${suffix}" \
               --adminUID admin \
               --adminPasswordFile "${jPW}" \
               --connectTimeout 1000000 \
               --readTimeout 1000000 \
               --trustAll \
               --no-prompt \
               --noPropertiesFile \
               >> ${logdir}/oud-setup-${now}.log 2>&1
            rc=$?;set +x
         fi
      fi
   fi

   if [ -z "${oudSupplier}" ] && [ -e "${dataFile}" ] && [ "${noinit}" == 'false' ]
   then
      if [ "${offline}" == 'false' ]
      then
         let steps++
         echo "Step: ${steps} - Load data LDIF file" | tee -a  ${logdir}/oud-setup-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/import-ldif \
            -O \
            -h ${localHost} \
            -p ${adminPort} \
            -D "${bDN}" \
            -j "${jPW}" \
            --skipFile ${logdir}/oud-import-skipfile-${now}.log \
            --rejectFile ${logdir}/oud-import-rejectfile-${now}.log \
            ${nocheck} \
            -n ${backend} \
            -l ${dataFile} \
            >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?
         set +x

         # Re-start OUD instance
         if [ "${notune}" == 'true' ]
         then
            true
         else
            if [ -e "${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds" ] && [ "${disableRestart}" != 'true' ]
            then
               stop_oud
               start_oud
            fi
         fi
      else
         let steps++
         echo "Step: ${steps} - Load data LDIF file offline" | tee -a  ${logdir}/oud-setup-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?
         rm -fr "/tmp/${oudprefix}${pnum}-tmp" 2> /dev/null
         mkdir "/tmp/${oudprefix}${pnum}-tmp" 2> /dev/null
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/import-ldif \
            -O \
            --skipFile ${logdir}/oud-import-skipfile-${now}.log \
            --rejectFile ${logdir}/oud-import-rejectfile-${now}.log \
            --tmpdirectory /tmp/${oudprefix}${pnum}-tmp \
            ${nocheck} \
            -n ${backend} \
            -l ${dataFile} \
            >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?
         rm -fr "/tmp/${oudprefix}${pnum}-tmp" 2> /dev/null
         ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/start-ds >> ${logdir}/oud-setup-${now}.log 2>&1
         rc=$?
         set +x
      fi

   elif [ -n "${oudSupplier}" ] && [ -n "${supplierHost}" ] && [ -n "${supplierPort}" ]
   then
      # Re-start OUD instance
      if [ -e "${oudmwdir}/${oudprefix}${pnum}/OUD/bin/stop-ds" ] && [ "${disableRestart}" != 'true' ]
      then
         stop_oud
      fi

      if [ "${noinit}" == 'false' ]
      then
         case ${initMethod} in
               'protocol') start_oud
                           let steps++
                           echo -e "Step: ${steps} - Initialize from supplier ${supplierH} (${oudprefix}${node}).\c" | tee -a  ${logdir}/oud-init-${now}.log
                           echo -e ".\c"
                           if [ "${dbg}" == 'true' ];then set -x;fi
                           ${drepl} initialize \
                              --hostSource ${supplierHost} \
                              --portSource ${supplierPort} \
                              --portProtocolSource auto-detect \
                              --hostDestination ${localHost} \
                              --portDestination ${adminPort} \
                              --portProtocolDestination auto-detect \
                              --baseDN "${suffix}" \
                              --adminUID admin \
                              --adminPasswordFile "${jPW}" \
                              --trustAll \
                              --no-prompt \
                           >> ${logdir}/oud-init-${now}.log 2>&1
                           rc=$?;set +x
                           echo -e ".done"
                           ;;
                   'ldif') if [ -e "${initInput}" ]
                           then
                              let steps++
                              echo "Step: ${steps} - Initialize from LDIF file" | tee -a  ${logdir}/oud-init-${now}.log
                              if [ "${dbg}" == 'true' ];then set -x;fi
                              ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/import-ldif \
                                 ${compress} \
                                 -O \
                                 --skipFile ${logdir}/oud-import-skipfile-${now}.log \
                                 --rejectFile ${logdir}/oud-import-rejectfile-${now}.log \
                                 ${nocheck} \
                                 -n "${backend}" \
                                 -l "${initInput}" \
                              >> ${logdir}/oud-init-${now}.log 2>&1
                              rc=$?
                              set +x
                           else
                              echo "ERROR: LDIF file not found"
                              echo "  file: ${initInput}"
                              echo "  Review log: ${logdir}/oud-init-${now}.log"
                              exit 1
                           fi
                           start_oud
                           ;;
                 'binary') if [ -d "${initInput}" ]
                           then
                              if [ "${dbg}" == 'true' ];then set -x;fi
                              let steps++
                              echo "Step: ${steps} - Restore from binary backup ${dir}" | tee -a  ${logdir}/oud-init-${now}.log
                              ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/restore \
                                 --backupDirectory "${initInput}/${backend}" \
                              >> ${logdir}/oud-init-${now}.log 2>&1
                              rc=$?
                              set +x
                           else
                              echo "ERROR: Backup directory not found"
                              echo "  file: ${initInput}"
                              echo "  Review log: ${logdir}/oud-init-${now}.log"
                              exit 1
                           fi
                           start_oud
                           ;;
         esac
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.oud
}

###############################################################################
# Export OUD
###############################################################################
export_oud() {
   if [ -z "${pnum}" ];then pnum=1;fi
   if [ ${pnum} -eq 0 ];then pnum=1;fi
   if [ -z "${initInput}" ]
   then
      echo "Usage: ${0} export --ldiffile <file> [--pnum <number> --be <backend>]"
      exit 1
   fi

   if [ -e "${initInput}" ]
   then
      echo "ERROR: export LDIF file already exists"
      exit 1
   else
      stop_oud
      if [ "${dbg}" == 'true' ];then set -x;fi
      let steps++
      echo "Step: ${steps} - Export backend ${backend} to compresed LDIF file" | tee -a  ${logdir}/oud-init-${now}.log
      ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/export-ldif \
         ${compress} \
         -n "${backend}" -l "${initInput}" \
      >> ${logdir}/oud-init-${now}.log 2>&1
      rc=$?
      set +x

      if [ ${rc} -ne 0 ]
      then
         echo "ERROR: LDIF export failed"
         echo "  Review log: ${logdir}/oud-init-${now}.log"
      fi

      start_oud
   fi
}

###############################################################################
# Import OUD
###############################################################################
import_oud() {
   if [ -z "${pnum}" ];then pnum=1;fi
   if [ ${pnum} -eq 0 ];then pnum=1;fi
   if [ -z "${initInput}" ]
   then
      echo "Usage: ${0} import --ldiffile <file> [--pnum <number> --be <backend>]"
      exit 1
   fi

   if [ -e "${initInput}" ]
   then
      stop_oud
      if [ "${dbg}" == 'true' ];then set -x;fi
      let steps++
      echo "Step: ${steps} - Import backend ${backend} from LDIF file" | tee -a  ${logdir}/oud-init-${now}.log
      rm -fr "/tmp/${oudprefix}${pnum}-tmp" 2> /dev/null
      mkdir "/tmp/${oudprefix}${pnum}-tmp" 2> /dev/null
      ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/import-ldif \
         --tmpdirectory /tmp/${oudprefix}${pnum}-tmp \
         --skipDNValidation --skipSchemaValidation \
         ${compress} \
         -n "${backend}" -l "${initInput}" \
      >> ${logdir}/oud-init-${now}.log 2>&1
      rc=$?
      rm -fr "/tmp/${oudprefix}${pnum}-tmp" 2> /dev/null
      set +x

      if [ ${rc} -ne 0 ]
      then
         echo "ERROR: LDIF import failed"
         echo "  Review log: ${logdir}/oud-init-${now}.log"
      fi

      start_oud
   else
      echo "ERROR: LDIF export file not found"
      echo "  file: ${initInput}"
      echo "  Review log: ${logdir}/oud-init-${now}.log"
      exit 1
   fi
}

###############################################################################
# Backup OUD
###############################################################################
backup_oud() {
   if [ -z "${pnum}" ];then pnum=1;fi
   if [ ${pnum} -eq 0 ];then pnum=1;fi
   if [ -z "${initInput}" ]
   then
      echo "Usage: ${0} backup --backupdir <dir> [--pnum <number> --be <backend>]"
      exit 1
   fi

   # Make sure backup directory exists
   mkdir -p "${initInput}" 2> /dev/null

   if [ -d "${initInput}" ]
   then
      stop_oud
      if [ "${dbg}" == 'true' ];then set -x;fi
      let steps++
      echo "Step: ${steps} - Backup backend ${backend} to binary files" | tee -a  ${logdir}/oud-init-${now}.log
      ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/backup \
         ${compress} \
         -n "${backend}" --backupDirectory "${initInput}/${backend}" \
      >> ${logdir}/oud-init-${now}.log 2>&1
      rc=$?
      set +x

      if [ ${rc} -ne 0 ]
      then
         echo "ERROR: Backup failed"
         echo "  Review log: ${logdir}/oud-init-${now}.log"
      fi

      start_oud
   else
      echo "ERROR: Backup directory not found"
      echo "  file: ${initInput}"
      echo "  Review log: ${logdir}/oud-init-${now}.log"
      exit 1
   fi
}

###############################################################################
# Restore OUD
###############################################################################
restore_oud() {
   if [ -z "${pnum}" ];then pnum=1;fi
   if [ ${pnum} -eq 0 ];then pnum=1;fi
   if [ -z "${initInput}" ]
   then
      echo "Usage: ${0} restore --backupdir <dir> [--pnum <number>]"
      exit 1
   fi

   if [ -d "${initInput}" ]
   then
      stop_oud
      if [ "${dbg}" == 'true' ];then set -x;fi
      let steps++
      echo "Step: ${steps} - Restore backend ${backend} from binary backup ${dir}" | tee -a  ${logdir}/oud-init-${now}.log
      ${oudmwdir}/${oudprefix}${pnum}/OUD/bin/restore \
         --backupDirectory "${initInput}/${backend}" \
      >> ${logdir}/oud-init-${now}.log 2>&1
      rc=$?
      set +x

      if [ ${rc} -ne 0 ]
      then
         echo "ERROR: Restore failed"
         echo "  Review log: ${logdir}/oud-init-${now}.log"
      fi

      start_oud
   else
      echo "ERROR: Backup directory not found"
      echo "  file: ${initInput}"
      echo "  Review log: ${logdir}/oud-init-${now}.log"
      exit 1
   fi
}

###############################################################################
# List OUD backups
###############################################################################
list_backups() {
   if [ -z "${initInput}" ]
   then
      echo "Usage: ${0} blist --backupdir <dir> [--pnum <number>]"
      exit 1
   fi

   if [ -d "${initInput}" ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      let steps++
      echo "Step: ${steps} - Restore backend ${backend} from binary backup ${dir}" | tee -a  ${logdir}/oud-init-${now}.log
      ${oudmwdir}/oud/bin/restore --listBackups \
         --backupDirectory "${initInput}/${backend}"
      rc=$?
      set +x

      if [ ${rc} -ne 0 ]
      then
         echo "ERROR: Backup list failed"
         echo "  Review log: ${logdir}/oud-init-${now}.log"
      fi
   else
      echo "ERROR: Backup directory not found"
      echo "  file: ${initInput}"
      echo "  Review log: ${logdir}/oud-init-${now}.log"
      exit 1
   fi
}

###############################################################################
# Check ou=status
###############################################################################
checkstatus() {
   echo "Show ou=status description value:"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${lsrch} -T -Z -X -p ${ldapsPort} -h ${localHost} -D "${bDN}" -j "${jPW}" -b ou=status 'ou=status' description <<EOF
${bPW}
f
EOF
   rc=$?
   set +x
}

###############################################################################
# Add ou=status
###############################################################################
addstatus() {
   echo "Add ou=status backend"

   # Step 1: Create status batch configuration file
   cat > ${cfgdir}/status.batch <<EOF
create-workflow-element --element-name status-be --set enabled:true --type db-local-backend --set base-dn:ou=status
create-workflow --workflow-name status-wf --set enabled:true --type generic --set base-dn:ou=status --set workflow-element:status-be
set-network-group-prop --group-name network-group --add workflow:status-wf
EOF

   # Step 2: Apply batch configuration
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${dcfg} \
      --batchFilePath ${cfgdir}/status.batch \
      --hostName ${localHost} \
      --port ${adminPort} \
      --bindDN "${bDN}" \
      --bindPasswordFile "${jPW}" \
      --no-prompt \
      --trustAll \
      --noPropertiesFile \
      >> ${logdir}/status-cfg-${now}.log 2>&1
      rc=$?
      set +x

   # Step 3: Populate ou=status
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${lmod} -Z -X -p ${ldapsPort} -h ${localHost} -D "${bDN}" -j "${jPW}" -c <<EOF <<EOF
${bPW}
f
EOF
dn: ou=status
changeType: add
objectClass: top
objectClass: organizationalUnit
ou: status
description: instanceIsUp
EOF
   rc=$?
   set +x
}

###############################################################################
# Delete ou=status
###############################################################################
delstatus() {
   echo "Delete ou=status backend"

   # Step 1: Create destatus batch configuration file
   cat > ${cfgdir}/destatus.batch <<EOF
set-network-group-prop --group-name network-group --remove workflow:status-wf
delete-workflow --workflow-name status-wf
delete-workflow-element --element-name status-be
EOF

   # Step 2: Apply batch configuration
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${dcfg} \
      --batchFilePath ${cfgdir}/destatus.batch \
      --hostName ${localHost} \
      --port ${adminPort} \
      --bindDN "${bDN}" \
      --bindPasswordFile "${jPW}" \
      --no-prompt \
      --trustAll \
      --noPropertiesFile \
      >> ${logdir}/status-cfg-${now}.log 2>&1

   rc=$?
   set +x
}

###############################################################################
# Enable ou=status
###############################################################################
enablestatus() {
   echo "Set ou=status description to instanceIsUp"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${lmod} -Z -X -p ${ldapsPort} -h ${localHost} -D "${bDN}" -j "${jPW}" -c <<EOF
dn: ou=status
changeType: modify
replace: description
description: instanceIsUp
EOF
   rc=$?
   set +x
   checkstatus
}

###############################################################################
# Disable ou=status
###############################################################################
disablestatus() {
   echo "Set ou=status description to instanceIsDown"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${lmod} -Z -X -p ${ldapsPort} -h ${localHost} -D "${bDN}" -j "${jPW}" -c <<EOF
dn: ou=status
changeType: modify
replace: description
description: instanceIsDown
EOF
   rc=$?
   set +x
   checkstatus
}

###############################################################################
# Sync data from local file/directory to remote host with rsync over ssh
###############################################################################
push_data() {
   if [ -z "${rhost}" ] || [ -z "${lpath}" ] || [ -z "${rpath}" ]
   then
      echo "Usage: ${cmd} push --ruser <user_id> --rhost <host> --lpath <file|dir> --rpath <file|dir>"
      exit 1
   fi
   if [ "${dbg}" == 'true' ];then set -x;fi
   rsync --progress -qHave ssh "${lpath}" ${ruser}@${rhost}:"${rpath}"
   set +x
}

###############################################################################
# Parse arguments
###############################################################################
nobatch='false'
norepl='false'
noinit='false'
initMethod='protocol'
initInput=''
compress=' -c '
replEnc='--secureReplication1 --secureReplication2'
steps=0
force=''
rdisp=''
radv=''
offline='false'
isreadonly='false'
fifo='false'
p=0
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            swdir) swdir="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            pnum) myPnum="$1";pnum="${myPnum}";shift;;
            suffix) suffix="$1";shift;;
            basedn) basedn="$1";shift;;
            supplier) oudSupplier="$1";shift;;
            replica) replica="$1";shift;;
            pfile) jPW="$1";shift;;
            jh) export JAVA_HOME="$1";PATH="$JAVA_HOME:$PATH";shift;;
            ktype) ktype="$1";shift;;
            kstore) kstore="$1";shift;;
            kpin) kpin="$1";shift;;
            swdir) swdir="$1";shift;;
            fmwi) fmwi="$1";shift;;
            fmwo) fmwo="$1";shift;;
            batch) batchFile="$1";shift;;
            schema) schemaFile="$1";shift;;
            data) dataFile="$1";shift;;
            be) backend="$1";shift;;
            force) force=' -f ';;
            integration) integration="$1";shift;;
            step) mySteps="$1";steps=${mySteps};shift;;
            norest) disableRest='true';;
            noroles) disableRoles='true';;
            norestart) disableRestart='true';;
            nosudo) sudoFlag=' --nosudo';;
            nobatch) nobatch='true';;
            noreplenc) replEnc='';;
            norepl) norepl='true';;
            noinit) noinit='true';;
            notune) notune='true';;
            nocompress) compress='';;
            advanced) radv="--advanced";;
            'disp'|'display'|'dataToDisplay') rdisp="$1";shift;;
            ldiffile) initMethod='ldif';initInput="$1";shift;;
            backupdir) initMethod='binary';initInput="$1";shift;;
            jmem) jmem="$1";shift;;
            xmn) xmn="$1";shift;;
            prefix) myOudPrefix="$1";shift;;
            ruser) ruser="$1";shift;;
            rhost) rhost="$1";shift;;
            lpath) lpath="$1";shift;;
            rpath) rpath="$1";shift;;
            'DS'|'ds') role='DS';;
            'RS'|'rs') role='RS';;
            readonly) isreadonly='true';;
            fifo) fifo='true';;
            plugin) plugins[${p}]="$1";let p++;shift;;
            offline) offline='true';;
            nocheck) nocheck=' --skipDNValidation --skipSchemaValidation ';;
            mlkem) export OPENDS_JAVA_ARGS="-Djdk.tls.namedGroups=MLKEM768";;
            12c) fmwVersion='12c';fmwFlag="--${fmwVersion}";;
            14c) fmwVersion='14c';fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            D) bDN="$1";;
            j) jPW="$1";;
            S) suffix="$1";;
            s) oudSupplier="$1";shift;;
            n) templateName=$1; shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done
export fmwVersion fmwFlag
setfmwenv

#echo DEBUG notune=${notune}

if [ -n "${oudSupplier}" ]
then
   supplierHost=$(echo "${oudSupplier}:"|cut -d':' -f1)
   supplierH=$(echo "${supplierHost}."|cut -d. -f1)
   supplierPort=$(echo "${oudSupplier}:"|cut -d':' -f2)
   supplierReplPort=$(echo "${oudSupplier}:"|cut -d':' -f3)
fi

# Set port numbers if pnum specified
if [ "${pnum}" == 'all' ];then pnum=0;fi
if [ "${pnum}" != 'all' ] && [ -n "${pnum}" ]
then
   ldapPort=${pnum}389
   ldapsPort=${pnum}636
   adminPort=${pnum}444
   replPort=${pnum}989
   httpsPort=${pnum}443
   httpsAdminPort=${pnum}555
fi

if [ "${pnum}" == '0' ]
then
      adminPort=444
      ldapPort=389
      ldapsPort=636
      replPort=989
      httpsPort=443
      httpsAdminPort=555
fi

if [ "${disableRest}" != 'true' ];then restOptions="--httpAdminConnectorPort ${httpsAdminPort} --httpPort disabled --httpsPort ${httpsPort}";fi


if [ -n "${templateName}" ] && [ -z "${schemaFile}" ];then schemaFile="${cfgdir}/${templateName}.schema";fi
if [ -n "${templateName}" ] && [ -z "${dataFile}" ];then dataFile="${cfgdir}/${templateName}.ldif";fi
if [ -n "${templateName}" ] && [ -z "${batchFile}" ];then batchFile="${cfgdir}/${templateName}.batch";fi
if [ -n "${templateName}" ] && [ -z "${compatBatchFile}" ];then compatBatchFile="${cfgdir}/${templateName}.compat";fi
if [ -n "${myOudPrefix}" ];then oudprefix="${myOudPrefix}";fi

if [ -z "${ktype}" ];then ktype='jks';fi
if [ "${ktype}" == 'jks' ];then kstore="${certdir}/${localHost}/${localHost}.jks";kpin="${certdir}/${localHost}/${localHost}.pin";fi
if [ "${ktype}" == 'p12' ];then kstore="${certdir}/${localHost}/${localHost}.p12";kpin="${certdir}/${localHost}/${localHost}.pin";fi

if [ -z "${ruser}" ];then ruser="${me}";fi

    if [ -z "${rdisp}" ];then rdisp='compact-view';fi

    case ${rdisp} in
                            'all') true   # All the replication information available, including advanced data.  
                                          # If this option is specified, it is recommended to use the script-friendly mode.
                                   ;;
                        'compact') rdisp='compact-view';;
                   'compact-view') true   # The minimum replication information.  It is equivalent to specifying 
                                          #    -d entry-number 
                                          #    -d missing-changes 
                                          #    -d aoomc 
                                          #    -d status 
                                          #    -d conflicts.  
                                          # The replication information that was displayed in versions prior to 11.2.2.0.0.
                                          # It is equivalent to specifying 
                                          #    -d replication-gateway-conf 
                                          #    -d entry-number 
                                          #    -d missing-changes 
                                          #    -d aoomc 
                                          #    -d status 
                                          #    -d secure-conf 
                                          #    -d trust-info 
                                          #    -d changelog-conf 
                                          #    -d group 
                                          #    -d connected-to.
                                   ;;
                   'entry-number') true;; # The number of entries in each server replicating data.
                'missing-changes') true;; # The missing changes.
                          'aoomc') true;; # The age of the oldest missing change.
                         'status') true;; # The replication status of the replication domain or of the replication server.
                    'secure-conf') true;; # The security configuration.
                     'trust-info') true;; # The trust replication information.
                 'changelog-conf') true;; # The changelog configuration.
                          'group') true;; # The replication group.
                   'connected-to') true;; # The replication server a server is connected to.
                 'rs-connections') true;; # The connections between the replication servers.
                      'conflicts') true;; # The number of currently unresolved replication conflicts.
                          'doomc') true;; # The date of generation of the oldest missing change.
                'fractional-conf') true;; # The fractional replication configuration.
                   'assured-conf') true;; # The assured replication configuration.
       'replication-gateway-conf') true;; # The replication gateway configuration.
                                *) echo "ERROR: Invalid replication status view (${rdisp})";exit 1;;
   esac

if [ -z "${backend}" ];then backend='userRoot';fi
if [ -z "${role}" ];then role='DSRS';fi

if [ -z "${xmn}" ];then xmn=4;fi

if [ -n "${jmem}" ]
then
   jmem=$(echo "${jmem}"|tr -cd '[:digit:]')
else
   # Determine database cache size
   if [ -n "${dataFile}" ]
   then
      if [ -e "${dataFile}" ]
      then
         ldifSize=$(du -ms ${dataFile} 2> /dev/null)
         if [ -n "${ldifSize}" ]
         then
            jmem=$(echo ${ldifSize}|awk '{ print int($1*2.5+2048) }')
         else
            jmem=4096
         fi
      fi
   else
      jmem=4096
   fi
   if [ -z "${jmem}" ];then jmem=4096;fi
   if [ ${jmem} -lt 4096 ]; then jmem=4096;fi
fi

if [ ${jmem} -lt 4096 ]
then
   importJmem=4
   importXmn=1
else
   importJmem=8
   importXmn=4
fi

# Make sure JVM/DB Cache are not under 2048MB (2GB)
if [ -n "${jmem}" ]
then
   lookupos
   case ${os} in
      'Linux') maxjmem=$(grep "^MemTotal" /proc/meminfo|awk '{ print int($2/1024-2) }');;
      'SunOS') maxjmem=$(lgrpinfo|grep "Memory:"|awk '{ print $3 }'|tr -cd '[:alnum:]'|sed -e "s/G/000000000/g" -e "s/M/000000/g" -e "s/K/000/g"|awk '{ print $1/1000 }');;
   esac
   if [ -z "${maxjmem}" ];then maxjmem=4096;fi
   if [ ${jmem} -lt 2 ];then echo "Error: JVM Heap must be at least 2048MB";exit 1;fi
   if [ ${jmem} -gt ${maxjmem} ];then echo "Error: JVM Heap cannot be greater than ${maxjmem}MB";exit 1;fi
   dbc=$(echo ${jmem}|awk '{ print int(($1-2048)*.7) }')
fi

if [ -z "${jmem}" ];then echo "ERROR: Cannot determine JVM sizing (jmem)";rm;exit 1;fi

if [ "${subcmd}" == 'setup' ]
then
   if [ "${nobatch}" == 'true' ] || [ "${notune}" == 'true' ]
   then
      true
   elif [ -n  "${batchFile}" ]
   then
      if [ -e  "${batchFile}" ]
      then
         true
      else
         echo "Batch file (${batchFile}) does not exist"
         exit 1
      fi
   fi
fi

integrationOption=' --integration no-integration '
if [ -n "${integration}" ]
then
   case ${integration} in
      'eus') integrationOption=' --integration eus ';;
      'dip') integrationOption=' --integration basic ';;
      'none') integrationOption=' --integration no-integration ';;
          *) showUsage "Integration options include eus";;
   esac
fi

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
        'rstatus') replication_status;;
          'setup') setup_oud;;
         'backup') backup_oud;;
        'restore') restore_oud;;
          'blist') list_backups;;
         'import') import_oud;;
         'export') export_oud;;
           'stop') stop_oud;;
          'start') start_oud;;
        'upgrade') upgrade_oud;;
          'apply') apply_custom_batch;;
           'init') init_all;;
      'deinstall') deinstall_oud;;
           'push') push_data;;
      'addstatus') addstatus;;
      'delstatus') delstatus;;
   'enablestatus') enablestatus;;
  'disablestatus') disablestatus;;
    'checkstatus') checkstatus;;
                *) showUsage;;
esac
