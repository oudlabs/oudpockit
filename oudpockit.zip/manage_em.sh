#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [setup|deinstall|start|stop] [options]

SYNOPSIS
     Setup EM Instance
        ${cmd} setup [other optons]

     Start EM instance
        ${cmd} start

     Stop EM instance
        ${cmd} stop

     Install EM software
        ${cmd} install

DESCRIPTION
     Sample script for managing Enterprise Manager 13u5 (or newer) instance

OPTIONS
     Setup Options
     The following options are supported:

         --bitsdir <dir>         Directory of the software packages

         --swdir <dir>           Directory of the extracted software

EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            dbv) dbv="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            swdir) swdir="$1";shift;;
            ldapHost|ldaphost) ldapHost="$1";shift;;
            ldapPort|ldapport) ldapPort="$1";shift;;
            ldapAdmin|ldapadmin) ldapAdmin="$1";shift;;
            ldapPW|ldappw) ldapPW="$1";shift;;
            step) mySteps="$1";steps=${mySteps};shift;;
            pdb) pdbName="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            j) jPW="$1";;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

setup_em() {
  if [[ "$swVer" == 13* ]];then exit ;fi

   oemTmpDir=''
   export oemVer
   case ${swVer} in
      '13.3.0.0') oemVer=13c;installCmd="em13300_linux64.bin";oemTmpDir=" -J-Djava.io.tmpdir=${TMP} ";;
      '13.2.0.0') oemVer=13c;installCmd="em13200p1_linux64.bin";oemTmpDir=" -J-Djava.io.tmpdir=${TMP} ";;
   esac

   mkCfgFiles oemcc null
   mkCfgFiles wls null

   MW_HOME=${demoDir}/oemcc
   MIDDLEWARE_HOME=${demoDir}/oemcc
   ORACLE_HOME=${demoDir}/database/product/${dbvdir}/dbhome_1
   ORACLE_SID=${dbh}
   #OMS_HOME=${demoDir}/oemcc/oms
   AGENT_HOME=${demoDir}/oemcc-agent${oemVer}/agent_inst
   export MIDDLEWARE_HOME JAVA_HOME ORACLE_HOME ORACLE_SID LOGS OMS_HOME AGENT_HOME

      # Step 4 - Setup database for OEMCC
      if [ -e "${demoDir}/database/.tunedoemcc" ]
      then
         true
      else
         cksga=$(strings -a ${demoDir}/database/product/${dbvdir}/dbhome_1/dbs/spfile${dbh}.ora 2> /dev/null|grep '\.sga_target='|cut -d'=' -f2|sed -e "s/[kmg]//g")
         cksga=$((${cksga} + 0))
         if [ ${cksga} -lt 4294967296 ]
         then
            showPreState "Optimize database for OEMCC on $h"
            if [ "$debug" == 'on' ];then echo;set -x;fi
            $ORACLE_HOME/bin/sqlplus /nolog >> $LOGS/odb-install-$now.log 2>&1 << EOF
connect / as sysdba
alter system set sga_max_size=4g scope=spfile;
alter system set sga_target=4g scope=spfile;
alter system set "_allow_insert_with_update_check" = TRUE;
create pfile from spfile;
shutdown immediate;
startup;
exit;
EOF
            rc=$?;set +x
            if [ $rc -eq 0 ];then ck='OK';else ck='FAILED';fi;showPostState "$ck" exit
            touch "${demoDir}/database/.tunedoemcc"
            sleep 30
         fi

         # Wait for database to finish starting up
         wait4db
      fi

      # Step 5 - Install the OEMCC software
      if [ -d "${demoDir}/oemcc-inst" ]
      then
         # The OEM CC software is already installed
         true
      else
         whichLatest oemcc null
         showPreState "Install OEM CC ${oemVer} on $h"
         if [ "$osv" == '5.11' ];then ignorePreReqs='-ignoreSysPrereqs -ignorePrereq';else ignorePreReqs='';fi
         ignorePreReqs='-ignoreSysPrereqs -ignorePrereq'
         if [ "$debug" == 'on' ];then echo;set -x;fi
         ${swdir}/oemcc/${installCmd} -jreLoc "$JAVA_HOME" ${oemTmpDir} -silent ${ignorePreReqs} -responseFile $kitdir/silent/oemcc-${swVer}.rsp -invPtrLoc ${demoDir}/kit/silent/oraInventory.loc -waitforcompletion ${myIgnoreReqs} >> $LOGS/oemcc-install-$now.log 2>&1
         rc=$?;set +x
         if [ $rc -eq 0 ];then ck='OK';else ck='FAILED';fi
         ck4failed=$(grep -i failed $LOGS/oemcc-install-$now.log|grep -vi 'does not meet the configuration requirements.')
         if [ -n "$ck4failed" ];then ck='WARN';msg=$ck4failed;fi
         showPostState "$ck" exit "$msg"
      fi

   elif [ "${runLocal}" == 'yes' ] && [ ${userid} -eq 0 ] && [ ${phase} -eq 2 ]
   then
      # Step 6 - Run post-install scripts
      showPreState "Run OMS root.sh script on $h"
      if [ "$debug" == 'on' ];then echo;set -x;fi
      if [ -e "${demoDir}/oemcc/oms/bin/emctl" ];then OMS_HOME="${demoDir}/oemcc/oms";fi
      if [ -e "${demoDir}/oemcc/bin/emctl" ];then OMS_HOME="${demoDir}/oemcc";fi
      if [ -e "${demoDir}/oemcc/bin/emctl" ];then OMS_HOME="${demoDir}/oemcc";fi
      if [ -n "${OMS_HOME}" ]
      then
         ${OMS_HOME}/allroot.sh >> $LOGS/oemcc-install-$now.log 2>&1
         rc=$?;set +x
      else
         rc=1;msg="No OMS_HOME"
      fi
      if [ $rc -eq 0 ];then ck='OK';else ck='FAILED';fi;showPostState "$ck" exit
      chown ${ouid}:${ogid} $LOGS/oemcc-install-$now.log 2>&1

   elif [ "${runLocal}" == 'yes' ] && [ ${userid} -ne 0 ] && [ ${phase} -eq 3 ]
   then
      showPreState "Start OEM CC (OMS) on $h"
      if [ "$debug" == 'on' ];then echo;set -x;fi
      emctlBin="${demoDir}/oemcc/oms/bin/emctl"
      if [ -e "${demoDir}/oemcc/oms/bin/emctl" ];then emctlBin="${demoDir}/oemcc/oms/bin/emctl";fi
      if [ -e "${demoDir}/oemcc/bin/emctl" ];then emctlBin="${demoDir}/oemcc/bin/emctl";fi
      ${emctlBin} start oms >> $LOGS/oemcc-$now.log 2>&1
      rc=$?;set +x
      if [ $rc -eq 0 ];then ck='OK';else ck='FAILED';fi;showPostState "$ck" exit

      # Re-link the oemcc default to the installed version
      rm -f "${swdir}/oemcc" 2> /dev/null
      ln -s "${swdir}/oemcc-${swVer}" "${swdir}/oemcc" 2> /dev/null

      # Make library path so we don't have to manually
      mkdir ${demoDir}/oemcc/library

      # Provide URL for where to go next
      showURL "         OEM CC: " "https://$host:7803/em"
      showURL "   OEM CC Admin: " "https://$host:7102/console"
   fi
}




if [ -n "${mySteps}" ]; then steps=${mySteps};else steps=0;fi


###############################################################################
# Set Defaults
###############################################################################
if [ -z "${dbv}" ];then dbv='19.3.0.0';fi
if [ -z "${pdbName}" ];then pdbName='PDB1';fi

case ${dbv} in
   '21.3.0.0'|'21.3.0'|'21.3'|'21') export dbvdir="21.3.0" ;;
   '19.3.0.0'|'19.3.0'|'19.3'|'19') export dbvdir="19.3.0" ;;
   '18.0.0.0'|'18.0.0'|'18.0'|'18') export dbvdir="18.0.0" ;;
   '12.2.0.1') export dbvdir="12.2.0" ;;
   '12.1.0.2') export dbvdir="12.1.0" ;;
   '11.2.0.4') export dbvdir="11.2.0" ;;
esac

if [ -z "${ldapHost}" ];then ldapHost="${localHost}";fi
if [ -z "${ldapAdmin}" ];then ldapAdmin='cn=eusadmin,ou=Admins,cn=oracleContext';fi
if [ -z "${ldapPW}" ];then ldapPW="${bPW}";fi

###############################################################################
# Make response files
###############################################################################
extract_software() {
   # Set Oracle Env variables
   setOraEnv

   if [ -z "$ORACLE_HOME" ]
   then
      echo "ERROR: ORACLE_HOME not set"
      exit 1
   fi

   if [ -d "$ORACLE_HOME/bin/dbca" ]
   then
      true
   else
      if [ "${dbg}" == 'true' ];then set -x;fi
      case ${dbvdir} in
         21.3.0)
            if [ -e "$ORACLE_HOME/bin/dbca" ]
            then
               true
            elif [ -e "${bitsdir}/V1011496-01.zip" ]
            then
               let steps++
               echo "Step: ${steps} - Extract ODB ${dbvdir} software" | tee -a  ${logdir}/sw-extract-${now}.log
               if [ "${dbg}" == 'true' ];then set -x;fi
               mkdir -p "$ORACLE_HOME" 2> /dev/null
               unzip -d "$ORACLE_HOME" -qo ${bitsdir}/V1011496-01.zip
               rc=$?
               set +x
            fi
            ;;
         19.3.0)
            if [ -e "$ORACLE_HOME/bin/dbca" ]
            then
               true
            elif [ -e "${bitsdir}/V982063-01.zip" ]
            then
               let steps++
               echo "Step: ${steps} - Extract ODB ${dbvdir} software" | tee -a  ${logdir}/sw-extract-${now}.log
               if [ "${dbg}" == 'true' ];then set -x;fi
               mkdir -p "$ORACLE_HOME" 2> /dev/null
               unzip -d "$ORACLE_HOME" -qo ${bitsdir}/V982063-01.zip
               rc=$?
               set +x
            fi
            ;;
         18.0.0)
            if [ -e "$ORACLE_HOME/bin/dbca" ]
            then
               true
            elif [ -e "${bitsdir}/V978967-01.zip" ]
            then
               let steps++
               echo "Step: ${steps} - Extract ODB ${dbvdir} software" | tee -a  ${logdir}/sw-extract-${now}.log
               if [ "${dbg}" == 'true' ];then set -x;fi
               mkdir -p "$ORACLE_HOME" 2> /dev/null
               unzip -d "$ORACLE_HOME" -qo ${bitsdir}/V978967-01.zip
               rc=$?
               set +x
            fi
            ;;
      esac
   fi
}

###############################################################################
# Make response files
###############################################################################
mk_response() {
   setOraEnv
   if [ -e "${cfgdir}/oraInventory.loc" ]
   then
      true
   else
      mkdir -p "${cfgdir}" 2> /dev/null
      cat > ${cfgdir}/oraInventory.loc <<EOF
inventory_loc=${cfgdir}/oraInventory
inst_group=${me}
EOF
   fi

   mkdir -p "${curdir}/db/${dbvdir}/admin" 2> /dev/null
   case ${dbvdir} in
      19.3.0) cat > ${cfgdir}/odb${dbvdir}.rsp <<EOF
oracle.install.responseFileVersion=/oracle/install/rspfmt_dbinstall_response_schema_v19.0.0
oracle.install.option=INSTALL_DB_SWONLY
UNIX_GROUP_NAME=${myg}
INVENTORY_LOCATION=${cfgdir}/oraInventory
ORACLE_HOME=${curdir}/db/${dbvdir}/dbhome_1
ORACLE_BASE=${curdir}/db/${dbvdir}/app/oracle
oracle.install.db.InstallEdition=EE
oracle.install.db.OSDBA_GROUP=${myg}
oracle.install.db.OSOPER_GROUP=${myg}
oracle.install.db.OSBACKUPDBA_GROUP=${myg}
oracle.install.db.OSDGDBA_GROUP=${myg}
oracle.install.db.OSKMDBA_GROUP=${myg}
oracle.install.db.OSRACDBA_GROUP=${myg}

oracle.install.db.config.starterdb.memoryOption=false
oracle.install.db.config.starterdb.memoryLimit=4096
oracle.install.db.config.starterdb.password.ALL=${bPW}
oracle.install.db.config.starterdb.managementOption=DEFAULT
oracle.install.db.config.starterdb.enableRecovery=false
oracle.install.db.config.starterdb.storageType=FILE_SYSTEM_STORAGE
oracle.install.db.config.starterdb.fileSystemStorage.dataLocation=$ORACLE_BASE/oradata
SECURITY_UPDATES_VIA_MYORACLESUPPORT=false
DECLINE_SECURITY_UPDATES=true
oracle.installer.autoupdates.option=SKIP_UPDATES
EOF

              cat > ${cfgdir}/odb${dbvdir}-deinstall.rsp <<EOF
ORACLE_HOME=$ORACLE_HOME
COMPS_TO_REMOVE=oledbolap,ntoledb,asp.net,odp.net
ORACLE_HOME_VERSION=19.0.0.0.0
ORACLE_BASE=$ORACLE_BASE
INVENTORY_LOCATION=${cfgdir}/oraInventory
CRS_HOME=false
HOME_TYPE=CLIENT
silent=true
WindowsRegistryCleanupList=
MinimumSupportedVersion=11.2.0.1.0
LOCAL_NODE=ol8
local=false
ObaseCleanupPtrLoc=
ORACLE_HOME=$ORACLE_HOME
LOGDIR=${logdir}
OLD_ACTIVE_ORACLE_HOME=
ORACLE_HOME_VERSION_VALID=true
EOF


#oracle.install.db.DBA_GROUP=${ogid}
#oracle.install.db.OPER_GROUP=${ogid}
#oracle.install.db.BACKUPDBA_GROUP=${ogid}
#oracle.install.db.DGDBA_GROUP=${ogid}
#oracle.install.db.KMDBA_GROUP=${ogid}
#oracle.install.db.OSRACDBA_GROUP=${ogid}
#oracle.install.db.isRACOneInstall=false
#oracle.install.db.config.starterdb.memoryOption=false
#oracle.install.db.config.starterdb.memoryLimit=${dbMem}
#oracle.install.db.config.starterdb.password.ALL=${bPW}
#oracle.install.db.config.starterdb.managementOption=DEFAULT
#oracle.install.db.config.starterdb.enableRecovery=false
#oracle.install.db.config.starterdb.storageType=FILE_SYSTEM_STORAGE
#oracle.install.db.config.starterdb.fileSystemStorage.dataLocation=${demoDir}/database/oradata
#SECURITY_UPDATES_VIA_MYORACLESUPPORT=false
#DECLINE_SECURITY_UPDATES=true
#oracle.installer.autoupdates.option=SKIP_UPDATES
              ;;
   esac

}

###############################################################################
# Check Enterprise Manager requisites
###############################################################################
ck_em_reqs() {
   ck4portrange=$(grep 'net.ipv4.ip_local_port_range = 11000' /etc/sysctl.conf)
   if [ -z "${ck4shmmni}" ]
   then
      sudo -n tee -a /etc/sysctl.conf <<EOF
net.ipv4.ip_local_port_range="11000 65000"
EOF
   fi

   # Make sure sysctl.conf updates are applied
   sudo -n sysctl -p /etc/sysctl.conf >> ${logdir}/sysctl-${now}.log

         cksga=$(strings -a ${demoDir}/database/product/${dbvdir}/dbhome_1/dbs/spfile${dbh}.ora 2> /dev/null|grep '\.sga_target='|cut -d'=' -f2|sed -e "s/[kmg]//g")
         cksga=$((${cksga} + 0))
         if [ ${cksga} -lt 4294967296 ]
         then
            showPreState "Optimize database for OEMCC on $h"
            if [ "$debug" == 'on' ];then echo;set -x;fi
            $ORACLE_HOME/bin/sqlplus /nolog >> $LOGS/odb-install-$now.log 2>&1 << EOF
connect / as sysdba
alter system set session_cached_cursors=500 scope=spfile;
alter system set sga_max_size=4g scope=spfile;
alter system set sga_target=4g scope=spfile;
alter system set "_allow_insert_with_update_check" = TRUE;
create pfile from spfile;
shutdown immediate;
startup;
exit;
EOF
            rc=$?;set +x
            if [ $rc -eq 0 ];then ck='OK';else ck='FAILED';fi;showPostState "$ck" exit
            touch "${demoDir}/database/.tunedoemcc"
            sleep 30
         fi
}

###############################################################################
# Check Database requisites
###############################################################################
ck_db_reqs() {

   let steps++
   echo "Step: ${steps} - Confirm OS packages are installed for ODB" | tee -a  ${logdir}/os-requisites-${now}.log

   lookupos

   if [ "${os}" == 'Linux' ]
   then
      if [ "${olv}" == '6' ] || [ "${olv}" == '7' ]
      then
         if [[ ${dbvdir} == 12* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-server-12cR2-preinstall)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-server-12cR2-preinstall > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         elif [[ ${dbvdir} == 18* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-preinstall-18c)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-preinstall-18c > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         elif [[ ${dbvdir} == 19* ]] || [[ ${dbvdir} == 20* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-preinstall-19c)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-preinstall-19c > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         elif [[ ${dbvdir} == 21* ]]
         then
            ck4pkg=$(rpm -qa|grep oracle-database-preinstall-21c)
            if [ -z "${ck4pkg}" ]
            then
               if [ "${dbg}" == 'true' ];then set -x;fi
               sudo -n yum install -y oracle-database-preinstall-21c > ${logdir}/os-requisites-${now}.log 2>&1
               rc=$?;set +x
            fi
         fi
      elif [ "${olv}" == '8' ]
      then
         if [[ ${dbvdir} == 19* ]] || [[ ${dbvdir} == 20* ]]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            sudo -n yum install -y oracle-database-preinstall-19c > ${logdir}/os-requisites-${now}.log 2>&1
            rc=$?;set +x
         elif [[ ${dbvdir} == 21* ]]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            sudo -n yum install -y oracle-database-preinstall-21c > ${logdir}/os-requisites-${now}.log 2>&1
            rc=$?;set +x
         fi

         # Other requisites
         if [ "${dbg}" == 'true' ];then set -x;fi
         sudo -n yum install -y libnsl > ${logdir}/os-requisites-${now}.log 2>&1
         rc=$?;set +x
      fi
   fi

 
   if [ -d "${cfgdir}/oraInventory" ]
   then
      true
   else
      mkdir "${cfgdir}/oraInventory" 2> /dev/null
   fi
   set +x

   # Make sure there is sufficient swap
   swapSize=$(free -k|grep "^Mem:"|awk '{ print $2 }') >> ${logdir}/swap-$now.log 2>&1
   swapSize=$((1024*1024*16))
   swapFile="${tmpdir}/pocSwapFile"
   if [ -e "${swapFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Increase swap to satisfy Oracle Universal Installer" | tee -a  ${logdir}/swap-${now}.log

      dd if=/dev/zero of="${swapFile}" bs=1k count=${swapSize} >> ${logdir}/swap-$now.log 2>&1
      rc=$?
      chmod 600 "${swapFile}" >> ${logdir}/swap-$now.log 2>&1
      rc=$?
      mkswap -f ${swapFile} >> ${logdir}/swap-$now.log 2>&1
      rc=$?
      sudo -n chown root ${swapFile} >> ${logdir}/swap-$now.log 2>&1
      rc=$?
   fi
   ckswap=$(swapon -s|grep pocSwapFile)
   if [ -z "${ckswap}" ]
   then
      sudo -n /sbin/swapon ${swapFile} >> ${logdir}/swap-$now.log 2>&1
      rc=$?
   fi
   set +x
}

###############################################################################
# Wait for database to transition to finish starting up
###############################################################################
wait4db() {
   if [ "$1" == 'test' ];then dbTstCnt=2;else dbTstCnt=40;fi

   # Set Oracle Env variables
   setOraEnv

   if [ -e "$ORACLE_HOME/bin/sqlplus" ]
   then
      isDbUp=''
      isCDB='NO'
      n=1
      ### Determine if it's a CDB 
      if [[ ${dbvdir} == 18* ]] || [[ ${dbvdir} == 19* ]]
      then
         # Determine whether it's a CDB
         #isCDB=$(export ORACLE_HOME=${curdir}/database/product/${dbvdir}/dbhome_1 ORACLE_SID=${localH};$ORACLE_HOME/bin/sqlplus -S system/${bPW}   2> /dev/null << EOF
         isCDB=$($ORACLE_HOME/bin/sqlplus -S system/${bPW} 2> /dev/null << EOF
SELECT CDB FROM V\$DATABASE;
EOF
)
         isCDB=$(echo $isCDB | cut -d " " -f3)
         #isCDB=$(echo ${isCDB}|egrep "^YES|^NO")
      fi
   
      if [ "${isCDB}" == "YES" ]
      then 
          # Make sure each PDB is up
          isPdbUp=''
          while [[ "${isPdbUp}" != 'WRITE' ]] && [ $n -lt ${dbTstCnt} ]
          do
             # Wait fore a few seconds
             sleep 5
             if [ "${dbg}" == 'on' ];then echo;set -x;fi
             #isPdbUp=$(export ORACLE_HOME=$demoDir/database/product/${dbvdir}/dbhome_1 ORACLE_SID=${dbh}
             isPdbUp=$($ORACLE_HOME/bin/sqlplus -S system/${bPW} as sysdba << EOF
COLUMN NAME FORMAT A8;
select name, open_mode from v\$pdbs where con_id>=3;
EOF
)
              isPdbUp=$(echo ${isPdbUp} |grep "WRITE" | cut -d " " -f7)
              set +x
              let n++
          done

          if [ "${isPdbUp}" != 'WRITE' ]
          then
             echo "Error: PDB database is not responding."
             exit 1
          fi
      else 
         while [ "${isDbUp}" != 'USER is "SYSTEM"' ] && [ $n -lt ${dbTstCnt} ]
         do
            # Wait fore a minute
            sleep 5
            if [ "${dbg}" == 'on' ];then echo;set -x;fi
            isDbUp=$($ORACLE_HOME/bin/sqlplus -S system/${bPW} 2> /dev/null << EOF
show user;
EOF
)
            set +x
            let n++
         done

         if [ "${cmd}" == 'setup' ] || [ "${cmd}" == 'start' ]
         then
            if [ "${isDbUp}" != 'USER is "SYSTEM"' ]
            then
               echo "Error: Database is not responding."
               exit 1
            fi
         fi
      fi
   else
      echo "Error: Database is not installed."
      exit 1
   fi
}

###############################################################################
# Install Oracle Database
###############################################################################
install_db() {
   ck_db_reqs
   mk_response
   extract_software
   setOraEnv

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -d "$ORACLE_HOME/bin/dbca" ]
   then
      true
   else
      case ${dbvdir} in
          19.3.0)
                 if [ -e "$ORACLE_HOME/runInstaller" ] && [ -e "$ORACLE_HOME/root.sh.old.2" ]
                 then
                    true
                 elif [ -e "$ORACLE_HOME/runInstaller" ]
                 then
                    if [ "${olv}" == '8' ];then export CV_ASSUME_DISTID=OEL7.8;fi

                    let steps++
                    echo "Step: ${steps} - Install ${dbvdir} database" | tee -a ${logdir}/odb-install-${now}.log
                    if [ "${dbg}" == 'true' ];then set -x;fi
                    $ORACLE_HOME/runInstaller -silent -responseFile "${cfgdir}/odb${dbvdir}.rsp" -waitforcompletion >> ${logdir}/odb-install-${now}.log 2>&1
                    rc=$?
                    if [ ${rc} -ne 0 ];then echo "Error: Review log ${logdir}/odb-install-${now}.log";exit 1;fi

                    if [ -e "${cfgdir}/oraInventory/orainstRoot.sh" ]
                    then
                       sudo -n ${cfgdir}/oraInventory/orainstRoot.sh >> ${logdir}/odb-install-${now}.log 2>&1
                       rc=$?
                       if [ ${rc} -ne 0 ];then echo "Error: Review log ${logdir}/odb-install-${now}.log";exit 1;fi
                    fi

                    sudo -n $ORACLE_HOME/root.sh >> ${logdir}/odb-install-${now}.log 2>&1
                    rc=$?
                    if [ ${rc} -ne 0 ];then echo "Error: Review log ${logdir}/odb-install-${now}.log";exit 1;fi

                    echo ${steps} > ${cfgdir}/.steps.install.db

#                    Oracle 12c use case
#                    sudo -n $ORACLE_HOME/bin/relink all >> ${logdir}/odb-install-${now}.log 2>&1
#                    rc=$?
#                    if [ ${rc} -ne 0 ];then echo "Error: Review log ${logdir}/odb-install-${now}.log";exit 1;fi

                    set +x
                 fi
              ;;
      esac
   fi
   set +x

   # Confirm that DB installed
   if [ -e "$ORACLE_HOME/bin/lsnrctl" ]
   then
      true
   else
      echo "ERROR: DB version ${dbv} is not installed"
      echo "   ORACLE_HOME=$ORACLE_HOME"
      echo "   ORACLE_BASE=$ORACLE_BASE"
      echo "   TNS_ADMIN=$TNS_ADMIN"
      exit 1
   fi
}

###############################################################################
# Stop Oracle Listener
###############################################################################
stop_listener() {
   setOraEnv

   ck4lsnr=$(ps -ef|grep tnslsnr|grep -v grep|awk '{ print $2 }')
   if [ -n "${ck4lsnr}" ]
   then
      let steps++
      echo "Step: ${steps} - Stop Oracle ${dbvdir} database listener" | tee -a ${logdir}/odb-ctl-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/lsnrctl stop >> ${logdir}/odb-ctl-$now.log 2>&1
      rc=$?;set +x
      sleep 2
      ck4lsnr=$(ps -ef|grep tnslsnr|grep -v grep|awk '{ print $2 }')
      if [ -n "${ck4lsnr}" ];then kill -9 ${ck4lsnr};fi
   fi

   echo ${steps} > ${cfgdir}/.steps.stop.db
}

###############################################################################
# Stop Oracle Database
###############################################################################
stop_db() {
   setOraEnv

   if [ -s "$ORACLE_HOME/network/admin/samples/sqlnet.ora" ]
   then
      true
   else
      echo "ERROR: Database is not setup"
      exit 1
   fi

   ck4db=$(ps -ef|grep ora_|grep -v grep|awk '{ print $2 }')
   if [ -n "${ck4db}" ]
   then
      let steps++
      echo "Step: ${steps} - Stop Oracle ${dbvdir} database instance" | tee -a ${logdir}/odb-ctl-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/sqlplus / as sysdba >> ${logdir}/odb-ctl-${now}.log 2>&1 << EOF
shutdown immediate ;
EOF
      rc=$?;set +x
   fi

   stop_listener
}

###############################################################################
# Start Oracle Database
###############################################################################
start_db() {
   setOraEnv

   if [ -s "$ORACLE_HOME/network/admin/samples/sqlnet.ora" ]
   then
      true
   else
      echo "ERROR: Database is not setup"
      exit 1
   fi

   ck4lsnr=$(ps -ef|grep tnslsnr|grep -v grep|awk '{ print $2 }')
   if [ -z "${ck4lsnr}" ]
   then
      let steps++
      echo "Step: ${steps} - Start Oracle ${dbvdir} database listener" | tee -a ${logdir}/odb-ctl-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/lsnrctl start >> ${logdir}/odb-ctl-$now.log 2>&1
      rc=$?;set +x
   fi

   ck4db=$(ps -ef|grep ora_|grep -v grep|awk '{ print $2 }')
   if [ -z "${ck4db}" ]
   then
      let steps++
      echo "Step: ${steps} - Start Oracle ${dbvdir} database instance" | tee -a ${logdir}/odb-ctl-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/sqlplus / as sysdba >> ${logdir}/odb-ctl-$now.log 2>&1 << EOF
startup;
alter system register;
exit
EOF
      rc=$?;set +x
   fi

   # Start PDB databases
   isCDB='NO'
   n=1
   ### Determine if it's a CDB 
   if [[ ${dbvdir} == 18* ]] || [[ ${dbvdir} == 19* ]]
   then
      # Determine whether it's a CDB
      isCDB=$($ORACLE_HOME/bin/sqlplus -S system/${bPW} 2> /dev/null << EOF
SELECT CDB FROM V\$DATABASE;
EOF
)
      PDBLOG="${cfgdir}/.pdbs"
      isCDB=$(echo ${isCDB}| cut -d " " -f3)
      if [ "${isCDB}" == "YES" ]
      then
         let steps++
         echo "Step: ${steps} - Start Oracle ${dbvdir} plugable databases" | tee -a ${logdir}/odb-ctl-${now}.log
         if [ "$dbg" == 'on' ];then echo;set -x;fi
         # Start PDBs
         $ORACLE_HOME/bin/sqlplus / as sysdba > ${PDBLOG} 2>&1 << EOF
alter pluggable database all open;
alter system register;
alter session set container=${pdbName};
exec DBMS_XDB_CONFIG.SETHTTPSPORT(5501);
EOF
         rc=$?;set +x
      fi
   fi

   wait4db

   echo ${steps} > ${cfgdir}/.steps.start.db
}

###############################################################################
# Delete Oracle Database
###############################################################################
delete_db() {
   setOraEnv
   if [ -e "$ORACLE_HOME/bin/dbca" ]
   then
      let steps++
      echo "Step: ${steps} - Delete database instance" | tee -a ${logdir}/odb-dbca-${now}.log

      # Set Oracle Env variables
      setOraEnv
      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/dbca \
         -silent \
         -deleteDatabase \
         -sourceDB ${localH} \
         -sysDBAUserName sys \
         -sysDBAPassword "${bPW}" \
         >>  ${logdir}/odb-dbca-rm-$now.log 2>&1
      rc=$?
   fi
}

###############################################################################
# Setup Oracle Database
###############################################################################
setup_db() {
   install_db

   setOraEnv
   if [ -s "$ORACLE_HOME/dbs/spfile$ORACLE_SID.ora" ]
   then
      echo "INFO: Database is already setup"
      exit
   fi

   if [ -e "$ORACLE_HOME/bin/netca" ]
   then
      ck4lsnr=$(ps -ef|grep tnslsnr|grep -v grep|awk '{ print $2 }')
      if [ -z "${ck4lsnr}" ]
      then
         let steps++
         echo "Step: ${steps} - Setup listener" | tee -a ${logdir}/odb-netca-${now}.log

         if [ "${dbg}" == 'true' ];then set -x;fi
         $ORACLE_HOME/bin/netca /orahome "$ORACLE_HOME" /instype typical /inscomp client,oraclenet,javavm,server,ano /insprtcl tcp /cfg local /authadp NO_VALUE /responseFile $ORACLE_HOME/network/install/netca_typ.rsp /lisport 1521 /silent /orahnam ${localH} >> ${logdir}/odb-netca-${now}.log 2>&1
         rc=$?
      fi
   fi

   if [ -e "$ORACLE_HOME/bin/dbca" ]
   then
      let steps++
      echo "Step: ${steps} - Setup database instance" | tee -a ${logdir}/odb-dbca-${now}.log

      # -emConfiguration DBEXPRESS -emExpressPort 5500

      if [ "${dbg}" == 'true' ];then set -x;fi
      $ORACLE_HOME/bin/dbca \
         -silent \
         -createDatabase \
         -databaseConfigType SINGLE \
         -emConfiguration NONE \
         -templateName General_Purpose.dbc \
         -characterSet AL32UTF8 \
         -totalMemory 4096 \
         -storageType FS \
         -datafileDestination "$ORACLE_BASE/oradata" \
         -datafileJarLocation "$ORACLE_HOME/assistants/dbca/templates" \
         -sampleSchema FALSE \
         -oratabLocation /etc/oratab  \
         -runCVUChecks false \
         -continueOnNonFatalErrors true \
         -createAsContainerDatabase true \
         -gdbName ${localHost} \
         -sid ${localH} \
         -initParams filesystemio_options=setall \
         -ignorePrereqs \
         -numberOfPDBs 1 \
         -pdbName ${pdbName} \
         -pdbadminUsername pdbadmin \
         -pdbAdminPassword "${bPW}" \
         -sysPassword "${bPW}" \
         -systemPassword "${bPW}" \
         >>  ${logdir}/odb-dbca-$now.log 2>&1
      rc=$?
   fi
   set +x

   # Make sure that oratab is set to Y
   grep -vi "^$ORACLE_SID:" /etc/oratab > ${cfgdir}/oratab-${now} 2> /dev/null
   cat ${cfgdir}/oratab-${now} | sudo -n tee /etc/oratab > /dev/null
   echo "$ORACLE_SID:$ORACLE_HOME:Y:" | sudo -n tee -a /etc/oratab > /dev/null
   rc=$?

   # Setup listener
   cp $ORACLE_HOME/network/admin/samples/listener.ora $ORACLE_HOME/network/admin
   cat >> $ORACLE_HOME/network/admin/listener.ora <<EOF
LISTENER =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = ${localHost})(PORT = 1521))
      (ADDRESS = (PROTOCOL = IPC)(KEY = EXTPROC1521))
    )
  )
EOF

   start_db
}

###############################################################################
# Deinstall DB
###############################################################################
deinstall_db() {
   setOraEnv

   #if [ -x $ORACLE_HOME/bin/dbca ] && [ -d "$ORACLE_BASE/admin/$ORACLE_SID" ]

   if [ -s "$ORACLE_HOME/deinstall/deinstall" ]
   then
#      stop_db
#  
#      let steps++
#      echo "Step: ${steps} - Remove database instance " | tee -a ${logdir}/db-deinstall-${now}.log
#      echo "Remove ${swVer} database content from $h"
#         if [ "${dbg}" == 'true' ];then set -x;fi
#      $ORACLE_HOME/bin/dbca -deleteDatabase -silent -sourceDB  $h > ${logdir}/db-deinstall-$now.log 2>&1
#      rc=$?;set +x
#
#      # Remove DB 
#      if [ -d "$ORACLE_HOME" ]
#      then
#         echo "Deinstall Database product from $h"
#         if [ "${dbg}" == 'true' ];then set -x;fi
#         echo rm -fr "$ORACLE_HOME"
#         rc=$?;set +x
#      fi

      # Deinstall Oracle Database software
      let steps++
      echo "Step: ${steps} - Deinstall database software " | tee -a ${logdir}/db-deinstall-${now}.log
      lookupos
      if [ ${olv} -eq 8 ];then export CV_ASSUME_DISTID=OL7;fi
      $ORACLE_HOME/deinstall/deinstall -silent -paramfile "${cfgdir}/odb${dbvdir}-deinstall.rsp" > ${logdir}/db-deinstall-$now.log 2>&1
   fi

   # Make sure listener is stopped
   stop_listener

   if [ -e "/etc/oratab" ];then sudo -n rm -f /etc/oratab;fi
   if [ -e "${cfgdir}/.pdbs" ];then rm -f ${cfgdir}/.pdbs;fi
   if [ -e "${cfgdir}/.eusbatch-loaded" ];then rm -f ${cfgdir}/.eusbatch-loaded;fi
   if [ -e "${cfgdir}/.eusrealm-loaded" ];then rm -f ${cfgdir}/.eusrealm-loaded;fi
}

###############################################################################
# Process subcommand
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
case ${subcmd} in
        'extract') extract_software;;
        'install') install_db;;
          'setup') setup_db;;
         'delete') delete_db;;
           'stop') stop_db;;
          'start') start_db;;
      'deinstall') deinstall_db;;
                *) showUsage;;
esac
###############################################################################
#This information is also available at: 
#
#	${curdir}/em/install/setupinfo.txt
#
#See the following for information pertaining to your Enterprise Manager installation:
#
# Use the following URL to access:
#
#	1. Enterprise Manager Cloud Control URL: https://ol8.lbsub7b72aa1b5.oke18.oraclevcn.com:7803/em
#	2. Admin Server URL: https://ol8.lbsub7b72aa1b5.oke18.oraclevcn.com:7102/console
#
#The following details need to be provided while installing an additional OMS:
#
#	1. Admin Server Host Name: ol8.lbsub7b72aa1b5.oke18.oraclevcn.com
#	2. Admin Server Port: 7102
#
#You can find the details on ports used by this deployment at : ${curdir}/em/install/portlist.ini
