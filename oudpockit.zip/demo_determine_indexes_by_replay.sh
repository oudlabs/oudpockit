#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
accesslog="$1"

if [ -e "${accesslog}" ]
then
   if [ -s "${accesslog}" ]
   then
      true
   else
      echo "ERROR: access log is empty"
      echo "USAGE: ${0} <access_log_file>"
      exit 1
   fi
else
   echo "ERROR: access log does not exist"
   echo "USAGE: ${0} <access_log_file>"
   exit 1
fi

set -x
echo '#!/bin/bash' > ${accesslog}.search
echo "export JAVA_HOME=\"$JAVA_HOME\"" >> ${accesslog}.search
echo 'set -x' >> ${accesslog}.search
echo 'shopt -s expand_aliases' >> ${accesslog}.search
echo "alias lsrch=${lsrch}" >> ${accesslog}.search

echo "cd ${cfgdir}" >> ${accesslog}.search
echo "cat ...pw" >> ${accesslog}.search

egrep -h "SEARCH REQ|SRCH" ${accesslog}|sed -e "s/^\[.*base=/ -b /g" -e "s/attrs=.*/ debugsearchindex/g"|sort -fu|sed -e "s/filter=/ /g" -e "s/scope=2/-s sub/g" -e "s/scope=1/-s one/g" -e "s/scope=0/-s base/g" -e "s/scope=base/-s base/g" -e "s/scope=sub/-s sub/g" -e "s/base=one/-s one/g" -e "s/^/lsrch -h ${localHost} -p ${ldapPort} -D \"${bDN}\" -j ...pw/g" >> ${accesslog}.search

echo 'set +x' >> ${accesslog}.search
chmod 0700 ${accesslog}.search

${accesslog}.search
