#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive 
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            suffix) suffix="$1";shift;;
            domain) domain="$1";shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Make sure clean slate
###############################################################################
if [ -d "${oudmwdir}/oud1" ]
then
   echo "ERROR: Please make sure no previous OUD instances exist before running this demo"
   exit 1
fi

###############################################################################
# Setup OUD instances and replication topology
###############################################################################
echo "DEMO --> Setup OUD instances:"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh setup --pnum 1 --suffix "${suffix}" ${dbgFlag}

${curdir}/manage_oud.sh setup --pnum 2 --suffix "${suffix}" --supplier ${localHost}:${adminPort} ${dbgFlag}

${curdir}/manage_oud.sh setup --DS --pnum 3 --suffix "${suffix}" --supplier ${localHost}:${adminPort} ${dbgFlag}

set +x

###############################################################################
# Set JAVA_HOME if not already set
###############################################################################
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi

###############################################################################
# Configure DS1 and DS2 for Assured replication
###############################################################################
echo "DEMO --> Configure DS1 and DS2 for assured replication with group 1"
if [ "${dbg}" == 'true' ];then set -x;fi
groupId=10
for pnum in 1 2 3
do
   ${dcfg} \
      set-replication-domain-prop \
      --provider-name 'Multimaster Synchronization' \
      --domain-name "${suffix}" \
      --set group-id:${groupId} \
      --set assured-type:safe-read \
      --hostName ${localHost} \
      --port ${pnum}444 \
      --bindDN "${bDN}" \
      --bindPasswordFile "${jPW}" \
      --trustAll \
      --no-prompt \
      --noPropertiesFile \
      >> ${logdir}/demo-assured-read-${now}.log 2>&1

   ${dcfg} \
      set-replication-server-prop \
      --provider-name 'Multimaster Synchronization' \
      --set group-id:${groupId} \
      --hostName ${localHost} \
      --port ${pnum}444 \
      --bindDN "${bDN}" \
      --bindPasswordFile "${jPW}" \
      --trustAll \
      --no-prompt \
      --noPropertiesFile \
      >> ${logdir}/demo-assured-read-${now}.log 2>&1
done
echo "done"
