#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
steps=$2
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Set steps
###############################################################################
if [ -z "${steps}" ];then steps=0;fi

###############################################################################
# Extract JDK
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi

for fmwVersion in 12c 14c
do
   setfmwenv
   if [ -n "${JAVA_HOME}" ] && [ -e "${JAVA_HOME}/bin/java" ]
   then
      true
   else
      if [ "${fmwVersion}" == '12c' ]
      then  
         jdkgz=$(ls -1 ${bitsdir}/jdk-8*gz 2> /dev/null|grep "${osn}"|tail -1)
         jdktar=$(ls -1 ${bitsdir}/jdk-8*.tar 2> /dev/null|grep "${osn}"|tail -1)
      elif [ "${fmwVersion}" == '14c' ]
      then
         jdkgz=$(ls -1 ${bitsdir}/jdk-21*gz ${bitsdir}/jdk-17*gz 2> /dev/null|grep "${osn}"|tail -1)
         jdktar=$(ls -1 ${bitsdir}/jdk-21*.tar ${bitsdir}/jdk-17*.tar 2> /dev/null|grep "${osn}"|tail -1)
      fi    

      if [ -n "${jdkgz}" ] || [ -n "${jdktar}" ]
      then
         let steps++
         echo "Step: ${steps} - Extract JDK software" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         cd "${swdir}"
         rc=$?
         if [ -n "${jdkgz}" ]
         then
            tar -zxf ${jdkgz}
            rc=$?
         elif  [ -n "${jdktar}" ]
         then
            tar -xf ${jdktar}
            rc=$?
         fi
         set +x
      else
         echo "Error: No JDK tar.gz file"
         exit 1
      fi
   fi
done
