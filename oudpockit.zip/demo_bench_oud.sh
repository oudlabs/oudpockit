#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
dbg='false'
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            suffix) mySuffix="$1";shift;;
            timeout) myTimeout=$1;shift;;
            jmem) myJvmSize=$1;shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
            n) myTemplate=$1;shift;;
            N) myNumUsers=$1;shift;;
            T) myThreads=$1;shift;;
            M) myRate=$1;shift;;
        esac;;
    esac
done

###############################################################################
# Set defaults
###############################################################################
if [ -n "${myTemplate}" ];then templateName=${myTemplate};fi
if [ -n "${myNumUsers}" ];then numUsers="${myNumUsers}";fi
if [ -n "${mySuffix}" ];then suffix=${mySuffix};fi
if [ -n "${myTimeout}" ];then duration=${myTimeout};fi
if [ -n "${myThreads}" ];then threads=${myThreads};fi
if [ -n "${myRate}" ];then rate=${myRate};fi
if [ -n "${myJvmSize}" ];then jvmSize=${myJvmSize};fi

if [ -z "${duration}" ];then duration=300;fi

dsteps=0

###############################################################################
# Generate data
###############################################################################
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Generate data"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_data.sh genall -n ${templateName} -N ${numUsers} --suffix "${suffix}" --rm
rc=$?;set +x

###############################################################################
# Determine size of DB for JVM sizing
###############################################################################
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Assess JVM sizing"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
ldifSize=$(du -ms ${cfgdir}/${templateName}.ldif|awk '{ printf "%.0f", $1 }')
dbSize=$(echo ${ldifSize}|awk '{ printf "%.0f", $1*2.5 }')
if [ ${dbSize} -lt 1024 ];then dbSize=1024;fi
jvmSize=$(echo ${dbSize}|awk '{ printf "%.0f", $1+4096 }')
set +x
echo "LDIF Size: ${ldifSize} Mib"
echo "Target DB Size: ${dbSize} Mib"
echo "Target JVM Size: ${jvmSize} Mib"

# Set default if cannot estimate jvmSize
if [ -z "${jvmSize}" ];then jvmSize=8192;fi

###############################################################################
# Setup OUD instance
###############################################################################
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Setup OUD instance"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh setup --pnum 1 -n ${templateName} --suffix "${suffix}" --jmem ${jvmSize}
rc=$?;set +x
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh setup --pnum 2 -n ${templateName} --suffix "${suffix}" --jmem ${jvmSize} --supplier ${localHost}:1444:1989
rc=$?;set +x

###############################################################################
# Show replication status
###############################################################################
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Show replication status"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh rstatus -z
rc=$?;set +x

###############################################################################
# Run timed performance campaigns
###############################################################################
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Make service info template"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_slamd.sh mksvcinfo -n ${templateName}
rc=$?
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Install SLAMD for *rate commands"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_slamd.sh install
rc=$?
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Apply load"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
timeout ${duration} ${curdir}/manage_slamd.sh bsearchrate -n ${templateName} --suffix "${suffix}" -T ${myThreads} -M ${myRate}
rc=$?
timeout ${duration} ${curdir}/manage_slamd.sh searchrate -n ${templateName} --suffix "${suffix}" -T ${myThreads} -M ${myRate}
rc=$?
timeout ${duration} ${curdir}/manage_slamd.sh authrate -n ${templateName} --suffix "${suffix}" -T ${myThreads} -M ${myRate}
rc=$?
timeout ${duration} ${curdir}/manage_slamd.sh modrate -n ${templateName} --suffix "${suffix}" -T ${myThreads} -M ${myRate}
rc=$?
set +x
###############################################################################
# Show replication status
###############################################################################
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Show replication status immediately after modrate"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh rstatus -z
rc=$?;set +x

###############################################################################
# Show replication status
###############################################################################
let dsteps++
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "=-= DEMO: ${dsteps} - Show replication status 5 seconds later"
echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ "${dbg}" == 'true' ];then set -x;fi
sleep 5
${curdir}/manage_oud.sh rstatus -z
rc=$?;set +x

