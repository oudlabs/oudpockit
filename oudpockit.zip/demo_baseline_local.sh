#!/bin/bash
subcmd="$1"
cmd=$(basename $0)
curdir=$(dirname $0)
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive 
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            threads) benchThreads="$1";shift;;
            tempalte) benchTemplate="$1";shift;;
            batch) benchBatch="$1";shift;;
            schema) benchSchema="$1";shift;;
            data) benchData="$1";shift;;
            jprops) benchJavaProps="$1";shift;;
            lspan) benchSpanFlag="--lspan $1";shift;;
            jmem) benchJmem="$1";shift;;
            xmn) benchXmn="$1";shift;;
            notune) notuneFlag="--notune";;
            duration) duration="$1";shift;;
            host) remoteHost="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            N) benchEntries="$1";shift;;
            M) benchTargetRate="$1";shift;;
            m) benchOpsPerConn="$1";shift;;
            T) benchThreads="$1";shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

##############################################################################
# Parse inputs
##############################################################################
if [ -z "${subcmd}" ];then subcmd="both";fi
if [ -z "${remoteHost}" ];then remoteHost="${localHost}";fi

if [ -z "${benchTemplate}" ];then benchTemplate="inetorg";fi
if [ -z "${benchBatch}" ];then benchBatch="${cfgdir}/inetorg.batch";fi
if [ -z "${benchData}" ];then benchData="${cfgdir}/inetorg.ldif";fi
if [ -z "${benchJavaProps}" ];then benchJavaProps="${cfgdir}/myJava.properties";fi
if [ -z "${benchEntries}" ];then benchEntries=100000;fi
if [ -z "${benchJmem}" ];then benchJmem=4096;fi
if [ -z "${benchXmn}" ];then benchXmn=2;fi
if [ -z "${benchTargetRate}" ];then benchTargetRate=100000000;fi
if [ -z "${benchOpsPerConn}" ];then benchOpsPerConn=10000;fi
if [ -z "${benchThreads}" ];then benchThreads=100;fi
if [ -z "${duration}" ];then duration=60;fi
if [ ${duration} -lt 10 ];then echo "ERROR: Minimum duration is 10";exit 1;fi

##############################################################################
# Setup OUD instances
##############################################################################
setup_oud() {
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Show processor information"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   lscpu|egrep "^Model name|^Socket|^Core|^CPU.*MHz|^Thread"|tee ${tmpdir}/bench-cores-${now}

   coresPerSocket=$(grep "Core(s) per socket" ${tmpdir}/bench-cores-${now}|awk '{ print $4 }')
   sockets=$(grep "Socket(s):" ${tmpdir}/bench-cores-${now}|awk '{ print $2 }')
   corecnt=$((${coresPerSocket}*${sockets}))
   echo "Total Core(s): ${corecnt}"


   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Show memory information"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   free -h

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Generate data"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${curdir}/manage_data.sh genall -n "${benchTemplate}" -N ${benchEntries} --rm

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= LDIF file size"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ldifSize=$(du -hs ${cfgdir}/${benchTemplate}.ldif|awk '{ print $1 }')
   entryCount=$(grep -c "^dn: " ${cfgdir}/${benchTemplate}.ldif)
   echo "LDIF file size: ${ldifSize}"
   echo "Entry count: ${entryCount}"

   if [ "${notuneFlag}" == '--notune' ]
   then
      cp /dev/null ${cfgdir}/${benchTemplate}.batch
   else
      echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      echo -e "=-= Show batch configuration file"
      echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
      if [ -s "${benchBatch}" ] && [ "${benchBatch}" != "${cfgdir}/${benchTemplate}.batch" ]
      then
      cp "${benchBatch}" "${cfgdir}/${benchTemplate}.batch"
      fi
      cat ${cfgdir}/${benchTemplate}.batch
   fi

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Setup 2 OUD instances"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   if [ -e "${oudmwdir}/oud1/OUD/bin/start-ds" ]
   then
      true
   else
      ${curdir}/manage_oud.sh setup --pnum 1 ${notuneFlag} --jmem ${benchJmem} --xmn ${benchXmn} -n ${benchTemplate} --noroles --batch ${cfgdir}/${benchTemplate}.batch
   fi

   if [ -e "${oudmwdir}/oud2/OUD/bin/start-ds" ]
   then
      true
   else
      #${curdir}/manage_oud.sh setup --pnum 2 ${notuneFlag} --jmem ${benchJmem} --xmn ${benchXmn} -n ${benchTemplate} --noroles --batch ${cfgdir}/${benchTemplate}.batch --supplier ${remoteHost}:1444:1989
      ${curdir}/manage_oud.sh setup --pnum 2 ${notuneFlag} --jmem 4096 --xmn 1 -n ${benchTemplate} --noroles --batch ${cfgdir}/${benchTemplate}.batch --supplier ${remoteHost}:1444:1989
   fi

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Initial userRoot DB size"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   initDbSize=$(du -hs ${oudmwdir}/oud1/OUD/db/userRoot|awk '{ print $1 }')
   echo "Initial DB size: ${initDbSize}"

   if [ -e "${benchJavaProps}" ]
   then
      cp "${benchJavaProps}" "${oudmwdir}/oud1/OUD/config/java.properties"
      ${oudmwdir}/oud1/OUD/bin/dsjavaproperties
   fi

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Show running OUD jvms"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ps -ef|grep config.ldif|grep -v grep

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Generate SLAMD service info file"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   ${curdir}/manage_slamd.sh mksvcinfo -n ${benchTemplate}
}

##############################################################################
# Apply load to OUD instance
##############################################################################
apply_load() {
   # Copy service info file
   if [ "${remoteHost}" != "${localHost}" ]
   then
      rsync -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' opc@${remoteHost}:${cfgdir}/${benchTemplate}.info ${cfgdir}/${benchTemplate}.info
      rc=$?
   fi

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Prime OUD caches"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout $((${duration}*5)) ${curdir}/manage_slamd.sh bsearchrate -n ${benchTemplate} -h ${remoteHost} -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} ${benchSpanFlag} ${dbgFlag}| tee ${tmpdir}/bench-${now}-prime.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Perform base searchrate returning all attributes"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout ${duration} ${curdir}/manage_slamd.sh bsearchrate -n ${benchTemplate} -h ${remoteHost} ${dbgFlag} -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} ${benchSpanFlag}| tee ${tmpdir}/bench-${now}-bsearchall.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Perform base searchrate returning 5 attributes"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout ${duration} ${curdir}/manage_slamd.sh searchrate -n ${benchTemplate} -h ${remoteHost} ${dbgFlag} -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} -A "uid cn sn givenName mobile" ${benchSpanFlag}| tee ${tmpdir}/bench-${now}-bsearch5.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Perform presence searchrate returning all attributes"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout ${duration} ${curdir}/manage_slamd.sh searchrate -n ${benchTemplate} -h ${remoteHost} ${dbgFlag} -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} ${benchSpanFlag}| tee ${tmpdir}/bench-${now}-psearchall.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Perform presence searchrate returning 5 attributes"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout ${duration} ${curdir}/manage_slamd.sh searchrate -n ${benchTemplate} -h ${remoteHost} ${dbgFlag} -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} -A "uid cn sn givenName mobile" ${benchSpanFlag}| tee ${tmpdir}/bench-${now}-psearch5.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Perform authrate"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout ${duration} ${curdir}/manage_slamd.sh authrate -n ${benchTemplate} -h ${remoteHost} ${dbgFlag} -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} ${benchSpanFlag}| tee ${tmpdir}/bench-${now}-auth.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Perform modification rate on 1 un-indexed attr"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout ${duration} ${curdir}/manage_slamd.sh modrate -n ${benchTemplate} -h ${remoteHost} ${dbgFlag} -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} ${benchSpanFlag}| tee ${tmpdir}/bench-${now}-mod0idx.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Perform modification rate on attr with eq and substring indexes"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout ${duration} ${curdir}/manage_slamd.sh modrate -n ${benchTemplate} -h ${remoteHost} ${dbgFlag} -A cn -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} ${benchSpanFlag} | tee ${tmpdir}/bench-${now}-mod2idx.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Mature userRoot DB size"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   if [ "${remoteHost}" != "${localHost}" ]
   then
      matureDbSize=$(ssh -qp 22 -o 'StrictHostKeyChecking=no' opc@${remoteHost} du -hs ${oudmwdir}/oud1/OUD/db/userRoot|awk '{ print $1 }')
   else
      matureDbSize=$(du -hs ${oudmwdir}/oud1/OUD/db/userRoot|awk '{ print $1 }')
   fi
   echo "Mature DB size: ${matureDbSize}"

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Perform one last base searchrate to check caches"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   timeout ${duration} ${curdir}/manage_slamd.sh bsearchrate -n ${benchTemplate} -h ${remoteHost} ${dbgFlag} -T ${benchThreads} -M ${benchTargetRate} -m ${benchOpsPerConn} ${benchSpanFlag}| tee ${tmpdir}/bench-${now}-lastsearch.out

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= Performance summary"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="

   prime_ops=$(cat ${tmpdir}/bench-${now}-prime.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")
   bSearchAll_ops=$(cat ${tmpdir}/bench-${now}-bsearchall.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")
   bSearch5_ops=$(cat ${tmpdir}/bench-${now}-bsearch5.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")
   pSearchAll_ops=$(cat ${tmpdir}/bench-${now}-psearchall.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")
   pSearch5_ops=$(cat ${tmpdir}/bench-${now}-psearch5.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")
   arate_ops=$(cat ${tmpdir}/bench-${now}-auth.out|awk '{ print $4 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")
   mod0idx_ops=$(cat ${tmpdir}/bench-${now}-mod0idx.out|awk '{ print $4 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")
   mod2idx_ops=$(cat ${tmpdir}/bench-${now}-mod2idx.out|awk '{ print $4 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")
   lastsrch_ops=$(cat ${tmpdir}/bench-${now}-lastsearch.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|xargs -n1 printf "%'d")

   prime_rs=$(cat ${tmpdir}/bench-${now}-prime.out|awk '{ print $6 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")
   bSearchAll_rs=$(cat ${tmpdir}/bench-${now}-bsearchall.out|awk '{ print $6 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")
   bSearch5_rs=$(cat ${tmpdir}/bench-${now}-bsearch5.out|awk '{ print $6 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")
   pSearchAll_rs=$(cat ${tmpdir}/bench-${now}-psearchall.out|awk '{ print $6 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")
   pSearch5_rs=$(cat ${tmpdir}/bench-${now}-psearch5.out|awk '{ print $6 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")
   arate_rs=$(cat ${tmpdir}/bench-${now}-auth.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")
   mod0idx_rs=$(cat ${tmpdir}/bench-${now}-mod0idx.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")
   mod2idx_rs=$(cat ${tmpdir}/bench-${now}-mod2idx.out|awk '{ print $5 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")
   lastsrch_rs=$(cat ${tmpdir}/bench-${now}-lastsearch.out|awk '{ print $6 }'|tail -1|cut -d'.' -f1|sed -e "s/-//g" -e "s/^$/0/g")

   printf "%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n" "Prime" "bSearch(all)" "bSearch(5)" "pSearch(all)" "psearch(5)" "arate" "mod0idx" "mod2idx" "lastsrch"
   printf "%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s%-13s\n" "${prime_ops}[${prime_rs}]" "${bSearchAll_ops}[${bSearchAll_rs}]" "${bSearch5_ops}[${bSearch5_rs}]" "${pSearchAll_ops}[${pSearchAll_rs}]" "${pSearch5_ops}[${pSearch5_rs}]" "${arate_ops}[${arate_rs}]" "${mod0idx_ops}[${mod0idx_rs}]" "${mod2idx_ops}[${mod2idx_rs}]" "${lastsrch_ops}[${lastsrch_rs}]"

   echo "Prime,bSearch(all),bSearch(5),pSearch(all),psearch(5),arate,mod0idx,mod2idx,lastsrch" > ${logdir}/bench-${benchTemplate}-${benchEntries}-${now}.csv

   echo "${prime_ops}[${prime_rs}],${bSearchAll_ops}[${bSearchAll_rs}],${bSearch5_ops}[${bSearch5_rs}],${pSearchAll_ops}[${pSearchAll_rs}],${pSearch5_ops}[${pSearch5_rs}],${arate_ops}[${arate_rs}],${mod0idx_ops}[${mod0idx_rs}],${mod2idx_ops}[${mod2idx_rs}],${lastsrch_ops}[${lastsrch_rs}]" >> ${logdir}/bench-${benchTemplate}-${benchEntries}--${now}.csv

   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e "=-= CSV Summary"
   echo -e "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   cat ${logdir}/bench-${benchTemplate}-${benchEntries}-${now}.csv ${logdir}/bench-${benchTemplate}-${benchEntries}--${now}.csv
}

###############################################################################
# Process inputs
###############################################################################
case ${subcmd} in
   'setup') setup_oud;;
    'load') apply_load;;
    'both') setup_oud;apply_load;;
         *) echo "USAGE: ${0} <setup|load|both> [options]";exit 1;;
esac
