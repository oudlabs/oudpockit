#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Here are some command line tools for various notification methods:
# 
# Mail: mail
#
# SMS: https://textbelt.com
#
# SNMP Trap:
#    CLI: http://net-snmp.sourceforge.net/download.html
#    Perl: https://metacpan.org/pod/Net::SNMP
#    Python: https://pysnmp.readthedocs.io/en/latest/quick-start.html#send-snmp-trap
###############################################################################
log="${oudmwdir}/oud1/OUD/logs/access"

tail -F ${log} |egrep --line-buffered "result=[1-9]" |
while read line
do
    conn=$(echo "${line}"|sed -e "s/.* conn=/ conn=/g" -e "s/msgID.*//g")
    seq=$(grep "${conn}" ${log})

    # Insert your notification command here to echo, sms, snmp trap, ...
    echo "${seq}"
done
