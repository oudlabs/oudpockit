#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
cmdArg2=$2
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

##############################################################################
zones=()

##############################################################################
# Process inputs
##############################################################################
z=0
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            compartment) compartment="$1";shift;;
            region) region="$1";shift;;
            subnet) subnet="$1";shift;;
            zone) zones[${z}]="$1";let z++;shift;;
            image) image="$1";shift;;
            dr) dr="$1";shift;;
            rs) rs="$1";shift;;
            ds) ds="$1";shift;;
            ad) availabilityDomain="$1";shift;;
            bm) bm='true';;
            arch) arch="$1";shift;;
            cores) cores="$1";shift;;
            mem) mem="$1";shift;;
            jmem) jmemFlag="--jmem $1";shift;;
            xmn) xmnFlag="--xmn $1";shift;;
            suffix) suffix=$1; shift;;
            template) myTemplateName=$1; shift;;
            batch) myBatchFile=$1; shift;;
            schema) mySchemaFile=$1; shift;;
            data) myDataFile=$1; shift;;
            templ) templateFile=$1; shift;;
            ldifFile'ldiffile') myLdifFile=$1; shift;;
            hard) hardStop='true';;
            webproxy) webProxyFlag='--webproxy';;
            pubip) pubipFlag='--pubip';;
            storage) storageFlag="--storage $1";shift;;
            duration) duration="$1";shift;;
            notune) notuneFlag="--notune";;
            threads) threadsFlag="-T $1"; shift;;
            ocios) ociOS="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            z) dbg="true";dbgFlag=' -z ';;
            h) myHost=$1; shift;;
            p) myPort=$1; shift;;
            Z) useSSL='SSL';;
            D) bindDN=$1;bDN=$1; shift;;
            w) bindPW=$1;bPW=$1; shift;;
            C) clients=$1; shift;;
            T) threadsFlag="-T $1"; shift;;
            M) myModulateOps=$1;modulateOps=$1; shift;;
            m) myMaxOps=$1;maxOps=$1; shift;;
            A) attrs=$1; shift;;
            r) rateDN=$1; shift;;
            S) suffix=$1; shift;;
            s) mySchemaFile=$1; shift;;
            t) templateFile=$1; shift;;
            n) myTemplateName=$1; shift;;
            u) templUserFile=$1; shift;;
            l) myLdifFile=$1; shift;;
            W) mySwDir=$1; shift;;
            a) args=$1; shift;;
            q) disclaimOnce=1;addQ=' -q ';;
            P) prePurge=true;prePurgeFlag=' -P ';;
            N) myNumUsers=$1;shift;;
            g) numGroups=$1; prePurge=true;shift;;
            G) numMembers=$1; prePurge=true;shift;;
        esac;;
    esac
done

##############################################################################
# Initialize key variables
##############################################################################
if [ -n "${myHost}" ];then dsHost="${myHost}";else dsHost=${localHost};fi
if [ -n "${myPort}" ];then dsPort="${myPort}";else dsPort=${ldapPort};fi

if [ -n "${myTemplateName}" ];then templateName="${myTemplateName}";fi

if [ -n "${ociOS}" ];then ociOS="${ociOS}";else ociOS='ol8';fi

if [ -n "${myBatchFile}" ]
then
   batchFile="${myBatchFile}"
elif [ -n "${templateName}" ]
then
   batchFile="${cfgdir}/${templateName}.batch"
else
   batchFile="${cfgdir}/data.batch"
fi

if [ -n "${mySchemaFile}" ]
then
   schemaFile="${mySchemaFile}"
elif [ -n "${templateName}" ]
then
   if [ -n "${cfgdir}/${templateName}.schema" ]
   then
      schemaFile="${cfgdir}/${templateName}.schema"
   elif [ -n "${curdir}/samples/${templateName}.schema" ]
   then
      schemaFile="${curdir}/samples/${templateName}.schema"
   else
      schemaFile=''
   fi
else
   schemaFile=''
fi

if [ -n "${myDataFile}" ]
then
   dataFile="${myDataFile}"
else
   dataFile="${cfgdir}/data.ldif"
fi

#if [ -e "${batchFile}" ];then true;else touch ${batchFile};fi
#if [ -e "${schemaFile}" ];then true;else touch ${schemaFile};fi
#if [ -e "${dataFile}" ];then true;else touch ${dataFile};fi

if [ -z "${bm}" ];then bm='false';fi
if [ -z "${arch}" ];then arch='amd';fi
if [ -z "${cores}" ];then cores='1';fi
if [ -z "${mem}" ];then mem='15';fi
if [ -z "${duration}" ];then duration='30';fi

privip=''
pubip=''

##############################################################################
# Lookup IP from ${cfgdir}/hosts
##############################################################################
lookupip() {
   lhost="$1"
   if [ -z "${lhost}" ];then echo "Error: Must provide name on IP lookup";exit 1;fi
   privip=$(grep -h "^${lhost}|" ${cfgdir}/hosts 2> /dev/null|cut -d'|' -f2)
   pubip=$(grep -h "^${lhost}|" ${cfgdir}/hosts 2> /dev/null|cut -d'|' -f3)
   if [ -z "${pubip}" ] || [ "${pubip}" == 'None' ]
   then
      sship="${privip}"
   else
      sship="${pubip}"
   fi
}

##############################################################################
# Launch compute instances for OUD
##############################################################################
setup_oci() {
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo      "=-= Setup OCI infrastructure for OUD"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="

   z=0
   region=$(echo ${zones[${z}]}|cut -d'|' -f1)
   availabilityDomain=$(echo ${zones[${z}]}|cut -d'|' -f2)
   subnet=$(echo ${zones[${z}]}|cut -d'|' -f3)

   if [ -z "${region}" ];then region='us-ashburn-1';fi
   if [ -z "${availabilityDomain}" ];then availabilityDomain='uYkY:US-ASHBURN-AD-1';fi
   if [ -z "${subnet}" ]
   then
      echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
      exit 1
   fi
   ${curdir}/manage_oci.sh launch --name ouddr1 --role dr --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} --ocios ${ociOS} ${webProxyFlag} ${pubipFlag} ${storageFlag} ${dbgFlag}

   # Update OUD POC Kit hosts file
   echo "Update OCI local hosts"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oci.sh list net --region ${region} --subnet ${subnet} --compartment ${compartment} ${dbgFlag}
   set +x
   
}

##############################################################################
# Run end-to-end campaign
##############################################################################
terminate_oci() {
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo -e   "=-= Terminate OCI infrastructure"
   echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="

   z=0
   region=$(echo ${zones[${z}]}|cut -d'|' -f1)
   availabilityDomain=$(echo ${zones[${z}]}|cut -d'|' -f2)
   subnet=$(echo ${zones[${z}]}|cut -d'|' -f3)
   if [ -z "${region}" ];then region='us-ashburn-1';fi
   if [ -z "${availabilityDomain}" ];then availabilityDomain='uYkY:US-ASHBURN-AD-1';fi
   if [ -z "${subnet}" ]
   then
      echo "ERROR: Invalid zone. Proper syntax --zone \"<region>|<ad>|<subnet>\""
      exit 1
   fi
   ${curdir}/manage_oci.sh terminate --name ouddr1 --region ${region} --ad ${availabilityDomain} --subnet ${subnet} --compartment ${compartment} --arch ${arch} --cores ${cores} --mem ${mem} --tag ${now} ${dbgFlag}

   # Make sure no launches are still running
   ck4pids=$(ps -ef|grep -v grep|grep "oci compute instance launch"|awk '{ print $2 }')
   if [ -n "${ck4pids}" ];then echo ${ck4pids}|xargs -n1 kill;fi

   # Update OUD POC Kit hosts file
   ${curdir}/manage_oci.sh list net --region ${region} --subnet ${subnet} --compartment ${compartment} ${dbgFlag}
}

##############################################################################
# Run setup routines
##############################################################################
setup_oci
lookupip ouddr1
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo      "=-= Upload schema, batch, and data if specified"
echo -e   "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
if [ -s "${schemaFile}" ];then echo "Copy schema file";rsync --progress -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' ${schemaFile} opc@${privip}:${cfgdir}/bench${templateName}.schema;fi
if [ -s "${batchFile}" ];then echo "Copy batch file";rsync --progress -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' ${batchFile} opc@${privip}:${cfgdir}/bench${templateName}.batch;fi
if [ -s "${dataFile}" ];then echo "Copy data file";rsync --progress -qHave 'ssh -qp 22 -o StrictHostKeyChecking=no' ${dataFile} opc@${privip}:${cfgdir}/bench${templateName}.ldif;fi

ssh -qp 22 -o StrictHostKeyChecking=no opc@${sship} "${curdir}/demo_baseline_local.sh setup --batch \"${cfgdir}/bench${templateName}.batch\" --schema \"${cfgdir}/bench${templateName}.schema\" --data \"${cfgdir}/bench${templateName}.ldif\" ${notuneFlag} ${jmemFlag} ${xmnFlag} 2>&1" | tee -a ${logdir}/run_baseline-${now}.log

ocidomain=${domain}
${curdir}/demo_baseline_local.sh load --duration ${duration} ${threadsFlag} --host ouddr1.${ocidomain}

terminate_oci
