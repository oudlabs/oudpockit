#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Set global variables
###############################################################################
fifoCachePct=20

###############################################################################
# 1. Determine how much RAM the host has
###############################################################################
echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "Gather data from ..."
echo "   OS..."
lookupos
osRAM=''
case ${os} in
   'Linux') osRAM=$(grep "^MemTotal" /proc/meminfo|awk '{ print int($2/1024-2) }')
            vmSwappiness=$(sysctl vm.swappiness|awk '{ print $3 }')
            ck4limits=$(grep -i "^${me}" /etc/security/limits.conf)
            ;;
   'SunOS') osRAM=$(lgrpinfo|grep "Memory:"|awk '{ print $3 }'|tr -cd '[:alnum:]'|sed -e "s/G/000000000/g" -e "s/M/000000/g" -e "s/K/000/g"|awk '{ print $1/1000 }')
            # Gather L2Arc setting
            ;;
esac

###############################################################################
# 2. Determine JVM size estimate per instance
###############################################################################
echo "   OUD instances..."
cd ${oudmwdir}
readarray -t instances < <(ls -1d oud[1-9])
n=0
aggregateJvm=0
for (( m=0; m< ${#instances[*]}; m++ ))
do
   inst=$(echo ${instances[${m}]}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
   instSize=$(du -ms ${inst}/OUD/db|awk '{ print $1 }')
   jvmSize=$((${instSize}+5120))
   aggregateJvm=$((${aggregateJvm}+${jvmSize}))
   jvmSizes[${n}]="${inst}|${jvmSize}"
   let n++
done

###############################################################################
# 3. Gather backend data per OUD instance
###############################################################################
echo "   OUD instance backends..."
readarray -t backends < <(ls -1d oud[1-9]/OUD/db/*|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")
o=0
for (( m=0; m< ${#instances[*]}; m++ ))
do
   inst=$(echo ${instances[${m}]}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
   for be in ${backends[@]}
   do
      beInst=$(echo ${be}|cut -d'/' -f1|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      if [ "${beInst}" == "${inst}" ]
      then
         beDir=$(echo ${be}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
         beName=$(echo "${beDir}"|cut -d'/' -f4)
         beSize=$(du -ms "${beDir}"|awk '{ print $1 }')
         if [ ${beSize} -le 0 ];then beSize=1;fi
         beList[${o}]="${inst}|${beName}|${beSize}"
         let o++
      fi
   done
done

###############################################################################
# Summarize optimal sizing recommendations
###############################################################################
rm -f ${cfgdir}/oud[1-9]-optimal.batch 2> /dev/null
rm -f ${cfgdir}/oud[1-9]-minimal.batch 2> /dev/null

echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "   Best Practice Recommendations for optimal OUD Sizings:"
optimalRam=$((${aggregateJvm}*2))
printf "%s %'d MB\n\n" "      Host RAM should be at least " "${optimalRam}"

printf "      %-6s%-10s%-20s%-11s%-10s\n" "" "JVM" "" "DB" "FIFO"
printf "      %-6s%-10s%-20s%-11s%-10s\n" "Inst" "Size(MB)" "Backend" "Cache (MB)" "Cache (%)"
printf "      %-6s%-10s%-20s%-11s%-10s\n" "-----" "---------" "-------------------" "----------" "---------"

for (( m=0; m< ${#instances[*]}; m++ ))
do
   inst=$(echo ${instances[${m}]}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")

   # Lookup jvmSize
   jvmSize=$(echo "${jvmSizes[@]}"|sed -e "s/ /\n/g"|grep "^${inst}|"|cut -d '|' -f2)

   # Lookup backends
   for (( n=0; n< ${#beList[*]}; n++ ))
   do
      beInst=$(echo "${beList[${n}]}"|cut -d'|' -f1)
      beName=$(echo "${beList[${n}]}"|cut -d'|' -f2)
      beSize=$(echo "${beList[${n}]}"|cut -d'|' -f3)
      if [ ${beSize} -le 0 ];then beSize=1;fi
      if [ "${beInst}" == "${inst}" ]
      then
          printf "      %-6s%'-10d%-20s%-11s%-10s\n" "${inst}" "${jvmSize}" "${beName}" "${beSize}" "${fifoCachePct}"
          cat >> ${cfgdir}/${inst}-optimal.batch <<EOF
set-workflow-element-prop --element-name ${beName} --set db-cache-size:${beSize}\ mib
create-entry-cache --type fifo --cache-name ${beName}-fifoEC --set max-entries:1000000 --set max-memory-percent:${fifoCachePct} --set cache-level:2 --set enabled:true --set entry-cache-workflow-element:${beName}
EOF
      fi
   done
done

echo "      Optimal batch settings:"
for (( m=0; m< ${#instances[*]}; m++ ))
do
   inst=$(echo ${instances[${m}]}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
   echo "         ${cfgdir}/${inst}-optimal.batch"
done

echo -e "\n      The following commands are what you would use to adjust\n      the JVM run time settings:"
for (( m=0; m< ${#instances[*]}; m++ ))
do
   inst=$(echo ${instances[${m}]}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")

   jvmSize=$(echo "${jvmSizes[@]}"|sed -e "s/ /\n/g"|grep "^${inst}|"|cut -d '|' -f2)
   jvmSize=$((${jvmSize}+5120))

   echo -e "           ${oudmwdir}/${inst}/OUD/bin/dstune mem-based --memory ${jvmSize}m --targetTool server --no-prompt"
   echo -e "\n      Edit ${oudmwdir}/${inst}/OUD/java.properties and\n      set -Xmn <value> to -Xmn 4g and add the following to the\n      end of the start-ds line:"
   echo -e "           -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark\ -XX:+DisableExplicitGC\ -Djdk.tls.maxHandshakeMessageSize=36864"
   echo -e "\n      Apply JVM settings with:\n         ${oudmwdir}/${inst}/OUD/bin/dsjavaproperties"
   echo -e "\n      Re-start the OUD instance to apply Java changes"
done


###############################################################################
# Summarize minimal sizing recommendations
###############################################################################
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "   Best Practice Recommendations for minimal OUD Sizings:"
minimalRAM=$((${aggregateJvm}/2+8096))
printf "%s %'d MB\n" "      Host RAM should be at least " "${minimalRAM}"

printf "      %-6s%-10s%-20s%-11s\n" "" "JVM" "" "DB"
printf "      %-6s%-10s%-20s%-11s\n" "Inst" "Size(MB)" "Backend" "Cache (MB)"
printf "      %-6s%-10s%-20s%-11s\n" "-----" "---------" "-------------------" "----------"
for (( m=0; m< ${#instances[*]}; m++ ))
do
   inst=$(echo ${instances[${m}]}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")

   # Lookup jvmSize
   jvmSize=$(echo "${jvmSizes[@]}"|sed -e "s/ /\n/g"|grep "^${inst}|"|cut -d '|' -f2)
   jvmSize=$(((${jvmSize}-5120)/2+5120))
   if [ ${jvmSize} -le 0 ];then jvmSize=6144;fi

   # Lookup backends
   for (( n=0; n< ${#beList[*]}; n++ ))
   do
      beInst=$(echo "${beList[${n}]}"|cut -d'|' -f1)
      beName=$(echo "${beList[${n}]}"|cut -d'|' -f2)
      beSize=$(echo "${beList[${n}]}"|cut -d'|' -f3)
      beSize=$((${beSize}/2))
      if [ ${beSize} -le 0 ];then beSize=1;fi
      if [ "${beInst}" == "${inst}" ]
      then
          printf "      %-6s%'-10d%-20s%-11s\n" "${inst}" "${jvmSize}" "${beName}" "${beSize}"
          cat >> ${cfgdir}/${inst}-minimal.batch <<EOF
set-workflow-element-prop --element-name ${beName} --set db-cache-size:${beSize}\ mib
EOF
      fi
   done
done
# Make batch configuration file
echo "      Minimal batch settings:"
for (( m=0; m< ${#instances[*]}; m++ ))
do
   inst=$(echo ${instances[${m}]}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
   echo "         ${cfgdir}/${inst}-minimal.batch"
done

echo -e "\n      The following commands are what you would use to adjust\n      the JVM run time settings:"
for (( m=0; m< ${#instances[*]}; m++ ))
do
   inst=$(echo ${instances[${m}]}|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")

   jvmSize=$(echo "${jvmSizes[@]}"|sed -e "s/ /\n/g"|grep "^${inst}|"|cut -d '|' -f2)
   jvmSize=$(((${jvmSize}-5120)/2+5120))

   echo -e "           ${oudmwdir}/${inst}/OUD/bin/dstune mem-based --memory ${jvmSize}m --targetTool server --no-prompt"
   echo -e "\n      Edit ${oudmwdir}/${inst}/OUD/java.properties and\n      set -Xmn <value> to -Xmn 4g and add the following to the\n      end of the start-ds line:"
   echo -e "           -XX:+UseCMSInitiatingOccupancyOnly\ -XX:+CMSScavengeBeforeRemark\ -XX:+DisableExplicitGC\ -Djdk.tls.maxHandshakeMessageSize=36864"
   echo -e "\n      Apply JVM settings with:\n         ${oudmwdir}/${inst}/OUD/bin/dsjavaproperties"
   echo -e "\n      Re-start the OUD instance to apply Java changes"
done

###############################################################################
# Operating System Settings
###############################################################################
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "   OS Tuning recommendations:"
case ${os} in
   'Linux') if [ ${vmSwappiness} -ne 0 ]
            then
               cat <<EOF
      Add the following to /etc/sysctl.conf and then run sysctl -p /etc/sysctl.conf:
vm.swappiness = 0
net.netfilter.nf_conntrack_tcp_timeout_time_wait=1
net.ipv4.tcp_tw_reuse=1
net.ipv4.tcp_fin_timeout=1
EOF
            fi
            if [ -z "${ck4limits}" ]
            then
               cat <<EOF

      Make sure the following limits exist in /etc/security/limits.conf:
${me}       hard    nofile  65535
${me}       soft    nofile  8192
${me}       hard    nproc   16384
${me}       soft    nproc   16384
EOF
            fi
            ;;
   'SunOS') if [ ${l2Arc} -eq 0 ];then echo "Preserve memory for OUD by setting l2arc to... ";fi
            ;;
esac
