#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

# If a suffix is passed as input, use that for the suffix for this demo
if [ -n "$1" ];then suffix="$1";fi

###############################################################################
# Install OUD
###############################################################################
echo -e "\nDEMO --> Install OUD"
${curdir}/manage_install.sh install oud ${fmwFlag}

###############################################################################
# Generate data
###############################################################################
cd "${cfgdir}"
rm -f ad.* inetorg.* us.* emea.* apac.* 2> /dev/null

echo -e "\nDEMO --> Generate Data for US AD Forest"
${curdir}/manage_data.sh gentempl -n ad -N 100 --suffix "${suffix}" --rm
sed -e "s/^sAMAccountName: user/sAMAccountName: ususer/g" -e "s/|user|/|ususer|/g" ${cfgdir}/ad.tmpl > ${cfgdir}/us.tmpl
head -6 ${cfgdir}/us.tmpl > ${cfgdir}/us.info
mv ${cfgdir}/us.tmpl ${cfgdir}/ad.tmpl
${curdir}/manage_data.sh gendata -n ad --rm
${curdir}/manage_data.sh gendn -n ad --dnfilter cn=ususer --rm
${curdir}/manage_data.sh genrdn -n ad --dnfilter cn=ususer --rm
for i in ad*;do j=$(echo ${i}|sed -e "s/^ad/us/g");mv ${i} ${j};done

echo -e "\nDEMO --> Generate Data for EMEA AD Forest"
${curdir}/manage_data.sh gentempl -n ad -N 100 --suffix "dc=emea,${suffix}" --rm
sed -e "s/^sAMAccountName: user/sAMAccountName: emeauser/g" -e "s/|user|/|emeauser|/g" ${cfgdir}/ad.tmpl > ${cfgdir}/emea.tmpl
head -6 ${cfgdir}/emea.tmpl > ${cfgdir}/emea.info
mv ${cfgdir}/emea.tmpl ${cfgdir}/ad.tmpl
${curdir}/manage_data.sh gendata -n ad --rm
${curdir}/manage_data.sh gendn -n ad --dnfilter cn=emeauser --rm
${curdir}/manage_data.sh genrdn -n ad --dnfilter cn=emeauser --rm
for i in ad*;do j=$(echo ${i}|sed -e "s/^ad/emea/g");mv ${i} ${j};done

echo -e "\nDEMO --> Generate Data for APAC AD Forest"
${curdir}/manage_data.sh gentempl -n ad -N 100 --suffix "dc=apac,${suffix}" --rm
sed -e "s/^sAMAccountName: user/sAMAccountName: apacuser/g" -e "s/|user|/|apacuser|/g" ${cfgdir}/ad.tmpl > ${cfgdir}/apac.tmpl
head -6 ${cfgdir}/apac.tmpl > ${cfgdir}/apac.info
mv ${cfgdir}/apac.tmpl ${cfgdir}/ad.tmpl
${curdir}/manage_data.sh gendata -n ad --rm
${curdir}/manage_data.sh gendn -n ad --dnfilter cn=apacuser --rm
${curdir}/manage_data.sh genrdn -n ad --dnfilter cn=apacuser --rm
for i in ad*;do j=$(echo ${i}|sed -e "s/^ad/apac/g");mv ${i} ${j};done

# Create data for local backends
head -11 us.ldif > example.ldif
sed -e "s/${suffix}/dc=com/g" -e "s/dc: example/dc: com/g" example.ldif > com.ldif

###############################################################################
# Create proxy batch configuration file
###############################################################################
echo -e "\nDEMO --> Create OUD Proxy batch configuration file"
sed -e "s/dk0.example.com/${localHost}/gi" -e "s/Oracle123/${bPW}/g" -e "s/dc=example,dc=com/${suffix}/g" ${samples}/multiforest.batch > ${cfgdir}/multiforest.batch

###############################################################################
# Setup OUD instances that emulate AD forests
###############################################################################
echo -e "\nDEMO --> Setup OUD instance to emulate US AD Forest"
${curdir}/manage_oud.sh setup --pnum 1 -n us   --suffix "${suffix}" --schema "${samples}/ad.schema" --nobatch

echo -e "\nDEMO --> Setup OUD instance to emulate US EMEA Forest"
${curdir}/manage_oud.sh setup --pnum 2 -n emea --suffix "dc=emea,${suffix}" --schema "${samples}/ad.schema" --nobatch

echo -e "\nDEMO --> Setup OUD instance to emulate US APAC Forest"
${curdir}/manage_oud.sh setup --pnum 3 -n apac --suffix "dc=apac,${suffix}" --schema "${samples}/ad.schema" --nobatch

###############################################################################
# Setup OUD Proxy
###############################################################################
echo -e "\nDEMO --> Setup MultiForest OUD Proxy"
${curdir}/manage_proxy.sh setup --pnum 1 --batch "${cfgdir}/multiforest.batch" --schema "${samples}/ad.schema"
rc=$?

###############################################################################
# Load data into dc=com and dc=example backends
###############################################################################
basedn="${suffix}"
while [ -n "${basedn}" ]
do
   baserdn=$(echo ${basedn}|cut -d',' -f1|cut -d'=' -f1)
   basevalue=$(echo ${basedn}|cut -d',' -f1|cut -d'=' -f2)
   basefile=$(echo ${basedn}|sed -e "s/ //g" -e "s/	//g" -e "s/=//gi" -e "s/,//g")

   echo -e "\nMultiForest DEMO: Load ${basedn} local backend data"
   # Create LDIF file
   cat > ${cfgdir}/${basefile}.ldif <<EOF
dn: ${basedn}
objectClass: top
objectClass: domain
${baserdn}: ${basevalue}
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///cn=*,cn=Admins,dc=com";) aci: (target="ldap:///dc=com")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,dc=com";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///all";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "AD Admin contorls"; allow(read,search,compare) userdn="ldap:///cn=*,cn=Admins,${basedn}";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "OUD Admin contorls"; allow(read,search,compare) userdn="ldap:///uid=*,ou=Admins,${basedn}";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "OUD Admin contorls"; allow(read,search,compare) userdn="ldap:///cn=*,ou=ServiceAccounts,${basedn}";)
EOF

   # Load LDIF file
   ${oudmwdir}/proxy1/OUD/bin/import-ldif -h ${localHost} -p 1445 -D "${bDN}" -j "${jPW}" -n ${basevalue}-be --skipFile ${logdir}/example-skips.out --rejectFile ${logdir}/example-rejects.out -l ${cfgdir}/${basefile}.ldif >> ${logdir}/${basefile}-import-${now}.log 2>&1
   rc=$?

   basedn=$(echo "${basedn},"|cut -d',' -f2-|sed -e "s/,$//g")
done

###############################################################################
# Test each backend
###############################################################################
echo -e "\nMultiForest DEMO: Demonstrate search across domains:"
basedn="${suffix}"
authUser="cn=admin1,cn=Admins,${basedn}"
setfmwenv
while [ -n "${basedn}" ]
do
set -x
   ${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "${authUser}" -j "${jPW}" -b "${basedn}" -s sub '(samAccountName=ususer1)'   dn
   ${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "${authUser}" -j "${jPW}" -b "${basedn}" -s sub '(samAccountName=emeauser1)' dn
   ${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "${authUser}" -j "${jPW}" -b "${basedn}" -s sub '(samAccountName=apacuser1)' dn
set +x

   basedn=$(echo "${basedn},"|cut -d',' -f2-|sed -e "s/,$//g")
done
