#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Generate ShadowJoin batch configuration file
###############################################################################
cat > ${cfgdir}/shadowjoin.batch <<EOF
# Create local base backend
create-workflow-element --element-name oud-base-be --set enabled:true --type db-local-backend --set base-dn:${suffix} 

create-workflow --workflow-name oud-base-wf --set enabled:true --type generic --set base-dn:${suffix} --set workflow-element:oud-base-be 

set-network-group-prop --group-name network-group --add workflow:oud-base-wf

# Add MSAD extension/wfe/wf/ng for cn=Users
create-extension --extension-name msad-xtn --set enabled:true --type ldap-server --set remote-ldap-server-address:${localHost} --set remote-ldap-server-port:1389 --set remote-ldap-server-ssl-port:1636 --set remote-ldap-server-ssl-policy:always --set ssl-trust-all:true --set directory-type:ad 

create-workflow-element --element-name msad-wfe --set enabled:true --type proxy-ldap --set client-cred-mode:use-specific-identity --set ldap-server-extension:msad-xtn --set remote-ldap-server-bind-dn:cn=admin1,cn=Admins,${suffix} --set remote-root-dn:cn=admin1,cn=Admins,${suffix} --set remote-ldap-server-bind-password:${bPW} --set remote-root-password:${bPW}

create-workflow --workflow-name msad-wf --set enabled:true --type generic --set base-dn:cn=Users,${suffix} --set workflow-element:msad-wfe 

#set-network-group-prop --group-name network-group --add workflow:msad-wf

# Add OUD extension/wfe/wf/ng for cn=Users
create-extension --extension-name oud-ldap-xtn  --set enabled:true --type ldap-server --set remote-ldap-server-address:${localHost} --set remote-ldap-server-port:2389 --set remote-ldap-server-ssl-port:2636 --set remote-ldap-server-ssl-policy:always --set ssl-trust-all:true --set directory-type:oud

create-workflow-element --element-name oud-wfe --set enabled:true --type proxy-ldap --set client-cred-mode:use-specific-identity --set ldap-server-extension:oud-ldap-xtn --set remote-ldap-server-bind-dn:cn=admin1,cn=Admins,${suffix} --set remote-ldap-server-bind-password:${bPW} --set remote-root-dn:cn=admin1,cn=Admins,${suffix} --set remote-root-password:${bPW}

create-workflow --workflow-name oud-wf --set enabled:true --type generic --set base-dn:cn=Users,${suffix} --set workflow-element:oud-wfe 

#set-network-group-prop --group-name network-group --add workflow:oud-wf

# Add ShadowJoin wfe
create-workflow-element --element-name shadowJoin-wfe --set enabled:true --type join --set join-suffix:cn=Users,${suffix} --set dn-attribute:distinguishedName --set dn-attribute:manager --set dn-attribute:member --set dn-attribute:memberof --set dn-attribute:uniquemember --set save-password-on-successful-bind:true 

# Add Join Participants
create-join-participant --element-name shadowJoin-wfe --type generic --set participant-dn:cn=Users,${suffix} --set participating-workflow-element:msad-wfe --set enabled-operation:add --set enabled-operation:bind --set enabled-operation:compare --set enabled-operation:delete --set enabled-operation:modify --set enabled-operation:modifydn --set enabled-operation:search --set primary-participant:true --set non-storable-attribute:userSSN --set non-retrievable-attribute:userSSN --set joiner-type:one-to-one --participant-name primary-ad

create-join-participant --element-name shadowJoin-wfe --type generic --set participant-dn:cn=Users,${suffix} --set participating-workflow-element:oud-wfe --set enabled-operation:add --set enabled-operation:bind --set enabled-operation:compare --set enabled-operation:delete --set enabled-operation:modify --set enabled-operation:modifydn --set enabled-operation:search --set joiner-type:shadow --set participant-bind-priority:1 --set storable-attribute:cn --set storable-attribute:givenName --set storable-attribute:sn --set storable-attribute:uid --set storable-attribute:userSSN --set storable-attribute:userPassword --set participants-join-rule:'(secondary-oud.uid=primary-ad.samAccountName)' --participant-name secondary-oud

# Create ShadowJoin workflow
create-workflow --workflow-name shadowJoin-wf --set enabled:true --type generic --set base-dn:cn=Users,${suffix} --set workflow-element:shadowJoin-wfe

# Add ShadowJoin wf to ng
set-network-group-prop --group-name network-group --add workflow:oud-base-wf --add workflow:shadowJoin-wf
EOF

###############################################################################
# Generate data
###############################################################################
echo -e "\nDEMO --> Generate Data"
${curdir}/manage_data.sh genall -n ad -N 2 --rm --dnfilter cn=user

rm -f msad*.ldif 2> /dev/null
sed -e "s/numusers=.*/numusers=2/g" -e "s/numgroups=.*/numgroups=0/g" ${cfgdir}/ad.tmpl > ${cfgdir}/msad.tmpl
sed -e "s/numusers=.*/numusers=2/g" \
    -e "s/numgroups=.*/numgroups=0/g" \
    -e "s/^uid: .*/uid: user{employeeID}/g" \
    -e "s/^cn: {sAMAccountName.*/cn: user{employeeID}/g" \
    -e "s/{gidNumber}/100/g" \
    ${cfgdir}/ad.tmpl \
    |egrep -vi "^subordinateTemplate: eusAdmin|^objectClass: user|^objectClass: posixaccount|^objectcategory:|^codepage:|^countrycode:|^division:|^givenName:|^samaccountname:|^objectguid:|^displayName:|^userprincipalname:|^name:|^distinguishedName:|^telephoneNumber:|^instancetype:|^useraccountcontrol:|^accountexpires:|^altsecurityidentities:|^mail:|^homedrive:|^uidNumber:|^gidNumber:|^homeDirectory:|^unixhomedirectory:|^loginShell:|^mobile:|^title:|^manager:|^secretary:|^ds-privilege-name:" \
    > ${cfgdir}/oud.tmpl


${curdir}/manage_install.sh install oud ${fmwFlag} <<EOF
${bPW}
EOF

${curdir}/manage_data.sh gendata -n msad --rm --dnfilter cn=user
rm -f ${cfgdir}/oud.ldif 2> /dev/null
${curdir}/manage_data.sh gendata -n oud

###############################################################################
# Setup MSAD and OUD Instances
###############################################################################
echo -e "\nDEMO --> Setup MSAD Instance"
${curdir}/manage_oud.sh setup --pnum 1 --suffix "${suffix}" -n msad --schema ${samples}/ad.schema --nobatch --noroles

echo -e "\nDEMO --> Setup OUD Storage Instance"
${curdir}/manage_oud.sh setup --pnum 2 --suffix "${suffix}" -n oud  --nobatch --noroles 

###############################################################################
# Setup MetaDir OUD instance
###############################################################################
echo -e "\nDEMO --> Setup ShadowJoin OUD Proxy Instance"
${curdir}/manage_proxy.sh setup --pnum 1 --ktype jks --batch "${cfgdir}/shadowjoin.batch" --schema ${samples}/ad.schema
rc=$?

###############################################################################
# Load base entry to ShadowJoin instance
###############################################################################
setfmwenv
${lmod} -h ${localHost} -Z -X -p 1637 -D "${bDN}" -j "${jPW}" -a -c <<EOF
dn: ${suffix}
objectClass: top
objectClass: domain
dc: example
EOF

###############################################################################
# Test each backend
###############################################################################
echo -e "\nDEMO --> Show users in MSAD:"
${lsrch} -h ${localHost} -T -Z -X -p 1636 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub '(&(objectClass=inetOrgPerson)(cn=user*))' 

echo -e "\nDEMO --> Show users in OUD metadirectory:"
set -x
result=$(${lsrch} -h ${localHost} -T -Z -X -p 2636 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub '(&(objectClass=inetOrgPerson)(cn=user*))')
if [ -z "${result}" ]
then
   echo "There are no users in the OUD metadirectory"
else
   echo "${result}"
fi
set +x

echo -e "\nDEMO --> Show combined users through OUD proxy:"
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "${bDN}" -j "${jPW}" -b "${suffix}" -s sub '(&(objectClass=inetOrgPerson)(cn=user*))' dn

echo -e "\nDEMO --> Add user through OUD Proxy:"
${lmod} -h ${localHost} -Z -X -p 1637 -D "${bDN}" -j "${jPW}" -a -c <<EOF
dn: uid=newuser,cn=Users,${suffix}
objectClass: top
objectClass: inetOrgPerson
cn: user
sn: new
uid: newuser
userPassword: ${bPW}
EOF

echo -e "\nDEMO --> Show the new user through OUD Proxy:"
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(uid=newuser)'

echo -e "\nDEMO --> Show the new user in MSAD:"
${lsrch} -h ${localHost} -T -Z -X -p 1636 -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(uid=newuser)'

echo -e "\nDEMO --> Show the new user in OUD metadirectory:"
${lsrch} -h ${localHost} -T -Z -X -p 2636 -D "${bDN}" -j "${jPW}" -b "cn=Users,${suffix}" -s sub '(uid=newuser)'
