#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

l=-1
gMembers=( )

# If member list exists, move it to last
if [ -e "${cfgdir}/modMembers.current" ]
then
    mv ${cfgdir}/modMembers.current ${cfgdir}/modMembers.last
fi

# Read in all groups from virtual attribute
readarray -t vAttrGroups < <(${dcfg} -s -h ${localHost}  -X -p ${adminPort} -D "${bDN}" -j "${jPW}" --no-prompt get-virtual-attribute-prop --name "Password Reset Privilege" --property group-dn -E|cut -c10-|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")

virtValue=$(${dcfg} -s -h ${localHost}  -X -p ${adminPort} -D "${bDN}" -j "${jPW}" --no-prompt get-virtual-attribute-prop --name "Password Reset Privilege" --property value -E|awk '{ print $2 }')

if [ -n "${virtValue}" ]
then
   for (( m=0; m< ${#vAttrGroups[*]}; m++ ))
   do
      # Lookup members
      vAttrGroup=$(echo "${vAttrGroups[${i}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")

      # Lookup members of the group
      readarray -t nMembers < <(${lsrch} -T -h ${localHost}  -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "${vAttrGroup}" -s sub 'objectClass=top' member uniqueMember|grep -v "^dn:"|sed -e "s/^uniqueMember: //gi" -e "s/^member: //gi" -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")

      # Iterate through each member and update virtual attribute
      for (( n=0; n< ${#nMembers[*]}; n++ ))
      do
         let l++
         gMembers[${l}]="${nMembers[${n}]}"
      done
   done

   # Unique list of members:
   uniqueMembers=($(echo "${gMembers[@]}" | tr ' ' '\n' | sort -u | tr '\n' ' '))

   # Process member list
   for (( n=0; n< ${#uniqueMembers[*]}; n++ ))
   do
      gMember=$(echo "${uniqueMembers[${n}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      echo "${gMember}" >> ${cfgdir}/modMembers.current
   done

   # Purge previous modMembers.ldif
   rm -f ${cfgdir}/modMembers.ldif 2> /dev/null

   # Diff current and last list to find previous members to remove priv
   if [ -s "${cfgdir}/modMembers.last" ]
   then
      readarray -t lastMembers < <(cat ${cfgdir}/modMembers.last|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")
      rmQueue=( )
      i=-1
      for (( m=0; m< ${#uniqueMembers[*]}; m++ ))
      do
         match='false'
         for (( n=0; n< ${#lastMembers[*]}; n++ ))
         do
            if [ "${lastMembers[${n}]}" == "${uniqueMembers[${m}]}" ];then match='true';fi
         done
         if [ "${match}" == 'false' ];then let i++;rmQueue[${i}]="${uniqueMembers[${m}]}";fi
      done

      # Queue up members for which priv should be removed
      for (( n=0; n< ${#rmQueue[*]}; n++ ))
      do
         gMember=$(echo "${rmQueue[${n}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
         ck4value=$(${lsrch} -T -h ${localHost}  -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "${gMember}" -s base 'objectClass=top' ds-privilege-name|grep "^ds-privilege-name: ${virtValue}")
         if [ -n "${ck4value}" ]
         then
            cat >> ${cfgdir}/modMembers.ldif <<EOF

dn: ${gMember}
changeType: modify
delete: ds-privilege-name
ds-privilege-name: ${virtValue}
EOF
         fi
      done
   fi

   # Queue up members for which priv should be added
   for (( n=0; n< ${#uniqueMembers[*]}; n++ ))
   do
      gMember=$(echo "${uniqueMembers[${n}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      ck4value=$(${lsrch} -T -h ${localHost}  -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b "${gMember}" -s base 'objectClass=top' ds-privilege-name|grep "^ds-privilege-name: ${virtValue}")
      if [ -z "${ck4value}" ]
      then
         cat >> ${cfgdir}/modMembers.ldif <<EOF

dn: ${gMember}
changeType: modify
add: ds-privilege-name
ds-privilege-name: ${virtValue}
EOF
      fi
   done

   # Apply queued changes
   if [ -s "${cfgdir}/modMembers.ldif" ]
   then
      ${lmod} -h ${localHost}  -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -c -f "${cfgdir}/modMembers.ldif"
   fi
fi
