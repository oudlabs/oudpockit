#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Retrieve cn=monitor data for db and entry caches and report performance
# dbCache for each backend
# entryCache for each entry Cache
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            pemcert) myPemCert=$1;shift;;
            trustchain) myCaChain=$1;shift;;
            12c) fmwVersion='12c';fmwFlag="--${fmwVersion}";storeType="JKS";;
            14c) fmwVersion='14c';fmwFlag="--${fmwVersion}";storeType="PKCS12";;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            n) myTemplate=$1;shift;;
            N) numUsers=$1;shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -z "${fmwVersion}" ];then fmwVersion='14c';fi
case ${fmwVersion} in
   '14c') storeType='PKCS12'
          tstore="${certdir}/truststore.p12"
          kstore="${certdir}/${localHost}/${localHost}.p12"
          ;;
   '12c') storeType='JKS'
          tstore="${certdir}/CA/truststore"
          kstore="${certdir}/${localHost}/${localHost}.jks"
          ;;
esac


if [ -n "${myTemplate}" ];then templateName=${myTemplate};else templateName='inetorg';fi
if [ -n "${myPemCert}" ];then pemCert=${myPemCert};else pemCert="${cfgdir}/certs/${localHost}.pem";fi
if [ -n "${myCaChain}" ];then caChain=${myCaChain};else caChain="${cfgdir}/certs/intermediate/certs/ca-chain-cert.pem";fi

if [ -e "${oudmwdir}/${oudprefix}1/OUD" ]
then
   echo -e "ERROR: Must not be any OUD instances. \nUse manage_ouds.sh deinstall to remove existing OUD instances."
   exit 1
fi

###############################################################################
# Share requisite expectations"
###############################################################################
echo -e "\nDEMO --> This demonstration shows how to migrate from self-signed"
echo "         certificates to certificates singed by a certificate authority"
echo "         by re-configuring OUD to use new keystore and truststore "
echo "         that contains the new signed certificate and certificate chain"
echo "         of trust"


###############################################################################
# Generate basic data
###############################################################################
echo -e "\nDEMO --> Generate some data"
${curdir}/manage_data.sh genall -n ${templateName} -N ${numUsers}

###############################################################################
# Setup 3 Setup private CA with signed certs
###############################################################################
if [ -d "${certdir}" ]
then
   true
else
   echo -e "\nDEMO --> Setup private CA and sign cert"
   ${curdir}/manage_certs.sh gencert -h ${localHost}
fi

###############################################################################
# Setup 3 replicated OUD instances with self-signed certificates
###############################################################################
echo -e "\nDEMO --> Setup 3 replicated OUD instances"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh setup --pnum 1 -n ${templateName} --noroles --notune --ktype none
${curdir}/manage_oud.sh setup --pnum 2 -n ${templateName} --noroles --notune --ktype none --supplier $(hostname -f):1444:1989

###############################################################################
# Show current self-signed certificate subject
###############################################################################
echo -e "\nDEMO --> Show self-signed certificate Subject:"
echo      "   LDAPS Connection Handler Certificate:
echo | openssl s_client -connect ${localHost}:1636 2>&1 | openssl x509 -noout -text | egrep "Subject:"
echo      "   Administration Connection Handler Certificate:
echo | openssl s_client -connect ${localHost}:1444 2>&1 | openssl x509 -noout -text | egrep "Subject:"
echo      "   Replication Connection Handler Certificate:
echo | openssl s_client -connect ${localHost}:1989 2>&1 | openssl x509 -noout -text | egrep "Subject:"

###############################################################################
# Create new JKS and PKCS12 keystores
###############################################################################
echo -e "\nDEMO --> Create new keystore, generate CSR, sign CSR, and load CRT into keystore"
if [ "${dbg}" == 'true' ];then set -x;fi

if [ -e "${kstore}" ]
then
   true
else
   ${curdir}/manage_certs.sh gencert -h $(hostname -f)
fi

###############################################################################
# Create new JKS truststore and import CA cert chain
###############################################################################
#echo -e "\nDEMO --> If not already in keystore, import CA certificate chain into keystore"
#set -x
#${ktool} -importcert -trustcacerts -storepass "${bPW}" -keystore "${kstore}" -alias intermediate-ca -file ${caChain} -noprompt >> ${logdir}/demo-certs-${now}.log 2>&1
#rc=$?;set +x
#if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import certificate chain into JKS keystore";fi

###############################################################################
# Create new JKS truststore and import CA cert chain
###############################################################################
#echo -e "\nDEMO --> Create new JKS truststore and import CA cert chain"
#set -x
#${ktool} -importcert -trustcacerts -storepass "${bPW}" -keystore "${tstore}" -alias intermediate-ca -file  ${caChain} -noprompt >> ${logdir}/demo-certs-${now}.log 2>&1
#rc=$?;set +x
#if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Root CA cert into Intermediat CA keystore";fi

###############################################################################
# Re-configure OUD Truststores including new pin
###############################################################################
echo -e "\nDEMO --> Re-configure OUD ${storeType} Truststore including new pin of all OUD instances"
for pnum in 1 2
do
   echo      "   Update LDAPS Connection Handler truststore of oud${pnum}" | tee -a ${logdir}/demo-certs-${now}.log
   ${dcfg} -h ${localHost} -X -p ${pnum}444 -D "${bDN}" -j "${jPW}" --no-prompt set-trust-manager-provider-prop --provider-name ${storeType} --set trust-store-file:"${tstore}" --set trust-store-pin:"${bPW}" >> ${logdir}/demo-certs-${now}.log 2>&1
   rc=$?

   echo      "   Update Administration Connection Handler truststore of oud${pnum}" | tee -a ${logdir}/demo-certs-${now}.log
   ${dcfg} -h ${localHost} -X -p ${pnum}444 -D "${bDN}" -j "${jPW}" --no-prompt set-trust-manager-provider-prop --provider-name Administration --set trust-store-file:"${tstore}" --set trust-store-pin:"${bPW}" >> ${logdir}/demo-certs-${now}.log 2>&1

   rc=$?
done

###############################################################################
# Restart OUD instances in order to have new trust store in place for replication to work properly
###############################################################################
echo -e "\nDEMO --> Restart all OUD instances"
${curdir}/manage_oud.sh stop
${curdir}/manage_oud.sh start

###############################################################################
# Re-configure first OUD keystore including new pin
###############################################################################
echo -e "\nDEMO --> Re-configure OUD ${storeType} Keystores including new pin"
for pnum in 1 2
do
   echo      "   Update LDAPS Connection Handler keystore of oud${pnum}" | tee -a ${logdir}/demo-certs-${now}.log
   ${dcfg} -h ${localHost} -X -p ${pnum}444 -D "${bDN}" -j "${jPW}" --no-prompt set-key-manager-provider-prop --provider-name ${storeType} --set key-store-file:"${kstore}" --set key-store-pin:"${bPW}" >> ${logdir}/demo-certs-${now}.log 2>&1
   rc=$?

   echo      "   Administration Connection Handler keystore of oud${pnum}" | tee -a ${logdir}/demo-certs-${now}.log
   ${dcfg} -h ${localHost} -X -p ${pnum}444 -D "${bDN}" -j "${jPW}" --no-prompt set-key-manager-provider-prop --provider-name Administration --set key-store-file:"${tstore}" --set key-store-pin:"${bPW}" >> ${logdir}/demo-certs-${now}.log 2>&1
   rc=$?

   ${dcfg} -h ${localHost} -X -p ${pnum}444 -D "${bDN}" -j "${jPW}" --no-prompt set-administration-provider-prop --connector-name LDAP --set ssl-cert-nickname:server-cert  >> ${logdir}/demo-certs-${now}.log 2>&1
   rc=$?
done

echo "   Replication Connection Handler keystore" | tee -a ${logdir}/demo-certs-${now}.log
${drepl} set-cert -h ${localHost} -X -p 1444 --adminUID admin --adminPasswordFile "${jPW}" --no-prompt --replCertNickName server-cert --replKeyStoreType ${storeType} --replKeyStorePath "${kstore}" --replKeyStorePasswordFile ${jPW} >> ${logdir}/demo-certs-${now}.log 2>&1
rc=$?

###############################################################################
# Restart OUD instances to apply cert change
###############################################################################
echo -e "\nDEMO --> Restart OUD instances"
${curdir}/manage_oud.sh stop
${curdir}/manage_oud.sh start

###############################################################################
# Show updated certificate subject
###############################################################################
echo -e "\nDEMO --> Show updated certificate Subject:"
echo      "   LDAPS Connection Handler Certificate:"
echo | openssl s_client -connect ${localHost}:1636 2>&1 | openssl x509 -noout -text | egrep "Subject:"
echo      "   Administration Connection Handler Certificate:"
echo | openssl s_client -connect ${localHost}:1444 2>&1 | openssl x509 -noout -text | egrep "Subject:"
echo      "   Replication Connection Handler Certificate:"
echo | openssl s_client -connect ${localHost}:1989 2>&1 | openssl x509 -noout -text | egrep "Subject:"

###############################################################################
# Check replication
###############################################################################
echo -e "\nDEMO --> Show replication status"
${curdir}/manage_oud.sh rstatus
