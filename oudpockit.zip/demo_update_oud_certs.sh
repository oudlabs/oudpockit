#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Retrieve cn=monitor data for db and entry caches and report performance
# dbCache for each backend
# entryCache for each entry Cache
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            pemcert) myPemCert=$1;shift;;
            trustchain) myCaChain=$1;shift;;
            certdir) myCertDir=$1;shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            n) myTemplate=$1;shift;;
            N) numUsers=$1;shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -n "${myCertDir}" ];then certDir=${myCertDir};else certDir="${tmpdir}/certs";fi
mkdir -p "${certDir}" 2> /dev/null

jksTrustStore="${certDir}/truststore"
p12TrustStore="${certDir}/truststore.p12"

if [ -n "${myTemplate}" ];then templateName=${myTemplate};else templateName='inetorg';fi
if [ -n "${myPemCert}" ];then pemCert=${myPemCert};else pemCert="${cfgdir}/certs/${localHost}.pem";fi
if [ -n "${myCaChain}" ];then caChain=${myCaChain};else caChain="${cfgdir}/certs/intermediate/certs/ca-chain-cert.pem";fi

if [ -e "${oudmwdir}/${oudprefix}1/OUD" ]
then
   echo -e "ERROR: Must not be any OUD instances. \nUse manage_ouds.sh deinstall to remove existing OUD instances."
   exit 1
fi

###############################################################################
# Share requisite expectations"
###############################################################################
echo -e "\nDEMO --> This demonstration shows how to migrate from self-signed"
echo "         certificates to certificates singed by a certificate authority"

###############################################################################
# Generate basic data
###############################################################################
echo -e "\nDEMO --> Generate some data"
${curdir}/manage_data.sh genall -n ${templateName} -N ${numUsers}

###############################################################################
# Setup 3 replicated OUD instances with self-signed certificates
###############################################################################
echo -e "\nDEMO --> Setup 3 replicated OUD instances"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh setup --pnum 1 -n ${templateName} --noroles --notune --ktype none
${curdir}/manage_oud.sh setup --pnum 2 -n ${templateName} --noroles --notune --ktype none --supplier $(hostname -f):1444:1989
${curdir}/manage_oud.sh setup --pnum 3 -n ${templateName} --noroles --notune --ktype none --supplier $(hostname -f):1444:1989

###############################################################################
# Show replication status
###############################################################################
echo -e "\nDEMO --> Show replication status"
${curdir}/manage_oud.sh rstatus

###############################################################################
# Create new JKS and PKCS12 keystores
###############################################################################
echo -e "\nDEMO --> Create new keystore, generate CSR, sign CSR, and load CRT into keystore"
if [ "${dbg}" == 'true' ];then set -x;fi
if [ -e "${cfgdir}/certs/${localHost}/${localHost}.jks" ]
then
   true
else
   ${curdir}/manage_certs.sh gencert -h $(hostname -f)
fi
cp ${cfgdir}/certs/${localHost}/${localHost}.jks ${certDir}/keystore
rc=$?;set +x

echo -e "\nDEMO --> If not already in keystore, import CA certificate chain into keystore"
set -x
${ktool} -importcert -trustcacerts -storepass "${bPW}" -keystore "${certDir}/keystore" -alias intermediate-ca -file ${caChain} -noprompt >> ${logdir}/demo-certs-${now}.log 2>&1
rc=$?;set +x
if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import certificate chain into JKS keystore";fi

#echo -e "\nDEMO --> Create new PKCS12 keystore and import CA digned cert"
#set -x
#${ktool} -importkeystore -srckeystore ${certDir}/keystore.p12 -destkeystore ${certDir}/${localHost}.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass "${bPW}" -deststorepass "${bPW}" -srcalias server-cert -destalias server-cert >> ${logdir}/demo-certs-${now}.log 2>&1 <<EOF
#yes
#EOF
#rc=$?;set +x
#if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to export JKS keystore to PKCS12 keystore";fi

#echo -e "\nDEMO --> Import CA certificate chain into JKS keystore"
#set -x
#${ktool} -importcert -trustcacerts -storepass "${bPW}" -keystore "${certDir}/${localHost}.p12" -alias root-ca-cert -file ${caChain} -srcstoretype JKS -deststoretype PKCS12 -noprompt >> ${logdir}/demo-certs-${now}.log 2>&1
#rc=$?;set +x
#if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import certificate chain into PKCS12 keystore";fi

###############################################################################
# Create new JKS truststore and import CA cert chain
###############################################################################
echo -e "\nDEMO --> Create new JKS truststore and import CA cert chain"
set -x
${ktool} -importcert -trustcacerts -storepass "${bPW}" -keystore "${jksTrustStore}" -alias intermediate-ca -file  ${caChain} -noprompt >> ${logdir}/demo-certs-${now}.log 2>&1
rc=$?;set +x
if [ $rc -ne 0 ];then msg="$msg\n   Error: Failed to import Root CA cert into Intermediat CA keystore";fi

###############################################################################
# Re-configure OUD Truststores including new pin
###############################################################################
echo -e "\nDEMO --> Re-configure OUD Truststore including new pin of all OUD instances"
for pnum in 1 2 3
do
set -x
   ${dcfg} -h ${localHost} -X -p ${pnum}444 -D "${bDN}" -j "${jPW}" --no-prompt set-trust-manager-provider-prop --provider-name JKS --set trust-store-file:"${jksTrustStore}" --set trust-store-pin:"${bPW}"
   rc=$?;set +x
done

###############################################################################
# Restart OUD instances in order to have new trust store in place for replication to work properly
###############################################################################
echo -e "\nDEMO --> Restart all OUD instances"
${curdir}/manage_oud.sh stop
${curdir}/manage_oud.sh start

###############################################################################
# Re-configure first OUD keystore including new pin
###############################################################################
echo -e "\nDEMO --> Re-configure OUD Keystores including new pin"
set -x
${dcfg} -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --no-prompt set-key-manager-provider-prop --provider-name JKS --set key-store-file:"${certDir}/keystore" --set key-store-pin:"${bPW}"
rc=$?;set +x

###############################################################################
# Restart OUD instances to apply cert change
###############################################################################
echo -e "\nDEMO --> Restart OUD instances"
${curdir}/manage_oud.sh stop --pnum 1
${curdir}/manage_oud.sh start --pnum 1

###############################################################################
# Check replication
###############################################################################
echo -e "\nDEMO --> Show replication status"
${curdir}/manage_oud.sh rstatus
