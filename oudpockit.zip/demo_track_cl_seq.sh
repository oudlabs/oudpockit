#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

# The purpose of this demo is to watch the sequence of change
# numbers over time
setfmwenv
clnFile="${cfgdir}/.clt"
while true
do
   printf "%-15s%-15s%-20s\n" "Line" "ChangeNum" "TimeOfChange"
   ${lsrch} -T -h ${localHost} -Z -X -p ${ldapsPort} -D "${bDN}" -j "${jPW}" -b cn=changelog -s sub changenumber=* changenumber changeTime|egrep -i "^changenumber:|^changeTime"|tr -d '[\n\r]'|sed -e "s/changenumber: /\n/g" -e "s/changeTime: / /g" |grep -v "^$" > ${clnFile}
   fn=$(head -1 ${clnFile} |awk '{ print $1 }')
   let fn--
   cat -n ${clnFile} | awk -v fn=${fn} '{ printf("%-15s%-15s%-20s\n",  $1+fn, $2, $3) }'|tail -5
   sleep 10
done
