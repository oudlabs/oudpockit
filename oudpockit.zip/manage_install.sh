#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
product=$2
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd}

SYNOPSIS
     ${cmd} [ install | deinstall ] [Optional: oud|oudsm|oid|jdk|perf|tns|eus]  [ options ]

DESCRIPTION
     Sample script to install OUD

OPTIONS
     The following options are supported:

         --jh <dir>              JAVA_HOME directory if not already specified in env

         --bitsdir <dir>         Directory containing the unextracted software bits

         --swdir <dir>           Directory of the extracted software

         --nosudo                Don't use sudo
EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            jh) export JAVA_HOME="$1";PATH="$JAVA_HOME:$PATH";shift;;
            swdir) swdir="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            nosudo) sudoFlag=' --nosudo';;
            step) mySteps="$1";steps=${mySteps};shift;;
            12c) fmwVersion='12c';fmwFlag="--${fmwVersion}";;
            14c) fmwVersion='14c';fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done
export fmwVersion fmwFlag
setfmwenv

if [ -n "${mySteps}" ]; then steps=${mySteps};else steps=0;fi


###############################################################################
# Create requisite response files
###############################################################################
if [ -d "${cfgdir}" ];then true;else mkdir -p "${cfgdir}" > /dev/null 2>&1;fi

if [ -e "${cfgdir}/oraInventory.loc" ]
then
   true
else
   mkdir -p "${cfgdir}" 2> /dev/null
   cat > ${cfgdir}/oraInventory.loc <<EOF
inventory_loc=${cfgdir}/oraInventory
inst_group=${me}
EOF
fi

if [ -e "${cfgdir}/oudsm-fmw${fmwVersion}.rsp" ]
then
   true
else
   cat > ${cfgdir}/oudsm-fmw${fmwVersion}.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudsmmwdir}
INSTALL_TYPE=Fusion Middleware Infrastructure
EOF
fi

if [ -e "${cfgdir}/dip-fmw${fmwVersion}.rsp" ]
then
   true
else
   cat > ${cfgdir}/dip-fmw${fmwVersion}.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${dipmwdir}
INSTALL_TYPE=Fusion Middleware Infrastructure
EOF
fi

if [ -e "${cfgdir}/oud-fmw${fmwVersion}.rsp" ]
then
   true
else
   cat > ${cfgdir}/oud-fmw${fmwVersion}.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudmwdir}
INSTALL_TYPE=Fusion Middleware Infrastructure
EOF
fi

if [ -e "${cfgdir}/oud${fmwVersion}-standalone.rsp" ]
then
   true
else
   cat > ${cfgdir}/oud${fmwVersion}-standalone.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudmwdir}
INSTALL_TYPE=Standalone Oracle Unified Directory Server (Managed independently of WebLogic server)
EOF
fi
if [ -e "${cfgdir}/oudsm${fmwVersion}-standalone.rsp" ]
then
   true
else
   cat > ${cfgdir}/oudsm${fmwVersion}-standalone.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudmwdir}
INSTALL_TYPE=Standalone Oracle Unified Directory Server (Managed independently of WebLogic server)
EOF
fi

if [ -e "${cfgdir}/oudsm${fmwVersion}-shared.rsp" ]
then
   true
else
   cat > ${cfgdir}/oudsm${fmwVersion}-shared.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudsmmwdir}
INSTALL_TYPE=Collocated Oracle Unified Directory Server (Managed through WebLogic server)
EOF

fi

if [ -e "${cfgdir}/dip${fmwVersion}-shared.rsp" ]
then
   true
else
   cat > ${cfgdir}/dip${fmwVersion}-shared.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${dipmwdir}
INSTALL_TYPE=Collocated Oracle Unified Directory Server (Managed through WebLogic server)
EOF
fi

if [ -e "${cfgdir}/oid-fmw${fmwVersion}.rsp" ]
then
   true
else
   cat > ${cfgdir}/oid-fmw${fmwVersion}.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oidmwdir}
FEDERATED_ORACLE_HOMES=
INSTALL_TYPE=Fusion Middleware Infrastructure
EOF
fi

if [ -e "${cfgdir}/oid${fmwVersion}-shared.rsp" ]
then
   true
else
   cat > ${cfgdir}/oid${fmwVersion}-shared.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oidmwdir}
FEDERATED_ORACLE_HOMES=
INSTALL_TYPE=Collocated Oracle Internet Directory Server (Managed through WebLogic server)
JDK_HOME=${JAVA_HOME}
EOF
fi

if [ -e "${cfgdir}/rcu${fmwVersion}.rsp" ]
then
   true
else
   cat > ${cfgdir}/rcu${fmwVersion}.rsp <<EOF
operation=createRepository
connectString=${localHost}:${dbPort}:PDB1.${domain}
databaseType=ORACLE
dbUser=sys
schemaPrefix=PROD
componentList=STB,OPSS,OID,IAU,IAU_APPEND,IAU_VIEWER,WLS
useSamePasswordForAllSchemaUsers=true
EOF
fi

###############################################################################
# Extract bits
###############################################################################
extract_bits() {
   setfmwenv
   # JDK
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -n "${JAVA_HOME}" ] && [ -e "${JAVA_HOME}/bin/java" ]
   then
      true
   else
      if [ "${fmwVersion}" == '12c' ] || [ "${fmwVersion}" == '12cPS4' ] || [ "${fmwVersion}" == '12cPS3' ]
      then
         jdkgz=$(ls -1 ${bitsdir}/jdk-8*gz 2> /dev/null|grep "${osn}"|tail -1)
         jdktar=$(ls -1 ${bitsdir}/jdk-8*.tar 2> /dev/null|grep "${osn}"|tail -1)
      elif [ "${fmwVersion}" == '14c' ]
      then
         jdkgz=$(ls -1 ${bitsdir}/jdk-21*gz ${bitsdir}/jdk-17*gz 2> /dev/null|grep "${osn}"|tail -1)
         jdktar=$(ls -1 ${bitsdir}/jdk-21*.tar ${bitsdir}/jdk-17*.tar 2> /dev/null|grep "${osn}"|tail -1)
      fi
      if [ -n "${jdkgz}" ] || [ -n "${jdktar}" ]
      then
         let steps++
         echo "Step: ${steps} - Extract JDK software" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         cd "${swdir}"
         rc=$?
         if [ -n "${jdkgz}" ] 
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            tar -zxf ${jdkgz}
            rc=$?;set +x
         elif  [ -n "${jdktar}" ]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            tar -xf ${jdktar}
            rc=$?;set +x
         fi
         set +x
      else
         echo "Error: No JDK tar.gz file"
         exit 1
      fi
   fi

   if [ "${product}" == 'jdk' ];then echo ${steps} > ${cfgdir}/.steps.extracted;exit;fi

   # Find and extract patches
   readarray -t generalPatches < <(ls -1d ${bitsdir}/p*.zip 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")

   if [ "${dbg}" == 'true' ];then set -x;fi
   for (( x=0; x< ${#generalPatches[*]}; x++ ))
   do
      patch=$(echo "${generalPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${generalPatches[${x}]}")
      if [ -e "${swdir}/.${patchname}.extracted" ]
      then
         true
      else
         let steps++
         echo "Step: ${steps} - Extract patch ${patchname}" | tee -a ${logdir}/patch-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         cd "${swdir}"
         unzip -ou ${patch} >> ${logdir}/patch-${now}.log 2>&1
         set +x
         touch ${swdir}/.${patchname}.extracted
      fi
   done
   if [ "${dbg}" == 'true' ];then set -x;fi
   readarray -t oudPatches < <(ls -1 ${swdir}/*/binary_patches/oud/generic/p*.zip 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")
   for (( x=0; x< ${#oudPatches[*]}; x++ ))
   do
      patch=$(echo "${oudPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${oudPatches[${x}]}")
      if [ -e "${swdir}/.${patchname}.extracted" ]
      then
         true
      else
         let steps++
         echo "Step: ${steps} - Extract OUD patch ${patchname}" | tee -a ${logdir}/patch-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         cd "${swdir}"
         unzip -ou ${patch} >> ${logdir}/patch-${now}.log 2>&1
         set +x
         touch ${swdir}/.${patchname}.extracted
      fi
   done

   # FMW Infrastructure 14c
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'oudsm' ] || [ "${product}" == 'fmw' ] 
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${swdir}/fmw_14.1.2.0.0_infrastructure.jar" ]
      then
         true
      else
         if [ -e "${bitsdir}/fmw_14.1.2.0.0_infrastructure.jar" ]
         then
            cp ${bitsdir}/fmw_14.1.2.0.0_infrastructure.jar ${swdir} 2> /dev/null
         fi

         if [ -e "${bitsdir}/V1045135-01.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract Fusion Middleware (FMW) Infrastructure 14c software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/V1045135-01.zip
            rc=$?
            set +x
         elif [ -e "${swdir}/fmw_14.1.2.0.0_infrastructure.jar" ]
         then
            true
         else
            fmw14err="Error: Cannot find FMW Infrastructure 14c file (V1045135-01.zip)\n"
         fi
      fi
   fi

   # OUD 14c (14.1.2.1.0)
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'oud' ] || [ "${product}" == 'oudsm' ] || [ "${product}" == 'eus' ] || [ "${product}" == 'tns' ] 
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${swdir}/fmw_14.1.2.1.0_oud.jar" ]
      then
         true
      else
         if [ -e "${bitsdir}/fmw_14.1.2.1.0_oud.jar" ]
         then
            cp ${bitsdir}/fmw_14.1.2.1.0_oud.jar ${swdir} 2> /dev/null
         fi

         if [ -e "${bitsdir}/V1048467-01.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract OUD 14c software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/V1048467-01.zip
            rc=$?
            set +x
         elif [ -e "${swdir}/fmw_14.1.2.1.0_oud.jar" ]
         then
            true
         else
            oud14err="Error: Cannot find OUD 14c file (V1048467-01.zip)\n"
         fi
      fi
   fi

   # OUD 14c (14.1.2.0.0)
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'oud' ] || [ "${product}" == 'oudsm' ] || [ "${product}" == 'eus' ] || [ "${product}" == 'tns' ] 
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${swdir}/fmw_14.1.2.1.0_oud.jar" ]
      then
         true
      else
         if [ -e "${bitsdir}/fmw_14.1.2.1.0_oud.jar" ]
         then
            cp ${bitsdir}/fmw_14.1.2.1.0_oud.jar ${swdir} 2> /dev/null
         fi

         if [ -e "${bitsdir}/V1048203-01.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract OUD 14c software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/V1048203-01.zip
            rc=$?
            set +x
         elif [ -e "${swdir}/fmw_14.1.2.1.0_oud.jar" ]
         then
            true
         else
            oud14err="Error: Cannot find OUD 14c file (V1048203-01.zip)\n"
         fi
      fi
   fi

   # FMW Infrastructure 12cPS4
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'oudsm' ] || [ "${product}" == 'fmw' ] || [ "${product}" == 'oid' ] || [ "${product}" == 'dip' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${swdir}/fmw_12.2.1.4.0_infrastructure.jar" ]
      then
         true
      else
         if [ -e "${bitsdir}/fmw_12.2.1.4.0_infrastructure_Disk1_1of1.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract Fusion Middleware (FMW) Infrastructure software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/fmw_12.2.1.4.0_infrastructure_Disk1_1of1.zip
            rc=$?
            set +x
         elif [ -e "${bitsdir}/V983368-01.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract Fusion Middleware (FMW) Infrastructure software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/V983368-01.zip
            rc=$?
            set +x
         else
            fmw12214err="Error: Cannot find FMW Infrastructure 12cPS4 file (V983368-01.zip)\n"
         fi
      fi
   fi

   # OUD 12cPS4
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'oud' ] || [ "${product}" == 'oudsm' ] || [ "${product}" == 'eus' ] || [ "${product}" == 'tns' ] || [ "${product}" == 'dip' ]
   then
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -e "${swdir}/fmw_12.2.1.4.0_oud.jar" ]
   then
      true
   else
      if [ -e "${bitsdir}/fmw_12.2.1.4.0_oud_Disk1_1of1.zip" ]
      then
         let steps++
         echo "Step: ${steps} - Extract Oracle Unified Directory (OUD) software" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         cd "${swdir}"
         unzip -qo ${bitsdir}/fmw_12.2.1.4.0_oud_Disk1_1of1.zip
         rc=$?
         set +x
      elif [ -e "${bitsdir}/V983402-01.zip" ]
      then
         let steps++
         echo "Step: ${steps} - Extract Oracle Unified Directory (OUD) software" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         cd "${swdir}"
         unzip -qo ${bitsdir}/V983402-01.zip
         rc=$?
         set +x
      else
         oud12214err="Error: Cannot find OUD 12cPS4 file (V983368-01.zip)\n"
      fi
   fi
   fi

   # DB 23.5
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'eus' ] || [ "${product}" == 'tns' ] || [ "${product}" == 'db' ] || [ "${product}" == 'oid' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${bitsdir}/V1043785-01.zip" ] && [ -e "${swdir}/db/23.5/bin/dbca" ]
      then
         true
      elif [ -e "${bitsdir}/V1043785-01.zip" ]
      then
         let steps++
         echo "Step: ${steps} - Extract ODB 23.5 software" | tee -a  ${logdir}/sw-extract-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         mkdir -p "${swdir}/db" 2> /dev/null
         unzip -d "${swdir}/db/19.3" -qo ${bitsdir}/V982063-01.zip
         rc=$?
         set +x
      fi
   fi

   # DB 19.3
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'eus' ] || [ "${product}" == 'tns' ] || [ "${product}" == 'db' ] || [ "${product}" == 'oid' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${bitsdir}/V982063-01.zip" ] && [ -e "${swdir}/db/19.3/bin/dbca" ]
      then
         true
      elif [ -e "${bitsdir}/V982063-01.zip" ]
      then
         let steps++
         echo "Step: ${steps} - Extract ODB 19.3 software" | tee -a  ${logdir}/sw-extract-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         mkdir -p "${swdir}/db" 2> /dev/null
         unzip -d "${swdir}/db/19.3" -qo ${bitsdir}/V982063-01.zip
         rc=$?
         set +x
      fi
   fi

   # OID 12cPS4
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'oid' ] || [ "${product}" == 'oidsm' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${swdir}/fmw_12.2.1.4.0_oid_linux64.bin" ]
      then
         true
      else
         if [ -e "${bitsdir}/fmw_12.2.1.4.0_oid_Disk1_1of1.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract Oracle Inerenet Directory (OID) software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/fmw_12.2.1.4.0_oid_Disk1_1of1.zip
            rc=$?
            set +x
         elif [ -e "${bitsdir}/V983403-01.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract Oracle Internet Directory (OID) software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/V983403-01.zip
            rc=$?
            set +x
         else
            oid12214err="Error: Cannot find OID 12cPS4 file (V983403-01.zip)\n"
         fi
      fi
   fi

   # FMW Infrastructure 12cPS3
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'oudsm' ] || [ "${product}" == 'fmw' ] 
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${swdir}/fmw_12.2.1.3.0_infrastructure.jar" ]
      then
         true
      else
         if [ -e "${bitsdir}/V886426-01.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract Fusion Middleware (FMW) Infrastructure 12cPS3 software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/V886426-01.zip
            rc=$?
            set +x
         else
            fmw12213err="Error: Cannot find FMW Infrastructure 12cPS3 file (V886426-01.zip)\n"
         fi
      fi
   fi

   # OUD 12cPS3
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'oud' ] || [ "${product}" == 'oudsm' ] || [ "${product}" == 'eus' ] || [ "${product}" == 'tns' ] 
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${swdir}/fmw_12.2.1.3.0_oud.jar" ]
      then
         true
      else
         if [ -e "${bitsdir}/V886447-01.zip" ]
         then
            let steps++
            echo "Step: ${steps} - Extract OUD 12cPS3 software" | tee -a  ${logdir}/sw-install-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            cd "${swdir}"
            unzip -qo ${bitsdir}/V886447-01.zip
            rc=$?
            set +x
         else
            oud12213err="Error: Cannot find OUD 12cPS3 file (V886447-01.zip)\n"
         fi
      fi
   fi

   # EM 13u5
   if [ -z "${product}" ] || [ "${product}" == 'all' ] || [ "${product}" == 'em' ] || [ "${product}" == 'oem' ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${bitsdir}/V1007079-01.zip" ] && [ -e "${swdir}/em/em13500_linux64.bin" ]
      then
         true
      elif [ -e "${bitsdir}/V1007079-01.zip" ]
      then
         let steps++
         echo "Step: ${steps} - Extract Enterprise Mangaer 13u5 software" | tee -a  ${logdir}/sw-extract-${now}.log

         if [ "${dbg}" == 'true' ];then set -x;fi
         if [ -e "${bitsdir}/V1007079-01.zip" ]
         then
            mkdir -p "${swdir}/em" 2> /dev/null
            unzip -d "${swdir}/em" -qo ${bitsdir}/V1007079-01.zip
            rc=$?
         fi
         if [ -e "${bitsdir}/V1007080-01.zip" ]
         then
            mkdir -p "${swdir}/em" 2> /dev/null
            unzip -d "${swdir}/em" -qo ${bitsdir}/V1007080-01.zip
            rc=$?
         fi
         if [ -e "${bitsdir}/V1007081-01.zip" ]
         then
            mkdir -p "${swdir}/em" 2> /dev/null
            unzip -d "${swdir}/em" -qo ${bitsdir}/V1007081-01.zip
            rc=$?
         fi
         if [ -e "${bitsdir}/V1007082-01.zip" ]
         then
            mkdir -p "${swdir}/em" 2> /dev/null
            unzip -d "${swdir}/em" -qo ${bitsdir}/V1007082-01.zip
            rc=$?
         fi
         if [ -e "${bitsdir}/V1007083-01.zip" ]
         then
            mkdir -p "${swdir}/em" 2> /dev/null
            unzip -d "${swdir}/em" -qo ${bitsdir}/V1007083-01.zip
            rc=$?
         fi
         set +x
      fi
   fi

   # Error out if any requisite software is missing
   if [ -z "${fmw14err}" ];then fmwbits='good';fi
   if [ -z "${oud14err}" ];then oudbits='good';fi

   if [ -z "${fmw12214err}" ];then fmwbits='good';fi
   if [ -z "${oud12214err}" ];then oudbits='good';fi

   if [ -z "${oid12214err}" ];then oidbits='good';fi
   echo ${steps} > ${cfgdir}/.steps.extracted
}

###############################################################################
# Check OUD bits
###############################################################################
check_oud_bits() {
   extract_bits oud
   setfmwenv

   # Set JAVA_HOME if not set
   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   PATH=${JAVA_HOME}/bin:$PATH

   case "${fmwVersion}" in
      '14c') fmwo="${swdir}/fmw_14.1.2.1.0_oud.jar";;
      '12c'|'12cPS4') fmwo="${swdir}/fmw_12.2.1.4.0_oud.jar";;
      '12cPS3') fmwo="${swdir}/fmw_12.2.1.3.0_oud.jar";;
   esac

   fmwo_file=$(basename ${fmwo})

   if [ -e "${swdir}/${fmwo_file}" ]
   then
      true
   elif [ -e "${curdir}/${fmwo_file}" ]
   then
      mv "${curdir}/${fmwo}" "${swdir}/${fmwo}"
   else
      echo "FMW OUD installer (${fmwo}) not present"
      exit 1
   fi
}

###############################################################################
# Check for FMW bits
###############################################################################
check_fmw_bits() {
   extract_bits fmw
   setfmwenv
   if [ -e "${cfgdir}/.steps.extracted" ];then steps=$(cat ${cfgdir}/.steps.extracted);fi

   # Set JAVA_HOME if not set
   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   PATH=${JAVA_HOME}/bin:$PATH

   fmwi="${swdir}/fmw_14.1.2.0.0_infrastructure.jar"
   if [ -e "${fmwi}" ];then true; else fmwi="${swdir}/fmw_12.2.1.4.0_infrastructure.jar";fi
   if [ -e "${fmwi}" ];then true; else fmwi="${swdir}/fmw_12.2.1.3.0_infrastructure.jar";fi

   case "${fmwVersion}" in
      '14c') fmwo="${swdir}/fmw_14.1.2.0.0_infrastructure.jar";;
      '12c'|'12cPS4') fmwo="${swdir}/fmw_12.2.1.4.0_infrastructure.jar";;
      '12cPS3') fmwo="${swdir}/fmw_12.2.1.3.0_infrastructure.jar";;
   esac

   fmwi_file=$(basename ${fmwi})

   if [ -e "${swdir}/${fmwi_file}" ]
   then
      true
   elif [ -e "${curdir}/${fmwi_file}" ]
   then
      mv "${curdir}/${fmwi}" "${swdir}/${fmwi}"
   else
      echo "FMW Infrastructure installer (${fmwi}) not present"
      exit 1
   fi
}

###############################################################################
# Install OUD
###############################################################################
install_oud() {
   check_oud_bits
   if [ -e "${cfgdir}/.steps.extracted" ];then steps=$(cat ${cfgdir}/.steps.extracted);fi

   if [ "${product}" == 'oud' ] || [ "${product}" == 'oudsm' ]
   then
      if [ -e  "${oudmwdir}/oud" ]
      then
         true
      elif [ -n  "${fmwo}" ]
      then
         #instSwap
         if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
         let steps++
         echo "Step: ${steps} - Install Oracle Unified Directory (OUD) ${fmwVersion}" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${JAVA_HOME}/bin/java \
            -Djava.io.tmpdir="${tmpdir}" \
            -jar "${fmwo}" \
            -silent \
            -ignoreSysPrereqs \
            -responseFile ${cfgdir}/oud${fmwVersion}-standalone.rsp \
            -invPtrLoc ${cfgdir}/oraInventory.loc \
            >> ${logdir}/sw-install-${now}.log 2>&1
         rc=$?
         set +x
         if [ ${rc} -ne 0 ];then echo -e "ERROR: OUD install failed. Review log:\n${logdir}/sw-install-${now}.log";exit 1;fi
      fi
   fi

   # Deinstall configuration file
   rm -f "${cfgdir}/oud${fmwVersion}-standalone.rsp" 2> /dev/null

   patch_oud

   #remediate_log4j

   echo ${steps} > ${cfgdir}/.steps.install.oud
}

###############################################################################
# Install Fusion Middleware Infrastructure
###############################################################################
install_fmw() {
   check_fmw_bits

   if [ "${product}" == 'fmw' ] || [ "${product}" == 'oudsm' ]
   then
      if [ -e  "${oudsmmwdir}/oracle_common/bin/rcu" ]
      then
         true
      elif [ -n  "${fmwi}" ]
      then
         #instSwap
         if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
         let steps++
         echo "Step: ${steps} - Install Fusion Middleware (FMW) Infrastructure ${fmwVersion}" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${JAVA_HOME}/bin/java \
            -Djava.io.tmpdir="${tmpdir}" \
            -jar "${fmwi}" \
            -silent \
            -ignoreSysPrereqs \
            -responseFile ${cfgdir}/oudsm-fmw${fmwVersion}.rsp \
            -invPtrLoc ${cfgdir}/oraInventory.loc \
            >> ${logdir}/sw-install-${now}.log 2>&1
         rc=$?
         set +x
         if [ ${rc} -ne 0 ];then echo -e "ERROR: FMW install failed. Review log:\n${logdir}/sw-install-${now}.log";exit 1;fi
         echo ${steps} > ${cfgdir}/.steps.install.fmw.oudsm
      fi
   fi


   # Deinstall configuration file
   rm -f "${cfgdir}/oudsm-fmw${fmwVersion}.rsp" 2> /dev/null

}

###############################################################################
# Install OUDSM
###############################################################################
install_oudsm() {
   install_fmw
   check_oud_bits

   if [ "${product}" == 'fmw' ] || [ "${product}" == 'oudsm' ]
   then
      if [ -e  "${oudsmmwdir}/oud" ]
      then
         true
      elif [ -n  "${fmwo}" ]
      then
         #instSwap
         if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
         let steps++
         echo "Step: ${steps} - Install Oracle Unified Directory (OUD) ${fmwVersion}" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${JAVA_HOME}/bin/java \
            -Djava.io.tmpdir="${tmpdir}" \
            -jar "${fmwo}" \
            -silent \
            -ignoreSysPrereqs \
            -responseFile ${cfgdir}/oudsm${fmwVersion}-shared.rsp \
            -invPtrLoc ${cfgdir}/oraInventory.loc \
            >> ${logdir}/sw-install-${now}.log 2>&1
         rc=$?
         set +x
         if [ ${rc} -ne 0 ];then echo -e "ERROR: OUD install failed. Review log:\n${logdir}/sw-install-${now}.log";exit 1;fi
         echo ${steps} > ${cfgdir}/.steps.install.oudsm
      fi
   fi

   rm -f "${cfgdir}/oudsm${fmwVersion}-shared.rsp" 2> /dev/null

   patch_oudsm

   #remediate_log4j
}

###############################################################################
# Install DIP
###############################################################################
install_dip() {
   check_oud_bits
   check_fmw_bits

   if [ "${product}" == 'dip' ]
   then
      if [ -e  "${dipmwdir}/oracle_common/bin/rcu" ]
      then
         true
      elif [ -n  "${fmwi}" ]
      then
         #instSwap
         if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
         let steps++
         echo "Step: ${steps} - Install Fusion Middleware (FMW) Infrastructure ${fmwVersion}" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${JAVA_HOME}/bin/java \
            -Djava.io.tmpdir="${tmpdir}" \
            -jar "${fmwi}" \
            -silent \
            -ignoreSysPrereqs \
            -responseFile ${cfgdir}/dip-fmw${fmwVersion}.rsp \
            -invPtrLoc ${cfgdir}/oraInventory.loc \
            >> ${logdir}/sw-install-${now}.log 2>&1
         rc=$?
         set +x
         if [ ${rc} -ne 0 ];then echo -e "ERROR: FMW install failed. Review log:\n${logdir}/sw-install-${now}.log";exit 1;fi
         echo ${steps} > ${cfgdir}/.steps.install.fmw.dip
      fi

      if [ -e  "${dipmwdir}/oud" ]
      then
         true
      elif [ -n  "${fmwo}" ]
      then
         #instSwap
         if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
         let steps++
         echo "Step: ${steps} - Install Oracle Unified Directory (OUD) ${fmwVersion}" | tee -a  ${logdir}/sw-install-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${JAVA_HOME}/bin/java \
            -Djava.io.tmpdir="${tmpdir}" \
            -jar "${fmwo}" \
            -silent \
            -ignoreSysPrereqs \
            -responseFile ${cfgdir}/dip${fmwVersion}-shared.rsp \
            -invPtrLoc ${cfgdir}/oraInventory.loc \
            >> ${logdir}/sw-install-${now}.log 2>&1
         rc=$?
         set +x
         if [ ${rc} -ne 0 ];then echo -e "ERROR: OUD install failed. Review log:\n${logdir}/sw-install-${now}.log";exit 1;fi
         echo ${steps} > ${cfgdir}/.steps.install.dip
      fi
   fi

   # Deinstall configuration file
   rm -f "${cfgdir}/dip${fmwVersion}-shared.rsp" "${cfgdir}/dip-fmw${fmwVersion}.rsp" 2> /dev/null

   patch_dip

   #remediate_log4j
}

###############################################################################
# Deinstall Oracle Database
###############################################################################
deinstall_db() {
   ${curdir}/manage_db.sh deinstall
}

###############################################################################
# Deinstall OUD Replication Gateway (replgw)
###############################################################################
deinstall_replgw() {
   ${curdir}/manage_replgw.sh deinstall
}

###############################################################################
# Deinstall Oracle Directory Server Enterprise Edition (ODSEE)
###############################################################################
deinstall_odsee() {
   if [ -e "${curdir}/dsee7/bin/dsadm" ]
   then
      ${curdir}/manage_odsee.sh deinstall

      let steps++
      echo "Step: ${steps} - Deinstall ODSEE" | tee -a  ${logdir}/sw-install-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      rm -fr "${curdir}/dsee7"
      rc=$?;set +x
   fi 
}

###############################################################################
# Deinstall Oracle Inveontory
###############################################################################
deinstall_inventory() {
   if [ -d "${cfgdir}/oraInventory" ]
   then
      let steps++
      echo "Step: ${steps} - Deinstall Oracle Inventory" | tee -a  ${logdir}/sw-install-${now}.log
      rm -fr "${cfgdir}/oraInventory"
      rm -f "${cfgdir}/oraInventory.loc" 2> /dev/null
   fi 
}

###############################################################################
# Deinstall SLAMD
###############################################################################
deinstall_slamd() {
   ${curdir}/manage_slamd.sh deinstall
}

###############################################################################
# Deinstall OUD
###############################################################################
deinstall_oud() {
   if [ -d "${oudmwdir}" ]
   then
      # Stop and deinstall OUD proxy instances
      cd "${oudmwdir}"
      nodes=$(ls -1d proxy[1-9]* 2> /dev/null|sed -e "s/proxy//g")
      for node in ${nodes}
      do
         ${curdir}/manage_proxy.sh deinstall --pnum ${node} --step ${steps} ${dbgFlag}
         steps=$(cat ${cfgdir}/.steps.deinstall.proxy)
      done

      # Stop and deinstall OUD storage instances
      nodes=$(ls -1d oud[1-9]* 2> /dev/null|sed -e "s/oud//g")
      for node in ${nodes}
      do
         ${curdir}/manage_oud.sh deinstall --pnum ${node} --step ${steps} ${dbgFlag}
         steps=$(cat ${cfgdir}/.steps.deinstall.oud)
      done

      # Remove the OUD software
      let steps++
      echo "Step: ${steps} - Deinstall OUD software" | tee -a  ${logdir}/sw-deinstall-${now}.log
      cd "${curdir}"
      if [ -d "${oudmwdir}" ];then  rm -fr "${oudmwdir}" "${oudsmmwdir}";fi 
   fi

   # Deinstall configuration
   rm -f "${cfgdir}/oraInventory.loc" "${cfgdir}/oud-fmw${fmwVersion}.rsp" "${cfgdir}/oud${fmwVersion}-standalone.rsp" 2> /dev/null

   echo ${steps} > ${cfgdir}/.steps.deinstall
}

###############################################################################
# Deinstall OUDSM
###############################################################################
deinstall_oudsm() {
   if [ -d "${oudsmmwdir}" ]
   then
      # Stop and deinstall the OUDSM
      rm -f ${cfgdir}/.steps.oudsm 2> /dev/null
      ${curdir}/manage_oudsm.sh deinstall --step ${steps} ${dbgFlag}
      if [ -e "${cfgdir}/.steps.oudsm" ];then steps=$(cat ${cfgdir}/.steps.oudsm);fi

      # Remove the OUDSM software
      let steps++
      echo "Step: ${steps} - Deinstall OUDSM software" | tee -a  ${logdir}/sw-deinstall-${now}.log
      if [ -d "${oudsmmwdir}" ];then  rm -fr "${oudsmmwdir}";fi 
   fi

   # Deinstall configuration
   rm -f "${cfgdir}/oudsm-fmw${fmwVersion}.rsp" "${cfgdir}/oudsm${fmwVersion}-shared.rsp" 2> /dev/null

   echo ${steps} > ${cfgdir}/.steps.deinstall
}

###############################################################################
# Patch OUD
###############################################################################
patch_oud() {
   # Extract patches found in bitsdir
   extract_bits oud
   if [ -e "${cfgdir}/.steps.extracted" ];then steps=$(cat ${cfgdir}/.steps.extracted);fi

   # Make sure fuser is installed
   ck4fuser=$(which fuser 2> /dev/null)
   if [ -z "${ck4fuser}" ]
   then
      echo "ERROR: Patch requires fuser command.  Please install requisite package"
      echo " Linux: sudo yum install -y psmisc"
      exit 1
   fi

   ############################################################################
   # Patch OUD middleware home
   ############################################################################
   if [ "${product}" == 'oud' ]
   then
   patchOud='false'
   p=0
   p=q

   # Add in OPatch patches
   readarray -t tmpPatches < <(ls -1d ${swdir}/*/opatch_generic.jar 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/\/opatch_generic.jar//g")
   for (( x=0; x< ${#tmpPatches[*]}; x++ ))
   do
      patch=$(echo "${tmpPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${tmpPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -e "${oudmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let q++
         opatchPatches[${q}]="${patchname}"
      fi
   done

   # Determine which patches have not already been applied
   # Handle FMW bundle patches
   readarray -t oudPatches < <(ls -1 ${swdir}/*/binary_patches/oud/generic/p*.zip 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")
   for (( x=0; x< ${#oudPatches[*]}; x++ ))
   do
      patch=$(echo "${oudPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${oudPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -n "${patchname}" ] && [ -e "${oudmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let p++
         patches[${p}]="${patchname}"
      fi
   done

   # Add in OUD native bundle patches
   readarray -t oudPatches < <(ls -1d ${swdir}/*/files/oracle.idm.oud ${swdir}/*/oud/*/files/oracle.idm.oud 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/\/files\/oracle.idm.oud//g")
   for (( x=0; x< ${#oudPatches[*]}; x++ ))
   do
      patch=$(echo "${oudPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${oudPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -n "${patchname}" ] && [ -e "${oudmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let p++
         patches[${p}]="${patchname}"
      fi
   done

   if [ "${patchOud}" == 'true' ]
   then
      rm -f "${cfgdir}/.steps.proxy.stop" 2> /dev/null
      ${curdir}/manage_proxy.sh stop --step ${steps}
      if [ -e "${cfgdir}/.steps.proxy.stop" ];then steps=$(cat ${cfgdir}/.steps.proxy.stop);fi

      rm -f "${cfgdir}/.steps.oud.stop" 2> /dev/null
      ${curdir}/manage_oud.sh stop --pnum 0 --step ${steps}
      if [ -e "${cfgdir}/.steps.oud.stop" ];then steps=$(cat ${cfgdir}/.steps.oud.stop);fi

      # Apply OPatch updates
      for patch in ${opatchPatches[*]}
      do
         if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
         let steps++
         echo "Step: ${steps} - Apply OPatch ${patch} to OUD" | tee -a  ${logdir}/sw-install-${now}.log
         export ORACLE_HOME="${oudmwdir}"
         $JAVA_HOME/bin/java \
            -Djava.io.tmpdir="${tmpdir}" \
            -jar ${curdir}/sw/${patch}/opatch_generic.jar \
            -silent oracle_home=$ORACLE_HOME \
            >> ${logdir}/patch-opatch-${now}.log 2>&1
         rc=$?;set +x
         ck4warn=$(grep 'OPatch installation completed with warnings' ${logdir}/patch-opatch-${now}.log)
         if [ -n "${ck4warn}" ]
         then
            echo "WARNING: Patch install failed.  See: ${logdir}/patch-opatch-${now}.log for details"
         else
            touch "${oudmwdir}/.patch.${patch}.installed"
         fi
      done

      # Unique and then apply OUD patches
      readarray -t myPatches < <(echo ${patches[*]}|sed -e "s/ /\n/g"|grep -v "^$"|sort|uniq)
      for patch in ${myPatches[*]}
      do
         let steps++
         echo "Step: ${steps} - Apply OUD patch ${patch} to OUD"
         cksub=$(ls -1d  ${swdir}/*/oud/${patch} 2> /dev/null)
         if [ -d "${swdir}/${patch}" ]
         then
            cd ${swdir}/${patch}
         elif [ -n "${cksub}" ]
         then
            cd ${cksub}
         else
            echo "Cannot find patch ${patch}"
            exit 1
         fi

         if [ "${dbg}" == 'true' ];then set -x;fi
         export ORACLE_HOME="${oudmwdir}"
         ${ORACLE_HOME}/OPatch/opatch apply -silent >> ${logdir}/patch-oud-${now}.log 2>&1
         rc=$?;set +x
         ck4warn=$(grep 'OPatch completed with warnings' ${logdir}/patch-oud-${now}.log)
         if [ -n "${ck4warn}" ]
         then
            echo "WARNING: Patch install failed.  See: ${logdir}/patch-oud-${now}.log for details"
         else
            touch "${oudmwdir}/.patch.${patch}.installed"
         fi
      done

      rm -f "${cfgdir}/.steps.oud.start" 2> /dev/null
      ${curdir}/manage_oud.sh start --pnum 0 --step ${steps}
      if [ -e "${cfgdir}/.steps.oud.start" ];then steps=$(cat ${cfgdir}/.steps.oud.start);fi

      rm -f "${cfgdir}/.steps.proxy.start" 2> /dev/null
      ${curdir}/manage_proxy.sh start --step ${steps}
      if [ -e "${cfgdir}/.steps.proxy.start" ];then steps=$(cat ${cfgdir}/.steps.proxy.start);fi
   fi
   fi
}

###############################################################################
# Patch OUDSM
###############################################################################
patch_oudsm() {
   # Extract patches found in bitsdir
   extract_bits oudsm
   if [ -e "${cfgdir}/.steps.extracted" ];then steps=$(cat ${cfgdir}/.steps.extracted);fi

   # Make sure fuser is installed
   ck4fuser=$(which fuser 2> /dev/null)
   if [ -z "${ck4fuser}" ]
   then
      echo "ERROR: Patch requires fuser command.  Please install requisite package"
      echo " Linux: sudo yum install -y psmisc"
      exit 1
   fi

   if [ "${product}" == 'oudsm' ]
   then
   patchOud='false'
   p=0
   p=q

   # Add in OPatch patches
   readarray -t tmpPatches < <(ls -1d ${swdir}/*/opatch_generic.jar ${swdir}/*/files/oracle.adfrt.view_11g 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/\/opatch_generic.jar//g" -e "s/\/files\/oracle.adfrt.view_11g//g")
   for (( x=0; x< ${#tmpPatches[*]}; x++ ))
   do
      patch=$(echo "${tmpPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${tmpPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -e "${oudsmmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let q++
         opatchPatches[${q}]="${patchname}"
      fi
   done

   # Determine which patches have not already been applied
   # Handle FMW bundle patches
   readarray -t oudPatches < <(ls -1 ${swdir}/*/binary_patches/oud/generic/p*.zip 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")
   for (( x=0; x< ${#oudPatches[*]}; x++ ))
   do
      patch=$(echo "${oudPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${oudPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -n "${patchname}" ] && [ -e "${oudsmmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let p++
         patches[${p}]="${patchname}"
      fi
   done

   # Add in OUD native bundle patches
   readarray -t oudPatches < <(ls -1d ${swdir}/*/files/oracle.idm.oud ${swdir}/*/oud/*/files/oracle.idm.oud 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/\/files\/oracle.idm.oud//g")
   for (( x=0; x< ${#oudPatches[*]}; x++ ))
   do
      patch=$(echo "${oudPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${oudPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -n "${patchname}" ] && [ -e "${oudsmmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let p++
         patches[${p}]="${patchname}"
      fi
   done

   if [ "${patchOud}" == 'true' ]
   then
      # Stop OUDSM

      # Apply OPatch updates
      for patch in ${opatchPatches[*]}
      do
         if [ -e "${curdir}/sw/${patch}/opatch_generic.jar" ]
         then
            if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
            let steps++
            echo "Step: ${steps} - Apply OPatch ${patch} OUDSM" | tee -a  ${logdir}/sw-install-${now}.log
            export ORACLE_HOME="${oudsmmwdir}"
            $JAVA_HOME/bin/java \
               -Djava.io.tmpdir="${tmpdir}" \
               -jar ${curdir}/sw/${patch}/opatch_generic.jar \
               -silent oracle_home=$ORACLE_HOME \
               >> ${logdir}/patch-opatch-${now}.log 2>&1
            rc=$?;set +x
            ck4warn=$(grep 'OPatch installation completed with warnings' ${logdir}/patch-opatch-${now}.log)
            if [ -n "${ck4warn}" ]
            then
               echo "WARNING: Patch install failed.  See: ${logdir}/patch-opatch-${now}.log for details"
            else
               touch "${oudsmmwdir}/.patch.${patch}.installed"
            fi
         fi
      done

      # Unique and then apply OUD patches
      readarray -t myPatches < <(echo ${opatchPatches[*]}|sed -e "s/ /\n/g"|grep -v "^$"|sort|uniq)
      for patch in ${myPatches[*]}
      do
         let steps++
         echo "Step: ${steps} - Apply FMW patch ${patch} to OUDSM"
         cksub=$(ls -1d  ${swdir}/*/oud/${patch} 2> /dev/null)
         if [ -d "${swdir}/${patch}" ]
         then
            cd ${swdir}/${patch}
         elif [ -n "${cksub}" ]
         then
            cd ${cksub}
         else
            echo "Cannot find patch ${patch}"
            exit 1
         fi

         if [ "${dbg}" == 'true' ];then set -x;fi
         export ORACLE_HOME="${oudsmmwdir}"
         ${ORACLE_HOME}/OPatch/opatch apply -silent >> ${logdir}/patch-oud-${now}.log 2>&1
         rc=$?;set +x
         ck4warn=$(grep 'OPatch completed with warnings' ${logdir}/patch-oud-${now}.log)
         if [ -n "${ck4warn}" ]
         then
            echo "WARNING: Patch install failed.  See: ${logdir}/patch-oud-${now}.log for details"
         else
            touch "${oudsmmwdir}/.patch.${patch}.installed"
         fi
      done

      # Start OUDSM

   fi
   fi
}

###############################################################################
# Patch DIP
###############################################################################
patch_dip() {
   # Extract patches found in bitsdir
   extract_bits oud
   extract_bits dip

   if [ -e "${cfgdir}/.steps.extracted" ];then steps=$(cat ${cfgdir}/.steps.extracted);fi

   # Make sure fuser is installed
   ck4fuser=$(which fuser 2> /dev/null)
   if [ -z "${ck4fuser}" ]
   then
      echo "ERROR: Patch requires fuser command.  Please install requisite package"
      echo " Linux: sudo yum install -y psmisc"
      exit 1
   fi

   if [ "${product}" == 'dip' ]
   then
   patchOud='false'
   p=0
   p=q

   # Add in OPatch patches
   readarray -t tmpPatches < <(ls -1d ${swdir}/*/opatch_generic.jar 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/\/opatch_generic.jar//g")
   for (( x=0; x< ${#tmpPatches[*]}; x++ ))
   do
      patch=$(echo "${tmpPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${tmpPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -e "${dipmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let q++
         opatchPatches[${q}]="${patchname}"
      fi
   done

   # Determine which patches have not already been applied
   # Handle FMW bundle patches
   readarray -t oudPatches < <(ls -1 ${swdir}/*/binary_patches/oud/generic/p*.zip 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g")
   for (( x=0; x< ${#oudPatches[*]}; x++ ))
   do
      patch=$(echo "${oudPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${oudPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -n "${patchname}" ] && [ -e "${dipmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let p++
         patches[${p}]="${patchname}"
      fi
   done

   # Add in OUD native bundle patches
   readarray -t oudPatches < <(ls -1d ${swdir}/*/files/oracle.idm.oud ${swdir}/*/oud/*/files/oracle.idm.oud 2> /dev/null|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/\/files\/oracle.idm.oud//g")
   for (( x=0; x< ${#oudPatches[*]}; x++ ))
   do
      patch=$(echo "${oudPatches[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
      patchname=$(basename "${oudPatches[${x}]}"|sed -e "s/^p//g" -e "s/_.*//g")
      if [ -n "${patchname}" ] && [ -e "${dipmwdir}/.patch.${patchname}.installed" ]
      then
         true
      elif [ -n "${patchname}" ] 
      then
         patchOud='true'
         let p++
         patches[${p}]="${patchname}"
      fi
   done

   if [ "${patchOud}" == 'true' ]
   then
      # Stop DIP

      # Apply OPatch updates
      for patch in ${opatchPatches[*]}
      do
         if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
         let steps++
         echo "Step: ${steps} - Apply OPatch ${patch} DIP" | tee -a  ${logdir}/sw-install-${now}.log
         export ORACLE_HOME="${dipmwdir}"
         $JAVA_HOME/bin/java \
            -Djava.io.tmpdir="${tmpdir}" \
            -jar ${curdir}/sw/${patch}/opatch_generic.jar \
            -silent oracle_home=$ORACLE_HOME \
            >> ${logdir}/patch-opatch-${now}.log 2>&1
         rc=$?;set +x
         ck4warn=$(grep 'OPatch installation completed with warnings' ${logdir}/patch-opatch-${now}.log)
         if [ -n "${ck4warn}" ]
         then
            echo "WARNING: Patch install failed.  See: ${logdir}/patch-opatch-${now}.log for details"
         else
            touch "${dipmwdir}/.patch.${patch}.installed"
         fi
      done

      # Unique and then apply OUD patches
      readarray -t myPatches < <(echo ${patches[*]}|sed -e "s/ /\n/g"|grep -v "^$"|sort|uniq)
      for patch in ${myPatches[*]}
      do
         let steps++
         echo "Step: ${steps} - Apply OUD patch ${patch} to DIP"
         cksub=$(ls -1d  ${swdir}/*/oud/${patch} 2> /dev/null)
         if [ -d "${swdir}/${patch}" ]
         then
            cd ${swdir}/${patch}
         elif [ -n "${cksub}" ]
         then
            cd ${cksub}
         else
            echo "Cannot find patch ${patch}"
            exit 1
         fi

         if [ "${dbg}" == 'true' ];then set -x;fi
         export ORACLE_HOME="${dipmwdir}"
         ${ORACLE_HOME}/OPatch/opatch apply -silent >> ${logdir}/patch-oud-${now}.log 2>&1
         rc=$?;set +x
         ck4warn=$(grep 'OPatch completed with warnings' ${logdir}/patch-oud-${now}.log)
         if [ -n "${ck4warn}" ]
         then
            echo "WARNING: Patch install failed.  See: ${logdir}/patch-oud-${now}.log for details"
         else
            touch "${dipmwdir}/.patch.${patch}.installed"
         fi
      done

      # Start DIP

   fi
   fi
}

###############################################################################
# Patch Oracle Database
###############################################################################
patch_db() {
   ${curdir}/manage_db.sh patch
}

###############################################################################
# Check requisites
###############################################################################
check_requisites() {
   if [ "${templateName}" != 'inetorg' ]
   then
      if [ -e "${schemaFile}" ] 
      then
         true
      elif [ "${subcmd}" == 'setup' ]
      then
         echo "ERROR: The custom schema file does not exist:"
         echo "   ${schemaFile}"
         echo "   You may can generate with for inetorg template name:"
         echo "   ${curdir}/manage_data.sh genall -n ${templateName} -N 100000 --rm"
         exit 1
      fi
   fi

   if [ -e "${dataFile}" ]
   then
      true
   elif [ "${subcmd}" == 'setup' ]
   then
      echo "ERROR: The custom schema file does not exist:"
      echo "   ${dataFile}"
      echo "   You may can generate with for inetorg template name:"
      echo "   ${curdir}/manage_data.sh genall -n ${templateName} -N 100000 --rm"
      exit 1
   fi

   # Lookup OS
   lookupos

   if [ "${os}" == 'Linux' ] && [ "${olv}" == '7' ]
   then
      ck4pkgs=$(rpm -q ksh unzip libzip libzip.i686 libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel compat-db47 compat-libcap1.x86_64 compat-libstdc++-33.x86_64 compat-libstdc++-33.i686 libstdc++.i686 compat-libcap1 compat-libstdc++-33|grep "not installed")

      if [ -n "${ck4pkgs}" ]
      then
         echo "ERROR: Make sure that that all of the following requisite packagesare installed"
         echo "   ksh unzip libzip libzip.i686 libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel compat-db47 compat-libcap1.x86_64 compat-libstdc++-33.x86_64 compat-libstdc++-33.i686 libstdc++.i686 compat-libcap1 compat-libstdc++-33"
         exit 1
      fi
   elif [ "${os}" == 'Linux' ] && [ "${olv}" == '8' ]
   then

      ck4pkgs=$(rpm -q ksh unzip libzip libzip libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel|grep "not installed")
      if [ -n "${ck4pkgs}" ]
      then
         echo "ERROR: Make sure that that all of the following requisite packagesare installed"
         echo "   ksh unzip libzip libzip libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel"
         exit 1
      fi
   fi

   # Optional packages
   # rsync snapper psmisc net-tools lsof xauth libXrender libXtst perl-CPAN  perl-JSON-PP krb5-server krb5-server-ldap krb5-workstation 
}


###############################################################################
# Extract and install ODSEE software
###############################################################################
install_odsee() {
   # Check requisites
   check_requisites

   if [ -e "${curdir}/dsee7/bin/dsadm" ]
   then
      true
   else
      if [ -e "{swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip" ]
      then
         true
      else
         let steps++
         echo "Step: ${steps} - Extract ODSEE 11g (V35071-01.zip)"
         mkdir -p "${swdir}/odsee" 2> /dev/null
         cd "${swdir}/odsee"
         unzip -oq "${bitsdir}/V35071-01.zip"
         rc=$?
         if [ "${rc}" != 0 ]
         then
            echo "ERROR: Extraction of V35071-01.zip failed"
            exit 1
         fi
      fi

      if [ -e "${swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip" ]
      then
         let steps++
         echo "Step: ${steps} - Install ODSEE 11g"
         cd ${curdir}
         unzip -oq "${swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip"
         rc=$?
         if [ "${rc}" != 0 ]
         then
            echo "ERROR: Extraction of sun-dsee7.zip failed"
            exit 1
         fi
      fi
   fi

   # Extract and install ODSEE patches
   cd "${bitsdir}"
   patches=$(ls -1 p*_111170_Linux-x86-64.zip 2> /dev/null|sed -e "s/^p//g" -e "s/_111170_Linux-x86-64.zip//g")
   for patch in ${patches}
   do
      # Extract patch
      if [ -d "${swdir}/odsee/${patch}" ]
      then
         true
      else
         mkdir -p "${swdir}/odsee/${patch}" 2> /dev/null
         cd "${swdir}/odsee/${patch}"
         unzip -oq "${bitsdir}/p${patch}_111170_Linux-x86-64.zip"
         rc=$?
         tar -zxf dsee*.tar.gz 2> /dev/null
         rc=$?
      fi

      # Install patch
      if [ -e "${curdir}/dsee7/patch.${patch}" ]
      then
         true
      else
         let steps++
         echo "Step: ${steps} - Install patch ${patch}"
         unzip -oq "${swdir}/odsee/${patch}/sun-dsee7.zip"
         rc=$?
         if [ "${rc}" == 0 ]
         then
            touch "${curdir}/dsee7/patch.${patch}"
         else
            echo "ERROR: Failed to install patch ${patch}"
            exit 1
         fi
      fi
   done
}


###############################################################################
# Install OID
###############################################################################
install_oid() {
   extract_bits oid
   if [ -e "${cfgdir}/.steps.extracted" ];then steps=$(cat ${cfgdir}/.steps.extracted);fi

   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   PATH=${JAVA_HOME}/bin:$PATH

   fmwi="${swdir}/fmw_12.2.1.4.0_infrastructure.jar"
   if [ -e "${fmwi}" ];then true; else fmwi="${swdir}/fmw_12.2.1.3.0_infrastructure.jar";fi

   fmwo="${swdir}/fmw_12.2.1.4.0_oid_linux64.bin"
   if [ -e "${fmwo}" ];then true; else fmwo="${swdir}/fmw_12.2.1.3.0_oid_linux64.bin";fi

   fmwi_file=$(basename ${fmwi})
   fmwo_file=$(basename ${fmwo})

   if [ -e "${swdir}/${fmwi_file}" ]
   then
      true
   elif [ -e "${curdir}/${fmwi_file}" ]
   then
      mv "${curdir}/${fmwi}" "${swdir}/${fmwi}"
   else
      echo "FMW Infrastructure installer (${fmwi}) not present"
      exit 1
   fi
   if [ -e "${swdir}/${fmwo_file}" ]
   then
      true
   elif [ -e "${curdir}/${fmwo_file}" ]
   then
      mv "${curdir}/${fmwo}" "${swdir}/${fmwo}"
   else
      echo "FMW OID installer (${fmwo}) not present"
      exit 1
   fi

   if [ -e  "${oidmwdir}/oracle_common/bin/rcu" ]
   then
      true
   elif [ -n  "${fmwi}" ]
   then
      #instSwap
      if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
      let steps++
      echo "Step: ${steps} - Install Fusion Middleware (FMW) Infrastructure ${fmwVersion}" | tee -a  ${logdir}/sw-install-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${JAVA_HOME}/bin/java \
         -Djava.io.tmpdir="${tmpdir}" \
         -jar "${fmwi}" \
         -silent \
         -ignoreSysPrereqs \
         -responseFile ${cfgdir}/oid-fmw${fmwVersion}.rsp \
         -invPtrLoc ${cfgdir}/oraInventory.loc \
         >> ${logdir}/sw-install-${now}.log 2>&1
      rc=$?
      set +x
      if [ ${rc} -ne 0 ];then echo -e "ERROR: FMW install failed. Review log:\n${logdir}/sw-install-${now}.log";exit 1;fi
      echo ${steps} > ${cfgdir}/.steps.install.fmw.oidsm
   fi

   if [ -d  "${oidmwdir}/oid" ]
   then
      true
   elif [ -n  "${fmwo}" ]
   then
      #${swdir}/fmw_12.2.1.4.0_oid_linux64.bin -silent -J-Djava.io.tmpdir="${tmpdir}" -responseFile ${cfgdir}/oid${fmwVersion}-shared.rsp -invPtrLoc ${cfgdir}/oraInventory.loc >> ${logdir}/oid-install-${now}.log 2>&1

      #instSwap
      if [ -e "${cfgdir}/.steps.swap" ];then steps=$(cat ${cfgdir}/.steps.swap);fi
      let steps++
      echo "Step: ${steps} - Install Oracle Internet Directory (OID)" | tee -a  ${logdir}/sw-install-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${swdir}/fmw_12.2.1.4.0_oid_linux64.bin -silent -responseFile ${cfgdir}/oid${fmwVersion}-shared.rsp -invPtrLoc ${cfgdir}/oraInventory.loc >> ${logdir}/oid-install-${now}.log 2>&1
      rc=$?;set +x
      if [ ${rc} -ne 0 ];then echo -e "ERROR: OUD install failed. Review log:\n${logdir}/sw-install-${now}.log";exit 1;fi
      echo ${steps} > ${cfgdir}/.steps.install.oid
   fi

   # Deinstall configuration
   rm -f "${cfgdir}/oid-fmw${fmwVersion}.rsp" "${cfgdir}/oid${fmwVersion}-shared.rsp" 2> /dev/null

}

###############################################################################
# Deinstall OID
###############################################################################
deinstall_oid() {
   if [ "$dbg" == 'true' ];then set -x;fi
   if [ -d "${oidmwdir}" ];then rm -fr "${oidmwdir}" 2> /dev/null;fi
}

###############################################################################
# Install LDAP Performance Tools
###############################################################################
install_perftools() {
   if [ -d "${swdir}/LDAPPerfTools" ]
   then
      true
   else
      echo "Install LDAP Performance Tools"
      if [ -e "${bitsdir}/ldapperftools-1973807.zip" ]
      then
         if [ "$dbg" == 'true' ];then set -x;fi
         cd ${swdir};unzip -oq ${bitsdir}/ldapperftools-1973807.zip
         rc=$?;set +x
      else
         echo "ERROR: Missing install file.  Download from:\nhttp://www.oracle.com/technetwork/middleware/id-mgmt/learnmore/oid-demos-182820.html\nand put in $swdir/perftools"
         exit 1
      fi
   fi
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
         'patch') case ${product} in
                     'oud') patch_oud;;
                   'oudsm') patch_oudsm;;
                      'db') patch_db;;
                         *) patch_oud;patch_oudsm;;
                  esac
                  ;;
       'install') case ${product} in
                     'oud') install_oud;;
                   'oudsm') install_oudsm;;
                     'fmw') install_fmw;;
                     'dip') install_dip;;
                   'odsee') install_odsee;;
                     'oid') install_oid;;
                    'perf') install_perftools;;
                     'jdk') unset JAVA_HOME; extract_bits all;;
                         *) install_oud;install_oudsm;install_oid;;
                  esac
                  ;;
     'deinstall') case ${product} in
                     'oud') deinstall_oud;;
                   'oudsm') deinstall_oudsm;;
                  'replgw') deinstall_replgw;;
                     'oid') deinstall_oid;;
                    'perf') deinstall_perftools;;
                     'inv') deinstall_inventory;;
                   'odsee') deinstall_odsee;;
                         *) deinstall_db;deinstall_replgw;deinstall_oudsm;deinstall_oud;deinstall_oid;deinstall_odsee;deinstall_slamd;deinstall_inventory;;
                  esac
                  ;;
       'extract') extract_bits all;;
        'resize') resize_storage;;
      'instswap') echo instSwap;;
        'rmswap') rmSwap;;
               *) showUsage;;
esac
