#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Show Usage
###############################################################################
showUsage() {
   echo "Usage: ${cmd} [--ktype (none | jks | p12) ]"
   echo "Default is none"
   echo "   none = Self-signed certificate in JKS provider"
   echo "   jks  = CA-signed certificate in JKS provider"
   echo "   p12  = CA-signed certificate in PKCS12 provider"
   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            ktype) ktype=$1;shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set provider store variables
###############################################################################
if [ -z "${ktype}" ];then ktype='none';fi
case ${ktype} in
     'none') kstore="${oudmwdir}/oud1/OUD/config/keystore"
             tstore="${oudmwdir}/oud1/OUD/config/truststore"
             provider="JKS"
             signer="self"
             ;;
      'jks') kstore="${oudmwdir}/oud1/OUD/config/keystore"
             tstore="${oudmwdir}/oud1/OUD/config/truststore"
             provider="JKS"
             signer="CA"
             ;;
      'p12') kstore="${oudmwdir}/oud1/OUD/config/keystore.p12"
             tstore="${oudmwdir}/oud1/OUD/config/truststore.p12"
             provider="PKCS12"
             signer="CA"
             ;;
          *) showUsage;;
esac

###############################################################################
# Share requisite expectations"
###############################################################################
echo -e "\nThis demonstration shows how to re-configure Administration certificate"
echo -e "provider to use server ${provider} provider (keystore and truststore)"

###############################################################################
# Generate data
###############################################################################
if [ -e "${cfgdir}/inetorg.ldif" ]
then
   true
else
   echo -e "\nDEMO --> Generate data for the OUD topology"
   ${curdir}/manage_data.sh genall -n inetorg -N 1000 --rm
fi


###############################################################################
# Setup OUD instances
###############################################################################
if [ -e "${oudmwdir}/oud1" ]
then
   true
else
   echo -e "\nDEMO --> Setup oud1 with ${signer}-signed certificate"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oud.sh setup --pnum 1 -n inetorg --noroles --notune --ktype none
   set +x
fi

if [ -e "${oudmwdir}/oud1" ]
then
   true
else
   echo -e "\nDEMO --> Setup oud2 with ${signer}-signed certificate"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oud.sh setup --pnum 2 -n inetorg --noroles --notune --ktype none --supplier ${localHost}:1444:1989
   set +x
fi

###############################################################################
# Show oud1 Administration provider cert details before reconfiguration
###############################################################################
echo -e "\nDEMO --> Show oud1 Administration provider cert details before reconfiguration"
if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -T -h ${localHost} -Z -p 1444 -D "${bDN}" -j "${jPW}" -b '' -s base objectClass=top <<EOF

EOF
set +x      

###############################################################################
# Re-configure Administration cert provider to use server ${provider} cert provider
###############################################################################
echo -e "\nDEMO --> Get pin value of oud1 server ${provider} provider keystore."
if [ "${dbg}" == 'true' ];then set -x;fi
export storepass=$(${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --advanced --no-prompt --showKeystorePassword get-key-manager-provider-prop --provider-name ${provider} --property key-store-pin|grep "^key-store-pin"|cut -d' ' -f3)
rc=$?;set +x

if [ -z "${storepass}" ]
then echo "ERROR: Could not retrieve the keystore pin"
   exit 1
fi

echo -e "\nDEMO --> Re-configure oud1 Administration provider use server ${provider} truststore"
if [ "${dbg}" == 'true' ];then set -x;fi
${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --no-prompt set-trust-manager-provider-prop --provider-name Administration --set trust-store-file:"${tstore}" --set trust-store-pin:${storepass}
rc=$?;set +x

echo -e "\nDEMO --> Re-configure oud1 Administration provider use server ${provider} keystore"
if [ "${dbg}" == 'true' ];then set -x;fi
${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --no-prompt set-key-manager-provider-prop --provider-name Administration --set key-store-file:"${kstore}" --set key-store-pin:${storepass} 
rc=$?;set +x

echo -e "\nDEMO --> Re-configure oud1 Administration connector use server ${provider} cert nickname (server-cert)"
if [ "${dbg}" == 'true' ];then set -x;fi
${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --no-prompt set-administration-connector-prop --connector-name LDAP --set ssl-cert-nickname:server-cert
rc=$?;set +x

echo -e "\nDEMO --> Restart OUD instance to apply cert changes"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh stop --pnum 1
${curdir}/manage_oud.sh start --pnum 1
set +x  

###############################################################################
# Show existing oud1 certificate
###############################################################################
echo -e "\nDEMO --> Show oud1 Administration provider cert details after reconfiguration"
if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -T -h ${localHost} -Z -p 1444 -D "${bDN}" -j "${jPW}" -b '' -s base objectClass=top <<EOF

EOF
set +x      
