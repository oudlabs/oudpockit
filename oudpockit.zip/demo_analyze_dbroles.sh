#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} <db|ds|all> [options]

        db  - Analyze just Database users and roles
        ds  - Analyze just Directory Server
        all - Analyze both DB and DS

SYNOPSIS
     Produce centralized users and roles for Centrally Managed Users (CMU)
     and Enterprise User Security (EUS) architectures.

DESCRIPTION
     This script retrieves, analyzes, and provides recommendations for
     centralizing Oracle database users and roles for Centrally Managed
     Users and Enterprise User Security architectures.

     Note that this script analyzes only the database specified by
     the Oracle database environment variables including ORACLE_HOME,
     ORACLE_BASE, ORACLE_SID, ..."

OPTIONS

     --help                        Show Usage

     -z                            Enable debug mode
                                   Default: Disabled

     --base <suffix>               Specify DS base suffix
                                   Default: ou=People,${suffix}

     -h <name>                     Directory server host
                                   Default: ${localHost}

     -p <number>                   LDAP port number
                                   Default: ${ldapPort}

     -Z                            Use SSL connection to directory server
                                   Default: Disabled

     -D <bind_dn>                  Directory server BIND user
                                   Default: ${bDN}

     -j <full_path_to_file>        Password fine
                                   Default: ${jDN}

EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
useSSL=''
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            base) ldapBase=$1;shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            h) ldapHost=$1;shift;;
            p) ldapPort=$1;shift;;
            Z) useSSL='-Z -X ';;
            u) bDN=$1;shift;;
            j) jPW=$1;shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Validate inputs
###############################################################################
if [ -z "$ORACLE_HOME" ] || [ -z "$ORACLE_BASE" ] || [ -z "$TNS_ADMIN" ] || [ -z "$ORACLE_SID" ]
then
   echo "Error: Must set DB ENV before running this script"
   exit 1
fi

rootAcct="sys/${bPW}@PDB1_${localH} as sysdba"
tmpFile="${tmpdir}/demorolesassessment-${now}.tmp"
errFile="${logdir}/demorolesassessment-${now}.log"

###############################################################################
# Define OOTB users and groups
###############################################################################
#ootbUsers=('sys','system','scott')
#ootbRoles=('dba')

###############################################################################
# Test SQL connection
###############################################################################
$ORACLE_HOME/bin/sqlplus -S ${rootAcct} > ${tmpFile} 2> ${errFile} << EOF
show user;
quit;
EOF
rc=$?

testUser=$(cat ${tmpFile})

if [ ${rc} == 0 ] && [ "${testUser}" == 'USER is "SYS"' ]
then
   rm -f "${tmpFile}" "${errFile}" 2> /dev/null
else
   echo "Error: Database connect failed with the following errors:"
   cat ${errFile}
   rm -f "${tmpFile}" "${errFile}" 2> /dev/null
   exit 1
fi

###############################################################################
# Get users
###############################################################################
readarray -t allUserData < <($ORACLE_HOME/bin/sqlplus -S ${rootAcct} 2> /dev/null << EOF
SET FEEDBACK OFF;
set pagesize 0;
select username from dba_users;
EOF
)

###############################################################################
# Get roles
###############################################################################
readarray -t allRoleData < <($ORACLE_HOME/bin/sqlplus -S ${rootAcct} 2> /dev/null << EOF
SET FEEDBACK OFF;
set pagesize 0;
select role || '|' || common || '|' || oracle_maintained from dba_roles order by common asc,oracle_maintained asc,role;
EOF
)

###############################################################################
# Get role nesting
###############################################################################
readarray -t allRoleNestData < <($ORACLE_HOME/bin/sqlplus -S ${rootAcct} 2> /dev/null << EOF
SET FEEDBACK OFF;
set pagesize 0;
SELECT grantee || '|' || granted_role || '|' || admin_option || '|' || common || '|' || default_role
    FROM dba_role_privs
    WHERE grantee NOT IN ('SYS')
    ORDER BY grantee, granted_role;
EOF
)

###############################################################################
# Get role privileges
###############################################################################
readarray -t allRolePrivData < <($ORACLE_HOME/bin/sqlplus -S ${rootAcct} 2> /dev/null << EOF
SET FEEDBACK OFF;
set pagesize 0;
select role || '|' || privilege from role_sys_privs order by 1;
EOF
)

###############################################################################
# Analyze data
#  - Identify all non-OOTB users
#  - Identify all non-OOTB roles
#  - Identify potentially orphaned non-OOTB users (never logged in)
#  - Identify potentially orphaned non-OOTB roles (not assigned to any user)
#  - Identify user privileges assigned outside of roles
#  - Identify users with no roles (May need to be individually mapped)
# 
#  Show which roles should be mapped to AD groups 
#  Show users that could be consolidated into shared user schema (DBUSERS)
# 
###############################################################################


# Identify nested roles

# Identify 

###############################################################################
# Analyze DB
###############################################################################
analyzeDB() {
   let steps++
   echo -e "\n###############################################################################"
   echo -e "Step: ${steps} - List database users"
   for (( x=0; x< ${#allUserData[*]}; x++ ))
   do
      echo "${allUserData[${x}]}"
   done

   # Determine OOTB and custom DB users
   for (( x=0; x< ${#allUserData[*]}; x++ ))
   do
      dbuser=$(echo "${allUserData[${x}]}"|cut -d'|' -f1-2)
      isOOTB=$(echo "${allUserData[${x}]}"|grep "|Y$"|cut -d'|' -f1-)
      if [ -n "${isOOTB}" ]
      then
         ootbUsers+=("${dbuser}")
      else
         customUsers+=("${dbuser}")
      fi

         let steps++
         echo -e "\n###############################################################################"
         echo -e "Step: ${steps} - Show dba_role_privs granted to db user ${dbuser}"
         if [ "${dbg}" == 'true' ];then set -x;fi
         echo -e "SQL> select GRANTED_ROLE from dba_role_privs where GRANTEE = "${dbuser}";\c" 2>&1 | tee -a ${logdir}/roleassment-${now}.log
         $ORACLE_HOME/bin/sqlplus -S / as sysdba 2>&1 <<EOF
SET FEEDBACK OFF;
set pagesize 0;
select GRANTED_ROLE from dba_role_privs where GRANTEE = '${dbuser}';
EOF
         rc=$?;set +x
      
         echo
         let steps++
         echo -e "\n###############################################################################"
         echo "Step: ${steps} - Show dba_sys_privs granted to db user ${dbuser}"
         if [ "${dbg}" == 'true' ];then set -x;fi
         echo -e "SQL> select PRIVILEGE from dba_sys_privs where GRANTEE = '${dbuser}';\c" 2>&1 | tee -a ${logdir}/eus-${now}.log
         $ORACLE_HOME/bin/sqlplus -S / as sysdba 2>&1 <<EOF
SET FEEDBACK OFF;
set pagesize 0;
select PRIVILEGE from dba_sys_privs where GRANTEE = '${dbuser}';
EOF
         rc=$?;set +x

   done

   # Determine OOTB and custom roles
   for (( x=0; x< ${#allRoleData[*]}; x++ ))
   do
      role=$(echo "${allRoleData[${x}]}"|cut -d'|' -f1-2)
      isOOTB=$(echo "${allRoleData[${x}]}"|grep "|Y$"|cut -d'|' -f1-)
      if [ -n "${isOOTB}" ]
      then
         ootbRoles+=("${role}")
      else
         customRoles+=("${role}")
      fi
   done
}


###############################################################################
# Show all DBA role privileges assigned to each user
###############################################################################
analyzeDS() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   readarray -t dsUsers < <(${lsrch} -T -h ${localHost} ${useSSL} -p ${ldapPort} -D "${bDN}" -j "${jPW}" -b "${suffix}" '(objectClass=inetOrgPerson)' uid|grep "^uid: "|sed -e "s/^uid: //g")
   set +x

   let steps++
   echo -e "\n###############################################################################"
   echo -e "Step: ${steps} - List directory server users"
   for (( x=0; x< ${#dsUsers[*]}; x++ ))
   do
      echo "${dsUsers[${x}]}"
   done

   if [ "${dbg}" == 'true' ];then set -x;fi
   readarray -t dsGroups < <(${lsrch} -T -h ${localHost} ${useSSL} -p ${ldapPort} -D "${bDN}" -j "${jPW}" -b "${suffix}" '(|(objectClass=groupOfUsers)(objectClass=groupOfUniqueNames))' cn|grep "^cn: "|sed -e "s/^cn: //g")
   set +x

   let steps++
   echo -e "\n###############################################################################"
   echo -e "Step: ${steps} - List directory server groups"
   for (( x=0; x< ${#dsGroups[*]}; x++ ))
   do
      echo "${dsGroups[${x}]}"
   done
}

###############################################################################
# Show all DBA role privileges assigned to each user
###############################################################################

###############################################################################
# Produce recommendations
###############################################################################

###############################################################################
# Process subcommand
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi
if [ -z "${subcmd}" ];then subcmd='analyze_all';fi
case ${subcmd} in
    'db') analyzeDB;;
    'ds') analyzeDS;;
   'all') analyzeDB;analyzeDS;;
       *) showUsage;;
esac
set +x
