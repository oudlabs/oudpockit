#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Variables
###############################################################################
adminDN="uid=admin1,ou=Admins,${suffix}"
adminDN="${bDN}"
dnFile="${cfgdir}/custom_checkpoint.list"
entryDnFile="${cfgdir}/custom_checkpoint.ldif"
logFile="${logdir}/custom_checkpoint-${now}.log"

steps=0

###############################################################################
# Handle manager updates
###############################################################################
# 1. Retrieve all entries with manager value 
let steps++
echo -e "Step ${steps}: Derive user list...\c"
if [ -e "${dnFile}" ];then rm -f "${dnFile}" 2> /dev/null;rc=$?;set +x;fi
${oudmwdir}/oud/bin/ldapsearch -T --simplePageSize 100 -h ${localHost} -Z -X -p ${ldapsPort} -D "${adminDN}" -j "${jPW}" -b "${suffix}" -s sub '(objectClass=inetOrgPerson)' manager managerCN managerRDN managerUID uid 2> /dev/null \
    |sed \
       -e "s/^manager: /|manager:/gi" \
       -e "s/^managerCN: /|managercn:/gi" \
       -e "s/^managerRDN: /|managerrdn:/gi" \
       -e "s/^managerUID: /|manageruid:/gi" \
       -e "s/^secretary: /|secretary:/gi" \
       -e "s/^secretaryCN: /|secretarycn:/gi" \
       -e "s/^secretaryRDN: /|secretaryrdn:/gi" \
       -e "s/^secretaryUID: /|secretaryuid:/gi" \
       -e "s/^uid: /|entryuid:/gi" \
       -e "s/^dn: /${bolvar}/gi" \
       -e "s/ /${spcvar}/g" \
       -e "s/   /${spcvar}/g" \
    |tr -d '[\n\r]' \
    |sed \
        -e "s/${bolvar}/|\n/g" \
        -e "s/$/|/g" \
    |grep -v "^|$" \
    > ${dnFile}
if [ -s "${dnFile}" ]
then
   true
else
   echo "ERROR: Directory server ${localHost}:${ldapsPort} is not available"
   exit 1
fi

# 2. Iterate through all entries and identify values that need to be updated
readarray -t dnList < <(cat ${dnFile})

echo -e "${#dnList[*]} users"

# 3. Build unique list of managers
let steps++
echo -e "Step ${steps}: Derive manager list...\c"
readarray -t mgrList < <(cat ${dnFile}|sed -e "s/^.*manager://g" -e "s/|.*//g" -e "s/^${spcvar}//g"|sort -u)

echo -e "${#mgrList[*]} managers"

# 4. Build manager UID list
let steps++
echo "Step ${steps}: Lookup each manager's UID"
z=-1
for (( x=0; x< ${#mgrList[*]}; x++ ))
do
   mgr=$(echo ${mgrList[${x}]}|tr '[:upper:]' '[:lower:]')
   for (( y=0; y< ${#dnList[*]}; y++ ))
   do
      entryDN=$(echo "${dnList[${y}]}"|cut -d'|' -f1|tr '[:upper:]' '[:lower:]')
      if [ "${entryDN}" == "${mgr}" ]
      then
         mgrUid=$(echo "${dnList[${y}]}"|sed -e "s/^.*entryuid://g" -e "s/|.*//g")
         let z++
         mgrUidList[${z}]="${mgrList[${x}]}|${mgrUid}"
         # break out of loop
         break
      fi
   done
done

# 5. Determine updates to apply
let steps++
echo -e "Step ${steps}: Derive update list"
modList=( )
delList=( )

zm=-1
zd=-1
for (( x=0; x< ${#dnList[*]}; x++ ))
do
   entryDN=$(echo "${dnList[${x}]}"|cut -d'|' -f1)
   entryUID=$(echo "${dnList[${x}]}"  |grep -i "|entryuid:"  |sed -e "s/^.*entryuid://g"   -e "s/|.*//g")
   managerDN=$(echo "${dnList[${x}]}" |grep -i "|manager:"   |sed -e "s/^.*manager://g"    -e "s/|.*//g")
   managerRDN=$(echo "${dnList[${x}]}"|grep -i "|managerrdn:"|sed -e "s/^.*managerrdn://g" -e "s/|.*//g")
   managerCN=$(echo "${dnList[${x}]}" |grep -i "|managercn:" |sed -e "s/^.*managercn://g"  -e "s/|.*//g")

   # Derive all manager related variables from managerDN
   if [ -n "${managerDN}" ]
   then
      mgrRDN=$(echo "${managerDN}"|cut -d',' -f1)
      mgrCN=$(echo "${mgrRDN}"|sed -e "s/^cn=//g" -e "s/uid=//g" -e "s/,.*//g")

      # Lookup manager's UID
      for (( y=0; y< ${#mgrUidList[*]}; y++ ))
      do
         mgrDN=$(echo ${mgrUidList[${y}]}|cut -d'|' -f1)
         if [ "${mgrDN}" == "${managerDN}" ]
         then
            mgrUid=$(echo ${mgrUidList[${y}]}|cut -d'|' -f2)
            break
         fi
      done

      if [ "${managerRDN}" != "${mgrRDN}" ]
      then
         echo "   Update managerRDN of ${entryDN}"
         let zm++
         modList[$zm]="\ndn: ${entryDN}\nchangeType: modify\nreplace: managerRDN\nmanagerRDN: ${mgrRDN}\n"
      fi

      if [ "${managerCN}" != "${mgrCN}" ]
      then
         echo "   Update managerCN of ${entryDN}"
         let zm++
         modList[$zm]="\ndn: ${entryDN}\nchangeType: modify\nreplace: managerCN\nmanagerCN: ${mgrCN}\n"
      fi

      if [ "${managerUID}" != "${mgrUID}" ]
      then
         echo "   Update managerUID of ${entryDN}"
         let zm++
         modList[$zm]="\ndn: ${entryDN}\nchangeType: modify\nreplace: managerUID\nmanagerUID: ${mgrUID}\n"
      fi
   else
      if [ -n "${managerRDN}" ]
      then
         echo "   Delete managerRDN from ${entryDN}"
         let zd++
         delList[$zd]="\ndn: ${entryDN}\nchangeType: modify\ndelete: managerRDN\n"
      fi

      if [ -n "${managerCN}" ]
      then
         echo "   Delete managerCN from ${entryDN}"
         let zd++
         delList[$zd]="\ndn: ${entryDN}\nchangeType: modify\ndelete: managerCN\n"
      fi

      if [ -n "${managerUID}" ]
      then
         echo "   Delete managerUID from ${entryDN}"
         let zd++
         delList[$zd]="\ndn: ${entryDN}\nchangeType: modify\ndelete: managerUID\n"
      fi
   fi

done

# 6. Dump mod list into an LDIF file
if [ -n "${modList[*]}" ] || [ -n "${delList[*]}" ]
then
   let steps++
   echo "Step ${steps}: Generate LDIF file of all changes"
   echo -e "${modList[*]}" | sed -e "s/^ //g" >> ${entryDnFile} 2>> ${logFile}
   echo >> ${entryDnFile} 2>> ${logFile}
   echo -e "${delList[*]}" | sed -e "s/^ //g" >> ${entryDnFile} 2>> ${logFile}
fi

###############################################################################
# Handle secretary updates
###############################################################################

# 7. Build unique list of secretarys
let steps++
echo -e "Step ${steps}: Derive secretary list...\c"
readarray -t scrList < <(cat ${dnFile}|sed -e "s/^.*secretary://g" -e "s/|.*//g" -e "s/^${spcvar}//g"|sort -u)

echo -e "${#scrList[*]} secretarys"

# 8. Build secretary UID list
let steps++
echo "Step ${steps}: Lookup each secretary's UID"
z=-1
for (( x=0; x< ${#scrList[*]}; x++ ))
do
   scr=$(echo ${scrList[${x}]}|tr '[:upper:]' '[:lower:]')
   for (( y=0; y< ${#dnList[*]}; y++ ))
   do
      entryDN=$(echo "${dnList[${y}]}"|cut -d'|' -f1|tr '[:upper:]' '[:lower:]')
      if [ "${entryDN}" == "${scr}" ]
      then
         scrUid=$(echo "${dnList[${y}]}"|sed -e "s/^.*entryuid://g" -e "s/|.*//g")
         let z++
         scrUidList[${z}]="${scrList[${x}]}|${scrUid}"
         # break out of loop
         break
      fi
   done
done

# 9. Determine updates to apply
let steps++
echo -e "Step ${steps}: Derive update list"
modList=( )
delList=( )

zm=-1
zd=-1
for (( x=0; x< ${#dnList[*]}; x++ ))
do
   entryDN=$(echo "${dnList[${x}]}"|cut -d'|' -f1)
   entryUID=$(echo "${dnList[${x}]}"  |grep -i "|entryuid:"  |sed -e "s/^.*entryuid://g"   -e "s/|.*//g")
   secretaryDN=$(echo "${dnList[${x}]}" |grep -i "|secretary:"   |sed -e "s/^.*secretary://g"    -e "s/|.*//g")
   secretaryRDN=$(echo "${dnList[${x}]}"|grep -i "|secretaryrdn:"|sed -e "s/^.*secretaryrdn://g" -e "s/|.*//g")
   secretaryCN=$(echo "${dnList[${x}]}" |grep -i "|secretarycn:" |sed -e "s/^.*secretarycn://g"  -e "s/|.*//g")

   # Derive all secretary related variables from secretaryDN
   if [ -n "${secretaryDN}" ]
   then
      scrRDN=$(echo "${secretaryDN}"|cut -d',' -f1)
      scrCN=$(echo "${scrRDN}"|sed -e "s/^cn=//g" -e "s/uid=//g" -e "s/,.*//g")

      # Lookup secretary's UID
      for (( y=0; y< ${#scrUidList[*]}; y++ ))
      do
         scrDN=$(echo ${scrUidList[${y}]}|cut -d'|' -f1)
         if [ "${scrDN}" == "${secretaryDN}" ]
         then
            scrUid=$(echo ${scrUidList[${y}]}|cut -d'|' -f2)
            break
         fi
      done

      if [ "${secretaryRDN}" != "${scrRDN}" ]
      then
         echo "   Update secretaryRDN of ${entryDN}"
         let zm++
         modList[$zm]="\ndn: ${entryDN}\nchangeType: modify\nreplace: secretaryRDN\nsecretaryRDN: ${scrRDN}\n"
      fi

      if [ "${secretaryCN}" != "${scrCN}" ]
      then
         echo "   Update secretaryCN of ${entryDN}"
         let zm++
         modList[$zm]="\ndn: ${entryDN}\nchangeType: modify\nreplace: secretaryCN\nsecretaryCN: ${scrCN}\n"
      fi

      if [ "${secretaryUID}" != "${scrUID}" ]
      then
         echo "   Update secretaryUID of ${entryDN}"
         let zm++
         modList[$zm]="\ndn: ${entryDN}\nchangeType: modify\nreplace: secretaryUID\nsecretaryUID: ${scrUID}\n"
      fi
   else
      if [ -n "${secretaryRDN}" ]
      then
         echo "   Delete secretaryRDN from ${entryDN}"
         let zd++
         delList[$zd]="\ndn: ${entryDN}\nchangeType: modify\ndelete: secretaryRDN\n"
      fi

      if [ -n "${secretaryCN}" ]
      then
         echo "   Delete secretaryCN from ${entryDN}"
         let zd++
         delList[$zd]="\ndn: ${entryDN}\nchangeType: modify\ndelete: secretaryCN\n"
      fi

      if [ -n "${secretaryUID}" ]
      then
         echo "   Delete secretaryUID from ${entryDN}"
         let zd++
         delList[$zd]="\ndn: ${entryDN}\nchangeType: modify\ndelete: secretaryUID\n"
      fi
   fi

done

# 10. Dump mod list into an LDIF file
if [ -n "${modList[*]}" ] || [ -n "${delList[*]}" ]
then
   let steps++
   echo "Step ${steps}: Generate LDIF file of all changes"
   echo -e "${modList[*]}" | sed -e "s/^ //g" >> ${entryDnFile} 2>> ${logFile}
   echo >> ${entryDnFile} 2>> ${logFile}
   echo -e "${delList[*]}" | sed -e "s/^ //g" >> ${entryDnFile} 2>> ${logFile}
fi

# 11. Apply secretary updates
if [ -e "${entryDnFile}" ]
then
   let steps++
   echo "Step ${steps}: Apply changes"
   ${oudmwdir}/oud/bin/ldapmodify -h ${localHost} -Z -X -p ${ldapsPort} -D "${adminDN}" -j "${jPW}" -c -f "${entryDnFile}" > ${logFile} 2>&1
   rc=$?;set +x
fi

# 12. Purge secretary dn file
let steps++
echo "Step ${steps}: Clean up temporary files"
if [ -e "${dnFile}" ];then rm -f "${dnFile}" 2> /dev/null;rc=$?;set +x;fi
if [ -e "${entryDnFile}" ];then rm -f "${entryDnFile}" 2> /dev/null;rc=$?;set +x;fi


###############################################################################
# Conclude run
###############################################################################
let steps++
echo -e "Step ${steps}: Checkpoint complete"
