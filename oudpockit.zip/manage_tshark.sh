#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
steps=0
PATH=/usr/sbin:${swdir}/wireshark/build/run:$PATH
tshark=$(which tshark 2> /dev/null)

###############################################################################
# Check requisites
###############################################################################
# Determine Operating System
os=$(uname -s 2> /dev/null)
# Set osVersion
compat='false'
case ${os} in
   'Linux') if [ -n "$(grep -i Tikanga /etc/redhat-release 2> /dev/null)" ]
            then
               osVersion="OEL5"
               buildSupported='false'
            elif [ -n "$(grep -i Santiago /etc/redhat-release 2> /dev/null)" ]
            then
               osVersion="OL6"
               buildSupported='false'
            elif [ -n "$(grep -i Maipo /etc/redhat-release 2> /dev/null)" ]
            then
               osVersion="OL7"
               compat='true'
               buildSupported='false'
            elif [ -n "$(grep -i Ootpa /etc/redhat-release 2> /dev/null)" ]
            then
               osVersion="OL8"
               compat='true'
               buildSupported='true'
            else
               compat='true'
               buildSupported='false'
            fi
            ;;
esac

if [ "${compat}" != 'true' ]
then
   echo "ERROR: Unsupported OS.  Only support RedHat/Oracle Linux 8 and newer"
   exit 1
fi

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd}

SYNOPSIS
     ${cmd} [ install | build | snoop ] [options]


DESCRIPTION
     Sample script for installing and running tshark packet analysis
     for the purpose of snooping cryptographic negotiation between
     LDAP client and OUD.

     Note that this script requires sudo.

OPTIONS
     The following options are supported:

         -p <port>               Encrypted port to snoop
                                 Default: 1636

         -n <seconds>            Number of seconds to capture packets
                                 Default: 5

         -T                      Use TCP Dump to capture packets

EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
quiet='false'
useTcpDump='false'
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            pnum) myPnum="$1";pnum="${myPnum}";shift;;
            host) myHost="$1";shift;;
            tcpdump) useTcpDump='true';;
            14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            T) useTcpDump='true';;
            p) port="$1";shift;;
            n) duration="$1";shift;;
            q) quiet='true';;
            z) dbg='true';;
        esac;;
    esac
done

if [ -n "${myPnum}"   ];then pnum=${myPnum};else pnum=1;fi
if [ -n "${myHost}"   ];then dsHost=${myHost};fi
if [ -z "${dsHost}"   ];then dsHost=${localHost};fi
if [ -z "${port}"     ];then port=${pnum}636;fi
if [ -z "${duration}" ];then duration=5;fi

###############################################################################
# Install Wireshark
###############################################################################
install_wireshark() {
   if [ "${dbg}" == 'true' ];then set -x;fi
   sudo -n yum install -y wireshark > ${logdir}/install-wireshark-${now}.log 2>&1
   rc=$?
   if [ ${rc} -ne 0 ]
   then
      echo -e "ERROR: Install failed.  See log:\n  ${logdir}/install-wireshark-${now}.log"
      exit 1
   fi

   tSharkVer=$(tshark -v|grep "^TShark"|tr -d -c '[0-9.]')
   tSharkVerMajor=$(echo ${tSharkVer}|cut -d. -f1)
   if [ -e "/usr/sbin/tshark" ]
   then
      echo "Wireshark ${tSharkVer} successfully installed"
   else
      echo -e "ERROR: Something went wrong. tshark command not found. See log:\n  ${logdir}/install-wireshark-${now}.log"
   fi
}

###############################################################################
# Build Wireshark
###############################################################################
build_wireshark() {
   if [ ${buildSupported} == 'false' ]
   then
      echo "ERROR: RedHat/Oracle/CentOS version 8 or newer required to build tshark"
      exit 1
   fi
   let steps++
   echo "Step ${steps}: Install requisite packages"
   if [ "${dbg}" == 'true' ];then set -x;fi
   sudo -n yum install -y git cmake cmake3 qt5-qttools-devel qt5-qttools qt5-qtsvg-devel qt5-qtmultimedia-devel libpcap libgcrypt-devel libgcrypt bison flex c-ares-devel c-ares perl-open > ${logdir}/build-wireshark-${now}.log 2>&1
   rc=$?
   if [ ${rc} -ne 0 ]
   then
      echo -e "ERROR: Prequisite package install failed.  See log:\n  ${logdir}/build-wireshark-${now}.log"
      exit 1
   fi

   if [ -e "${swdir}/wireshark/INSTALL" ]
   then
      true
   else
      let steps++
      echo "Step ${steps}: Retrieve source code from github"
      git clone https://github.com/wireshark/wireshark ${swdir}/wireshark >> ${logdir}/build-wireshark-${now}.log 2>&1
      rc=$?
      if [ ${rc} -ne 0 ]
      then
         echo -e "ERROR: Git clone failed.  See log:\n  ${logdir}/build-wireshark-${now}.log"
         exit 1
      fi
   fi

   mkdir -p "${swdir}/wireshark/build"
   cd "${swdir}/wireshark/build"

   if [ -e "${swdir}/wireshark/build/CMakeCache.txt" ]
   then
      true
   else
      let steps++
      echo "Step ${steps}: Prepare code for compilation"
      cmake ../ >> ${logdir}/build-wireshark-${now}.log 2>&1
      rc=$?
      if [ ${rc} -ne 0 ]
      then
         echo -e "ERROR: cmake failed.  See log:\n  ${logdir}/build-wireshark-${now}.log"
         exit 1
      fi
   fi
 
   if [ -e "${swdir}/wireshark/build/run/tshark" ]
   then
      true
   else
      let steps++
      echo "Step ${steps}: Compile wireshark"
      make >> ${logdir}/build-wireshark-${now}.log 2>&1
      rc=$?
      if [ ${rc} -ne 0 ]
      then
         echo -e "ERROR: make failed.  See log:\n  ${logdir}/build-wireshark-${now}.log"
         exit 1
      fi
   fi

   if [ -e "${swdir}/wireshark/build/run/tshark" ]
   then
      true
   else
      echo -e "ERROR: Something went wrong.  See log:\n  ${logdir}/build-wireshark-${now}.log"
      exit 1
   fi
   set +x

   tSharkVer=$(tshark -v|grep "^TShark"|awk '{ print $2 }')
   echo "Wireshark ${tSharkVer} successfully built"
   echo "tshark command: ${swdir}/wireshark/tshark"
}

###############################################################################
# Snoop cryptograhpic negotiation
###############################################################################
snoop_negotiation() {
   if [ "${quiet}" == 'false' ]
   then
      echo "Snooping for cryptographic negotiation"
   fi

   if [ -e "${tshark}" ];
   then
      tSharkVer=$(tshark -v|grep "^TShark"|tr -d -c '[0-9.]')
      tSharkVerMajor=$(echo ${tSharkVer}|cut -d. -f1)

      if [ "${osVersion}" == "OL7" ] && [ "${quiet}" == 'false' ]
      then
         echo -e "NOTE: RedHat/Oracle Linux 7 shows TLSv1.3 as TLSv1.2 and displays\nTLSv1.3 cipher suites as:\n   Cipher Suite: Unknown"
      fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ ${tSharkVerMajor} -ge 3 ]; then useTcpDump='true';else tshark=/usr/sbin/tshark;fi
      if [ "${useTcpDump}" == 'false' ]
      then
         sudo -n ${tshark} -i any -d "tcp.port==${port},ssl" -a duration:${duration} -V 2> /dev/null | egrep "Cipher Suites \(|Cipher Suite:|^            Version: |Record Layer: Handshake Protocol: Client Hello|Handshake Protocol: Server Hello|Record Layer"| uniq | sed -e "s/(0x.*)//g" -e "s/.* Record Layer: Handshake Protocol: Client Hello/Client requested:/g" -e "s/.*Version:/   Protocol Version:/g" -e "s/.*Cipher Suites /   Cipher Suites Requested:/g" -e "s/.*Handshake Protocol: Server Hello/Server replied with:/g" |egrep -v "Server replied with: Done"
      else
         tfile="${tmpdir}/tsharkdump-${now}"
         rm -f "${tfile}" 2> /dev/null
         sudo -n timeout ${duration} sudo -n tcpdump -s 65535 -w "${tfile}" -i any "tcp port ${port}" > ${logdir}/tshark-snoop-${now}.log 2>&1
         ${tshark} -r "${tfile}" -d "tcp.port==${port},ssl" -V 2> /dev/null | egrep "Cipher Suites \(|Cipher Suite:|^            Version: |Record Layer: Handshake Protocol: Client Hello|Handshake Protocol: Server Hello|Record Layer"| uniq | sed -e "s/(0x.*)//g" -e "s/.* Record Layer: Handshake Protocol: Client Hello/Client requested:/g" -e "s/.*Version:/   Protocol Version:/g" -e "s/.*Cipher Suites /   Cipher Suites Requested:/g" -e "s/.*Handshake Protocol: Server Hello/Server replied with:/g" |egrep -v "Server replied with: Done"
         rm -f "${tfile}" 2> /dev/null
      fi
      set +x
   else
      echo "ERROR: Cannot find tshark"
   fi

}

###############################################################################
# Test cryptograhpic negotiation
###############################################################################
test_crypto_negotiation() {
   # Make sure OUD is installed for ldap commands
   ${curdir}/manage_install.sh install oud --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag}

   # Disable all JDK-based restrictions to allow all protocols and cipher sutites to be allowed
   export OPENDS_JAVA_ARGS="-Djava.security.properties=${samples}/sslv3-java.security"
   #${curdir}/manage_oud.sh stop --pnum 1
   #set-connection-handler-prop --handler-name "LDAP Connection Handler" --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1 --add ssl-protocol:SSLv3 --no-prompt
   #${curdir}/manage_oud.sh start --pnum 1

   cd "${samples}"
   for tlscfg in tlsconfig-*.properties
   do
      echo -e '\n###############################################################################'
      tlsVersion=$(grep tls_protocols ${tlscfg}|cut -d'=' -f2)
      let steps++
      echo "Step ${steps}: Test cryptographic negotiation for ${tlsVersion}"
      if [ "${dbg}" == 'true' ];then set -x;fi
      export OPENDS_JAVA_ARGS=" -Dcustom.config.location=${samples}/${tlscfg} -Djava.security.properties=${samples}/sslv3-java.security"
      snoop_negotiation &
      ${oudmwdir}/oud${pnum}/OUD/bin/ldapsearch -T -h ${dsHost} -Z -X -p ${port} -b 'cn=schema' -s base 'objectClass=top' dn
      rc=$?
      if [ ${rc} -eq 1 ]
      then
         echo -e "ERROR: jdk.tls.disabledAlgorithms may need to be relaxed in:\n   ${JAVA_HOME}/jre/lib/security/java.security"
      fi
      wait
   done
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
       'install') install_wireshark;;
         'build') build_wireshark;;
         'snoop') snoop_negotiation;;
          'test') test_crypto_negotiation;;
               *) showUsage;;
esac
