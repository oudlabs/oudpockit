#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################
options=''
ldifFile=''
pgsz=500 # Data Chunk Size in number of entries
pgmax=1000000
n=0
dit[$n]=''
dnCnt=0

logFile="${logdir}/bulk_load-${now}.log"

refresh=4
entries=0
tCnt=0
forceAction='false'
avgRate=0
paused_by=''

#
# Option defaults
#
ditOption='false'
logOption='true'
reportOption='true'
rollBackOption='true'
monitorOption='false'
modulateOption='true'
dupCheckOption='true'
filterAttrOption='true'
filterDnOption='true'
preProcess='true'

###############################################################################
#
# Usage Message Handler
#
showUsage() {
   findpager
   cat <<EOF | ${pgcmd}
DS Administration Commands                     bulkloadldif(1M)

NAME
     bulkloadldif - A general purpose bulk loading directory servicces tool.

SYNOPSIS
     Normal usage:
     bulkloadldif -f <ldif_file> -h <host> -p <port> -j <pw_file> [other options]

     See proper usage:
     bulkloadldif -H

DESCRIPTION
     The purpose of bulkloadldif is to provide a general purpose tool for
     safely bulk loading data from an input LDIF file to a directory service 
     over the LDAP protocol.

OPTIONS
     The following options are supported:

     -l               Show the CDDL license.

     -f <file>        Specify the input LDIF file.

     -h <host>        Specify the host name or IP address of the directory server.

     -p <port>        Specify the LDAP port number of the directory server.
                      Default: 389

     -D "<rootuser>|<monitoruser>"
                      Specify the root dn user.  In addition, you can optionally
                      specify an specific user for the monitoring probes.
                      Default[for both]: cn=Directory Manager

     -j "<rootuser file or pw>|<monitoruser file or pw>"
                      Specify the password of the root dn user.  In addition, you
                      can optionally specify the monitoring user's password.

     -F               Automatically respond 'yes' to all questions. a.k.a. Force
                      Default: Do NOT force

     -c <size>        Specify the data page size in terms of number of entries 
                      per page
                      Default: 1000 [Max is 1,000,000]

     -r <seconds>     Specify the refresh rate in seconds of the status.
                      Default: 1

     -t <threads>     Specify the initial number of threads to use when loading
                      the data.
                      Default: 4

     -T <add|mod|del> Specify the input LDIF file format.
                      Default: add

     -o "<opt1>, <opt2>, ... <optN>"
                      Specify optional features to enable or disable.  If a feature
                      is specified multiple times, the last instance of the feature
                      is what is applied.  Here are the available features:

                         dit = Determine the requisite DIT structure in order for 
                            the input LDIF file to be processed without error.  If the
                            requisite DIT does not exist, the script will exit with an
                            error message before applying any changes from the LDIF 
                            file.
                            Default: The dit option is enabled by default.

                         nodit = Disable the dit option.

                         log = Send all output to a log file.
                            Default: The log option is enabled by default.

                         nolog = Disable the log option.

                         monitor = Monitor the state of the directory server while
                            processing the changes in the LDIF input file.  See the
                            -m flag for a list of supported monitors.
                            Default: The monitor option is enabled by default.

                         nomonitor = Disable the monitor option.

                         modulate = Modulate the flow of new connections to the 
                            directory server based on the status of the monitoring
                            results relative to designated thresholds for each
                            monitor. For example, if the response time to to the
                            directory server exceeds 1,000ms, discontinue sending
                            new connections to the directory server until the 
                            response time drops below 1,000ms.
                            Default: The modulate option is enabled by default.

                         nomodulate = Disable the modulate option.

                         dupcheck = Check to see if the DN list has any duplicates.
                            Duplicate DNs in the LDIF input file means that a DN
                            may get altered multiple times.  This could cause 
                            data consistency problems if the DNs are not processed
                            in the desired order due to the multi-threaded loading
                            used by this bulk loader.
                            Default: The dupcheck option is enabled by default.

                         nodupcheck = Disable the dupcheck option.

     -m "rt|rw|rqb|ar"
                      Specify the monitoring thresholds.
                         rt  = Response time of an ldapsearch. [Default: 1000ms]
                         rw  = readWaiters threshold. [Default: 3]
                         rqb = request-que-backlog threshold. [Default: 5]
                         ar  = Maximum average rate of LDAP operations. [Default: 500]

     -L <file>        Specify the output log file.
                      Default: bulk_loading-<date>.log

     -H               Show the usage of the bulkloadldif command.

INTERACTIVE BULK LOAD CONTROL

     Once the bulk loader reaches the point at which it starts to load
     data, you can enter Ctrl-C to see the following menu of options
     for controlling the data load.

+-----------------------------------------------+
| (i)ncrease (d)ecrease (p)ause (r)esume (q)uit |
+-----------------------------------------------+
Please choose one of the options above :

     When you enter "i" followed by [Enter], this increases the maximum
     threads by 1.
     
     When you enter "d" followed by [Enter], this decreases the maximum
     threads by 1.

     When you enter "p" followed by [Enter], this sets the threads to 0
     and waits for the remaining active threads to complete processing.

     When you enter "r" followed by [Enter], this resets the threads to 
     the value they were set to when the bulk load was paused. 

     When you enter "q" followed by [Enter], this sets the threads to 0
     and waits for the remaining active threads to complete processing and
     then exits.


EXAMPLES

     Example 1:  Add new 100,000 new subscriber entries.

     The following command will add 100,000 new subscriber entries to the 
     directory service.  The bulk loader will run as many as 4 (default) threads
     simultaneously.  Each thread will process 1,000 entries (default page size)
     before closing the LDAP connection for that thread.

         # bulkloadldif -f /add100kSubscribers.ldif -h dsM1 -w /.pwf 


     Example 2:  Add a single new attribute to all 100,000 subscriber entries.

     The following command will add a single new attribute to all 100,000 
     subscriber entries.  The bulk loader will run as many as 4 (default) 
     threads simultaneously.  Each thread will process 1,000 entries (default 
     page size) before closing the LDAP connection for that thread.

         # bulkloadldif -f /addAttr.ldif -h dsM1 -T mod -w /.pwf 


     Example 3:  Modify a single attribute on all 100,000 subscriber entries.

     The following command will modify a single attribute on all 100,000 
     subscriber entries.  The bulk loader will run as many as 4 (default) 
     threads simultaneously.  Each thread will process 1,000 entries (default 
     page size) before closing the LDAP connection for that thread.

         # bulkloadldif -f /modAttr.ldif -h dsM1 -T mod -w /.pwf 

NOTES

     Note that GNU(TM) sed is required because none of the sed versions 
     that come with Solaris(TM) can handle long strings.  You can obtain 
     GNU(TM) sed for Solaris(TM) from either of the following sites:
        http://www.sunfreeware.com/
        http://www.blastwave.org/
     References on this subject:
        http://www.mail-archive.com/libtool@gnu.org/msg01707.html
        http://www.grymoire.com/Unix/Sed.html
        http://www.scit.wlv.ac.uk/cgi-bin/mansec?1B+sed

EOF

   exit 2
}

###############################################################################
#
# Error Message Handler
#
error_message() {
   echo -e "Error: $1"
   #exit 1
}

###############################################################################
#
# Show status
#
show_status() {
   myMsg="${1}"
   now=$(date +"[%d/%h/%Y:%H:%M:%S %z]")
   if [ -n "${myMsg}" ]
   then
      if [ "${logOption}" == 'true' ]
      then
         echo -e "${now}|${myMsg}" | tee -a "${logFile}"
      else
         echo -e "${now}|${myMsg}"
      fi
   else
      posentrycnt=$(($(egrep "operation successful for DN" "${ldifFile}".[0-9]*.out 2> /dev/null | wc -l) + 0))
      negentrycnt=$(($(egrep "^Additional Information: |(Entry Already Exists)" "${ldifFile}".[0-9]*.out 2> /dev/null | wc -l) + 0))
      entries=$((${posentrycnt}+${negentrycnt}))
      if [ ${entries} -gt 0 ]
      then
         avgRate=$((${entries}/(${cTimeN} - ${sTime})))
         pComplete=$((100*${entries}/${dnCnt}))
      else
      avgRate=0
         pComplete=0
      fi
      if [ "${logOption}" == 'true' ]
      then
         echo -e "${now}|Processed ${entries} of ${dnCnt} (${pComplete}%)|${avgRate} entries/sec|${negentrycnt} failed|threads=${tCnt}|${ds_state}" | tee -a "${logFile}"
      else
         echo -e "${now}|Processed ${entries} of ${dnCnt} (${pComplete}%)|${avgRate} entries/sec|${negentrycnt} failed|threads=${tCnt}|${ds_state}"
      fi
   fi
}

###############################################################################
#
# Set up trap and associated menu
#
send_menu() {
   trap 'send_menu' HUP TERM INT
   menu="\n+-----------------------------------------------+\n| (i)ncrease (d)ecrease (p)ause (r)esume (q)uit |\n+-----------------------------------------------+"

   show_status "$menu"
   read -p "Please choose one of the options above : " option
   case ${option} in
      i)   maxThreads=$((${maxThreads}+1)); show_status "Increasing thread count by 1 to ${maxThreads}.";;
      d)   if [ $maxThreads -le 0 ]
           then
              show_status "Cannot decrease threads right now.  Try again later."
           else
              maxThreads=$((${maxThreads}-1))
              show_status "Decreasing thread count by 1 to ${maxThreads}."
           fi
           ;;
      p)   saveMaxThreads=${maxThreads};maxThreads=0; show_status "Pausing bulk load"; paused_by='ctrlC';;
      r)   if [ "$paused_by" != 'ctrlC' ]
           then
              show_status "Cannot resume from pause right now.  Try again later."
           else
              maxThreads=${saveMaxThreads}; 
              show_status "Resuming bulk load"; paused_by=''
           fi
           ;;
      q)   show_status "Gracefully quitting"; maxThreads=0; wait; exit;;
      *)   if [ "${logOption}" == 'true' ]
           then
              echo "Sorry, that isn't an option, try again. " | tee -a "${logFile}"
           else
              echo "Sorry, that isn't an option, try again. "
           fi
           sleep ${refresh}
           ;;
   esac
}

##############################################################################
#
# Find pager
#
findpager() {
   #
   # Set the page command
   #
   pgcmd='cat - '
   ck4less=$(which less 2>&1 | grep -v "no less")
   if [ -n "${ck4less}" ]
   then
      pgcmd='less'
   else
      ck4more=$(which more 2>&1 | grep -v "no more")
      if [ -n "${ck4more}" ]
      then
         pgcmd='more'
      fi
   fi
}


###############################################################################
#
# Validate the pre-requisite software is installed
#
sed=''
for sed_candidate in /opt/csw/bin/gsed /usr/local/bin/sed /usr/xpg4/bin/sed /usr/bin/sed /usr/ucb/sed /usr/xpg4/bin/sed /usr/local/Cellar/gnu-sed/4.7/libexec/gnubin/sed
do
   ckSed=$(echo 'foo' | "${sed_candidate}" --posix -ne '/^\(x\)*foo/p' 2>&1 | grep foo)
   if [ "${ckSed}" == 'foo' ]
   then
      sed="${sed_candidate}"
      break
   fi
done
if [ -z "${sed}" ]
then
   error_message "No supported sed command found.  Please download and install GNU(TM) sed."
fi

for prog in bash grep egrep awk cut tee date
do
   ck4prog=$(which $prog | grep "^no $prog ")
   if [ -n "$ck4prog" ]
   then 
      error_message "$prog is required by $0"
   fi
done

##############################################################################
#
# Function to seek assurance
#
are_you_sure() {
   faction="$1"
   if [ "$forceAction" == 'false' ]
   then
      echo -e "\n$faction [no] \c"
      read ck4response
      ck4response=$(echo $ck4response | ${sed} --posix -e "y/ABCDEFGHIJKLMNOPQRSTUVWXYZ/abcdefghijklmnopqrstuvwxyz/")
      if [ "$ck4response" != 'yes' ]
      then
         error_message "You chose not to perform action \"$faction\"."
      fi
   else
      show_status "The \"$faction\" action was forced with the -F parameter."
   fi
}

##############################################################################
#
# If any parameters were passed evaluate their usage...
#
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            csvFile) csvFile="$1";;
            ldifFile) ldifFile="$1";;
            rdn) my_rdn="$1";shift;;
            suffix) suffix="$1";shift;;
            pgsz) pgsz="$1";shift;;
            overwrite) overwrite="true";;
            nochunk) preProcess='false';;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            o) options="$1";shift;;
            f) ldifFile="$1";shift;;
            L) logFile="$1";shift;;
            c) pgsz="$1";shift;;
            h) host="$1";shift;;
            p) port="$1";shift;;
            D) bDN="$1";shift;;
            j) jPW="$1";shift;;
            m) mDN="$1";shift;;
            M) mPW="$1";shift;;
            r) refresh="$1";shift;;
            t) maxThreads="$1";shift;;
            F) forceAction='true';;
        esac;;
    esac
done

#
# Validate the presence of the essential properties
#
if [ -z "${ldifFile}" ];then error_message "Must specify an input LDIF file.";fi
if [ -e "${ldifFile}" ];then true; else error_message "LDIF file (${ldifFile}) does not exist";fi
errorsFile="${ldifFile}.errors"

ck4mod=$(head -10000 ${ldifFile}|grep -i changetype)
ck4add=$(head -10000 ${ldifFile}|grep -i objectclass)
if [ -n "${ck4mod}" ]
then
   ldapcmd="${lmod}"
   ldapargs="-c"
elif [ -n "${ck4add}" ]
then
   ldapcmd="${lmod}"
   ldapargs="-a -c"
else
   ldapcmd="${ldel}"
   ldapargs="-c"
fi
set +x

dnfile="${ldifFile}.DNs"
preProcessingFile="${ldifFile}.pre"
rm -f "$dnfile" "$preProcessingFile"

if [ ${pgsz} -lt 1 ]
then
   error_message "The page size must be greater than 0"
elif [ $pgsz -gt $pgmax ]
then
   error_message "The page size must be less than $pgmax"
fi

if [ -z "${host}" ];then host=${localHost};fi
if [ -z "${port}" ];then port='1389';fi
if [ -z "${bDN}" ];then bDN='cn=Directory Manager';fi
if [ -z "${mDN}" ];then mDN="${bDN}";fi

if [ -n "${jPW}" ] && [ -e "${jPW}" ];then bPW=$(cat ${jPW});fi
if [ -z "${mPW}" ];then mPW="${bPW}";fi
if [ -z "$bPW" ];then error_message "Must specify root dn password."; fi


if [ -z "${maxThreads}" ];then maxThreads=5;fi

if [ ${refresh} -lt 1 ] || [ ${refresh} -gt 100 ]
then 
   error_message "The refresh rate must be betweeen 1 an 100 seconds"
fi

#
# If monitor thresholds not set, set them to safe system defaults.
#
if [ -z "${maxRespTime}" ]; then maxRespTime=200; fi
if [ -z "${maxReadWaiters}" ]; then maxReadWaiters=20; fi
if [ -z "${maxRequestQueBacklog}" ]; then maxRequestQueBacklog=5; fi
if [ -z "${maxAvgRate}" ]; then maxAvgRate=50000; fi
if [ -z "${maxMissingChanges}" ]; then maxMissingChanges=1000; fi

#
# Break out the options
#
options=$(echo ${options} | sed -e "s/[ 	,|]/ /g" | tr -s '[:upper:]' '[:lower:]')
for o in ${options}
do
   case ${o} in
     'dit') ditOption='true';;
     'nodit') ditOption='false';;
     'log') logOption='true';;
     'nolog') logOption='false';;
     'report') reportOption='true';;
     'noreport') reportOption='false';;
     'rollback') rollBackOption='true';;
     'norollback') rollBackOption='false';;
     'monitor') monitorOption='true';;
     'nomonitor') monitorOption='false';;
     'modulate') modulateOption='true';;
     'nomodulate') modulateOption='false';;
     'dupcheck') dupCheckOption='true';;
     'nodupcheck') dupCheckOption='false';;
     'filterattr') filterAttrOption='true';;
     'nofilterattr') filterAttrOption='false';;
     'filterdn') filterDnOption='true';;
     'nofilterdn') filterDnOption='false';;
   esac
done

##############################################################################
#
# Purge all old data
#
if [ -e "${ldifFile}" ]
then 
   rm -f ${logFile} ${ldifFile}.*.out ${ldifFile}.*.errors ${ldifFile}.[0-9]* 2> /dev/null
fi

##############################################################################
#
# Perform specified pre-processor types
#
if [ "$ditOption" == 'true' ] || "$dupCheckOption" == 'true' ]
then
   show_status "Perform requisite DIT and duplicate checks..."
   ###########################################################################
   # Determine the requisite DIT structure and store in array (dit[])
   # To do this, we must do the following:
   #   1. strip all line wrapping that may exist in the LDIF so that we 
   #      get the full dn attr
   #   2. then filter down to just the dn attrs
   #   3. then sort by length 
   #   4. then normalize all quotes 
   #
   ${sed} --posix -e "s/^ /__EOL2TRIM__/g" -e "s/$/__EOL__/g" "${ldifFile}" \
      | tr -d '\n' \
      | ${sed} --posix -e "s/__EOL____EOL2TRIM__//g" -e "s/__EOL__/\n/g" \
      | grep "^dn: " \
      | awk '{ print length, $0 }' \
      | sort -n \
      | awk '{$1=""; print $0}' \
      | ${sed} --posix -e "s/^dn: //g" -e "s/\"/__DQ0UT3__/g" \
            -e "s/'/__FQ0UT3__/g" -e "s/\`/__BQ0UT3__/g" \
      > "$dnfile" 
fi

if [ "$ditOption" == 'true' ]
then
   ########################################################################
   #
   # Store the DIT structure into array
   #
   show_status "Derive DIT structure..."
   while read dn;
   do
      rdn=$(echo $dn | cut -d'=' -f1)
      rdnvalue=$(echo $dn | cut -d'=' -f2 | cut -d',' -f1)
      base=$(echo $dn | cut -d',' -f2- | ${sed} --posix -e "s/__DQ0UT3__/\"/g" -e "s/__FQ0UT3__/\'/g" -e "s/__BQ0UT3__/\\\`/g" -e "s/^ //g")
      if [ ${#dit[*]} -ge 1 ]
      then
         isBaseInDit='false'
         p=0
         while [ $p -lt ${#dit[*]} ]
         do
            if [ "$base" == "${dit[$p]}" ]
            then
               isBaseInDit='true'
            fi
            p=$(($p+1))
         done
         if [ "$isBaseInDit" == 'false' ]
         then
            n=$(($n+1))
            dit[$n]=$(echo $base | ${sed} --posix -e "s/^dn: //g")
         fi
      else
         dit[$n]=$(echo $base | ${sed} --posix -e "s/^dn: //g")
      fi
      dnCnt=$((${dnCnt}+1))
   done < "$dnfile"
   show_status "The requisite DIT has now been determined."
else
   dnCnt=$(($(grep "^dn: " ${ldifFile} | wc -l) + 0))
fi

#
# Check for duplicate dn entries
#
if [ "$dupCheckOption" == 'true' ]
then
   uniq_dnCnt=$(cat "$dnfile" | uniq | wc -l)
   if [ $dnCnt -gt $uniq_dnCnt ]
   then
      show_status "There are duplicate DN entries in the input LDIF file."
      are_you_sure "Do you want to proceed even though there are duplicate DN entries?"
   fi
fi

#
# Remove the dn file now that we are done with it
#
if [ -e "${dnfile}" ]
then
   rm -f "${dnfile}"
fi

##############################################################################
#
# Determine if any of the DIT branches are touched by LDIF file.  If true
# apply these changes before everything else.
#
if [ "$preProcess" == 'true' ]
then
   show_status "Begin pre-processing analysis and partition data into sets..."
   workingDN='false'
   e=1
   chunk=1
   cp /dev/null "${ldifFile}.${chunk}" 
   while read dline;
   do
      if [ "$preProcessor" == 'dit' ]
      then
         p=0
         while [ $p -lt ${#dit[*]} ]
         do
            if [ "$dline" == "dn: ${dit[$p]}" ]
            then
               workingDN='true'
               show_status "Queuing dn \"${dit[$p]}\" for pre-processing."
            fi
            p=$(($p+1))
         done
         #
         # Reset the workingDN when we reach the end of the entry
         #
         if [ "$workingDN" == 'true' ]
         then
            echo "$dline" >> "$preProcessingFile"
            if [ -z "$dline" ];
            then 
               workingDN='false'; 
            fi
         fi
      fi

      #
      # Make chunks for threaded loading...
      #
      echo "$dline" >> "${ldifFile}.${chunk}"
      if [ -z "$dline" ];then e=$(($e+1));fi
      if [ $e -gt ${pgsz} ];
      then 
         e=1 
         let chunk++
         cp /dev/null "${ldifFile}.${chunk}"
      fi

   done < "${ldifFile}"
   show_status "Completed pre-processing analysis and partition data into ${chunk} sets..."
fi

##############################################################################
#
# Seek confirmation to commit changes
#
#are_you_sure "Do you want to apply the changes contained in (${ldifFile}) to the directory?"

##############################################################################
#
# Apply DIT structure changes (if any exist)
#
if [ "$preProcessor" == 'dit' ]
then
   if [ -s "$preProcessingFile" ]
   then
      show_status "Applying pre-procesing changes."
      ${ldapcmd} ${ldapargs} -h ${host} -p ${port} -D "${bDN}" -w "${bPW}" \
          -f "$preProcessingFile" > "$preProcessingFile.out" 2>&1 &
      show_status "Pre-procesing changes complete."
   fi
fi

##############################################################################
#
# Validate the DIT structure in DS
#
if [ "$preProcessor" == 'dit' ]
then
   show_status "Validating the presence of the requisite DIT structure in the directory server..."
   p=0
   while [ $p -lt ${#dit[*]} ]
   do
      if [ -n "${dit[$p]}" ]
      then 
         #
         # Search fo the presence of the DIT branch
         #
         show_status "DIT Branch: ${dit[$p]}"
         "${lsrch}" -h ${host} -p ${port} -D "${mDN}" -w "${bPW}" \
           -b "${dit[$p]}" -s base objectClass=* dn  > /dev/null 2>&1
         if [ $? -ne 0 ];
         then 
            error_message "DIT branch ${dit[$p]} does not exist.\nAll requisite DIT branches must exist.  Exiting!"
         fi
      fi
      p=$(($p+1))
   done
   show_status "The requisite DIT structure exists."
fi

##############################################################################
#
# Calculate the total number of chunks
#
tChunks=$((${dnCnt}/${pgsz}+2))

##############################################################################
#
# Check the response time of an ldapsearch operation.
#
check_respTime() {

   { time "${lsrch}" -h ${host} -Z -X -p ${adminPort} -D "${mDN}" -w "${mPW}" -b "cn=monitor" -s sub '(objectClass=top)' > ${mFile} 2> /dev/null ; } 2>> ${mFile}
   rc=$?

   #
   # Make sure we got a valid response
   #
   ck4err=$(grep "^dn: cn=monitor$" ${mFile})
   if [ "${ck4err}" != "dn: cn=monitor" ]
   then
      error_message "Response time check failed with error: $ck4err"
   fi
   
   #
   # Extract the response time from timex output
   #
   respTimeFloat=$(tail -10 ${mFile}|grep "^real " | awk '{ print $2 }')

   if [ "$modulateOption" == 'true' ]
   then
      respTimeInt=$((($(echo ${respTimeFloat} | cut -d'.' -f1) + 0)*1000))
      respTimeRem=$((($(echo ${respTimeFloat} | cut -d'.' -f2 | sed -e "s/^0//g") + 0)*10))
      respTime=$((${respTimeInt} + ${respTimeRem}))
      if [ ${respTime} -gt ${maxRespTime} ]
      then  
         if [ -z "${paused_by}" ]
         then
	    show_status "Exceeded search response time (${respTime} ) threshold of ${maxRespTime}. Suspending new connections."
            paused_by='respTime'
            saveMaxThreads=${maxThreads}
            maxThreads=0
         fi
      elif [ ${respTime} -le ${maxRespTime} ]
      then  
         if [ "${paused_by}" == 'respTime' ]
         then
            show_status "Search response time normalized.  Resuming new connections."
            paused_by=''
            maxThreads=${saveMaxThreads}
            saveMaxThreads=0
         fi
      fi
   fi
}

##############################################################################
#
# Check the readWaiters metric
#
check_readWaiters() {
   #
   # Get the readWaiters data from cn=montior
   #
   if [ -e "${mFile}" ]
   then
      readWaiters=$(cat ${mFile}|grep EnvironmentNWaiters|awk ' BEGIN { t = 0; }{ t += $2; } END { print sprintf("%.0f", t); }')
   else
      readWaiters=0
   fi

   #
   # Make sure we got a valid response
   #
   if [ -z "${readWaiters}" ]
   then
      error_message "Cannot check the readWaiters attribute of cn=monitor"
      readWaiters=0
   fi

   if [ "$modulateOption" == 'true' ]
   then
      if [ ${readWaiters} -gt ${maxReadWaiters} ]
      then  
         if [ -z "${paused_by}" ]
         then
            show_status "Exceeded readWaiters threshold. Suspending new connections."
            paused_by='readWaiters'
            saveMaxThreads=${maxThreads}
            maxThreads=0
         fi
      elif [ ${readWaiters} -le ${maxReadWaiters} ]
      then  
         if [ "${paused_by}" == 'readWaiters' ]
         then
            show_status "Read waiters threshold normalized.  Resuming new connections."
            paused_by=''
            maxThreads=${saveMaxThreads}
            saveMaxThreads=0
         fi
      fi
   fi
}

##############################################################################
#
# Check the requestQueBacklog metric
#
check_requestQueBacklog() {
   #
   # Get the request-que-backlog data from cn=montior
   #
   if [ -e "${mFile}" ]
   then
      requestQueBacklog=$(cat ${mFile}|grep averageRequestBacklog|sed -e "s/^.*: //g")
   else
      requestQueBacklog=0
   fi

   #
   # Make sure we got a valid response
   #
   if [ -z "${requestQueBacklog}" ]
   then
      error_message "Cannot check the request-que-backlog attribute of cn=monitor"
      requestQueBacklog=0
   fi

   if [ "$modulateOption" == 'true' ]
   then
      if [ ${requestQueBacklog} -gt ${maxRequestQueBacklog} ]
      then  
         if [ -z "${paused_by}" ]
         then
            show_status "Exceeded request queue backlog threshold. Suspending new connections."
            paused_by='requestQueBacklog'
            saveMaxThreads=${maxThreads}
            maxThreads=0
         fi
      elif [ ${requestQueBacklog} -le ${maxRequestQueBacklog} ]
      then  
         if [ "${paused_by}" == 'requestQueBacklog' ]
         then
            show_status "Request queue backlog normalized.  Resuming new connections."
            paused_by=''
            maxThreads=${saveMaxThreads}
            saveMaxThreads=0
         fi
      fi
   fi
}

##############################################################################
#
# Check the avgRate metric
#
check_avgRate() {
   if [ ${avgRate} -gt 0 ]
   then
      if [ "$modulateOption" == 'true' ]
      then
         if [ ${avgRate} -gt ${maxAvgRate} ]
         then  
            if [ -z "${paused_by}" ]
            then
               show_status "Exceeded search average rate threshold.  Suspending new connections."
               paused_by='avgRate'
               saveMaxThreads=${maxThreads}
               maxThreads=0
            fi
         elif [ ${avgRate} -le ${maxAvgRate} ]
         then  
            if [ "${paused_by}" == 'avgRate' ]
            then
               show_status "Search average rate normalized.  Resuming new connections."
               paused_by=''
               maxThreads=${saveMaxThreads}
               saveMaxThreads=0
            fi
         fi
      fi
   fi
}

##############################################################################
#
# Check the requestQueBacklog metric
#
check_missingChanges() {
   rduration=$((${cTimeN} - ${rTime}))
   if [ ${rduration} -ge $((${refresh}*8)) ]
   then
      prevMissingChanges=${missingChanges}
      ${drepl} status -s --dataToDisplay compact-view --hostname ${host} --port ${adminPort} --portProtocol auto-detect --adminPasswordFile "${jPW}" --bindDN "${mDN}" --trustAll --no-prompt --connectTimeout 1000000 --readTimeout 1000000 2> /dev/null|grep "^Missing Changes"|sed -e "s/^.*: //g"|sort -unr|head -1 > ${rFile} &
      rTime=$(perl -e "print time;")
   fi

   if [ -e "${rFile}" ]
   then
      missingChanges=$(cat ${rFile})
      if [ -z "${missingChanges}" ]
      then
         missingChanges=${prevMissingChanges}
      fi
   else
      missingChanges=0
   fi

   #
   # Make sure we got a valid response
   #
   if [ -z "${missingChanges}" ]
   then
      error_message "Cannot check the replication status"
      missingChanges=0
   fi

      if [ "$modulateOption" == 'true' ]
      then
         if [ ${missingChanges} -gt ${maxMissingChanges} ]
         then  
            if [ -z "${paused_by}" ]
            then
               show_status "Exceeded missing change volume threshold.  Suspending new connections."
               paused_by='missingChanges'
               saveMaxThreads=${maxThreads}
               maxThreads=0
            fi
         elif [ ${avgRate} -le ${maxAvgRate} ]
         then  
            if [ "${paused_by}" == 'missingChanges' ]
            then
               show_status "Missing changes volume normalized.  Resuming new connections."
               paused_by=''
               maxThreads=${saveMaxThreads}
               saveMaxThreads=0
            fi
         fi
      fi
}

##############################################################################
#
# Set up function for forking threads
#
start_thread() {
   lcmd=$(basename ${ldapcmd})
   tCnt=$(($(ps -efo "ppid,comm" | grep "$$"|grep "${lcmd}"| wc -l) + 0))
   if [ ${tCnt} -lt ${maxThreads} ]
   then
      #if [ ${chunk} -le ${tChunks} ]
      #then
         if [ -e "${ldifFile}.${chunk}" ]
         then
            ${ldapcmd} ${ldapargs} -f "${ldifFile}.${chunk}" -h ${host} -p ${port} \
              -D "${bDN}" -w "${bPW}" > "${ldifFile}.${chunk}.out" 2>&1 &
            let chunk++
            let tCnt++
         fi
      #fi
   fi
}

##############################################################################
#
# Set up trap to manage bulk load
#
stty susp "" #Trapping CTRL-Z 2> /dev/null
trap 'send_menu' HUP TERM INT

##############################################################################
#
# Main section
#
cTime=$(perl -e "print time;")
sTime=${cTime}
rTime=${cTime}

chunk=1
while [ ${entries} -lt ${dnCnt} ]
do
   #
   # Launch threads
   #
   start_thread 

   #
   # Show the status
   #
   cTimeN=$(perl -e "print time;")
   duration=$((${cTimeN} - ${cTime}))
   if [ ${duration} -ge ${refresh} ]
   then
      check_now=$(date +'%Y%m%d%H%M%S')
      check_today=$(echo ${check_now}|cut -c1-6)
      mFile="${tmpdir}/m.${check_now}"
      rFile="${tmpdir}/r.${check_today}"

      #
      # Check DS State.  If one monitor pauses the state, make 
      # sure that monitor normalizes before checking any other 
      # monitors.
      #
      if [ "$monitorOption" == 'true' ]
      then
         case ${paused_by} in
            'ctrlC') true;;
            'respTime') check_respTime;;
            'readWaiters') check_readWaiters;;
            'requestQueBacklog') check_requestQueBacklog;;
            'missingChanges') check_missingChanges;;
            'avgRate') check_avgRate;;
            *) check_respTime;check_readWaiters;check_requestQueBacklog;check_avgRate;check_missingChanges;;
         esac
         ds_state="rt=${respTime}ms|rw=${readWaiters}|rqb=${requestQueBacklog}|mc=${missingChanges}"
      fi

      #
      # Show the status
      #
      show_status
      cTime=$(perl -e "print time;")

      #
      # Remove the temporary file
      #
      rm -f "${mFile}"
   fi
done

#
# Make error log from out files
#
negentrycnt=$(($(egrep "^Additional Information: |(Entry Already Exists)" "${ldifFile}".[0-9]*.out 2> /dev/null | wc -l) + 0))
if [ ${negentrycnt} -gt 0 ]
then
   grep "^Additional Information" ${ldifFile}.*.out > ${errorsFile}
fi

#
# Remove all meta-data files
#
wait
rm -f ${logFile} ${ldifFile}.*.out ${ldifFile}.*.errors ${ldifFile}.*[0-9]

if [ ${negentrycnt} -eq 0 ]
then
   show_status "Bulk data load complete."
else
   show_status "Bulk data load completed with ${negentrycnt} errors."
   show_status "   Errors logged in ${errorsFile}"
fi

#
# Show a summary success and failure report
#

# Restore suspend (^Z)
stty susp "^Z" 2> /dev/null
