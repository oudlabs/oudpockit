#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive 
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

   findpager
   cat << EOF | ${pgcmd}
NAME
     ${cmd} [ setup | start | stop | deinstall ] [options]

SYNOPSIS
     Setup OUDSM
        ${cmd} setup

     Start OUD instance
        ${cmd} start

     Stop OUD instance
        ${cmd} stop

     Un-install OUD instance
        ${cmd} deinstall

OPTIONS
     Setup Options
     The following options are supported:

         --12c                   Use settings for OUD 12cPS4

         --14c                   Use settings for OUD 14c
                                 Default: --14c is the default setting

         --ktype <type>          Key and trust store type (jks or p12)
                                 Default: p12

         --kstore <file>         Keystore file including full path

         --tstore <file>         Truststore file including full path

     
EOF

   exit 1

}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            bitsdir) bitsdir="$1";shift;;
            jh) export JAVA_HOME="$1";PATH="$JAVA_HOME:$PATH";shift;;
            ktype) ktype="$1";shift;;
            kstore) kstore="$1";shift;;
            tstore) tstore="$1";shift;;
            step) steps="$1";shift;;
            nosudo) sudoFlag=' --nosudo';;
            12c) fmwVersion='12c';oudsmmwdir="${fmwVersion}"; fmwFlag="--${fmwVersion}";;
            14c) fmwVersion='14c';oudsmmwdir="${fmwVersion}";fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            D) bDN="$1";;
            j) jPW="$1";;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done
setfmwenv

ktype=$(echo ${ktype}|tr '[:lower:]' '[:upper:]')
if [ -z "${ktype}" ];then ktype='JKS';fi
if [ "${ktype}" == 'P12' ];then ktype='PKCS12';fi

if [ "${ktype}" == 'JKS' ] && [ -z "${tstore}" ];then tstore="${certdir}/CA/truststore";fi
if [ "${ktype}" == 'JKS' ] && [ -z "${kstore}" ];then kstore="${certdir}/${localHost}/${localHost}.jks";fi

if [ "${ktype}" == 'PKCS12' ] && [ -z "${tstore}" ];then tstore="${certdir}/CA/truststore.p12";fi
if [ "${ktype}" == 'PKCS12' ] && [ -z "${kstore}" ];then kstore="${certdir}/${localHost}/${localHost}.p12";fi

if [ -n "${adPW}" ];then if [ -e "${adPW}" ];then adPW=$(cat ${adPW});fi;fi

###############################################################################
# Address error introduced by JDK security enhancement
#   There is an error with the certificate presented by the server <host>:1444. 
#   Details: java.security.cert.CertificateException: No subject alternative 
#      names present
export WL_ARGS='-Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true'

###############################################################################
# Create requisite directories and response files
###############################################################################
make_cfg_files() {
   if [ -e "${cfgdir}/oraInventory.loc" ]
   then
      true
   else
      cat > ${cfgdir}/oraInventory.loc <<EOF
inventory_loc=${cfgdir}/oraInventory
inst_group=${me}
EOF
   fi

   if [ -e "${cfgdir}/oudsm-fmw12c.rsp" ]
   then
      true
   else
      cat > ${cfgdir}/oudsm-fmw12c.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudsmmwdir}
INSTALL_TYPE=Fusion Middleware Infrastructure
EOF
   fi

   if [ -e "${cfgdir}/oudsm12c-shared.rsp" ]
   then
      true
   else
      cat > ${cfgdir}/oudsm12c-shared.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudsmmwdir}
INSTALL_TYPE=Collocated Oracle Unified Directory Server (Managed through WebLogic server)
EOF
   fi

   if [ -e "${cfgdir}/oudsm12c.py" ]
   then
      true
   else
      localIP=$(getent ahostsv4 ${localHost}|grep "${localHost}$"|awk '{ print $1 }')
      cat > ${cfgdir}/oudsm12c.py <<EOF
setTopologyProfile('Compact')
selectTemplate("Basic WebLogic Server Domain")
loadTemplates()
cd(r'/Security/base_domain/User/weblogic')
cmo.setPassword("${bPW}")
writeDomain('${oudsmmwdir}/domains/oudsm')
closeTemplate()
readDomain('${oudsmmwdir}/domains/oudsm')
cd('Servers/AdminServer')
cmo.setListenPort(${oudsmHttpPort})
#set('ListenAddress', '127.0.0.1')
#cmo.setListenAddress('127.0.0.1')
create('AdminServer','SSL')
cd('SSL/AdminServer')
cmo.setEnabled(true)
#cmo.setListenPort(${oudsmHttpsPort})
#set('ListenAddress', '${localIP}')
#cmo.setListenAddress('${localIP}')
updateDomain()
closeDomain()
readDomain('${oudsmmwdir}/domains/oudsm')
selectTemplate('Oracle Unified Directory Services Manager')
loadTemplates()
updateDomain()
closeDomain()
readDomain('${oudsmmwdir}/domains/oudsm')
selectTemplate('Oracle Unified Directory')
loadTemplates()
updateDomain()
closeDomain()
disconnect()
exit()
EOF
   fi

   if [ -e "${cfgdir}/oudsm12c-addSSL.py" ]
   then
      true
   else
      cat > ${cfgdir}/oudsm12c-addSSL.py <<EOF
connect('weblogic',"${bPW}",'t3://${localHost}:${oudsmHttpPort}')
edit()
startEdit()
print('== Change certificate store to CustomIdentityAndCustomTrust.')
cd('/Servers/AdminServer')
cmo.setKeyStores('CustomIdentityAndCustomTrust')
print('== Change certificate keystore to ${kstore}')
cmo.setCustomIdentityKeyStoreFileName("${kstore}")
cmo.setCustomIdentityKeyStoreType('${ktype}')
set('CustomIdentityKeyStorePassPhrase', "${bPW}")
print('== Change certificate truststore to ${tstore}')
cmo.setCustomIdentityKeyStoreFileName("${kstore}")
cmo.setCustomTrustKeyStoreFileName("${tstore}")
cmo.setCustomTrustKeyStoreType('${ktype}')
set('CustomTrustKeyStorePassPhrase', "${bPW}")
print('== Change certificate alias to server-cert.')
cd('/Servers/AdminServer/SSL/AdminServer')
cmo.setServerPrivateKeyAlias('server-cert')
set('ServerPrivateKeyPassPhrase', "${bPW}")
print('== Enable the secure port ${oudsmHttpsPort}.')
cmo.setEnabled(true)
cmo.setListenPort(${oudsmHttpsPort})
cmo.setJSSEEnabled(true)
save()
activate()
disconnect()
exit()
EOF
   fi

   if [ -e "${cfgdir}/oudsm-fmw14c.rsp" ]
   then
      true
   else
      cat > ${cfgdir}/oudsm-fmw14c.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudsmmwdir}
INSTALL_TYPE=Fusion Middleware Infrastructure
EOF
   fi

   if [ -e "${cfgdir}/oudsm14c-shared.rsp" ]
   then
      true
   else
      cat > ${cfgdir}/oudsm14c-shared.rsp <<EOF
[ENGINE]
Response File Version=1.0.0.0.0
[GENERIC]
DECLINE_AUTO_UPDATES=true
MOS_USERNAME=
MOS_PASSWORD=<SECURE VALUE>
AUTO_UPDATES_LOCATION=
SOFTWARE_UPDATES_PROXY_SERVER=
SOFTWARE_UPDATES_PROXY_PORT=
SOFTWARE_UPDATES_PROXY_USER=
SOFTWARE_UPDATES_PROXY_PASSWORD=<SECURE VALUE>
ORACLE_HOME=${oudsmmwdir}
INSTALL_TYPE=Collocated Oracle Unified Directory Server (Managed through WebLogic server)
EOF
   fi

   if [ -e "${cfgdir}/oudsm14c.py" ]
   then
      true
   else
#showAvailableTemplates()
      cat > ${cfgdir}/oudsm14c.py <<EOF
setTopologyProfile('Compact')
selectTemplate("Basic WebLogic Server Domain")
selectTemplate('Oracle Unified Directory')
selectTemplate('Oracle Unified Directory Services Manager')
loadTemplates()
cd(r'/Security/base_domain/User/weblogic')
cmo.setPassword("${bPW}")
writeDomain('${oudsmmwdir}/domains/oudsm')
closeTemplate()
readDomain('${oudsmmwdir}/domains/oudsm')
cd('Servers/AdminServer')
cmo.setListenPort(${oudsmHttpPort})
#cmo.setListenAddress('127.0.0.1')
create('AdminServer','SSL')
cd('SSL/AdminServer')
cmo.setEnabled(true)
cmo.setListenPort(${oudsmHttpsPort})
#cmo.setListenAddress('${localIP}')
updateDomain()
closeDomain()
disconnect()
exit()
EOF
   fi

   if [ -e "${cfgdir}/oudsm14c-addSSL.py" ]
   then
      true
   else
      cat > ${cfgdir}/oudsm14c-addSSL.py <<EOF
connect('weblogic',"${bPW}",'t3://${localHost}:${oudsmHttpPort}')
edit()
startEdit()
print('== Change certificate store to CustomIdentityAndCustomTrust.')
cd('/Servers/AdminServer')
cmo.setKeyStores('CustomIdentityAndCustomTrust')
print('== Change certificate keystore to ${kstore}')
cmo.setCustomIdentityKeyStoreFileName("${kstore}")
cmo.setCustomIdentityKeyStoreType('${ktype}')
set('CustomIdentityKeyStorePassPhrase', "${bPW}")
print('== Change certificate truststore to ${tstore}')
cmo.setCustomIdentityKeyStoreFileName("${kstore}")
cmo.setCustomTrustKeyStoreFileName("${tstore}")
cmo.setCustomTrustKeyStoreType('${ktype}')
set('CustomTrustKeyStorePassPhrase', "${bPW}")
print('== Change certificate alias to server-cert.')
cd('/Servers/AdminServer/SSL/AdminServer')
cmo.setServerPrivateKeyAlias('server-cert')
set('ServerPrivateKeyPassPhrase', "${bPW}")
print('== Enable the secure port ${oudsmHttpsPort}.')
cmo.setEnabled(true)
cmo.setListenPort(${oudsmHttpsPort})
cmo.setJSSEEnabled(true)
save()
activate()
disconnect()
exit()
EOF
   fi

}

###############################################################################
# Wait for WebLogic to start
###############################################################################
wait4wls() {
   log=$1
   if [ -n "$2" ];then for (( b=1; b<= $2; b++ ));do echo -e "^H\c";done;fi
   for (( t=1; t<= 120; t++ ))
   do
      isWlsUp=$(grep "in RUNNING mode" $log 2> /dev/null)
      if [ -n "${isWlsUp}" ]
      then
         break
      elif [ -n "$(grep "Server state changed to FAILED" $log 2> /dev/null)" ]
      then
         echo -e "Startup Failed"
         exit
      else
         echo -e ".\c"
         sleep 30
      fi
   done
   echo -e "done"
   bdiff=$(($2-$t-4+1))
   if [ -n "$2" ];then for (( b=1; b<= $bdiff; b++ ));do echo -e " \c";done;fi
}

#############################################################################################################
# Stop OUDSM
#############################################################################################################
stop_oudsm() {
   setfmwenv
   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   if [ -e "${oudsmmwdir}/domains/oudsm/bin/stopWebLogic.sh" ]
   then
      true
      let steps++
      echo -e "Step: ${steps} - Stop WebLogic for OUDSM ${fmwVersion}.\c" | tee -a  ${logdir}/oudsm-ctl-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oudsmmwdir}/domains/oudsm/bin/stopWebLogic.sh >> ${logdir}/oudsm-ctl-${now}.log 2>&1
      rc=$?
      set +x
      echo -e ".\c"

      # Stop ODS NodeManager
      # The only supported way to stop the NodeManager is to kill the pid
      odsnmpid=$(ps -ef 2> /dev/null|egrep "startNodeManager|common\/nodemanager"|grep "${oudsmmwdir}"|egrep -v "grep|manage_oudsm"|awk '{ print $2 }'|egrep -v "^$$$"|sort -rn)
      odsnmpiducb=$(${ucbps} auxww 2> /dev/null|egrep "startNodeManager|common\/nodemanager"|grep "${oudsmmwdir}"|egrep -v "grep|manage_oudsm"|awk '{ print $2 }'|egrep -v "^$$$"|sort -rn)
      if [ -n "$odsnmpid" ] || [ -n "$odsnmpiducb" ]
      then
         echo "$odsnmpid" |xargs -n1 kill 2> /dev/null
      fi

      ps -ef | grep domains\/oudsm|egrep -v "grep|manage_oudsm"|awk '{ print $2 }' | xargs -n1 kill 2> /dev/null

      echo -e ".done"
   else
      exit 0
   fi
}

#############################################################################################################
# Start OUDSM
#############################################################################################################
start_oudsm() {
   setfmwenv
   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   if [ -e "${oudsmmwdir}/domains/oudsm/startWebLogic.sh" ]
   then
      let steps++
      echo -e "Step: ${steps} - Start WebLogic for OUDSM ${fmwVersion}.\c" | tee -a  ${logdir}/oudsm-ctl-${now}.log
      now=$(date +'%Y%m%d%H%M%S')
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oudsmmwdir}/domains/oudsm/startWebLogic.sh ${WL_ARGS} >> ${logdir}/oudsm-ctl-${now}.log 2>&1 &
      wait4wls "${logdir}/oudsm-ctl-${now}.log"
      ${oudsmmwdir}/domains/oudsm/bin/startNodeManager.sh >> ${logdir}/oudsm-ctl-${now}.log 2>&1 &
      set +x

      let steps++
      echo "Step: ${steps} - Open browser to https://${localHost}:${oudsmHttpsPort}/oudsm" | tee -a  ${logdir}/oudsm-ctl-${now}.log
   else
      exit 0
   fi
}

#############################################################################################################
# Deinstall OUDSM
#############################################################################################################
deinstall_oudsm() {
   setfmwenv
   if [ -e "$JAVA_HOME/bin/java" ];then true;else echo "JAVA_HOME not set";exit 1;fi
   if [ -d "${oudsmmwdir}/domains/oudsm" ]
   then
      stop_oudsm
      let steps++
      echo -e "Step: ${steps} - Deinstall OUDSM domain.\c" | tee -a  ${logdir}/oudsm-ctl-${now}.log
      rm -fr "${oudsmmwdir}/domains/oudsm"
      echo -e ".done"
   fi
   echo ${steps} > ${cfgdir}/.steps.oudsm
}

#############################################################################################################
# Setup WebLogic for OUDSM
#############################################################################################################
setup_oudsm() {
   # Make sure local cert is generated and trust store is setup
   if [ -e "${tstore}" ] 
   then
      true
   else
      ${curdir}/manage_certs.sh gencert
   fi

   setfmwenv
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -e "${oudsmmwdir}/domains/oudsm/startWebLogic.sh" ]
   then
      let steps++
      echo "Step: ${steps} - WebLogic and OUDSM appear to already be setup.  Restarting OUDSM." | tee -a  ${logdir}/oud-install-${now}.log
      stop_oudsm
      start_oudsm
   else
      # Make configuration files
      make_cfg_files

      # Install OUDSM
      rm ${cfgdir}/.steps.install.fmw.oudsm 2> /dev/null
      rm ${cfgdir}/.steps.install.oudsm 2> /dev/null
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/manage_install.sh install oudsm --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag} --step ${steps}
      set +x
      if [ -e "${cfgdir}/.steps.install.oudsm" ];then steps=$(cat ${cfgdir}/.steps.install.oudsm);fi

      # Confirm that FMW is installed
      if [ -e "${oudsmmwdir}/oracle_common/common/bin/wlst.sh" ]
      then
         true
      else
         echo "ERROR: Fusion Middleware not installed"
         exit 1
      fi

      if [ "${dbg}" == 'true' ];then set -x;fi
      export JAVA_OPTIONS=" -Dweblogic.security.SSL.minimumProtocolVersion=TLSv1 -Dweblogic.ssl.JSSEEnabled=true -Dweblogic.security.SSL.trustedCAKeyStore=${tstore}"

      ${oudsmmwdir}/oracle_common/common/bin/wlst.sh ${cfgdir}/oudsm${fmwVersion}.py >> ${logdir}/setup-oudsm-${now}.log 2>&1
      rc=$?
      set +x
      let steps++
      echo -e "Step: ${steps} - Start WebLogic.\c" | tee -a  ${logdir}/oudsm-ctl-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oudsmmwdir}/domains/oudsm/startWebLogic.sh ${WL_ARGS} >> ${logdir}/setup-oudsm-${now}.log 2>&1 &
      ${oudsmmwdir}/domains/oudsm/bin/startNodeManager.sh >> ${logdir}/setup-oudsm-${now}.log 2>&1 &
      wait4wls "${logdir}/setup-oudsm-${now}.log"
      set +x

      if [ -e "${tstore}" ] 
      then
         let steps++
         echo -e "Step: ${steps} - Add SSL config to WebLogic" | tee -a  ${logdir}/setup-oudsm-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudsmmwdir}/oracle_common/common/bin/wlst.sh ${cfgdir}/oudsm${fmwVersion}-addSSL.py >> ${logdir}/setup-oudsm-${now}.log 2>&1
         rc=$?
         set +x

         ## Add Custom Keystore to Nodemanager
         cat ${oudsmmwdir}/domains/oudsm/nodemanager/nodemanager.properties | sed -e "s/^ListenAddress.*/ListenAddress=0.0.0.0/g" > ${oudsmmwdir}/domains/oudsm/nodemanager/nodemanager.properties.${now}
         cat ${oudsmmwdir}/domains/oudsm/nodemanager/nodemanager.properties.${now} > ${oudsmmwdir}/domains/oudsm/nodemanager/nodemanager.properties

         if [ "${dbg}" == 'true' ];then set -x;fi
         now=$(date +'%Y%m%d%H%M%S')
         stop_oudsm
         start_oudsm
         set +x
      else
         echo -e "\n\nIf you want to use private cert, run \"${curdir}/manage_certs.sh gencert\" before setting up OUDSM.\n\n" | tee -a ${logdir}/setup-oudsm-${now}.log 2>&1
      fi
   fi

   #let steps++
   #echo "Step: ${steps} - Open browser to https://${localHost}:${oudsmHttpsPort}/oudsm" | tee -a  ${logdir}/oudsm-ctl-${now}.log
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
             'setup') setup_oudsm;;
         'deinstall') deinstall_oudsm;;
              'stop') stop_oudsm;;
             'start') start_oudsm;;
                   *) showUsage;;
esac
