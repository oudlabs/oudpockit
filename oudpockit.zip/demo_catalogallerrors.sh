#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Here are some command line tools for various notification methods:
###############################################################################
steps=0
let steps++
echo "Step: ${steps} - Setup catalog directory (${tmpdir}/ouderrors)"
mkdir -p ${tmpdir}/ouderrors/tmp 2> /dev/null
cd ${tmpdir}/ouderrors/tmp
let steps++
echo "Step: ${steps} - Find all files containing errors"
find ${oudmwdir}/oud -name "*.jar"|xargs -n1 ${JAVA_HOME}/bin/jar -xf

let steps++
echo "Step: ${steps} - Extract all error messages"
find . -type f -name "*en.properties" -exec grep -hv "^#|^$" '{}' \;|sed -e "s/$/EEOOLL/g" -e "s/ \\\EEOOLL/EEOOPP/g"|tr -d '\n\r'|sed -e "s/EEOOPP/ /g" -e "s/EEOOLL/\n/g" -e "s/  / /g"|egrep "SEVERE_ERR|FATAL_ERR|MILD_ERR|SEVERE_WARN|FATAL_WARN|MILD_WARN|NOTICE|WARNING|NOTIFICATION|ERROR|INFO"|grep -v "^#"|sort|uniq > ${tmpdir}/ouderrors/enErrors.txt

let steps++
echo "Step: ${steps} - Categorize error messages"
for err in SEVERE_ERR FATAL_ERR MILD_ERR SEVERE_WARN FATAL_WARN MILD_WARN NOTICE WARNING NOTIFICATION ERROR INFO
do
   grep ${err} ${tmpdir}/ouderrors/enErrors.txt > ${tmpdir}/ouderrors/${err}.txt
   if [ -s "${tmpdir}/ouderrors/${err}.txt" ]
   then
      true
   else
      rm -f "${tmpdir}/ouderrors/${err}.txt"
   fi
done

let steps++
echo "Step: ${steps} - Categorized errors in catalog directory:"
ls -1d ${tmpdir}/ouderrors/*.txt

rm -fr "${tmpdir}/ouderrors/tmp"
