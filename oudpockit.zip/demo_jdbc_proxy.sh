#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            pnum) pnum=$1;shift;;
            dbHost|dbhost) dbHost=$1;shift;;
            dbPort|dbport) dbPort=$1;shift;;
            dbSID|dbsid) dbSID=$1;shift;;
            ddl) ddl=$1;shift;;
            sqldata) sqldata=$1;shift;;
            suffix) suffix=$1;shift;;
            batch) batchFile=$1;shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set defaults if not specified
###############################################################################
if [ -z "${pnum}" ];then pnum="1";fi
ldapPort="${pnum}390"
adminPort="${pnum}445"

ldapPort="${pnum}389"
adminPort="${pnum}444"

if [ -z "${dbHost}" ];then dbHost="${localHost}";fi
if [ -z "${dbPort}" ];then dbPort="1521";fi
if [ -z "${dbSID}" ];then dbSID="${localH}";fi
if [ -z "${batchFile}" ];then batchFile="${samples}/jdbc.batch";fi

###############################################################################
# Tailor batch configuration
###############################################################################
cat ${batchFile}|sed -e "s/eus.example.com/${localHost}/g" > ${cfgdir}/jdbc.batch

###############################################################################
# Make sure database is populated with requisite data
###############################################################################
cat <<EOF
This demonstration requires that the Oracle database be loaded with the following data:

# Load DDL
\$ORACLE_HOME/bin/sqlplus sys/${bPW}@PDB1_${localH} as sysdba < ${samples}/enterprise.ddl

# Create table
\$ORACLE_HOME/bin/sqlplus oudadmin/${bPW}@PDB1_${localH} < ${samples}/enterprise.sql

# Load data
\$ORACLE_HOME/bin/sqlplus oudadmin/${bPW}@PDB1_${localH} < ${samples}/enterprise-entries.sql

EOF
read -p "Press any key to resume ..."

###############################################################################
# Copy updated JDBC driver to OUD proxy library
###############################################################################
if [ -e "${oudmwdir}/oracle_common/modules/oracle.jdbc/ojdbc8.jar" ]
then
   cp ${oudmwdir}/oracle_common/modules/oracle.jdbc/ojdbc8.jar ${oudmwdir}/oud/lib
elif [ -e "${oudmwdir}/oracle_common/modules/oracle.jdbc/ojdbc11.jar" ]
then
   cp ${oudmwdir}/oracle_common/modules/oracle.jdbc/ojdbc11.jar ${oudmwdir}/oud/lib
fi

###############################################################################
# Setup the OUD Proxy and apply the tailored batch configuration 
###############################################################################
#${curdir}/manage_proxy.sh setup --batch ${cfgdir}/jdbc.batch ${dbgFlag}

${curdir}/manage_data.sh genall -n inetorg -N 0 --rm ${dbgFlag}
${curdir}/manage_oud.sh setup --batch ${cfgdir}/jdbc.batch ${dbgFlag}

###############################################################################
# Demonstrate capabilities
###############################################################################
set -x
# Add virtual ACI to ou=dbGroups,${suffix}                      
${lmod} -h ${localHost} -p ${ldapPort} -D "${bDN}" -j "${jPW}" <<EOF
dn: ou=dbGroups,${suffix}
changetype: modify
add: aci
aci: (targetattr = "*") (version 3.0; acl "Group entry read"; allow (compare,search,read) userdn = "ldap:///all";)

dn: ou=dbPeople,${suffix}
changetype: modify
add: aci
aci: (targetattr= "*") (version 3.0 ; acl "self example" ; allow (all) userdn="ldap:///self" ;)

dn: ou=dbGroups,${suffix}
changetype: modify
add: aci
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "Admin contorls"; allow(read,search,compare) userdn="ldap:///uid=*,ou=Admins,[suffix]";)

dn: ou=dbPeople,${suffix}
changetype: modify
add: aci
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "Admin contorls"; allow(read,search,compare) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
EOF

# Change Group Memberships for DBAs

for i in 100 101 102 103 104 105
do
   ${lmod} -h ${localHost} -p ${ldapPort} -D "${bDN}" -j "${jPW}" <<EOF
dn: uid=user${i},ou=dbPeople,${suffix}
changetype: modify
replace: ou
ou: DBA
EOF
done

# Change Group Memberships for DBAs
for i in 106 107 108 109 110
do
   ${lmod} -h ${localHost} -p ${ldapPort} -D "${bDN}" -j "${jPW}" <<EOF
dn: uid=user${i},ou=dbPeople,${suffix}
changetype: modify
replace: ou
ou: HR
EOF
done

# Add new users
for i in 2000 2001
do
   ${lmod} -h ${localHost} -p ${ldapPort} -D "${bDN}" -j "${jPW}" -a <<EOF
dn: uid=user${i},ou=dbPeople,${suffix}
telephoneNumber: 007505${i}
userPassword: Oracle123
sn: TestUser${i}
title: Dr.
ou: TestUsers
givenName: user${i}
cn: user${i} Test_user${i}
objectClass: inetorgperson
EOF
done

# Show all users through ldapsearch
${lsrch} -h ${localHost} -p ${ldapPort} -D "${bDN}" -j "${jPW}" -B -b ou=dbPeople,${suffix} objectclass=inetorgperson

# Create a local backend for ${suffix}
${oudmwdir}/oud/bin/manage-suffix create --baseDN ou=groups,${suffix} --integration no-integration --hostname ${localHost} --port ${adminPort} --bindDN "${bDN}" --bindPasswordFile "${jPW}" --trustAll --no-prompt

# Add Dynamic and virtual static groups 
${lmod} -h ${localHost} -p ${ldapPort} -D "${bDN}" -j "${jPW}" -a <<EOF
dn: cn=HR,ou=groups,${suffix}
memberURL: ldap:///ou=dbPeople,${suffix}??sub?(&(objectclass=inetorgperson)(OU=HR))
objectClass: top
objectClass: groupOfURLs

dn: cn=HR_virt,ou=groups,${suffix}
objectClass: groupOfUniquenames
objectClass: ds-virtual-static-group
objectClass: top
ds-target-group-dn: cn=HR,ou=groups,${suffix}

dn: cn=DBA,ou=groups,${suffix}
memberURL: ldap:///ou=dbPeople,${suffix}??sub?(&(objectclass=inetorgperson)(OU=DBA))
objectClass: top
objectClass: groupOfURLs

dn: cn=DBA_virt,ou=groups,${suffix}
objectClass: groupOfUniquenames
objectClass: ds-virtual-static-group
objectClass: top
ds-target-group-dn: cn=DBA,ou=groups,${suffix}
EOF

