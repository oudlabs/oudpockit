#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################
err='false'
if [ -s "${oudmwdir}/oud1/OUD/bin/start-ds" ]
then
   echo "OUD1 should not exist for this demo"
   err='true'
fi

if [ -s "${oudmwdir}/oud1/OUD/bin/start-ds" ]
then
   echo "OUD2 should not exist for this demo"
   err='true'
fi

if [ "${err}" == 'true' ];then exit 1;fi

echo -e "\nDEMO --> Generate some data"
${curdir}/manage_data.sh genall -n inetorg -N 1

echo -e "\nDEMO --> Setup OUD1"
${curdir}/manage_oud.sh setup --pnum 1 -n inetorg

echo -e "\nDEMO --> Setup OUD2"
${curdir}/manage_oud.sh setup --pnum 2 -n inetorg --supplier ${localHost}:1444:1989

echo -e "\nDEMO --> Show replication status before disabling cn=schema replication on OUD1"
${curdir}/manage_oud.sh rstatus --basedn "cn=schema" --disp compact-view --advanced

echo -e "\nDEMO --> Disable replication of cn=schema on OUD1"
#${oudmwdir}/oud1/OUD/bin/dsreplication disable --hostname ${localHost} --port 1444 --noIntegrationDisable --baseDN cn=schema --adminUID admin --adminPasswordFile "${jPW}" --trustAll --no-prompt
${drepl} disable --hostname ${localHost} --port 1444 --noIntegrationDisable --baseDN cn=schema --adminUID admin --adminPasswordFile "${jPW}" --trustAll --no-prompt

echo -e "\nDEMO --> Show replication status after disabling cn=schema replication on OUD1"
${curdir}/manage_oud.sh rstatus --basedn "cn=schema" --disp compact-view --advanced

echo -e "\nDEMO --> Disable replication of cn=schema on OUD2"
#${oudmwdir}/oud1/OUD/bin/dsreplication disable --hostname ${localHost} --port 2444 --noIntegrationDisable --baseDN cn=schema --adminUID admin --adminPasswordFile "${jPW}" --trustAll --no-prompt
${drepl} disable --hostname ${localHost} --port 2444 --noIntegrationDisable --baseDN cn=schema --adminUID admin --adminPasswordFile "${jPW}" --trustAll --no-prompt

echo -e "\nDEMO --> Show replication status after disabling cn=schema replication on OUD2"
${curdir}/manage_oud.sh rstatus --basedn "cn=schema" --disp compact-view --advanced
