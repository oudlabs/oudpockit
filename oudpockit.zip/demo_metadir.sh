#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Generate data
###############################################################################
echo "MetaDir DEMO: Generate Data"

cd "${cfgdir}"
rm -f inetorg.* enterprise.* company*.ldif *customers*.ldif  inetorg.ldif customer_diff.ldif azuread.ldif  workday.ldif apps.ldif 2> /dev/null

${curdir}/manage_data.sh genall -n ad -N 10000 --suffix "dc=companya,dc=com" --rm
for i in ad*;do j=$(echo ${i}|sed -e "s/^ad/companya/g");mv ${i} ${j};done
${curdir}/manage_data.sh genall -n ad -N 10000 --suffix "dc=companyb,dc=com" --rm
for i in ad*;do j=$(echo ${i}|sed -e "s/^ad/companyb/g");mv ${i} ${j};done
${curdir}/manage_data.sh genall -n ad -N 10000 --suffix "dc=AzureAD,o=apps" --rm
for i in ad*;do j=$(echo ${i}|sed -e "s/^ad/azuread/g");mv ${i} ${j};done

${curdir}/manage_data.sh genall -n apps -N 10000 --suffix o=apps --rm

cp ${samples}/apps.tmpl ${cfgdir}/apps.tmpl

#sed -e "s/example/companya/gi" ${samples}/ad.tmpl > ${cfgdir}/companya.tmpl
#sed -e "s/example/companyb/gi" -e "s/user{/newuser{/gi" ${samples}/ad.tmpl > ${cfgdir}/companyb.tmpl
#sed -e "s/example/AzureAD/gi" -e "s/dc=AzureAD,dc=com/ou=AzureAD,o=apps/gi" ${samples}/ad.tmpl > ${cfgdir}/azuread.tmpl

sed -e "s/dk0.example.com/${localHost}/gi" ${samples}/metadir.batch > ${cfgdir}/metadir.batch

${curdir}/manage_install.sh install ${fmwFlag} <<EOF
Oracle123
EOF

#${curdir}/manage_data.sh gendata -n apps --rm
#${curdir}/manage_data.sh gendata -n companya --rm
#${curdir}/manage_data.sh gendata -n companyb --rm
#${curdir}/manage_data.sh gendata -n azuread --rm

grep -vi "^userPassw" ${cfgdir}/companya.ldif > ${cfgdir}/companya-be.ldif
grep -vi "^userPassw" ${cfgdir}/companyb.ldif > ${cfgdir}/companyb-be.ldif

${curdir}/manage_data.sh gentempl -n enterprise -N 10 --suffix "ou=WorkDay,o=apps" --rm
cp ${samples}/workday.tmpl ${cfgdir}/workday.tmpl
${curdir}/manage_data.sh gendata -n workday --rm

${curdir}/manage_data.sh genall -N 100 -n inetorg --suffix "ou=mf_customers,o=apps" --rm
for i in inetorg*;do j=$(echo ${i}|sed -e "s/^inetorg/mf/g");mv ${i} ${j};done
sed -e "s/^cn: /cn: MAINFRAME /gi" ${cfgdir}/mf.ldif > ${cfgdir}/mf_customers.ldif


${curdir}/manage_data.sh genall -N 100 -n inetorg --suffix "ou=rdbms_customers,o=apps" --rm
sed -e "s/^cn: /cn: RDBMS /gi" ${cfgdir}/inetorg.ldif > ${cfgdir}/rdbms_customers.ldif

cat ${samples}/ad.schema ${samples}/enterprise.schema > ${cfgdir}/metadir.schema

###############################################################################
# Setup CompanyA and B Instances
###############################################################################
echo "MetaDir DEMO: Setup CompanyA AD Instance"
${curdir}/manage_oud.sh setup --pnum 1 --ktype jks --suffix 'dc=companya,dc=com' -n companya --schema ${samples}/ad.schema --nobatch

echo "MetaDir DEMO: Setup CompanyB AD Instance"
${curdir}/manage_oud.sh setup --pnum 2 --ktype jks --suffix 'dc=companyb,dc=com' -n companyb --schema ${samples}/ad.schema --nobatch

###############################################################################
# Setup MetaDir OUD instance
###############################################################################
echo "MetaDir DEMO: Setup MetaDir OUD"
${curdir}/manage_proxy.sh setup --pnum 1 --ktype jks --batch "${cfgdir}/metadir.batch" --schema "${cfgdir}/metadir.schema"
rc=$?

###############################################################################
# Load data into MetaDir OUD instance
###############################################################################
echo "MetaDir DEMO: Load Apps data"
${oudmwdir}/proxy1/OUD/bin/import-ldif -h ${localHost} -p 1445 -D "${bDN}" -j "${jPW}" -n apps-be --skipFile ${logdir}/skips.out --rejectFile ${logdir}/rejects.out -l ${cfgdir}/apps.ldif >> ${logdir}/metadir-import-${now}.log 2>&1
rc=$?

echo "MetaDir DEMO: Load CompanyA data"
${oudmwdir}/proxy1/OUD/bin/import-ldif -h ${localHost} -p 1445 -D "${bDN}" -j "${jPW}" -n companya-be --skipFile ${logdir}/skips.out --rejectFile ${logdir}/rejects.out -l ${cfgdir}/companya-be.ldif >> ${logdir}/metadir-import-${now}.log 2>&1
rc=$?

echo "MetaDir DEMO: Load CompanyB data"
${oudmwdir}/proxy1/OUD/bin/import-ldif -h ${localHost} -p 1445 -D "${bDN}" -j "${jPW}" -n companyb-be --skipFile ${logdir}/skips.out --rejectFile ${logdir}/rejects.out -l ${cfgdir}/companyb-be.ldif >> ${logdir}/metadir-import-${now}.log 2>&1
rc=$?

echo "MetaDir DEMO: Load WorkDay data"
${oudmwdir}/proxy1/OUD/bin/import-ldif -h ${localHost} -p 1445 -D "${bDN}" -j "${jPW}" -n workday-be --skipFile ${logdir}/skips.out --rejectFile ${logdir}/rejects.out -l ${cfgdir}/workday.ldif >> ${logdir}/metadir-import-${now}.log 2>&1
rc=$?

echo "MetaDir DEMO: Load AzureAD data"
${oudmwdir}/proxy1/OUD/bin/import-ldif -h ${localHost} -p 1445 -D "${bDN}" -j "${jPW}" -n azuread-be --skipFile ${logdir}/skips.out --rejectFile ${logdir}/rejects.out -l ${cfgdir}/azuread.ldif >> ${logdir}/metadir-import-${now}.log 2>&1
rc=$?

echo "MetaDir DEMO: Load Mainframe Customer data"
${oudmwdir}/proxy1/OUD/bin/import-ldif -h ${localHost} -p 1445 -D "${bDN}" -j "${jPW}" -n mainframe-be --skipFile ${logdir}/skips.out --rejectFile ${logdir}/rejects.out -l ${cfgdir}/mf_customers.ldif >> ${logdir}/metadir-import-${now}.log 2>&1
rc=$?

echo "MetaDir DEMO: Load RDBMS Customer data"
${oudmwdir}/proxy1/OUD/bin/import-ldif -h ${localHost} -p 1445 -D "${bDN}" -j "${jPW}" -n rdbms-be --skipFile ${logdir}/skips.out --rejectFile ${logdir}/rejects.out -l ${cfgdir}/rdbms_customers.ldif >> ${logdir}/metadir-import-${now}.log 2>&1
rc=$?

###############################################################################
# Process mainframe changes from csv2ldif, diff, modify
###############################################################################
# Convert CSV to LDIF
${curdir}/manage_csv2ldif.sh --csvFile ${samples}/test.csv --suffix "ou=People,ou=mf_customers,o=apps"
rc=$?

# Diff with previous csv
rm -f "${cfgdir}/customer_diff.ldif" 2> /dev/null
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "${bDN}" -j "${jPW}" -b "ou=People,ou=mf_customers,o=apps" -s sub '(objectClass=inetOrgPerson)' > ${cfgdir}/mf_customers-people.ldif 2> /dev/null
rc=$?
${oudmwdir}/proxy1/OUD/bin/ldif-diff --singleValueChanges -s "${cfgdir}/mf_customers-people.ldif" -t "${samples}/test.ldif" -o "${cfgdir}/customer_diff.ldif"
rc=$?

# Bulk load the changes
${curdir}/demo_bulkloadldif.sh -f ${cfgdir}/customer_diff.ldif -h ${localHost} -p 1390 -j "${jPW}" -o nodupcheck
rc=$?

###############################################################################
# Apply a bunch of changes to the CSV users
###############################################################################
rm -f "${cfgdir}/customer_diff2.ldif" "${cfgdir}/mf_customers-people.ldif" "${cfgdir}/newvalues.ldif"
sed -e "s/^description: .*/description: new value/g" "${samples}/test.ldif" > ${cfgdir}/newvalues.ldif
rc=$?

# Download current people data
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "${bDN}" -j "${jPW}" -b "ou=People,ou=mf_customers,o=apps" -s sub '(objectClass=inetOrgPerson)' > ${cfgdir}/mf_customers-people.ldif 2> /dev/null
rc=$?

${oudmwdir}/proxy1/OUD/bin/ldif-diff --singleValueChanges -s "${cfgdir}/mf_customers-people.ldif" -t "${cfgdir}/newvalues.ldif" -o "${cfgdir}/customer_diff2.ldif"
rc=$?

${curdir}/demo_bulkloadldif.sh -f ${cfgdir}/customer_diff2.ldif -h ${localHost} -p 1390 -j "${jPW}" -o nodupcheck
rc=$?

###############################################################################
# Test each backend
###############################################################################
set -x
echo "MetaDir DEMO: Demonstrate searches for Access app:"
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "cn=accessadmin,ou=ServiceAccounts,o=apps" -j "${jPW}" -b "ou=Access,o=apps" -s sub '(cn=user1)'
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "cn=user1,cn=Users,ou=Access,o=apps" -j "${jPW}" -b "ou=Access,o=apps" -s sub '(cn=user1)'
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "cn=Directory Manager" -j "${jPW}" -b "ou=Access,o=apps" -s sub '(cn=user1)'

echo "MetaDir DEMO: Demonstrate searches for Badging app:"
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "cn=badgeadmin,ou=ServiceAccounts,o=apps" -j "${jPW}" -b "ou=Badging,o=apps" -s sub '(cn=user1)'
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "cn=user1,cn=Users,ou=Badging,o=apps" -j "${jPW}" -b "ou=Badging,o=apps" -s sub '(cn=user1)'
${lsrch} -h ${localHost} -T -Z -X -p 1637 -D "cn=Directory Manager" -j "${jPW}" -b "ou=Badging,o=apps" -s sub '(cn=user1)'
