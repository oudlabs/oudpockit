#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            swdir) swdir="$1";shift;;
            tmpl) myTemplFile="$1";shift;;
            ldif) myLdifFile="$1";shift;;
            attrs) myAttrs="$1";shift;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            n) myTemplateName=$1; shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

##############################################################################
if [ -n "${myTemplateName}" ];then templateName=${myTemplateName};fi
if [ -z "${templateName}" ];then templateName='inetorg';fi
if [ -n "${myLdifFile}" ];then ldifFile="${myLdifFile}";else ldifFile=${cfgdir}/${templateName}.ldif;fi
attrs=$(echo ${myAttrs}|sed -e "s/,/ /g")
if [ -z "${attrs}" ];then attrs='sn';fi

##############################################################################
for attr in ${attrs}
do
   echo "Top 10 unique ${attr} attribute names:"
   if [ "${dbg}" == 'on' ];then set -x;fi
   grep -i "^${attr}: " ${ldifFile}|sort --ignore-case|uniq -c --ignore-case|sort -nr --ignore-case|head -10
   set +x
done
