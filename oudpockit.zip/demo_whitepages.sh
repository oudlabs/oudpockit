#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# This demonstration showcases how the LDAP Tool Box White Pages can be 
# easily integrated with OUD.
# More at https://white-pages.readthedocs.io/en/latest/
###############################################################################

###############################################################################
# Example of how to setup Oracle Linux VM in OCI using OUD POC Kit:
# ./manage_oci.sh launch --name wp --compartment ocid1.compartment.oc1..aaaaaaaaxky7uzkyj4ws7yrdauqlagbewaelkrv5mozqzbl6xhp5zpnklypa --region us-phoenix-1 --pubip --role ds --ad uYkY:PHX-AD-1 --subnet ocid1.subnet.oc1.phx.aaaaaaaaa4dxkhgbrp2hg2tg7gvbtsjmmsagwd2h5ndam2pkb76a4cqpavba --arch amd-e3 --cores 1 --mem 16 --storage 200 --os ol9
#
# Once the VM is up, get the public IP with:
# ./manage_oci.sh getip --name wp --region us-phoenix-1 --compartment ocid1.compartment.oc1..aaaaaaaaxky7uzkyj4ws7yrdauqlagbewaelkrv5mozqzbl6xhp5zpnklypa
###############################################################################

###############################################################################
# Make sure running on Oracle Linux 9
###############################################################################
lookupos
if [ "${os}" != 'Linux'  ]
then
   echo "Error: This demo only runs on Oracle Linux 9 or later"
   exit 1
fi

if [ ${olv} -lt 9 ]
then
   echo "Error: This demo only runs on Oracle Linux 9 or later"
   exit 1
fi

###############################################################################
# Show Usage
###############################################################################
showUsage() {
   echo "Usage"
   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            n) my_templateName=$1; shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# set defaults
###############################################################################
if [ -n "${my_templateName}" ];then templateName="${my_templateName}";fi

if [ "${dbg}" == 'true' ];then set -x;fi

###############################################################################
echo -e "\nDEMO --> Generate data with ${templateName} template"
if [ "${templateName}" == 'ad' ];then adFlag='--usename';fi
rm ${cfgdir}/${templateName}.* 2> /dev/null

if [ -e "${samples}/${templateName}.schema" ]
then
   cp ${samples}/${templateName}.schema ${cfgdir}/${templateName}.schema
fi

if [ -e "${samples}/${templateName}.tmpl" ]
then
   cp ${samples}/${templateName}.tmpl ${cfgdir}/${templateName}.tmpl
fi

if [ -e "${samples}/${templateName}.batch" ]
then
   cp ${samples}/${templateName}.batch ${cfgdir}/${templateName}.batch
fi

${curdir}/manage_data.sh genall -n ${templateName} -N 99 ${adFlag} --domain example.com --rm


###############################################################################
echo -e "\nDEMO --> Setup two replicated OUD instances"
adFlag=''
${curdir}/manage_oud.sh setup --pnum 1 -n ${templateName}
${curdir}/manage_oud.sh setup --pnum 2 -n ${templateName} --supplier ${localHost}:1444:1989

###############################################################################
echo -e "\nDEMO --> Update apache white-pages config"
sudo tee /etc/httpd/conf.d/white-pages.conf > /dev/null <<EOF
<VirtualHost *:80>
    ServerName wp.example.com

    DocumentRoot /usr/share/white-pages/htdocs
    DirectoryIndex index.php

    <Directory /usr/share/white-pages/htdocs>
        AllowOverride None
        <IfVersion >= 2.3>
            Require all granted
        </IfVersion>
        <IfVersion < 2.3>
            Order Deny,Allow
            Allow from all
        </IfVersion>
    </Directory>

    LogLevel warn
    ErrorLog /var/log/httpd/wp_error.log
    CustomLog /var/log/httpd/wp_access.log combined
</VirtualHost>

Alias /wp /usr/share/white-pages/htdocs
<Directory /usr/share/white-pages/htdocs>
       DirectoryIndex index.php
       AllowOverride None
       <IfVersion >= 2.3>
           Require all granted
       </IfVersion>
       <IfVersion < 2.3>
           Order Deny,Allow
           Allow from all
       </IfVersion>
</Directory>
EOF
###############################################################################
if [ -e "/etc/yum.repos.d/ltb-project.repo" ]
then
   true
else
   echo -e "\nDEMO --> Update OS and install white-pages app and requisites"
   sudo rpm --import https://ltb-project.org/documentation/_static/RPM-GPG-KEY-LTB-project

   echo -e "\nDEMO --> Make ltp dnf repo"
   sudo tee /etc/yum.repos.d/ltb-project.repo > /dev/null <<EOF
[ltb-project-noarch]
name=LTB project packages (noarch)
baseurl=https://ltb-project.org/rpm/\$releasever/noarch
enabled=1
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-LTB-project
EOF

fi

echo -e "\nDEMO --> Enable EPEL and ltb repos"
sudo dnf config-manager --enable ol9_developer_EPEL
sudo dnf config-manager --enable ltb-project-noarch

echo -e "\nDEMO --> Update OS and install white-pages and requisites"
sudo dnf update -y
sudo dnf install -y php-Smarty white-pages

###############################################################################
echo -e "\nDEMO --> Configure white-pages app to point to OUD instances:"

if [ "${templateName}" == 'ad' ]
then
   rdnAttr="samAccountName"
   oudAdmin="cn=admin1,cn=Admins,${suffix}"
   userBase="cn=Users"
   groupBase="cn=Groups"
   userOC="user"
   groupOCFilter="(|(objectClass=group))"
else
   rdnAttr="uid"
   oudAdmin="uid=admin1,ou=Admins,${suffix}"
   userBase="ou=People"
   groupBase="ou=Groups"
   userOC="inetOrgPerson"
   groupOCFilter="(|(objectClass=groupOfNames)(objectClass=groupOfUniqueNames))"
fi

sudo tee /usr/share/white-pages/conf/config.inc.local.php > /dev/null <<EOF
<?php
# Debug mode
#$\debug = true;

# HTTP
\$http_url = "http://wp.example.com/";

# LDAP
\$ldap_url = "ldap://localhost:1389 ldap://localhost:2389";
\$ldap_starttls = false;
\$ldap_binddn = "${oudAdmin}";
\$ldap_bindpw = "${bPW}";
\$ldap_base = "${suffix}";
\$ldap_user_base = "${userBase},".\$ldap_base;
\$ldap_user_filter = "(objectClass=${userOC})";
#\$ldap_user_regex = "/,${userBase},/i";
\$ldap_group_base = "${groupBase},".\$ldap_base;
\$ldap_group_filter = "${groupOCFilter}";
\$ldap_size_limit = 100;
\$ldap_network_timeout = 5;

\$photo_local_directory = "../photos/";
\$photo_local_ldap_attribute = "${rdnAttr}";
\$photo_local_extension = ".jpg";

\$display_edit_link = "https://wp.example.com:7002/oudsm/faces/odsm.jspx";

?>
EOF

###############################################################################
echo -e "\nDEMO --> Start Apache (httpd) web server and PHP-FPM"
sudo systemctl enable httpd.service
sudo systemctl enable php-fpm.service

sudo systemctl restart httpd.service
sudo systemctl restart php-fpm.service

###############################################################################
echo -e "\nDEMO --> Open TCP port 80 on local firewall"
sudo firewall-cmd --permanent --zone=public --add-port=80/tcp
sudo firewall-cmd --reload

###############################################################################
echo -e "\nDEMO --> Enable permissive SELinux mode"
sudo setenforce 0


###############################################################################
echo -e "\nDEMO --> Add profile photo for each user"
if [ -e "${cfgdir}/faces.ldif" ];then rm -f "${cfgdir}/faces.ldif";fi

readarray -t users < <(sed -e "s/ /SSPPAACCEE/g" -e "s/	/TTAABB/g" ${cfgdir}/${templateName}.dn)
for (( x=0; x< ${#users[*]}; x++ ))
do
    dn=$(echo ${users[${x}]}|sed -e "s/SSPPAACCEE/ /g" -e "s/TTAABB/	/g")
    face=$(base64 ${curdir}/samples/photos/${x}.jpg|sed -e "s/^/ /g")
    cat >> ${cfgdir}/faces.ldif <<EOF
dn: ${dn}
changeType: modify
replace: jpegPhoto
jpegPhoto::${face}

EOF
done

setfmwenv

${lmod} -h ${localHost} -p 1389 -D 'cn=directory manager' -j "${jPW}" -c -f ${cfgdir}/faces.ldif

###############################################################################
echo -e "\nDEMO --> Next manual steps"
echo "Update server /etc/hosts to add wp.example.com to the local IP"
echo "Update client /etc/hosts to add wp.example.com of the server public IP"
echo "Add ingress rule to port 80 from either your IP address or 0.0.0.0/0"
echo "Open browser from client and bring up the following URL:"
echo "   http://wp.example.com/"
