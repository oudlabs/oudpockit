#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [genall|gendata|gentempl|genbatch|gendn|genrdn] [options]

SYNOPSIS
     Generate data

     genall      - Generate all data artifacts

     gendata     - Generate data from make-ldif template

     gentempl    - Generate template

     genbatch    - Generate batch configuration file

     gendn       - Generate file containing all DNs

     genrdn      - Generate file containing all RDNs

DESCRIPTION
     Sample script to setup Oracle Unified Directory load balancing proxy

OPTIONS
     The following options are supported:

         -n <name>               Template name
                                 Default: enterprise

            Templates Include:

            bank - Oriented to banking sector.  
               Users have 15 attributes and 5 objectClasses.

            enterprise - Oriented to generic enterprise with users, groups, 
               UNIX services and SuDO profiles.
               Users have 28 attributes and 8 objectClasses.

            inetorg - Basic DIT with users based on inetOrgPerson objectClass 
               and groups based on groupOfNames.  
               Users have 11 attributes and 4 objectClasses.

            telco - Telecommunications template that includes subscribers, 
               users, devices.
               Users have 111 attributes and 8 objectClasses.

            tns - Oracle database entries for net services resolution.

         -N <number>             Number of users to create
                                 Default: 10000

         --dnfilter <filter>     Filter to apply when generating DN and RDN
                                 files
                                 Default: uid=user

         --tmpl <file>           MakeLDIF template file
                                 Default: ${cfgdir}/<template>.tmpl

         --ldif <file>           LDIF output file
                                 Default: ${cfgdir}/<template>.ldif

         --rdnfile <file>        RDN output file
                                 Default: ${cfgdir}/<template>.rdn

         --dnfile <file>         DN output file
                                 Default: ${cfgdir}/<template>.dn

         --rm                    Remove template and LDIF file before running

EXAMPLES

   Generate template, data, batch, DN, and RDN files and remove existing files
 
   ${cmd} genall -n inetorg -N 10000 --rm

   Generate template

   ${cmd} gentempl -n inetorg -N 10000


   Generate DN file with filter cn=user of from existing inetorg data file

   ${cmd} gendn -n inetorg --dnfilter cn=user
   
   Generate RDN file from existing LDIF file with filter uid=user

   ${cmd} genrdn --ldiffile ${cfgdir}/mydata.ldif --dnfilter cn=user
   
EOF

   exit 1
}

###############################################################################
# Add big groups
###############################################################################
addGroups() {
   # Confirm settings
   if [ -n "${moreGroups}" ] && [ -z "${moreMembers}" ]
   then
      echo "Must provide --gcnt <n> when --gmembers <n>"
      exit 1
   elif [ -z "${moreGroups}" ] && [ -n "${moreMembers}" ]
   then
      echo "Must provide --gmembers <n> when --gcnt <n>"
      exit 1
   fi

   if [ -n "${moreGroups}" ] && [ -n "${moreMembers}" ]
   then

      # Make sure that the user count is as least as high as member count
      if [ ${moreMembers} -gt ${numUsers} ]
      then
         echo "The number of users (-N <n>) must be larger than the member count (--gmembers <n>)"
         exit 1
      fi

      let steps++
      echo "Step: ${steps} - Add ${moreGroups} groups with ${moreMembers} members"| tee -a  ${logdir}/gendata-${now}.log

      # Confirm presence of infoFile
      if [ -e "${infoFile}" ]
      then
         true
      else
         ck4info=$(grep -h 'urate|' ${tmplFile})
         if [ -n "${ck4info}" ]
         then
            grep "^#" ${tmplFile}|grep -v "^#$"|head -5 > ${infoFile}
         fi
      fi

      # Users / Subscribers
      uRdn=$(head -5 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f2)
      uBase=$(head -5 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f3)
      uPrefix=$(head -5 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f4)
      uFirst=$(head -5 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f5)
      uLast=$(head -5 "${infoFile}" 2> /dev/null|grep "^#urate"|cut -d'|' -f6)
      uSpan="${uFirst}-${uLast}"
      firstUser="${uRdn}=${uPrefix}${uFirst},${uBase}"
      firstUserRdn="${uRdn}=${uPrefix}${uFirst}"
      lastUser="${uRdn}=${uPrefix}${uLast},${uBase}"
      lastUserSchema="${uPrefix}${uLast}"
      secondUser="${uRdn}=${uPrefix}$((${uFirst}+1)),${uBase}"

      # Groups
      gRdn=$(head -5 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f2)
      gBase=$(head -5 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f3)
      gPrefix=$(head -5 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f4)
      gFirst=$(head -5 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f5)
      gLast=$(head -5 "${infoFile}" 2> /dev/null|grep "^#grate"|cut -d'|' -f6)
      gSpan="${gFirst}-${gLast}"

      # Group Members
      mRdn=$(head -5 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f2)
      mBase=$(head -5 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f3)
      mPrefix=$(head -5 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f4)
      mFirst=$(head -5 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f5)
      mLast=$(head -5 "${infoFile}" 2> /dev/null|grep "^#mrate"|cut -d'|' -f6)
      mSpan="${mFirst}-${mLast}"
   
      a=1
      while [ $a -le ${moreGroups} ]
      do
         cat >> ${ldifFile} <<EOF

dn: cn=bigGroup${a},${gBase}
objectClass: Top
objectClass: groupOfUniqueNames
cn: bigGroup${a}
EOF

         b=1
         u=${uFirst}
         while [ $b -le ${moreMembers} ]
         do
            echo "uniqueMember: uid=user${b},${uBase}" >> ${ldifFile}
            let b++
         done
         let a++
      done
   fi
}

###############################################################################
# Generate batch configuration file for indexes
###############################################################################
gen_batch() {
   if [ -e "${batchFile}" ] && [ "${rmFiles}" == 'false' ]
   then
      echo "ERROR: Batch file alread exists: ${batchFile}"
      exit 1
   fi

   # Purge if requested
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -n "${templateName}" ] &&  [ -e "${batchFile}" ] && [ "${rmFiles}" == 'true' ];then rm -f ${batchFile};set +x;fi

   # Determine database cache size
   ldifSize=$(du -ms ${ldifFile} 2> /dev/null)
   if [ -n "${ldifSize}" ]
   then
      jmem=$(echo ${ldifSize}|awk '{ print int($1*2+2048) }')
      dbc=$(echo ${ldifSize}|awk '{ print int(($1*2+2048)*80/100) }')
   else
      jmem=4096
   fi

   if [ -e "${batchFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate ${templateName} batch configuration for indexes"| tee -a  ${logdir}/gendata-${now}.log
      case ${templateName} in
         'telco') cat > ${batchFile} <<EOF
#set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-connection-details:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false --set log-connection-details:true --set log-controls:true

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1

#set-global-configuration-prop --set etime-resolution:nanoseconds

create-local-db-index --element-name userRoot   --index-name mobile                       --set index-entry-limit:10000 --set index-type:equality --set index-type:presence
create-local-db-index --element-name userRoot   --index-name telcoAccountNumber           --set index-entry-limit:10000 --set index-type:equality --set index-type:presence
create-local-db-index --element-name userRoot   --index-name telcoSubscriberAccountNumber --set index-entry-limit:10000 --set index-type:equality --set index-type:presence

set-local-db-index-prop --element-name userRoot --index-name sn                            --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name uid                           --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name cn                            --set index-entry-limit:10000 --add index-type:presence
EOF
          ;;
         't2') cat > ${batchFile} <<EOF
set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:false
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1 

set-work-queue-prop --set max-work-queue-capacity:500000

create-local-db-index --element-name userRoot   --index-name subid      --set index-entry-limit:100000 --set index-type:equality
create-local-db-index --element-name userRoot   --index-name devid      --set index-entry-limit:100000 --set index-type:equality
create-local-db-index --element-name userRoot   --index-name deviceIMSI --set index-entry-limit:100000 --set index-type:equality
create-local-db-index --element-name userRoot   --index-name wapSubNo   --set index-entry-limit:100000 --set index-type:equality

create-entry-cache --type fifo --cache-name userRoot-fifoEC --set max-entries:1000000 --set max-memory-percent:100 --set cache-level:2 --set enabled:true --set entry-cache-workflow-element:userRoot --set include-filter:"(|(objectClass=t2Device)(objectClass=t2Subscriber))"

#set-workflow-element-prop --element-name userRoot --set db-cache-size:28GiB
#set-workflow-element-prop --element-name userRoot --reset db-cache-size

EOF
          ;;
         'enterprise') cat > ${batchFile} <<EOF
#set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-connection-details:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false --set log-connection-details:true --set log-controls:true

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1

#set-global-configuration-prop --set etime-resolution:nanoseconds

create-local-db-index --element-name userRoot   --index-name mobile                       --set index-entry-limit:10000 --set index-type:equality --set index-type:presence

set-local-db-index-prop --element-name userRoot --index-name sn                            --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name uid                           --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name cn                            --set index-entry-limit:10000 --add index-type:presence

EOF
          ;;
                 'e2') cat > ${batchFile} <<EOF
set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-connection-details:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false --set log-connection-details:true --set log-controls:true

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1

#set-global-configuration-prop --set etime-resolution:nanoseconds

create-local-db-index --element-name userRoot   --index-name mobile                       --set index-entry-limit:10000 --set index-type:equality --set index-type:presence

set-local-db-index-prop --element-name userRoot --index-name sn                            --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name uid                           --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name cn                            --set index-entry-limit:10000 --add index-type:presence

EOF
          ;;
         'bank') cat > ${batchFile} <<EOF
#set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-connection-details:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false --set log-connection-details:true --set log-controls:true

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1

#set-global-configuration-prop --set etime-resolution:nanoseconds

EOF
          ;;
         'inetorg') cat > ${batchFile} <<EOF
#set-log-publisher-prop --publisher-name "File-Based Access Logger" --set log-connection-details:true
set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false --set log-connection-details:true --set log-controls:true

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1

#set-global-configuration-prop --set etime-resolution:nanoseconds

# Test reclaimed DB size
set-replication-domain-prop  --provider-name 'Multimaster Synchronization' --domain-name dc=example,dc=com --set 'conflicts-historical-purge-delay:1800 s'
set-replication-server-prop  --provider-name 'Multimaster Synchronization' --set 'replication-purge-delay:1800 s'
set-workflow-element-prop    --element-name   userRoot --set 'tombstone-lifetime:1800 s'

EOF
          ;;
         'eus') cat > ${batchFile} <<EOF
set-connection-handler-prop --handler-name "LDAPS Connection Handler" --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_128_GCM_SHA256 

create-password-policy --type generic --policy-name EUSAdmins --set password-attribute:userpassword --set default-password-storage-scheme:AES --set default-password-storage-scheme:Salted\ SHA-512

set-password-policy-prop --policy-name "Default Password Policy" --add default-password-storage-scheme:"EUS PBKDF2 SHA-512"

set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true

#set-work-queue-prop --set max-work-queue-capacity:500000

EOF
          ;;
         'tns') cat > ${batchFile} <<EOF
#set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-connection-details:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false --set log-connection-details:true --set log-controls:true

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1

#set-global-configuration-prop --set etime-resolution:nanoseconds

EOF
          ;;
         'sslv3') cat > ${batchFile} <<EOF
#set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-connection-details:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:true --set log-connection-details:true --set log-controls:true
set-log-publisher-prop --publisher-name 'Oracle Error Logger' --set enabled:true

set-replication-server-prop --provider-name "Multimaster Synchronization" --set replication-purge-delay:1d
set-replication-domain-prop --provider-name "Multimaster Synchronization" --domain-name dc=example,dc=com --set conflicts-historical-purge-delay:12h
set-workflow-element-prop --element-name userRoot --set tombstone-purge-interval:12h

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1 --add ssl-protocol:SSLv3

# Add all the cipher suites
set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-cipher-suite:SSL_NULL_WITH_NULL_NULL --add ssl-cipher-suite:SSL_RSA_WITH_NULL_MD5 --add ssl-cipher-suite:SSL_RSA_WITH_NULL_SHA --add ssl-cipher-suite:SSL_RSA_EXPORT_WITH_RC4_40_MD5 --add ssl-cipher-suite:SSL_RSA_WITH_RC4_128_MD5 --add ssl-cipher-suite:SSL_RSA_WITH_RC4_128_SHA --add ssl-cipher-suite:SSL_RSA_EXPORT_WTIH_RC2_CBC_40_MD5 --add ssl-cipher-suite:SSL_RSA_WITH_IDEA_CBC_SHA --add ssl-cipher-suite:SSL_RSA_EXPORT_WITH_DES40_CBC_SHA --add ssl-cipher-suite:SSL_RSA_WITH_DES_CBC_SHA --add ssl-cipher-suite:SSL_RSA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:SSL_DH_DSS_EXPORT_WITH_DES40_CBC_SHA --add ssl-cipher-suite:SSL_DH_DSS_WITH_DES_CBC_SHA --add ssl-cipher-suite:SSL_DH_DSS_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:SSL_DH_RSA_EXPORT_WITH_DES40_CBC_SHA --add ssl-cipher-suite:SSL_DH_RSA_WITH_DES_CBC_SHA --add ssl-cipher-suite:SSL_DH_RSA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA --add ssl-cipher-suite:SSL_DHE_DSS_WITH_DES_CBC_SHA --add ssl-cipher-suite:SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA --add ssl-cipher-suite:SSL_DHE_RSA_WITH_DES_CBC_SHA --add ssl-cipher-suite:SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:SSL_DH_anon_EXPORT_WITH_RC4_40_MD5 --add ssl-cipher-suite:SSL_DH_anon_WITH_RC4_128_MD5 --add ssl-cipher-suite:SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA --add ssl-cipher-suite:SSL_DH_anon_WITH_DES_CBC_SHA --add ssl-cipher-suite:SSL_DH_anon_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_PSK_WITH_NULL_SHA --add ssl-cipher-suite:TLS_DHE_PSK_WITH_NULL_SHA --add ssl-cipher-suite:TLS_RSA_PSK_WITH_NULL_SHA --add ssl-cipher-suite:TLS_RSA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_DH_DSS_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_DH_RSA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_DHE_DSS_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_RSA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_DH_DSS_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_DH_RSA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_DHE_DSS_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_RSA_WITH_NULL_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_AES_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_DSS_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_RSA_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_CAMELLIA_128_CBC_SHA --add ssl-cipher-suite:TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA --add ssl-cipher-suite:TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA --add ssl-cipher-suite:TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA --add ssl-cipher-suite:TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA --add ssl-cipher-suite:TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_DSS_WITH_AES_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_RSA_WITH_AES_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_256_CBC_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_CAMELLIA_256_CBC_SHA --add ssl-cipher-suite:TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA --add ssl-cipher-suite:TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA --add ssl-cipher-suite:TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA --add ssl-cipher-suite:TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA --add ssl-cipher-suite:TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA --add ssl-cipher-suite:TLS_PSK_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_PSK_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_PSK_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_PSK_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_DHE_PSK_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_RSA_PSK_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_RSA_PSK_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_RSA_PSK_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_RSA_WITH_SEED_CBC_SHA --add ssl-cipher-suite:TLS_DH_DSS_WITH_SEED_CBC_SHA --add ssl-cipher-suite:TLS_DH_RSA_WITH_SEED_CBC_SHA --add ssl-cipher-suite:TLS_DHE_DSS_WITH_SEED_CBC_SHA --add ssl-cipher-suite:TLS_DHE_RSA_WITH_SEED_CBC_SHA --add ssl-cipher-suite:TLS_DH_anon_WITH_SEED_CBC_SHA --add ssl-cipher-suite:TLS_RSA_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_RSA_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_RSA_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_DSS_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_DSS_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_anon_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_PSK_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_PSK_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_PSK_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_PSK_WITH_AES_256_CBC_SHA384 --add ssl-cipher-suite:TLS_PSK_WITH_NULL_SHA256 --add ssl-cipher-suite:TLS_PSK_WITH_NULL_SHA384 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_NULL_SHA256 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_NULL_SHA384 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_NULL_SHA256 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_NULL_SHA384 --add ssl-cipher-suite:TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 --add ssl-cipher-suite:TLS_EMPTY_RENEGOTIATION_INFO_SCSV --add ssl-cipher-suite:TLS_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_FALLBACK_SCSV --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_NULL_SHA --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_NULL_SHA --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_NULL_SHA --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_NULL_SHA --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_ECDH_anon_WITH_NULL_SHA --add ssl-cipher-suite:TLS_ECDH_anon_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_ECDH_anon_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_ECDH_anon_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_RC4_128_SHA --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_NULL_SHA --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_NULL_SHA256 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_NULL_SHA384 --add ssl-cipher-suite:TLS_RSA_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_RSA_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_PSK_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_PSK_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_PSK_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_PSK_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 --add ssl-cipher-suite:TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 --add ssl-cipher-suite:TLS_RSA_WITH_AES_128_CCM --add ssl-cipher-suite:TLS_RSA_WITH_AES_256_CCM --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_128_CCM --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_256_CCM --add ssl-cipher-suite:TLS_RSA_WITH_AES_128_CCM_8 --add ssl-cipher-suite:TLS_RSA_WITH_AES_256_CCM_8 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_128_CCM_8 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_AES_256_CCM_8 --add ssl-cipher-suite:TLS_PSK_WITH_AES_128_CCM --add ssl-cipher-suite:TLS_PSK_WITH_AES_256_CCM --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_128_CCM --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_256_CCM --add ssl-cipher-suite:TLS_PSK_WITH_AES_128_CCM_8 --add ssl-cipher-suite:TLS_PSK_WITH_AES_256_CCM_8 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_128_CCM_8 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_AES_256_CCM_8 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_128_CCM --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_256_CCM --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 --add ssl-cipher-suite:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 --add ssl-cipher-suite:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 --add ssl-cipher-suite:TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 --add ssl-cipher-suite:TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 --add ssl-cipher-suite:TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 --add ssl-cipher-suite:TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 --add ssl-cipher-suite:TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256

#set-global-configuration-prop --set etime-resolution:nanoseconds

EOF
          ;;
         'ad') cat > ${batchFile} <<EOF
set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false --set log-controls:true

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1

#set-global-configuration-prop --set etime-resolution:nanoseconds

create-local-db-index --element-name userRoot   --index-name mobile                      --set index-entry-limit:10000 --set index-type:equality --set index-type:presence

set-local-db-index-prop --element-name userRoot --index-name sn                          --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name uid                         --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name samAccountName              --set index-entry-limit:10000 --add index-type:presence
set-local-db-index-prop --element-name userRoot --index-name cn                          --set index-entry-limit:10000 --add index-type:presence

EOF
          ;;
       'apps') cat > ${batchFile} <<EOF
set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true --set log-controls:true
set-log-publisher-prop --publisher-name "Oracle Access Logger" --set enabled:false --set log-controls:true

set-connection-handler-prop --handler-name 'LDAPS Connection Handler' --add ssl-protocol:TLSv1.3 --add ssl-protocol:TLSv1.2 --add ssl-protocol:TLSv1.1 --add ssl-protocol:TLSv1

#set-global-configuration-prop --set etime-resolution:nanoseconds

set-local-db-index-prop --element-name userRoot --index-name cn                          --set index-entry-limit:10000 --add index-type:presence

EOF
          ;;
      esac
      set +x
   fi
   echo ${steps} > ${cfgdir}/.steps.gendata 2> /dev/null
}

###############################################################################
# Make Enterprise MakeLdif Template
###############################################################################
mkEnterpriseTemplate() {
   if [ -e "${templFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate enterprise template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|uid|ou=People,${suffix}|user|${firstUNum}|${lastUNum}
#grate|cn|ou=Groups,${suffix}|group|${firstGNum}|${lastGNum}
#mrate|uid|ou=People,${suffix}|user|${firstMNum}|${lastMNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=$suffix
define numadmins=1
define numsvcs=1
define numusers=${numUsers}
define numgroups=${numGroups}

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (targetattr="*")(version 3.0; acl "Authenticated Access"; allow(read,search,compare,write) userdn="ldap:///all";)
aci: (target="ldap:///[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "PAM LDAP Access"; allow(read,search,compare) userdn="ldap:///cn=pamldap,ou=Services,[suffix]";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "Service Accounts"; allow(read,search,compare) userdn="ldap:///cn=*,ou=ServiceAccounts,[suffix]";)

branch: ou=Admins,[suffix]
subordinateTemplate: enterpriseAdmin:[numadmins]

branch: ou=Services,[suffix]
subordinateTemplate: pamLDAP:1
subordinateTemplate: pamShadow:1
subordinateTemplate: adproxy:1

branch: cn=users,[suffix]
objectClass: container
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "AD Proxy Access"; allow(read,search,compare) userdn="ldap:///cn=adproxy,ou=Services,[suffix]";)

branch: ou=People,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "AD Proxy Access"; allow(read,search,compare) userdn="ldap:///cn=adproxy,ou=Services,[suffix]";)
subordinateTemplate: enterpriseUser:[numusers]

branch: cn=Groups,[suffix]
objectClass: container
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "AD Proxy Access"; allow(read,search,compare) userdn="ldap:///cn=adproxy,ou=Services,[suffix]";)

branch: ou=Groups,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "AD Proxy Access"; allow(read,search,compare) userdn="ldap:///cn=adproxy,ou=Services,[suffix]";)
subordinateTemplate: worldGroup:1
subordinateTemplate: enterpriseGroup:[numgroups]

branch: ou=rpc,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=protocols,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=networks,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=netgroup,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: cn=sysadmins,ou=netgroup,[suffix]
cn: sysadmins
objectClass: top
objectClass: nisNetgroup
nisNetgroupTriple: (,user10003,)
nisNetgroupTriple: (,user10004,)

branch: cn=interns,ou=netgroup,[suffix]
objectClass: top
objectClass: nisNetgroup
cn: interns
nisNetgroupTriple: (,user10005,)
nisNetgroupTriple: (,user10006,)

branch: cn=managers,ou=netgroup,[suffix]
objectClass: top
objectClass: nisNetgroup
cn: managers
nisNetgroupTriple: (,user10007,)
nisNetgroupTriple: (,user10008,)

branch: ou=aliases,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=hosts,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=ethers,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=projects,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=SolarisAuthAttr,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=SolarisProfAttr,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=ipTnet,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=printers,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: cn=automount,[suffix]
objectClass: top
objectClass: container

branch: automountMapName=auto.master,cn=automount,[suffix]
objectClass: top
objectClass: automountMap
automountMapName: auto.master

branch: automountMapName=auto.shares,cn=automount,[suffix]
objectClass: top
objectClass: automountMap
automountMapName: auto.shares

branch: automountKey=/shares,automountMapName=auto.master,cn=automount,[suffix]
objectClass: top
objectClass: automount
automountKey: /shares
automountInformation: auto.shares

branch: automountKey=components,automountMapName=auto.shares,cn=automount,[suffix]
objectClass: top
objectClass: automount
automountKey: components
automountInformation: ${localHost}:/export/components
description: components

branch: ou=SuDOers,[suffix]

branch: cn=defaults,ou=SuDOers,[suffix]
objectClass: sudoRole
description: Default sudo options go here
sudoOption: env_keep+=SSH_AUTH_SOCK


branch: cn=role1,ou=SuDOers,[suffix]
objectClass: sudoRole
objectClass: top
cn: role1
sudoUser: user1100
sudoHost: ALL
sudoCommand: ALL
sudoCommand: !/usr/bin/top
sudoCommand: !/bin/bash

template: enterpriseUser
rdnAttr: uid
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: geoObject
objectClass: socialPerson
objectClass: corpUser
uidNumber: <sequential:${firstUNum}>
gidNumber: {uidNumber}
employeeNumber: {uidNumber}
uid: user{uidNumber}
cn: {uid}
homeDirectory: /export/home/{uid}
loginShell: /bin/bash
sn: <last>
givenName: <first>
displayName: {givenName} {sn} ({employeeNumber})
gecos: {givenName} {sn}
description: {uid} POSIX Account
userPassword: $bPW
mail: {givenName}.{sn}@${domain}
telephoneNumber: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
mobile: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
title: <list:Contributor:Manager:Director:Vice President:President:CEO:CIO:Administrative Assistant>
photoURL: http://${localHost}:7001/nfDSRK/photos/{uid}.jpg
manager: uid=user<random:numeric:${firstUNum}:${hundredthUNum}>,ou=People,[suffix]
secretary: uid=user<random:numeric:${firstUNum}:${hundredthUNum}>,ou=People,[suffix]
isManager: yes
reportsTo: <list:Aartjan Aalders:Abagael Aasen>
departmentNumber: <list:1000:1001>
preferredLanguage: <list:US English:French:Spanish:UK English>
l: <list:US1:US2:US3:FR1:UK1:CN1>
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
friend: uid=user<random:numeric:${firstUNum}:${lastUNum}>,ou=People,[suffix]
location: <random:numeric:25:50>.<random:numeric:6>, -<random:numeric:70:120>.<random:numeric:6>
userStatus: <list:ACTIVE;80:INACTIVE;10:DISABLED;5:LOCKED;5>
userSSN: <random:numeric:3>-<random:numeric:2>-<random:numeric:4>

template: enterpriseAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: Admin
givenName: System
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

template: pamLDAP
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: pamldap
uid: {cn}
sn: Proxy User
givenName: PAM_LDAP
userPassword: $bPW

template: pamShadow
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: pamshadow
uid: {cn}
sn: PAM Shadow User
givenName: PAM_LDAP
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

template: adProxy
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: adproxy
uid: {cn}
sn: Proxy User
givenName: Active Directory
userPassword: $bPW

template: worldGroup
rdnAttr: cn
objectClass: Top
objectClass: groupOfNames
objectClass: posixGroup
cn: world
gidNumber: <sequential:1>
member: uid=user${firstMNum},ou=People,[suffix]
member: uid=user$((${firstMNum}+1)),ou=People,[suffix]
member: uid=user$((${firstMNum}+2)),ou=People,[suffix]
member: uid=user$((${firstMNum}+3)),ou=People,[suffix]
member: uid=user$((${firstMNum}+4)),ou=People,[suffix]
member: uid=user$((${firstMNum}+5)),ou=People,[suffix]
member: uid=user$((${firstMNum}+6)),ou=People,[suffix]
member: uid=user$((${firstMNum}+7)),ou=People,[suffix]
member: uid=user$((${firstMNum}+8)),ou=People,[suffix]
member: uid=user$((${firstMNum}+9)),ou=People,[suffix]
member: uid=user$((${firstMNum}+10)),ou=People,[suffix]
member: uid=user${lastMNum},ou=People,[suffix]

template: enterpriseGroup
rdnAttr: cn
objectClass: Top
objectClass: groupOfNames
objectClass: posixGroup
gidNumber: <sequential:${firstGNum}>
cn: group{gidNumber}
member: uid=user${firstMNum},ou=People,[suffix]
member: uid=user$((${firstMNum}+1)),ou=People,[suffix]
member: uid=user$((${firstMNum}+2)),ou=People,[suffix]
member: uid=user$((${firstMNum}+3)),ou=People,[suffix]
member: uid=user$((${firstMNum}+4)),ou=People,[suffix]
member: uid=user$((${firstMNum}+5)),ou=People,[suffix]
member: uid=user$((${firstMNum}+6)),ou=People,[suffix]
member: uid=user$((${firstMNum}+7)),ou=People,[suffix]
member: uid=user$((${firstMNum}+8)),ou=People,[suffix]
member: uid=user$((${firstMNum}+9)),ou=People,[suffix]
member: uid=user$((${firstMNum}+10)),ou=People,[suffix]
member: uid=user${lastMNum},ou=People,[suffix]
EOF
      set +x
   fi
}

###############################################################################
# Make Enterprise2 MakeLdif Template
###############################################################################
mkE2Template() {
   if [ -e "${templFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate enterprise v2 template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|uid|ou=People,${suffix}|user|${firstUNum}|${lastUNum}
#grate|cn|ou=Groups,${suffix}|group|${firstGNum}|${lastGNum}
#mrate|uid|ou=People,${suffix}|user|${firstMNum}|${lastMNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=$suffix
define numadmins=1
define numsvcs=1
define numusers=${numUsers}
define numgroups=${numGroups}

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (targetattr="*")(version 3.0; acl "Authenticated Access"; allow(read,search,compare,write) userdn="ldap:///all";)
aci: (target="ldap:///[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "PAM LDAP Access"; allow(read,search,compare) userdn="ldap:///cn=pamldap,ou=Services,[suffix]";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "Service Accounts"; allow(read,search,compare) userdn="ldap:///cn=*,ou=ServiceAccounts,[suffix]";)

branch: ou=Admins,[suffix]
subordinateTemplate: enterpriseAdmin:[numadmins]

branch: ou=Services,[suffix]
subordinateTemplate: pamLDAP:1
subordinateTemplate: pamShadow:1
subordinateTemplate: adproxy:1

branch: cn=users,[suffix]
objectClass: container
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "AD Proxy Access"; allow(read,search,compare) userdn="ldap:///cn=adproxy,ou=Services,[suffix]";)

branch: ou=People,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "AD Proxy Access"; allow(read,search,compare) userdn="ldap:///cn=adproxy,ou=Services,[suffix]";)
subordinateTemplate: enterpriseUser:[numusers]

branch: cn=Groups,[suffix]
objectClass: container
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "AD Proxy Access"; allow(read,search,compare) userdn="ldap:///cn=adproxy,ou=Services,[suffix]";)

branch: ou=Groups,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "AD Proxy Access"; allow(read,search,compare) userdn="ldap:///cn=adproxy,ou=Services,[suffix]";)
subordinateTemplate: worldGroup:1
subordinateTemplate: enterpriseGroup:[numgroups]

branch: ou=rpc,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=protocols,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=networks,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=netgroup,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: cn=sysadmins,ou=netgroup,[suffix]
cn: sysadmins
objectClass: top
objectClass: nisNetgroup
nisNetgroupTriple: (,user10003,)
nisNetgroupTriple: (,user10004,)

branch: cn=interns,ou=netgroup,[suffix]
objectClass: top
objectClass: nisNetgroup
cn: interns
nisNetgroupTriple: (,user10005,)
nisNetgroupTriple: (,user10006,)

branch: cn=managers,ou=netgroup,[suffix]
objectClass: top
objectClass: nisNetgroup
cn: managers
nisNetgroupTriple: (,user10007,)
nisNetgroupTriple: (,user10008,)

branch: ou=aliases,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=hosts,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=ethers,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=projects,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=SolarisAuthAttr,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=SolarisProfAttr,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=ipTnet,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: ou=printers,[suffix]
aci: (targetattr="*")(version 3.0; acl "PAM Shadow Access"; allow(all) userdn="ldap:///cn=pamshadow,ou=Services,[suffix]";)

branch: cn=automount,[suffix]
objectClass: top
objectClass: container

branch: automountMapName=auto.master,cn=automount,[suffix]
objectClass: top
objectClass: automountMap
automountMapName: auto.master

branch: automountMapName=auto.shares,cn=automount,[suffix]
objectClass: top
objectClass: automountMap
automountMapName: auto.shares

branch: automountKey=/shares,automountMapName=auto.master,cn=automount,[suffix]
objectClass: top
objectClass: automount
automountKey: /shares
automountInformation: auto.shares

branch: automountKey=components,automountMapName=auto.shares,cn=automount,[suffix]
objectClass: top
objectClass: automount
automountKey: components
automountInformation: ${localHost}:/export/components
description: components

branch: ou=SuDOers,[suffix]

branch: cn=defaults,ou=SuDOers,[suffix]
objectClass: sudoRole
description: Default sudo options go here
sudoOption: env_keep+=SSH_AUTH_SOCK


branch: cn=role1,ou=SuDOers,[suffix]
objectClass: sudoRole
objectClass: top
cn: role1
sudoUser: user1100
sudoHost: ALL
sudoCommand: ALL
sudoCommand: !/usr/bin/top
sudoCommand: !/bin/bash

template: enterpriseUser
rdnAttr: uid
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: corpUser
uidNumber: <sequential:${firstUNum}>
gidNumber: {uidNumber}
employeeNumber: {uidNumber}
uid: user{uidNumber}
cn: {uid}
homeDirectory: /export/home/{uid}
loginShell: /bin/bash
sn: <last>
givenName: <first>
displayName: {givenName} {sn} ({employeeNumber})
gecos: {givenName} {sn}
description: {uid} POSIX Account
userPassword: $bPW
mail: {givenName}.{sn}@${domain}
telephoneNumber: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
mobile: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
title: <list:Contributor:Manager:Director:Vice President:President:CEO:CIO:Administrative Assistant>
photoURL: http://${localHost}:7001/nfDSRK/photos/{uid}.jpg
manager: uid=user<random:numeric:${firstUNum}:${hundredthUNum}>,ou=People,[suffix]
isManager: yes
reportsTo: <list:Aartjan Aalders:Abagael Aasen>
departmentNumber: <list:1000:1001>
preferredLanguage: <list:US English:French:Spanish:UK English>
l: <list:US1:US2:US3:FR1:UK1:CN1>
userStatus: <list:ACTIVE;80:INACTIVE;10:DISABLED;5:LOCKED;5>
userSSN: <random:numeric:3>-<random:numeric:2>-<random:numeric:4>

template: enterpriseAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: Admin
givenName: System
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

template: pamLDAP
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: pamldap
uid: {cn}
sn: Proxy User
givenName: PAM_LDAP
userPassword: $bPW

template: pamShadow
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: pamshadow
uid: {cn}
sn: PAM Shadow User
givenName: PAM_LDAP
userPassword: $bPW

template: adProxy
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
cn: adproxy
uid: {cn}
sn: Proxy User
givenName: Active Directory
userPassword: $bPW

template: worldGroup
rdnAttr: cn
objectClass: Top
objectClass: groupOfNames
objectClass: posixGroup
cn: world
gidNumber: <sequential:1>
member: uid=user${firstMNum},ou=People,[suffix]
member: uid=user$((${firstMNum}+1)),ou=People,[suffix]
member: uid=user$((${firstMNum}+2)),ou=People,[suffix]
member: uid=user$((${firstMNum}+3)),ou=People,[suffix]
member: uid=user$((${firstMNum}+4)),ou=People,[suffix]
member: uid=user$((${firstMNum}+5)),ou=People,[suffix]
member: uid=user$((${firstMNum}+6)),ou=People,[suffix]
member: uid=user$((${firstMNum}+7)),ou=People,[suffix]
member: uid=user$((${firstMNum}+8)),ou=People,[suffix]
member: uid=user$((${firstMNum}+9)),ou=People,[suffix]
member: uid=user$((${firstMNum}+10)),ou=People,[suffix]
member: uid=user${lastMNum},ou=People,[suffix]

template: enterpriseGroup
rdnAttr: cn
objectClass: Top
objectClass: groupOfNames
objectClass: posixGroup
gidNumber: <sequential:${firstGNum}>
cn: group{gidNumber}
member: uid=user${firstMNum},ou=People,[suffix]
member: uid=user$((${firstMNum}+1)),ou=People,[suffix]
member: uid=user$((${firstMNum}+2)),ou=People,[suffix]
member: uid=user$((${firstMNum}+3)),ou=People,[suffix]
member: uid=user$((${firstMNum}+4)),ou=People,[suffix]
member: uid=user$((${firstMNum}+5)),ou=People,[suffix]
member: uid=user$((${firstMNum}+6)),ou=People,[suffix]
member: uid=user$((${firstMNum}+7)),ou=People,[suffix]
member: uid=user$((${firstMNum}+8)),ou=People,[suffix]
member: uid=user$((${firstMNum}+9)),ou=People,[suffix]
member: uid=user$((${firstMNum}+10)),ou=People,[suffix]
member: uid=user${lastMNum},ou=People,[suffix]
EOF
      set +x
   fi
}

###############################################################################
# Make InetOrg MakeLdif Template
###############################################################################
mkInetOrgTemplate() {
   if [ -e "${templFile}" ]
   then
      true
   else

      if [ $((${firstUNum}+9)) -gt ${lastUNum} ];then lastGroupUNum=$((${firstUNum}+9));fi


      let steps++
      echo "Step: ${steps} - Generate inetorg template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|uid|ou=People,${suffix}|user|${firstUNum}|${lastUNum}
#grate|cn|ou=Groups,${suffix}|group|${firstGNum}|${lastGNum}
#mrate|uid|ou=People,${suffix}|user|${firstMNum}|${lastMNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=$suffix
define domain=${domain}
define numusers=${numUsers}
define numadmins=2
define numgroups=${numGroups}

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Service Accounts"; allow(search,read) userdn="ldap:///uid=*,ou=Services,[suffix]";)
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=admin1,ou=Admins,[suffix]";)
aci: (target="ldap:///[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (targetattr="*")(version 3.0; acl "Authenticated Access"; allow(read,search,compare,write) userdn="ldap:///all";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "Service Accounts"; allow(read,search,compare) userdn="ldap:///cn=*,ou=ServiceAccounts,[suffix]";)
aci: (targetattr="orclIsEnabled||ds-pwp-account-disabled")(version 3.0; acl "Account Management Group"; allow (all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)

branch: ou=People,[suffix]
subordinateTemplate: customUser:[numusers]

branch: ou=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]

branch: ou=Services,[suffix]
subordinateTemplate: serviceAccount:[numadmins]

branch: ou=Groups,[suffix]
subordinateTemplate: inetOrgGroups:[numgroups]
subordinateTemplate: wlsAdminGroup:1

branch: cn=Directory Administrators,ou=Groups,[suffix]
objectClass: Top
objectClass: groupOfUniqueNames
cn: Directory Administrators
uniqueMember: uid=admin1,ou=Admins,[suffix]

template: customUser
rdnAttr: uid
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: user<sequential:${firstUNum}>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
mail: {givenName}.{sn}@[domain]

template: customAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

template: serviceAccount
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: svc<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW

template: inetOrgGroups
rdnAttr: cn
objectClass: Top
objectClass: groupOfUniqueNames
cn: group<sequential:${firstUGum}>
uniqueMember: uid=user$((${firstUNum}+0)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+1)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+2)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+3)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+4)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+5)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+6)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+7)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+8)),ou=People,[suffix]
uniqueMember: uid=user$((${firstUNum}+9)),ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]
uniqueMember: uid=user<random:numeric:$((${firstUNum}+9)):${lastGroupUNum}>,ou=People,[suffix]

template: wlsAdminGroup
rdnAttr: cn
objectClass: Top
objectClass: groupOfUniqueNames
cn: wlsAdmins
uniqueMember: uid=admin1,ou=Admins,[suffix]
EOF
      set +x
   fi
}

###############################################################################
# Make InetOrg MakeLdif Template
###############################################################################
mkSSLv3Template() {
   if [ -e "${templFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate SSLv3 template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|uid|ou=People,${suffix}|user|${firstUNum}|${lastUNum}
#grate|cn|ou=Groups,${suffix}|group|${firstGNum}|${lastGNum}
#mrate|uid|ou=People,${suffix}|user|${firstMNum}|${lastMNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=$suffix
define domain=${domain}
define numusers=${numUsers}
define numadmins=1
define numgroups=${numGroups}

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Service Accounts"; allow(search,read) userdn="ldap:///uid=*,ou=Services,[suffix]";)
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (target="ldap:///[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (targetattr="*")(version 3.0; acl "Authenticated Access"; allow(read,search,compare,write) userdn="ldap:///all";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "Service Accounts"; allow(read,search,compare) userdn="ldap:///cn=*,ou=ServiceAccounts,[suffix]";)

branch: ou=People,[suffix]
subordinateTemplate: customUser:[numusers]

branch: ou=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]

template: customUser
rdnAttr: uid
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: user<sequential:${firstUNum}>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
mail: {givenName}.{sn}@[domain]

template: customAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

EOF
      set +x
   fi
}

###############################################################################
# Make Bank MakeLdif Template
###############################################################################
mkBankTemplate() {
   if [ -e "${templFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate bank template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|uid|ou=People,${suffix}|user|${firstUNum}|${lastUNum}
#grate|cn|ou=Groups,${suffix}|group|${firstGNum}|${lastGNum}
#mrate|uid|ou=People,${suffix}|user|${firstMNum}|${lastMNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=$suffix
define numusers=$numUsers
define numadmins=1
define numgroups=${numGroups}

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (target="ldap:///[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)

branch: ou=People,[suffix]
subordinateTemplate: customUser:[numusers]

branch: ou=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]

branch: ou=Groups,[suffix]
subordinateTemplate: bankGroups:[numgroups]

template: customUser
rdnAttr: uid
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: ctscUserAuxClass
uid: user<sequential:${firstUNum}>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
ctscAccountEndDate: <random:numeric:14>Z
ctscAccountStartDate: <random:numeric:14>Z
ctscFailedLoginCount: 0
ctscLastResetDate: <random:numeric:14>Z
ctscLockoutExpirationDate: <random:numeric:14>Z
ctscPasswordCreationDate: <random:numeric:14>Z
ctscPasswordExpirationDate: <random:numeric:14>Z
ctscPasswordHistory: $bPW
ctscUserKeywords: NotExpired
ctscUserKeywords: PasswordPolicy

template: customAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

template: bankGroups
rdnAttr: cn
objectClass: Top
objectClass: groupOfNames
cn: group<sequential:${firstGNum}>
member: ${rateDN}100000001,ou=People,[suffix]
member: ${rateDN}100000002,ou=People,[suffix]
member: ${rateDN}100000003,ou=People,[suffix]
member: ${rateDN}100000004,ou=People,[suffix]
member: ${rateDN}100000005,ou=People,[suffix]
member: ${rateDN}100000006,ou=People,[suffix]
member: ${rateDN}100000007,ou=People,[suffix]
member: ${rateDN}100000008,ou=People,[suffix]
member: ${rateDN}100000009,ou=People,[suffix]
member: ${rateDN}100000010,ou=People,[suffix]
EOF
      set +x
   fi
}

###############################################################################
# Make Telco MakeLdif Template
###############################################################################
mkTelcoTemplate() {
   if [ -e "${templFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate ${templateName} template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|uid|ou=Subscribers,${suffix}|user|${firstUNum}|${lastUNum}
#grate|cn|ou=Groups,${suffix}|group|${firstGNum}|${lastGNum}
#mrate|uid|ou=Subscribers,${suffix}|user|${firstMNum}|${lastMNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=$suffix
define numusers=$numUsers
define numadmins=1

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (target="ldap:///[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)

branch: ou=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]

branch: ou=subscribers,[suffix]
subordinateTemplate: telcoUser:[numusers]

template: telcoUser
rdnAttr: uid
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: telcoAccountPerson
objectClass: telcoSubscriber
objectClass: inetUser
objectClass: inetAdmin
mobile: <sequential:${firstUNum}>
givenName: <first>
sn: <last>
cn: {givenName} {sn}
telcoINSPuid: <presence:9>{givenName}.{sn}
title: <list:Contributor:Manager:Director:Vice President:President:CEO:CIO:Administrative Assistant>
uid: user{mobile}
telcoAccountNumber: <random:numeric:100000000:200000000>
telcoAccountBillingID: <presence:19><list:00027:1,00043:1,04146:3877,04184:2031,40172:1052,40174:998,40176:748,40342:660,40344:487,40346:127,40687:88,40886:4,40887:2, 40889:4,40890:45,40891:34,40892:31,40893:25,40941:2,60057:260,85051:1>
telcoAccountSSN: <presence:91><random:numeric:9>
telcoAccountMarketIndicator: <list:cl:1157858,ill:2194227,lar:33347,mtz:1113703,mwr:826419,nbi:1204,nws:506075,nyr:935481,okc:667051,pac:7937751,rgv:81257,san:488187,sne:718344,stl:1169832,tul:343356,was:2111540,wtx:396667,001:337952,002:588344,003:1503065,004:491601,005:1548410,006:499222,007:432877,008:341592,009:379835,010:120278,011:551420,013:215254,014:310066,015:180052,016:194715,017:393191,019:185173,021:209521,022:539729,023:173877,024:194506,031:663027,032:301041,033:74244,034:178442,035:2011283,038:1210878,039:322134,040:644248,041:89009,042:2019010,043:671777,061:360002,066:835191,067:386814,1111:1,6132:1>
telcoAccountSubMarketIndicator: <random:alpha:3>
telcoDeviceBearerTechnology: <presence:99><list:gsm:1050576,gsm-gait:190,tdma:6>
telcoDeviceRatePlan: <presence:23><random:alpha:9>
telcoIPagerAddress: <presence:1><random:alphanumeric:8>
telcoLastReconciledDateTime: <presence:1><random:numeric:14>
telcoMobileChangeTo: <presence:1><random:numeric:10>
telcoMobileCreationDate: <random:numeric:8>
telcoMobileGeoCode: <presence:98><random:numeric:9>
telcoMobileIMEI: <presence:92><random:numeric:15>
telcoMobileIMSI: <presence:93><random:numeric:15>
telcoMobileMagID: <presence:69><random:alpha:3>_<random:alphanumeric:10>_vmag.mytelco.net
telcoMobileMailSubscriptionFlag: <presence:3><list:n:4002,y:14051>
telcoMobileMin: <presence:38><random:numeric:5>
telcoMobileMWWRegisteredFlag: <presence:9><list:n:610,y:157421>
telcoMobileNumberDST: <presence:9><list:n:1136,no:1,y:156254,yes:6>
telcoMobileNumberTimeZone: <presence:8><list:-0400:134,-0500:15631,-0600:1037,-0700:1728,-0800:131535,-0900:217,-1000:316,null:2907>
telcoMobileFailedAttemptCount: <presence:99><list:0:973382,1:29319,10:11,11:3,12:2,14:1,15:1,16:1,17:1,18:1,19:1,2:14775,3:17383,38:1,4:3474,5:2423,6:3436,7:950,8:1202,9:4405>
telcoMobileLockedFlag: <list:f:419,h:7040,n:1016571,r:434,s:26308>
telcoMobileRegisteredFlag: <list:n:585434,y:465338>
telcoMobileSoftLockedDateTime: <presence:13><random:numeric:19>
telcoMobilePrePaidPlatform: <random:alpha:8>
telcoMobilePrimaryDevice: <presence:3><list:rim:167,wt:17141>
telcoMobilePTTRegisteredFlag: <presence:7><list:n:1,y:157421>
telcoMobileRingbackTonesRegisteredFlag: <ifpresent:telcoMobilePTTRegisteredFlag>{telcoMobilePTTRegisteredFlag}
telcoMobileSSN: <ifpresent:telcoAccountSSN><presence:80>{telcoAccountSSN}
telcoMobileTextSubscriptionFlag: <presence:3><list:n:4975,y:13078>
telcoSecurityQuestion: <presence:3><random:alpha:25>
telcoSecurityAnswer: <ifpresent:telcoSecurityQuestion><random:alpha:6>
telcoSubscriberSubMarket: <random:alpha:3>
telcoSubscriberAccountNumber: <random:alphanumeric:1:20>
telcoSubscriberNumber: <random:alphanumeric:1:20>
telcoSubscriberProductType: <random:alphanumeric:1>
telcoSubscriberCompanyName: <random:alpha:1:20>
telcoSubscriberLastName: <last>
telcoSubscriberFirstName: <first>
telcoSubscriberSuffix: <random:alphanumeric:12>
telcoSubscriberType: <random:alphanumeric:1>
street: <random:numeric:5> <file:streets> <list:Street,Road,Lane,Avenue,Boulevard,Trail,Trace,Way,Court>
telcoSubscriberCity: <file:cities>
telcoSubscriberState: <file:states>
telcoSubscriberZipcode5: <random:numeric:5>
telcoSubscriberZipcode4: <random:numeric:4>
telcoSubscriberCounty: <random:alpha:3>
telcoSubscriberCountry: <random:alpha:3>
telcoSubscriberGeoCode: <random:alphanumeric:10>
telcoSubscriberSsn: <random:numeric:9>
telcoSubscriberTaxid: <random:numeric:9>
telcoSubscriberDateOfBirth: <random:numeric:8>
telcoSubscriberDriversLicenseNumber: <random:alphanumeric:7>
telcoSubscriberDriversLicenseState: <file:states>
telcoSubscriberDriversLicenseExpireDate: <random:numeric:8>
telcoSubscriberSubcompanyName: <random:alphanumeric:1:10>
telcoSubscriberSublastName: <last>
telcoSubscriberSubfirstName: <first>
telcoSubscriberSubsuffix: <random:alphanumeric:12>
telcoSubscriberSubadditionalTitle: <random:alphanumeric:1:10>
telcoSubscriberTelephoneNumber: <random:telephone>
telcoSubscriberTelephoneNumberExtension: <random:alphanumeric:4>
telcoSubscriberStartDate: <random:numeric:8>
telcoSubscriberEndDate: <random:numeric:8>
telcoSubscriberStatusReasonCode: <random:alphanumeric:4>
telcoSubscriberStatusDate: <random:numeric:8>
mail: {givenName}.{sn}@<list:example,a,iop,airius,government>.com
telcoSubscriberPrimaryEmailAddress: {mail}
telcoSubscriberContractTerm: <random:numeric:3>
telcoSubscriberContractSequenceNumber: <random:numeric:9>
telcoSubscriberContractReasonCode: <random:numeric:4>
telcoSubscriberContractType: <random:alphanumeric:1>
telcoSubscriberContractStartDate: <random:numeric:8>
telcoSubscriberContractEndDate: <random:numeric:8>
telcoSubscriberContractWaivePenalty: <random:alphanumeric:1>
telcoSubscriberContractCommissionsAgent: <random:alphanumeric:1:7>
telcoSubscriberContractCommissionRetail: <random:alphanumeric:1:7>
telcoSubscriberContractCommissionsSales: <random:alphanumeric:1:7>
telcoSubscriberCommissionsAgent: <random:alphanumeric:1:7>
telcoSubscriberCommissionsRetail: <random:alphanumeric:1:7>
telcoSubscriberCommissionSales: <random:alphanumeric:1:7>
telcoSubscriberTechType: <random:alphanumeric:1>
telcoSubscriberDeviceIMEIserialNumber: <random:alphanumeric:1:20>
telcoSubscriberDeviceIMEIumtsCapability: <random:alphanumeric:1>
telcoSubscriberDeviceIMEIpcCard: <random:alphanumeric:1>
telcoSubscriberDeviceESNSerialNumber: <random:alphanumeric:1:20>
telcoSubscriberDeviceESNType: <random:alphanumeric:1>
telcoSubscriberDeviceSIMSerialNumber: <random:alphanumeric:1:20>
telcoSubscriberDeviceSIMImsi: <random:alphanumeric:15>
telcoSubscriberDeviceSIMPuk1: <random:alphanumeric:8>
telcoSubscriberDeviceSIMPuk2: <random:alphanumeric:8>
telcoSubscriberDeviceSIMUiccKeyPublicKey: <random:alphanumeric:1:75>
telcoSubscriberDeviceSIMUiccKeyPrivateKey: <random:alphanumeric:1:75>
telcoSubscriberDeviceManufacturerMake: <random:alphanumeric:1:40>
telcoSubscriberVoiceMailId: <random:alphanumeric:1:30>
telcoSubscriberB2BAbiNumber: <random:alphanumeric:9>
telcoSubscriberB2BLiability: <random:alphanumeric:1>
telcoSubscriberB2BSegment: <random:alphanumeric:2>
telcoSubscriberB2BBusinessUnit: <random:alphanumeric:2>
telcoSubscriberSpendingLimitAmount: <random:numeric:1:999999999>.<random:numeric:1:99>
telcoSubscriberMergerMigration: <random:alphanumeric:1>
telcoSubscriberChurn: <random:numeric:1>
telcoSubscriberCseRatePlan: <random:alphanumeric:1>
telcoSubscriberRoutingDesignation: <random:alphanumeric:10>
telcoSubscriberDepositAmount: <random:numeric:1:999999999>.<random:numeric:1:99>
telcoSubscriberActivationFee: <random:numeric:1:999999999>.<random:numeric:1:99>
telcoSubscriberChurnIndicator: <random:alphanumeric:1>
telcoSubscriberLTV: <random:numeric:1:999999999>.<random:numeric:1:99>
telcoSubscriberARPU: <random:numeric:1:999999999>.<random:numeric:1:99>
telcoSubscriberLastUpdate: <random:numeric:8>
telcoSubscriberLastUpdateBy: <random:alphanumeric:1:20>
telcoSubscriberClosedDate: <presence:3><random:numeric:14>
telcoSubscriberLastUpdateApp: <presence:89><list:appatlas:90443,apprecon:932920,reconciled:124>
telcoSubscriberLastUpdateDateTime: <ifpresent:telcoSubscriberLastUpdateApp><random:numeric:14>
telcoSubscriberLastUpdateType: <ifpresent:telcoSubscriberLastUpdateApp><list:add:871,mod:1020875>
telcoSubscriberStatus: <list:a:1040329,c:4534,s:5909>
telcoSubscriberStatusChangeDate: <presence:32><random:numeric:14>
telcoTempAuthorizationCode: <presence:3><random:alphanumeric:6>
telcoUserBirthDate: <presence:7><random:numeric:8>
telcoUserOptInStatus: <presence:6><list:n:90764,y:49497>
inetUserStatus: <list:active:1040329,inactive:10443>
l: <file:cities>
postalCode: <random:numeric:5>-<random:numeric:4>
preferredLanguage: <list:e:1043466,s:7297>
roomNumber: <presence:8><random:alphanumeric:7>
st: <file:states>
userPassword: $bPW

template: customAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search
EOF
      set +x
   fi
}

###############################################################################
# Make TNS (Net Services) MakeLdif Template
###############################################################################
mkTnsTemplate() {
   if [ -e "${templFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate tns template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|cn|ou=Databases,cn=OracleContext,${suffix}|db|${firstUNum}|${lastUNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=$suffix
define numdbs=$numUsers
define numadmins=1
define sid=${localH}

branch: [suffix]

branch: ou=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]

branch: cn=OracleContext,[suffix]
objectclass: top
objectclass: orclContext
objectclass: orclContextAux82

branch: ou=Databases,cn=OracleContext,[suffix]
objectClass: Top
objectClass: organizationalunit
ou: Databases
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (target="ldap:///ou=Databases,cn=OracleContext,[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (target ="ldap:///ou=Databases,cn=OracleContext,[suffix]")(targetattr != "userPassword")(version 3.0;acl "Anonymous read-search access"; allow (read, search, compare)(userdn = "ldap:///anyone");)
subordinateTemplate: tnsCdbEntries:[numdbs]
subordinateTemplate: tnsPdbEntries:[numdbs]

template: tnsCdbEntries
rdnAttr: cn
objectClass: Top
objectClass: orclNetService
cn: mydb<sequential:1>
description: Example database service
orclNetDescString: (DESCRIPTION= (ADDRESS = (PROTOCOL = TCP)(HOST = ${localHost} )(PORT = 1521))(CONNECT_DATA = (SERVICE_NAME = {cn} )))

template: tnsPdbEntries
rdnAttr: cn
orclVersion: 121000
cn: mypdb<sequential:1>_[sid]
orclServiceType: DB
orclSid: [sid]
objectClass: orclApplicationEntity
objectClass: orclDBServer_92
objectClass: orclService
objectClass: orclDBServer
objectClass: top
orclOracleHome: ${curdir}/db/19c/dbhome_1
orclSystemName: ${localHost}
orclNetDescString: (DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${localHost})(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=mypdb<sequential:1>.${domain})))
orclDBGlobalName: {cn}
userPassword: ${bPW}
orclNetDescName: 000:cn=DESCRIPTION_0

template: customAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search
EOF
      set +x
   fi
}


###############################################################################
# Make T2 MakeLdif Template
###############################################################################
mkT2Template() {
   if [ -e "${templFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate ${templateName} template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|devid|ou=Devices,${suffix}||${firstUNum}|${lastUNum}
#grate|subid|ou=Subscribers,${suffix}||${firstGNum}|${lastGNum}
#mrate|devid|ou=Subscribers,${suffix}|user|${firstMNum}|${lastMNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#

# Target ratio of 10 devices per subscriber
define suffix=${suffix}
define numsubs=${numGroups}
define numdevices=${numUsers}
define numadmins=1

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (target="ldap:///[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)

branch: ou=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]

branch: ou=Subscribers,[suffix]
subordinateTemplate: t2Subscriber:[numsubs]

branch: ou=Devices,[suffix]
subordinateTemplate: t2Device:[numdevices]

template: t2Device
rdnAttr: devid
objectClass: top
objectClass: t2Device
devid: <sequential:1>
preferredLanguage: <list:EN:FR:RO:CA>
deviceType: <list:G:R:T:M:I:J>
deviceLastUpdateDate: <random:numeric:2000:2023><random:numeric:10:12><random:numeric:10:28><random:numeric:10:12><random:numeric:10:58><random:numeric:10:58>
deviceIMSI: <random:numeric:100000000000000:999999999999999>
deviceSubType: <random:numeric:1>
deviceICCID: <random:numeric:10000000000000000:999999999999999999>
deviceSCPID: <random:numeric:1>
deviceSPID: <random:numeric:1>
deviceLastOP: <list:ACT:SUP:MAL:LOK:UNP>
wapCOS: <random:numeric:10:99>
wapSubNo: <random:numeric:100000000:999999999>
province: <list:ON:BR:AB:CA:LM:QN>
deviceSubLink: subid=<random:numeric:1:100000>,ou=Subscribers,[suffix]
vmDeposit: <random:numeric:1000000000000:9999999999999>
tzOffset: <list:0:1:2:3:4:5>
activationDate: <random:numeric:2000:2023><random:numeric:10:12><random:numeric:10:28><random:numeric:10:12><random:numeric:10:58><random:numeric:10:58>
subscriberStatus: <list:A:I:S:L:U>

template: t2Subscriber
rdnAttr: subid
objectClass: top
objectClass: t2Subscriber
subid: <sequential:1>
t2SubType: <list:T:R:F:I:D>
t2Type: <list:S:L:R:F:I:D>
t2BillCycle: <list:30:15:7:14:24>

template: customAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: ${bPW}
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search
EOF
      set +x
   fi
}

###############################################################################
# Make TNS (Net Services) MakeLdif Template
###############################################################################
mkTnsTemplate() {
   if [ -e "${templFile}" ]
   then
      true
   else
      let steps++
      echo "Step: ${steps} - Generate tns template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|cn|ou=Databases,cn=OracleContext,${suffix}|db|${firstUNum}|${lastUNum}
#uadmin|uid|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=$suffix
define numdbs=$numUsers
define numadmins=1
define sid=${localH}

branch: [suffix]

branch: ou=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]

branch: cn=OracleContext,[suffix]
objectclass: top
objectclass: orclContext
objectclass: orclContextAux82

branch: ou=Databases,cn=OracleContext,[suffix]
objectClass: Top
objectClass: organizationalunit
ou: Databases
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (target="ldap:///ou=Databases,cn=OracleContext,[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (target ="ldap:///ou=Databases,cn=OracleContext,[suffix]")(targetattr != "userPassword")(version 3.0;acl "Anonymous read-search access"; allow (read, search, compare)(userdn = "ldap:///anyone");)
subordinateTemplate: tnsCdbEntries:[numdbs]
subordinateTemplate: tnsPdbEntries:[numdbs]

template: tnsCdbEntries
rdnAttr: cn
objectClass: Top
objectClass: orclNetService
cn: mydb<sequential:1>
description: Example database service
orclNetDescString: (DESCRIPTION= (ADDRESS = (PROTOCOL = TCP)(HOST = ${localHost} )(PORT = 1521))(CONNECT_DATA = (SERVICE_NAME = {cn} )))

template: tnsPdbEntries
rdnAttr: cn
orclVersion: 121000
cn: mypdb<sequential:1>_[sid]
orclServiceType: DB
orclSid: [sid]
objectClass: orclApplicationEntity
objectClass: orclDBServer_92
objectClass: orclService
objectClass: orclDBServer
objectClass: top
orclOracleHome: ${curdir}/db/19c/dbhome_1
orclSystemName: ${localHost}
orclNetDescString: (DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${localHost})(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=mypdb<sequential:1>.${domain})))
orclDBGlobalName: {cn}
userPassword: ${bPW}
orclNetDescName: 000:cn=DESCRIPTION_0

template: customAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: $bPW
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search
EOF
      set +x
   fi
}

###############################################################################
# Make Active Directory MakeLdif Template
###############################################################################
mkAdTemplate() {
   if [ -e "${templFile}" ]
   then
      true
   else

#manager: cn=user<random:numeric:${firstUNum}:${hundredthUNum}>,cn=Users,[suffix]
#secretary: cn=user<random:numeric:${firstUNum}:${hundredthUNum}>,cn=Users,[suffix]

      let steps++
      echo "Step: ${steps} - Generate AD template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile}.pre <<EOF
#
#suffix|${suffix}
#urate|cn|cn=Users,${suffix}|user|${firstUNum}|${lastUNum}
#grate|cn|cn=Groups,${suffix}|user|${firstGNum}|${lastGNum}
#uadmin|cn|cn=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=${suffix}
define domain=${domain}
define numusers=$numUsers
define numadmins=1

branch: [suffix]

branch: cn=ServiceAccounts,[suffix]

branch: cn=Admins,[suffix]
subordinateTemplate: adAdmin:[numadmins]

branch: cn=Users,[suffix]
subordinateTemplate: adUser:[numusers]
objectClass: adcontainer
description: Users
distinguishedName: cn=Users,[suffix]
instanceType: 4
showInAdvancedViewOnly: FALSE
name: Users

template: adUser
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: Person
objectClass: User
objectClass: posixAccount
sAMAccountName: user<sequential:${firstUNum}>
objectCategory: CN=Person,CN=Schema,CN=Configuration,[suffix]
codePage: 0
countryCode: 0
division: US
sn: <last>
givenName: <first>
objectGUID:: DF/V/iuG7ESdBPUrdUTPBA==
cn: ${adCnValue}
instanceType: 4
userAccountControl: 514
accountExpires: 0
uidNumber: <sequential:${firstUidNum}>
gidNumber: <sequential:${firstGidNum}>

template: adAdmin
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: Person
objectClass: User
sAMAccountName: admin<sequential:${firstUNum}>
objectCategory: CN=Person,CN=Schema,CN=Configuration,[suffix]
codePage: 0
countryCode: 0
division: US
sn: <last>
givenName: <first>
objectGUID:: DF/V/iuG7ESdBPUrdUTPBA==
cn: ${adCnValue}
instanceType: 4
userAccountControl: 514
accountExpires: 0

EOF


      cat > ${templFile} <<EOF
#
#suffix|${suffix}
#urate|cn|cn=Users,${suffix}|user|${firstUNum}|${lastUNum}
#grate|cn|cn=Groups,${suffix}|user|${firstGNum}|${lastGNum}
#uadmin|cn|ou=Admins,${suffix}|admin|${firstANum}|${lastANum}
#
define suffix=${suffix}
define domain=${domain}
define numusers=$numUsers
define numgroups=${numGroups}
define numadmins=1

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///cn=*,cn=Admins,[suffix]";) aci: (target="ldap:///[suffix]")(targetattr="*")(version 3.0; acl "Admin group"; allow(all) groupdn = "ldap:///cn=Directory Administrators,ou=Groups,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///all";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "AD Admin contorls"; allow(read,search,compare) userdn="ldap:///cn=*,cn=Admins,[suffix]";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "OUD Admin contorls"; allow(read,search,compare) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "OUD Admin contorls"; allow(read,search,compare) userdn="ldap:///cn=*,ou=ServiceAccounts,[suffix]";)

branch: cn=Users,[suffix]
subordinateTemplate: adUser:[numusers]
subordinateTemplate: adAdministrator:[numadmins]
subordinateTemplate: eusAdmin:[numadmins]
objectClass: adcontainer
description: Users
distinguishedName: cn=Users,[suffix]
instanceType: 4
showInAdvancedViewOnly: FALSE
name: Users

branch: cn=Groups,[suffix]
subordinateTemplate: eusGroups:[numgroups]
objectClass: adcontainer
description: Groups
distinguishedName: cn=Groups,[suffix]
instanceType: 4
showInAdvancedViewOnly: FALSE
name: Groups

branch: cn=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]
objectClass: adcontainer
description: Admins
distinguishedName: cn=Admins,[suffix]
instanceType: 4
showInAdvancedViewOnly: FALSE
name: Admins

template: eusAdmin
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: user
objectClass: inetOrgPerson
sn: eusadmin
givenName: eusadmin
employeeID: 999
cn: eusadmin
objectCategory: CN=Person,CN=Schema,CN=Configuration,[suffix]
distinguishedName: cn=eusadmin,cn=users,[suffix]
sAMAccountName: eusadmin
userAccountControl: 514
accountExpires: 0
uid: {sAMAccountName}
codePage: 0
instanceType: 4
userPassword: ${bPW}

template: customAdmin
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: user
sn: <last>
givenName: <first>
employeeID: 888
sAMAccountName: admin<sequential:1>
cn: {sAMAccountName}
uid: {sAMAccountName}
userPassword: ${bPW}
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

template: eusGroups
rdnAttr: cn
objectClass: Top
objectClass: group
gidNumber: <sequential:${firstGidNum}>
cn: US{gidNumber}
samAccountName: {cn}
distinguishedName: CN={cn},CN=Groups,[suffix]
member: cn=user1,cn=Users,[suffix]
member: cn=user2,cn=Users,[suffix]
member: cn=user3,cn=Users,[suffix]
member: cn=user4,cn=Users,[suffix]
member: CN=Aare5 Atp,CN=Users,[suffix]
member: CN=Aarika Atpco,CN=Users,[suffix]

template: adUser
rdnAttr: cn
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: User
objectClass: posixAccount
objectCategory: CN=Person,CN=Schema,CN=Configuration,[suffix]
codePage: 0
countryCode: 0
division: US
sn: <last>
givenName: <first>
employeeID: <sequential:${firstUNum}>
sAMAccountName: user{employeeID}
uid: {sAMAccountName}
objectGUID:: DF/V/iuG7ESdBPUrdUTPBA==
cn: ${adCnValue}
displayName: {cn}
userPrincipalName: {sAMAccountName}@[domain]
name: {givenName} {sn}
distinguishedName: CN={cn},CN=Users,[suffix]
telephoneNumber: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
instanceType: 4
userAccountControl: 514
accountExpires: 0
altSecurityIdentities: Kerberos:{userPrincipalName}
mail: {userPrincipalName}
homeDrive: Z:
uidNumber: <sequential:${firstUidNum}>
gidNumber: <sequential:${firstGidNum}>
homeDirectory: \\ads\home\{sAMAccountName}
homeDrive: Z:
unixHomeDirectory: /home/{sAMAccountName}
loginShell: /bin/bash
mobile: (<random:numeric:3>) <random:numeric:3>-<random:numeric:4>
title: <list:Contributor:Manager:Director:Vice President:President:CEO:CIO:Administrative Assistant>
manager: <file:${cfgdir}/managers>
secretary: <file:${cfgdir}/secretaries>
userPassword: ${bPW}
ds-privilege-name: unindexed-search

template: adAdministrator
rdnAttr: cn
objectClass: Top
objectClass: organizationalPerson
objectClass: Person
objectClass: User
sAMAccountName: Administrator
objectCategory: CN=Person,CN=Schema,CN=Configuration,[suffix]
codePage: 0
countryCode: 0
division: US
sn: <last>
givenName: <first>
objectGUID:: DF/V/iuG7ESdBPUrdUTPBA==
cn: Administrator
instanceType: 4
userPassword: ${bPW}
userAccountControl: 514
accountExpires: 0
EOF
   fi
}

###############################################################################
# Make Apps MakeLdif Template
###############################################################################
mkAppsTemplate() {
   if [ -e "${templFile}" ]
   then
      true
   else

      let steps++
      echo "Step: ${steps} - Generate Apps template"| tee -a  ${logdir}/gendata-${now}.log
      cat > ${templFile} <<EOF
#
#suffix|o=apps
#urate|uid|ou=People,o=apps|user|0|0
#grate|cn|ou=Groups,o=apps|group|0|0
#mrate|uid|ou=People,o=apps|user|0|0
#uadmin|uid|ou=Admins,o=apps|admin|1|1
#
define suffix=o=apps
define numadmins=1
define numusers=$numUsers

branch: [suffix]
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///cn=*,ou=Admins,[suffix]";)
aci: (targetattr="*")(targetscope="subtree")(version 3.0; acl "Admin Users"; allow(all) userdn="ldap:///uid=*,ou=Admins,[suffix]";)
aci: (targetattr="*")(version 3.0; acl "Self Access"; allow(read,search,compare,write) userdn="ldap:///self";)
aci: (targetcontrol="1.3.6.1.4.1.4203.1.10.1") (version 3.0; acl "OUD Admin contorls"; allow(read,search,compare) userdn="ldap:///cn=*,ou=ServiceAccounts,[suffix]";)

branch: ou=Preferences,[suffix]
subordinateTemplate: customUserPreferences:[numusers]

branch: ou=ServiceAccounts,[suffix]

branch: cn=badgeadmin,ou=ServiceAccounts,o=apps
objectClass: organizationalperson
objectClass: inetorgperson
uid: badgeadmin
cn: badgeadmin
sn: Service Account
givenName: Badge
userPassword: ${bPW}
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

branch: cn=accessadmin,ou=ServiceAccounts,o=apps
objectClass: organizationalperson
objectClass: inetorgperson
uid: accessadmin
cn: accessadmin
sn: Service Account
givenName: Acccess Certification
userPassword: ${bPW}
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search

branch: ou=Admins,[suffix]
subordinateTemplate: customAdmin:[numadmins]

template: customUserPreferences
rdnAttr: uid
objectClass: Top
objectClass: Person
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: user<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
description: {givenName} {sn} ({uid})

template: customAdmin
rdnAttr: uid
objectClass: Top
objectClass: organizationalPerson
objectClass: inetOrgPerson
uid: admin<sequential:1>
cn: {uid}
sn: <last>
givenName: <first>
userPassword: ${bPW}
ds-privilege-name: password-reset
ds-privilege-name: unindexed-search
EOF
   fi
}

###############################################################################
# Gen Make LDIF Template
###############################################################################
gen_template() {
   if [ -e "${templFile}" ] && [ "${rmFiles}" == 'false' ]
   then
      echo "ERROR: Template file alread exists: ${templFile}"
      exit 1
   fi

   if [ -n "${templateName}" ]
   then
      # Purge if requested
      if [ "${dbg}" == 'true' ];then set -x;fi
      if [ -e "${templFile}" ] && [ "${rmFiles}" == 'true' ];then rm -f ${templFile};set +x;fi

      case ${templateName} in
         'enterprise') mkEnterpriseTemplate;dnFilter="uid=user";;
                 'e2') mkE2Template;dnFilter="uid=user";;
            'inetorg') mkInetOrgTemplate;dnFilter="uid=user";;
              'sslv3') mkSSLv3Template;dnFilter="uid=user";;
               'bank') mkBankTemplate;dnFilter="uid=user";;
              'telco') mkTelcoTemplate;dnFilter="uid=user";;
                 't2') mkT2Template;dnFilter="uid=user";;
                'tns') mkTnsTemplate;dnFilter="cn=db";;
               'apps') mkAppsTemplate; dnFilter="uid=";;
                 'ad') mkAdTemplate; dnFilter="cn=";;
                'eus') mkTnsTemplate;dnFilter="cn=db";;
      esac

      if [ -n "${myDnFilter}" ];then dnFilter="${myDnFilter}";fi
      if [ -n "${myRdnFile}" ];then rdnFile="${myRdnFile}";else rdnFile="${cfgdir}/${templateName}.rdn";fi
      if [ -n "${myDnFile}" ];then dnFile="${myDnFile}";else dnFile="${cfgdir}/${templateName}.dn";fi

      # Generate corresponding info file for load generation
      grep "^#" ${cfgdir}/${templateName}.tmpl|head -10 >  ${cfgdir}/${templateName}.info 2> /dev/null
   fi
   echo ${steps} > ${cfgdir}/.steps.gendata 2> /dev/null
}

rmFiles='false'

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            swdir) swdir="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            suffix) suffix="$1";shift;;
            tmpl) myTemplFile="$1";shift;;
            ldif) myLdifFile="$1";shift;;
            step) steps="$1";shift;;
            nosudo) sudoFlag=' --nosudo';;
            rm) rmFiles='true';;
            gcnt) moreGroups="$1";shift;;
            gmembers) moreMembers="$1";shift;;
            dnfilter) myDnFilter="$1";shift;;
            dnfile) myDnFile="$1";shift;;
            rdnfile) myRdnFile="$1";shift;;
            domain) domain="$1";shift;;
            usename) adCnValue='{givenName} {sn}';;
            12c) fmwVersion='12c';fmwFlag="--${fmwVersion}";;
            14c) fmwVersion='14c';fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            N) numUsers="$1";shift;;
            g) numGroups="$1";shift;;
            G) numMembers=$1;shift;;
            n) myTemplateName=$1; shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done
export fmwVersion fmwFlag
setfmwenv

if [ -n "${myTemplateName}" ];then templateName=${myTemplateName};fi
if [ -z "${templateName}" ];then templateName='enterprise';fi
if [ -n "${myTemplFile}" ];then templFile=${myTemplFile};else templFile="${cfgdir}/${templateName}.tmpl";fi

if [ -z "${adCnValue}" ];then adCnValue='{sAMAccountName}';fi

if [ -n "${myLdifFile}" ];then ldifFile="${myLdifFile}"
else
   if [ -n "${templateName}" ]
   then
      ldifFile=${cfgdir}/${templateName}.ldif
   else
      ldifFile=${cfgdir}/my.ldif
   fi
fi
infoFile=$(echo ${ldifFile}|sed -e "s/\.ldif/\.info/g")

if [ -n "${templateName}" ];then batchFile=${cfgdir}/${templateName}.batch;fi

# Set user, group and member counts based on numUsers
if [ -z "$numUsers" ];then numUsers=10000;fi
if [ -z "$numGroups" ];then numGroups=100;fi
if [ -z "$numMembers" ];then numMembers=100;fi

# firstUNum=$((${numUsers}*10))
# firstGNum=$((${numGroups}*10))
# firstMNum=${firstUNum}

lastU=$((${numUsers}-1))
firstUNum=1
lastUNum=$((${firstUNum}+${numUsers}-1))
hundredthUNum=$((${firstUNum}+100))
firstGNum=1
lastGNum=$((${firstGNum}+${numGroups}-1))
firstMNum=1
lastMNum=$((${firstMNum}+${numMembers}-1))
firstANum=1
lastANum=2
firstUidNum=5000
firstGidNum=5000

magnitude=$((${numUsers}*10))
firstNum=$((${magnitude}))
lastNum=$((${magnitude}+${numUsers}-1))

firstContractor=$((${firstNum}*2))
tfile=$(basename "${templFile}")

if [ -n "${myDnFilter}" ];then dnFilter="${myDnFilter}";fi
if [ -n "${myRdnFile}" ];then rdnFile="${myRdnFile}";else rdnFile="${cfgdir}/${templateName}.rdn";fi
if [ -n "${myDnFile}" ];then dnFile="${myDnFile}";else dnFile="${cfgdir}/${templateName}.dn";fi
export dnFilter

###############################################################################
# Generate Data
###############################################################################
gen_data() {
   ${curdir}/manage_install.sh extract jdk ${fmwFlag} --step ${steps}
   if [ -e "${cfgdir}/.steps.extracted" ];then steps=$(cat ${cfgdir}/.steps.extracted);fi

   ############################################################################
   # Install OUD
   ############################################################################
   rm -f ${cfgdir}/.steps.install.oud 2> /dev/null
   if [ "${dbg}" == 'true' ];then set -x;fi
   setfmwenv

   ${curdir}/manage_install.sh install oud --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag} --step ${steps}
   set +x
   if [ -e "${cfgdir}/.steps.install.oud" ];then steps=$(cat ${cfgdir}/.steps.install.oud);fi

   ############################################################################
   # Generate LDIF file from Make LDIF template
   ############################################################################
   # Purge if requested
   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -n "${templateName}" ] &&  [ -e "${ldifFile}" ] && [ "${rmFiles}" == 'true' ];then rm -f ${ldifFile};set +x;fi

   if [ -e "${templFile}" ]
   then
      let steps++
      echo "Step: ${steps} - Generate LDIF file from ${templateName} template"| tee -a  ${logdir}/gendata-${now}.log

      if [ "${templateName}" == 'ad' ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/oud/bin/make-ldif -t ${templFile}.pre -o ${ldifFile}.pre.tmp >> ${logdir}/gendata-${now}.log 2>&1
         rc=$?

         # Filter out untypedobject added by make-ldif
         egrep -vi "untypedobject" ${ldifFile}.pre.tmp > ${ldifFile}.pre 2> /dev/null


         grep "^dn: cn=" ${ldifFile}.pre|egrep -i "ou=People|cn=Users"|sed -e "s/^dn: //g"|grep -v "^cn=Users" > ${cfgdir}/ad.dn.pre
         head -50 ${cfgdir}/ad.dn.pre|tail -10 > ${cfgdir}/managers
         tail -10 ${cfgdir}/ad.dn.pre > ${cfgdir}/secretaries

         rm -f ${cfgdir}/ad*.pre ${cfgdir}/ad*.pre.tmp 2> /dev/null

         ${oudmwdir}/oud/bin/make-ldif -t ${templFile} -o ${ldifFile}.tmp >> ${logdir}/gendata-${now}.log 2>&1
         rc=$?

         # Filter out untypedobject added by make-ldif
         egrep -vi "untypedobject" ${ldifFile}.tmp > ${ldifFile}  2> /dev/null

         rm -f ${ldifFile}.tmp 2> /dev/null
      else
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/oud/bin/make-ldif -t ${templFile} -o ${ldifFile}.tmp >> ${logdir}/gendata-${now}.log 2>&1
         rc=$?

         # Filter out untypedobject added by make-ldif
         egrep -vi "untypedobject" ${ldifFile}.tmp > ${ldifFile} 2> /dev/null

         rm -f ${ldifFile}.tmp 2> /dev/null
      fi

   else
      echo "Error: Template file (${templFile}) does not exist."
      exit 1
   fi

   # If requested, add additional groups
   addGroups
   echo ${steps} > ${cfgdir}/.steps.gendata 2> /dev/null
}

##############################################################################
# Generate DN list file
##############################################################################
gen_dn_file() {
   if [ -z "${dnFilter}" ]
   then
      echo "Usage: ${cmd} gendn --dnfilter <filter>"
      exit 1
   fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -z "${myDnFile}" ] && [ -n "${myLdifFile}" ];then dnFile=$(basename ${myLdifFile}|sed -e "s/\.ldif//gi");dnFile="${cfgdir}/${dnFile}.dn";fi

   if [ -e "${ldifFile}" ]
   then
      let steps++
      echo "Step: ${steps} - Generate DN list with filter (${dnFilter})"| tee -a  ${logdir}/gendata-${now}.log

      if [ -n "${dnFilter}" ]
      then
         grep "^dn: " ${ldifFile}|grep "${dnFilter}"|egrep -i "ou=People|cn=Users|ou=Preferences"|sed -e "s/^dn: //g" > ${dnFile}
      else
         grep "^dn: " ${ldifFile}|egrep -i "ou=People|cn=Users"|sed -e "s/^dn: //g" > ${dnFile}
      fi
   else
      echo "ERROR: LDIF file does not exist"
      exit 1
   fi
   set +x
   echo ${steps} > ${cfgdir}/.steps.gendata 2> /dev/null

   # Create managers and secretaries files
   head -50 ${dnFile} | tail -10 > ${cfgdir}/managers
   tail -10 ${dnFile} > ${cfgdir}/secretaries
}

##############################################################################
# Generate RDN list file
##############################################################################
gen_rdn_file() {
   if [ -z "${dnFilter}" ]
   then
      echo "Usage: ${cmd} genrdn --dnfilter <filter>"
      exit 1
   fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ -z "${myRdnFile}" ] && [ -n "${myLdifFile}" ];then rdnFile=$(basename ${myLdifFile}|sed -e "s/\.ldif//gi");rdnFile="${cfgdir}/${rdnFile}.rdn";fi

   if [ -e "${ldifFile}" ]
   then
      let steps++
      echo "Step: ${steps} - Generate RDN list with filter (${dnFilter})"| tee -a  ${logdir}/gendata-${now}.log

      if [ -n "${dnFilter}" ]
      then
         grep "^dn: " ${ldifFile}|grep "${dnFilter}"|sed -e "s/^dn: //g"|cut -d',' -f1 > ${rdnFile}
      else
         grep "^dn: " ${ldifFile}|grep "${dnFilter}"|sed -e "s/^dn: //g"|cut -d',' -f1 > ${rdnFile}
      fi
   else
      echo "ERROR: LDIF file does not exist"
      exit 1
   fi
   set +x
   echo ${steps} > ${cfgdir}/.steps.gendata 2> /dev/null
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
        'genall')  gen_template;gen_batch;gen_data;gen_dn_file;gen_rdn_file;;
        'gendata') gen_data;;
       'genbatch') gen_batch;;
       'gentempl') gen_template;;
          'gendn') gen_dn_file;;
         'genrdn') gen_rdn_file;;
                *) showUsage;;
esac
