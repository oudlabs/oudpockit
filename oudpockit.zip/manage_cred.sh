#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

   findpager
   cat << EOF | ${pgcmd}
NAME
     ${cmd} [add|update|delete|list|show] [options]

SYNOPSIS
     Add a new user credential to the wallet with
        ${cmd} add -T <tag> -D <userdn> [-w <pw>|-j <file>]

     Update a user credential in the wallet with
        ${cmd} update -T <tag> -D <userdn> [-w <pw>|-j <file>]

     Delete a user credential from the wallet with
        ${cmd} delete -T <tag> -D <userdn>

     List users in the wallet with
        ${cmd} list

     Show a user credential from the wallet with
        ${cmd} delete -T <tag> [-D <userdn>]

DESCRIPTION
     Sample script for managing wallet credentials

OPTIONS
     Setup Options
     The following options are supported:

         -T <tag>         Wallet tag
                          Default: BDN

         -D <userdn>      User DN
                          Default: cn=Directory Manager

         -j "<file>"      File containing user's password
                          Default: ${cfgdir}/...pw

         -w "<password>"  User's password
EOF

   exit 1
}

###############################################################################
# Process arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            D) my_bDN="$1";;
            j) my_jPW="$1";;
            w) my_bPW="$1";;
            T) my_bTag="$1";;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set defaults
###############################################################################
if [ -n "${my_bTag}" ];then bTag="${my_bTag}";fi
if [ -n "${my_bDN}" ];then bDN="${my_bDN}";fi
if [ -n "${my_jPW}" ];then jPW="${my_jPW}";fi
if [ -n "${my_bPW}" ];then bPW="${my_bPW}";fi

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
     'add') updateCreds;;
  'delete') delCred;;
  'update') updateCreds;;
    'list') showCreds;;
    'show') getCreds
            userLen=$(echo "${bDN}"|awk '{ print length }')
            printf "%-10s%-${userLen}s  %-30s\n" "Tag" "User" "Password"
            printf "%-10s%-${userLen}s  %-30s\n" "--------" "--------" "-----------"
            printf "%-10s%-${userLen}s  %-30s\n" "${bTag}" "${bDN}" "${bPW}"
            ;;
         *) showUsage;;
esac
