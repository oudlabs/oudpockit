#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# The purpose of this demo is to prepare source ACI for loading into OUD
###############################################################################
unset JAVA_TOOL_OPTIONS
instdir="${oudmwdir}/oud62/OUD"
aciLog="${logdir}/acitest-${now}.log"
aciBatch="${cfgdir}/aci-${now}.batch"
aciSchema="${cfgdir}/aci-${now}.schema"
ditLDIF="${cfgdir}/dit-${now}.ldif"
aciLDIF="${cfgdir}/aci-${now}.ldif"
aciTmp="${tmpdir}/acitmp-${now}.ldif"
ditTmp="${tmpdir}/dittmp-${now}.ldif"
useSSL=''
atCnt=0
atMaxCnt=0
ocCnt=0
ocMaxCnt=0
filteredIn='false'
filteredOut='false'

# Define special characters for beginning of line, attribute, and objectclass
begvar=$(head -$((RANDOM % 3000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
ocvar=$(head  -$((RANDOM % 4000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)
atvar=$(head  -$((RANDOM % 5000000)) /dev/urandom|tail -3|tr -d '[\n\r]'|tr -dc 'a-zA-Z0-9'|cut -c1-10)

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [options]

SYNOPSIS
     Prepare LDIF file:
        ${cmd} --ldif /<path>/<ldif_file> [Options]

     Prepare LDIF from source directory server from LDAP query:
        ${cmd} -h <host> -p <ldap_port> [-Z] [Options]

DESCRIPTION
     Custom Access Control Instruction (aci) preparation tool for migrating to OUD.

OPTIONS
     Options
     The following options are supported:

         --debug [-z]            Debug mode

         --norm                  Do not remove the temporary files from 

         --ldif /<dir>/<file>    LDIF file containing ACIs

         --host [-h]             Host of the source directory

         --port [-p]             LDAP port of the source directory

         -D <BindDN>             Bind DN of user with sufficient privilege to read all ACIs

         -w <BindPW>             Password of Bind DN user

         -j <BindPW_file>        File containing password of Bind DN user

         --baseDN <suffix> [-b]  BaseDN suffix

         --useSSL [-Z]           Use SSL/TLS connection to source directory


EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
   OPT=$1
   shift
   case $OPT in
       --*) case ${OPT:2} in
           help) showUsage;;
           ldif) ldifIn="$1";shift;;
           host) dsHost="$1";shift;;
           port) dsPort="$1";shift;;
           useSSL) useSSL='-Z -X';;
           baseDN|basedn) baseDN="$1";shift;;
           norm) norm='true';;
           debug) dbg="true";dbgFlag=' -z ';;
       esac;;
       -*) case ${OPT:1} in
           h) dsHost="$1";shift;;
           p) dsPort="$1";shift;;
           D) dsbDN="$1";shift;;
           w) dsbPW="$1";shift;;
           j) dsjPW="$1";shift;;
           b) baseDN="$1";shift;;
           Z) useSSL='-Z -X';;
           H) showUsage;;
           z) dbg="true";dbgFlag=' -z ';;
       esac;;
   esac
done

# If providing host details, must also provide bind creds
if [ -n "${dsHost}" ] || [ -n "${dsPort}" ]
then
   err=0
   if [ -z "${dsHost}" ];then err=1;echo "Error: must provide -h hostname";fi
   if [ -z "${dsPort}" ];then err=1;echo "Error: must provide -p port";fi
   if [ -z "${dsbDN}"  ];then err=1;echo "Error: must provide -D <bind_dn>";fi
   if [ -z "${dsbPW}"  ];then if [ -e "${dsjPW}" ];then dsbPW=$(cat ${dsjPW});fi;fi
   if [ -z "${dsbPW}"  ];then err=1;echo "Error: must provide -j <pw_file> or -w <bind_pw>";fi
   if [ -z "${baseDN}" ];then err=1;echo "Error: must provide baseDN -b <suffix>";fi
   if [ ${err} -eq 1   ];then exit 1;fi
fi

if [ -z "${ldifIn}" ];then ldifIn="${tmpdir}/myACIs-v0-${now}.ldif";fi
sName=$(basename ${ldifIn})

###############################################################################
# If host/port provided, retrieve the ACIs via ldapsearch
###############################################################################
if [ -n "${dsHost}" ] && [ -n "${dsPort}" ] && [ -n "${dsbDN}" ] && [ -n "${dsbPW}" ] && [ -n "${baseDN}" ]
then
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Retrieve ACIs from directory server (${dsHost}:${dsPort})"
   if [ "${dbg}" == 'true' ];then set -x;fi

   # Check for most common ACIs
   ${lsrch} -T -h ${dsHost} -p ${dsPort} -D "${dsbDN}" -w "${dsbPW}" -b "${baseDN}" -s sub '(|(aci=*)(orclACI=*))' aci orclaci 2> /dev/null |egrep -i "^dn|^aci|^orlcaci" > ${ldifIn}
   rc=$?

   if [ -s "${ldifIn}" ]
   then
      true
   else
      echo "Error: Input ACI LDIF file (${sName}) from ldapsearch is empty."
      exit 1
   fi
fi

###############################################################################
# Un-wrap wrapped files
###############################################################################
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo "--> Process ACIs of input file ${ldifIn}"
cat ${ldifIn} \
   |sed \
      -e "s/^/${begvar}/g" \
      -e "s/ /${spcvar}/g" \
      -e "s/	/${tabvar}/g" \
      -e "s/${tabvar}/${spcvar}/g" \
      -e "s/${begvar}${spcvar}//g" \
   |tr -d '[\n\r]' \
   |sed \
      -e "s/${begvar}/\n${begvar}/g" \
   |egrep -i "${begvar}dn:${spcvar}|${begvar}aci:${spcvar}" \
   |sed -e "s/${begvar}//g" \
   > ${aciTmp}

###############################################################################
# Load all data into an array
###############################################################################
ck4aci=$(grep "^aci:" ${aciTmp})
if [ -n "${ck4aci}" ]
then
   readarray -t allData <<< $(egrep -i "^dn:${spcvar}|^aci:${spcvar}|^orclAci:${spcvar}" ${aciTmp})
   readarray -t allDNs <<< $(egrep -i "^dn:${spcvar}" ${aciTmp})
   readarray -t orclAciData <<< $(grep -i "^orclAci:" ${aciTmp})
else
   echo "No ACIs were found"
fi

###############################################################################
# Build DN list from dn:, userdn, and groupdn filters
###############################################################################
#echo "DEBUG: spc=${spcvar} beg=${begvar}"
if [ -s "${ditLDIF}" ];then rm -f "${ditLDIF}";fi
#      -e "s/groupdn/\ndn:/gi" \
#      -e "s/userdn/\ndn:/gi" \

if [ -e "${ditTmp}" ];then rm -f "${ditTmp}";fi

for (( x=0; x< ${#allDNs[*]}; x++ ))
do
   echo "${allDNs[${x}]}" | sed -e "s/^dn:${spcvar}//g" \
      | egrep -v "^cn=config$|^cn=monitor|^uid=" \
   >> ${ditTmp}
done

egrep -i "^dn:|userdn|groupdn" ${aciTmp} \
   | sed \
      -e "s/${spcvar}/ /g" \
      -e "s/||ldap:/ ldap:/g" \
      -e "s/ldap:\/\/\//\ndn: /g" \
      -e "s/(\$dn)//gi" \
      -e "s/\[\$dn\]//gi" \
      -e "s/,,/,/gi" \
      -e "s/) and (//gi" \
      -e "s/)and(//gi" \
      -e "s/ = / /g" \
      -e "s/   / /g" \
      -e "s/  / /g" \
      -e "s/  / /g" \
      -e "s/   $//g" \
      -e "s/  $//g" \
      -e "s/ $//g" \
      -e "s/) ($//g" \
      -e "s/and.*ip.*//gi" \
      -e "s/^dn:  /dn: /g" \
      -e "s/^dn:  /dn: /g" \
      -e "s/^dn:  /dn: /g" \
      -e "s/ (authmethod.*//gi" \
      -e "s/(authmethod.*//gi" \
      -e "s/authmethod.*//gi" \
      -e "s/)(targetattr.*//gi" \
      -e "s/\"//g" \
      -e "s/'//g" \
      -e "s/;).*//g" \
      -e "s/;).*//g" \
      -e "s/ /${spcvar}/g" \
      -e "s/	/${tabvar}/g" \
   | grep "^dn:" \
   | grep "=" \
   | sed \
      -e "s/^dn:${spcvar}//g" \
      -e "s/^dn:=//g" \
      -e "s/^dn:!=//g" \
      -e "s/^dn://g" \
      -e "s/^=//g" \
      -e "s/)$//g" \
      -e "s/)$//g" \
      -e "s/);.*//g" \
      -e "s/${spcvar}$//g" \
      -e "s/${spcvar}$//g" \
      -e "s/;${spcvar}$//g" \
   | egrep -v "^self$|^all$|^anyone$|^$|^!=" \
   | egrep -v "^cn=config$|^cn=monitor" \
   | cut -d',' -f2- \
   | sed \
      -e "s/^${spcvar}//g" \
      -e "s/^${spcvar}//g" \
   | awk '{ print length($0) "|" $0; }'|sort -n|cut -d'|' -f2-|uniq \
   >> ${ditTmp}

readarray -t ditData <<< $(cat ${ditTmp})

###############################################################################
# Construct batch configuration file for multiple base DNs
###############################################################################
cat > ${aciBatch} <<EOF
set-log-publisher-prop --publisher-name 'File-Based Access Control Logger' --set enabled:true
EOF

for (( x=1; x< ${#ditData[*]}; x++ ))
do
   s=$(echo ${ditData[${x}]}|sed -e "s/${spcvar}/ /g")
   echo "set-workflow-element-prop --element-name userRoot --add base-dn:\"${s}\"" >> ${aciBatch}
   echo "create-workflow --set base-dn:\"${s}\" --set enabled:true --set workflow-element:userRoot --type generic --workflow-name userRoot${x}" >> ${aciBatch}
   echo "set-network-group-prop --group-name network-group --add workflow:userRoot${x}" >> ${aciBatch}
done

###############################################################################
# Construct requisite DIT
###############################################################################
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo -e "--> Construct requisite DIT"
rdnList='cn'
ldifDNs=( )
revspc=$(echo "${spcvar}"|rev)
revtab=$(echo "${tabvar}"|rev)
m=0
for (( x=0; x< ${#ditData[*]}; x++ ))
do
   # Iterate through each branch from base outward
#DEBUG

#   readarray -t allDNs <<< $(echo -e "${ditData[${x}]}"|rev|sed -e "s/${revspc}/ /g" -e "s/${revtab}/	/g" -e "s/, /,/g" -e "s/ ,/,/g" -e "s/,/\n/g"|sed  -e "s/ /${revspc}/g" -e "s/	/${revtab}/g"|rev|sed -e "s/^${spcvar}//g" -e "s/^${spcvar}//g" -e "s/${revspc}/\n/g")

#   for (( y=0; y< ${#allDNs[*]}; y++ ))
#   do
#      if [ ${y} -eq 0 ];then dn="${allDNs[${y}]}";else dn="${allDNs[${y}]},${dn}";fi
     
      # Determine whether or not to add to LDIF file
#      dnMatch='false'
#      for (( z=0; z< ${#ldifDNs[*]}; z++ ))
#      do
#         ck4match=$(echo "'${dn}'"|grep -i "'${ldifDNs[${z}]}'")
#         if [ -n "${ck4match}" ];then dnMatch='true';fi
#      done
#
#      if [ "${dnMatch}" == 'false' ]
#      then
         dn=$(echo "${ditData[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g" -e "s/dn: //g" -e "s/^ //g")
         rdn=$(echo "${dn},"|cut -d',' -f1|cut -d'=' -f1)
         rdnValue=$(echo "${dn},"|cut -d',' -f1|cut -d'=' -f2)

         #dn=$(echo "${dn}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g" -e "s/dn: //g")
         #rdn=$(echo "${allDNs[${y}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g" -e "s/dn: //g" -e "s/^ //g"|cut -d'=' -f1)
         #rdnValue=$(echo "${allDNs[${y}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g"|cut -d'=' -f2)
         if [ "${rdn}" != 'cn' ];then rdnList="${rdnList} ${rdn}";fi
         cat >> ${ditLDIF} <<EOF

dn: ${dn}
objectClass: top
objectClass: acitest
${rdn}: ${rdnValue}
EOF
         ldifDNs[${m}]="${dn}"
         let m++
#      fi
#   done
done

###############################################################################
# Construct custom schema if necessary for unique RDN attribute names
###############################################################################
mayList=''
rdnList=$(echo ${rdnList}|sed -e "s/ /\n/g"|tr '[:upper:]' '[:lower:]'|sort|uniq)
for rdn in ${rdnList}
do
   if [ -z "${mayList}" ];then mayList="${rdn}"; else mayList="${mayList} $ ${rdn}";fi
   ck4attr=$(grep "'${rdn}'" ${oudmwdir}/oud/config/schema/* 2> /dev/null)
   if [ -z "${ck4attr}" ]
   then
      cat >> ${aciSchema} <<EOF

dn: cn=schema
changeType: modify
add: attributeTypes
attributeTypes: ( ${rdn}-oid NAME '${rdn}' SYNTAX 1.3.6.1.4.1.1466.115.121.1.15 SINGLE-VALUE )
EOF

   fi

done 
      cat >> ${aciSchema} <<EOF

dn: cn=schema
changeType: modify
add: objectClasses
objectClasses: ( acitest-oid NAME 'acitest' STRUCTURAL MUST ( objectClass ) MAY ( ${mayList} ) )
EOF

###############################################################################
# Setup OUD instance for ACI testing on port 62389
###############################################################################
if [ -e "${instdir}/bin/start-ds" ]
then
   true
else
   s=$(echo ${ditData[0]}|sed -e "s/${spcvar}/ /g")
   if [ -z "${s}" ]
   then
      echo "Error: No base-dn found"
      exit 1
   fi
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Setup OUD instance for ACI testing with base-dn ${s}"
   ${curdir}/manage_oud.sh setup --pnum 62 --norestart --noroles --norepl --suffix "${s}" --schema ${aciSchema} --batch ${aciBatch} --data ${ditLDIF} ${dbgFlag}
fi

###############################################################################
# Set JAVA_HOME if not already set
###############################################################################
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi

###############################################################################
# Test each ACI
###############################################################################
echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
echo -e "--> Test each ACI"
dn=''
for (( x=0; x< ${#allData[*]}; x++ ))
do
   newdn=$(echo "${allData[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g"|grep -i "^dn: ")
   if [ -n "${newdn}" ];then dn="${newdn}";fi

   # Pre-filter ACI for most common syntax mistakes
   aci=$(echo "${allData[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g"|grep -i "^aci: " \
            |sed \
               -e "s/%20/ /g" \
               -e "s/%09/	/g" \
               -e "s/%21/'/g" \
               -e "s/%22/\"/g" \
               -e "s/”/\"/g" \
               -e "s/“/\"/g" \
               -e "s/”/\"/g" \
               -e "s/‘/\'/g" \
               -e "s/’/\'/g" \
               -e "s/ =/=/g" \
               -e "s/= /=/g" \
               -e "s/ ,/,/g" \
               -e "s/, /,/g" \
               -e "s/; acl/;acl/g" \
        )


   if [ -n "${aci}" ]
   then
      ${lmod} -Z -X -p 62636 -h ${localHost} -D "${bDN}" -j "${jPW}" -c > ${aciLog}.${x} 2>&1 <<EOF
${dn}
changeType: modify
add: aci
${aci}

EOF
      rc=$?
      cklog=$(egrep -v "^Processing MODIFY request|^MODIFY operation successful" ${aciLog}.${x})
      # Determine if ACI needs further refinement
      if [ ${rc} -eq 0 ] && [ -z "${cklog}" ]
      then
         echo "ACI ${x} loaded successfully"
         if [ "${dbg}" == 'true' ];then echo "   ${aci}";fi
         cat >> ${aciLDIF} <<EOF
${dn}
changeType: modify
add: aci
${aci}

EOF
      else
         echo "ACI ${x} did not load successfully"
         echo "   ${dn}"
         echo "   ${aci}"
         cat ${aciLog}.${x}|sed -e "s/^/   /g"
      fi
   fi
done


###############################################################################
# Remove the test OUD instance
###############################################################################
if [ -e "${instdir}/uninstall" ] && [ "${norm}" != 'true' ]
then
   echo -e "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
   echo "--> Remove OUD instance for ACI testing"
   cd "${curdir}"
   ${curdir}/manage_oud.sh deinstall --pnum 62 ${dbgFlag}
fi

#if [ -e "${aciTmp}" ];then rm -f "${aciTmp}";fi
#if [ -e "${aciBatch}" ];then rm -f "${aciBatch}";fi
if [ -e "${aciSchema}" ];then rm -f "${aciSchema}";fi

echo "DIT LDIF file: ${ditLDIF}"
echo "ACI LDIF file: ${aciLDIF}"
