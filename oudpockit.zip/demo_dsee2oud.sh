#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Demonstrate ODSEE to OUD bi-directional replication
###############################################################################
# Configure ldapsearch to use TLSv1.2 since ODSEE does not support TLSv1.3
export OPENDS_JAVA_ARGS=" -Dcustom.config.location=${samples}/tlsconfig-dsee.properties"

if [ -d "${curdir}/mw_oud12c/oud1" ] || [ -d "${curdir}/dsee7/var/ds1" ]
then
   echo "WARNING: OUD and/or ODSEE are already installed."
   echo "For this demonstration to work properly, please first "
   echo "deinstall OUD and ODSEE with:"
   echo "  ${curdir}/manage_replgw.sh deinstall"
   echo "  ${curdir}/manage_oud.sh deinstall"
   echo "  ${curdir}/manage_odsee.sh deinstall"
   exit
fi

echo -e "\nDEMO --> Apply requisite updates for ODSEE"
set -x
sudo yum install -y ksh unzip libzip libzip.i686 libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel compat-db47 compat-libcap1.x86_64 compat-libstdc++-33.x86_64 compat-libstdc++-33.i686 libstdc++.i686 compat-libcap1 compat-libstdc++-33 psmisc > ${logdir}/os-pkgs4dsee-${now}.log 2>&1
rc=$?;set +x

# Install OUD and gen data
echo -e "\nDEMO --> Install OUD and generate 10,000 users of data"
echo "./manage_data.sh genall -n inetorg -N 100000 --rm"
${curdir}/manage_data.sh genall -n inetorg -N 100000 --rm

# Setup ODSEE topology
echo -e "\nDEMO --> Setup ODSEE topology"
echo "./manage_odsee.sh setup --pnum 1 -n inetorg"
${curdir}/manage_odsee.sh setup --pnum 1 -n inetorg

echo "./manage_odsee.sh setup --pnum 2 -n inetorg --supplier ${localHost}:1393"
${curdir}/manage_odsee.sh setup --pnum 2 -n inetorg --supplier ${localHost}:1393

echo -e "\nDEMO --> Modify an entry to populate changelog"
echo "./manage_odsee.sh mod --pnum 1"
${curdir}/manage_odsee.sh mod --pnum 1

# Setup OUD topology
echo -e "\nDEMO --> Setup OUD topology"
echo "./manage_oud.sh setup --pnum 1 -n inetorg"
${curdir}/manage_oud.sh setup --pnum 1 -n inetorg 

echo "./manage_oud.sh setup --pnum 2  -n inetorg --supplier ${localHost}:1444:1989"
${curdir}/manage_oud.sh setup --pnum 2  -n inetorg --supplier ${localHost}:1444:1989

# Setup replication gateway
echo -e "\nDEMO --> Setup OUD Replication Gateway"
echo "./manage_replgw.sh setup"
${curdir}/manage_replgw.sh setup

# Initialize OUD from ODSEE data
echo -e "\nDEMO --> Export data from DSEE"
echo "./manage_replgw.sh export"
${curdir}/manage_replgw.sh export

echo -e "\nDEMO --> Initialize OUD"
echo "./manage_replgw.sh init"
${curdir}/manage_replgw.sh init

echo -e "\nDEMO --> Show OUD replication status"
echo "./manage_replgw.sh rstatus"
${curdir}/manage_replgw.sh rstatus

echo -e "\nDEMO --> Demonstrate bi-directional replication"
echo "./manage_replgw.sh test"
${curdir}/manage_replgw.sh test

echo -e "\nDEMO --> Demonstrate bi-directional replication in debug mode"
echo "./manage_replgw.sh test -z"
${curdir}/manage_replgw.sh test -z
