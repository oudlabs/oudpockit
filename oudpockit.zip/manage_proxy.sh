#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

   findpager
   cat << EOF | ${pgcmd}
NAME
     ${cmd} [ setup | start | stop | deinstall | apply ] [options]

SYNOPSIS
     Setup proxy with existing OUD instances:
        ${cmd} setup --pnum <n> --suffix <suffix> --nodes <nodes> [other optons]

     Setup proxy with your own custom batch configuration:
        ${cmd} setup --pnum <n> --batch /<path>/<batch_file> [other optons] 

     Setup proxy with no configuration:
        ${cmd} setup --pnum <n> [other optons] 


     Start OUD instance
        ${cmd} start [ --pnum <n> ]

     Stop OUD instance
        ${cmd} stop [ --pnum <n> ]

     Apply custom batch configuration file to OUD instance
        ${cmd} apply --batch <file>

     Install OUD software
        ${cmd} install --jh <dir> --swdir <dir> --fmwi <file> --fmwo <file>

     Deinstall OUD instance
        ${cmd} deinstall [ --pnum <n> ]

DESCRIPTION
     Sample script for managing Oracle Unified Directory (OUD) instances

OPTIONS
     Setup Options
     The following options are supported:

         --pnum <n>              OUD and port number prefix
                                 Default: 1

         --suffix <suffix>       Suffix used for proxy passthrough

         --nodes <nodes>         Comma separated list of nodes where each node
                                 is composed of <host>:<ldap_port>:<ldaps_port>
                                 of the target directory instance.
                                 Default ldap_port=${ldapPort}
                                 Default ldaps_port=${ldapsPort}

         --pfile <file>          Fully qualified path to password file
                                 Default: ${curdir}/...pw

         --jh <dir>              JAVA_HOME directory if not already specified in env

         --ktype <type>          Type of key type: none, jks, p12
                                 Default: none - Create a self signed cert

         --kstore <file>         Fully qualified path of keystore file
                                 Default: ${curdir}/keystore
                                 
         --kpin <file>           Fully qualified path of keystore pin file
                                 Default: ${curdir}/keystore.pin

         --swdir <dir>           Directory of the extracted software

         --batch <file>          Supplemental configuration to add to lb config

         --fmwi <file>           Fusion Middleware Infrastructure jar file
                                 Default: ${curdir}/fmw_12.2.1.4.0_infrastructure_generic.jar

         --fmwo <file>           Fusion Middleware OUD jar file
                                 Default: ${curdir}/fmw_12.2.1.4.0_oud_generic.jar

         --schema <file>         Fully qualified path of schema LDIF fie
                                 Default: ${curdir}/schema.ldif

         --data <file>           Fully qualified path of data LDIF  fie
                                 Default: ${curdir}/data.ldif

         --norest                Disable REST/SCIM interfaces

         --Integration <option>  Integration options include eus

         --prefix <text>         OUD Proxy instance name prefix
                                 Default: proxy

EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
integration=''
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            swdir) swdir="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            pnum) pnum="$1";shift;;
            suffix) suffix="$1";shift;;
            nodes) nodes="$1";shift;;
            pfile) jPW="$1";shift;;
            jh) export JAVA_HOME="$1";PATH="$JAVA_HOME:$PATH";shift;;
            prefix) myProxyPrefix="$1";shift;;
            ktype) ktype="$1";shift;;
            kstore) kstore="$1";shift;;
            kpin) kpin="$1";shift;;
            batch) batchfile="$1";shift;;
            fmwi) fmwi="$1";shift;;
            fmwo) fmwo="$1";shift;;
            schema) schemaFile="$1";shift;;
            data) dataFile="$1";shift;;
            norest) disableRest='true';;
            step) steps="$1";shift;;
            eus) integration="eus";shift;;
            nosudo) sudoFlag=' --nosudo';;
            14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            D) bDN="$1";;
            j) jPW="$1";;
            S) suffix="$1";;
            s) oudSupplier="$1";shift;;
            n) myTemplateName="$1";;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done
setfmwenv

###############################################################################
# Validate inputs and set defaults
###############################################################################
if [ -n "${integration}" ]
then
   case ${integration} in
      'eus') integrationOption=' --integration eus ';;
          *) showUsage "Integration options include eus";;
   esac
fi

# Set port numbers if pnum specified
if [ "${subcmd}" == 'setup' ]
then
   if [ -z "${pnum}" ]
   then
      pnum=1
   elif [ "${pnum}" == 'all' ]
   then
      showUsage "--pnum all is not allowed with setup sub command"
      exit 1
  fi
else
   if [ "${pnum}" == 'all' ];then pnum=0;fi
fi

if [ "${pnum}" != '0' ]
then
   ldapPort=${pnum}390
   ldapsPort=${pnum}637
   adminPort=${pnum}445
   httpsPort=${pnum}433
   httpsAdminPort=${pnum}556
fi

if [ -n "${myProxyPrefix}" ];then proxyprefix="${myProxyPrefix}";fi

if [ -z "${templateName}" ];then templateName='inetorg';fi
if [ -n "${myTemplateName}" ];then templateName="${myTemplateName}";fi

if [ -z "${ktype}" ];then ktype='none';fi
if [ "${ktype}" == 'jks' ];then kstore="${cfgdir}/${localHost}.jks";kpin="${cfgdir}/${localHost}.pin";fi
if [ "${ktype}" == 'p12' ];then kstore="${cfgdir}/${localHost}.p12";kpin="${cfgdir}/${localHost}.pin";fi

###############################################################################
# Make batch file
###############################################################################
gen_proxy_batch_files() {
   if [ -n "${nodes}" ]
   then
      cat > ${cfgdir}/proxy-${now}.batch <<EOF
# Enable access logger
set-log-publisher-prop --publisher-name "File-Based Access Logger" --set enabled:true

# Create Load Balancer Workflow Element
create-workflow-element --set enabled:true --type load-balancing --element-name ldap-lb-wfe

# Apply Load Balancer Workflow Element
create-load-balancing-algorithm --type proportional --element-name ldap-lb-wfe

# Create workflow
create-workflow --type generic --workflow-name ldap-lb-wf --set base-dn:${suffix} --set enabled:true --set workflow-element:ldap-lb-wfe

# Add workflow to network-group
set-network-group-prop --group-name network-group --add workflow:ldap-lb-wf

# Create virtual ACI group for node${n}
#create-access-control-group --type generic --group-name ldap-acigroup
#set-workflow-prop --workflow-name ldap-lb-wf --set access-control-group:ldap-acigroup --set virtual-aci-mode:true

EOF

      n=10
      for node in ${nodes}
      do
         node="${node}:"
         nHost=$(echo ${node}|cut -d':' -f1)
         myLdapPort=$(echo ${node}|cut -d':' -f2)
         myLdapsPort=$(echo ${node}|cut -d':' -f3)
         if [ -n "${myLdapPort}" ];then nodeLdapPort=${myLdapPort};fi
         if [ -n "${myLdapsPort}" ];then nodeLdapsPort=${myLdapsPort};fi
         if [ -z "${myLdapPort}" ];then nodeLdapPort=1389;fi
         if [ -z "${myLdapsPort}" ];then nodeLdapsPort=1636;fi
         
         myAdmin="uid=admin1,ou=Admins,${suffix}"
         if [ "${templateName}" == 'ad' ];then myAdmin="cn=admin1,cn=Admins,${suffix}";fi
         m=$((100 - ${n}))

         cat >> ${cfgdir}/proxy-${now}.batch <<EOF

# Create LDAP extension for node${n}
create-extension --type ldap-server --extension-name ldap-xtn${n} --set enabled:true --set remote-ldap-server-address:${nHost} --set remote-ldap-server-port:${nodeLdapPort} --set remote-ldap-server-ssl-port:${nodeLdapsPort} --set remote-ldap-server-ssl-policy:always --set ssl-trust-all:true --set pool-max-size:10

# Create LDAP Workflow Element for node${n}
create-workflow-element --type proxy-ldap --element-name ldap-wfe${n} --set enabled:true --set ldap-server-extension:ldap-xtn${n} --set client-cred-mode:use-specific-identity --set remote-ldap-server-bind-dn:"${myAdmin}" --set remote-root-dn:"${myAdmin}" --set remote-ldap-server-bind-password:"${bPW}" --set remote-root-password:"${bPW}"

# Create Load Balance Routes to each LDAP Workflow Element for node${n}
create-load-balancing-route --element-name ldap-lb-wfe --route-name ldap-lb-route${n} --type proportional --set workflow-element:ldap-wfe${n} --set add-weight:${m} --set modify-weight:${m} --set modifydn-weight:${m} --set delete-weight:${m} --set bind-weight:1 --set search-weight:1   --set compare-weight:1 --set extended-weight:1


EOF

         n=$((${n}+10))
      done
   fi
}

###############################################################################
# Deinstall Proxy
###############################################################################
deinstall_proxy() {
   if [ -z "${pnum}" ];then pnum=0;fi

   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d ${proxyprefix}[1-9] 2> /dev/null|sed -e "s/${proxyprefix}//g")
      for node in ${nodes}
      do
         if [ -e "${oudmwdir}/${proxyprefix}${node}/OUD/uninstall" ]
         then
         let steps++
            echo "Step: ${steps} - Deinstall OUD proxy instance (${proxyprefix}${node})" | tee -a  ${logdir}/proxy-deinstall-${now}.log
            if [ "${dbg}" == 'true' ];then set -x;fi
            #   ${force} \
            export OPENDS_JAVA_ARGS=' -Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true '
            ${oudmwdir}/${proxyprefix}${node}/OUD/uninstall \
               -i \
               -a \
               -I "admin" \
               -j ${jPW} \
               -X \
               -h ${localHost} \
               --no-prompt \
               --noPropertiesFile \
               >> ${logdir}/proxy-deinstall-${now}.log 2>&1
           rc=$?
           set +x
         fi

         if [ -e "${oudmwdir}/${proxyprefix}${node}/OUD/uninstall" ]
         then
            if [ "${dbg}" == 'true' ];then set -x;fi
            ${oudmwdir}/${proxyprefix}${node}/OUD/bin/stop-ds >> ${logdir}/proxy-deinstall-${now}.log 2>&1
            rc=$?
            rm -fr ${oudmwdir}/${proxyprefix}${node}
            rc=$?
            set +x
         fi
      done
   else
      if [ -e "${oudmwdir}/${proxyprefix}${pnum}/OUD/uninstall" ]
      then
         let steps++
         echo "Step: ${steps} - Deinstall OUD proxy instance (${proxyprefix}${pnum})" | tee -a  ${logdir}/proxy-deinstall-${now}.log
         #   ${force} \
         if [ "${dbg}" == 'true' ];then set -x;fi
         export OPENDS_JAVA_ARGS=' -Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true '
         ${oudmwdir}/${proxyprefix}${pnum}/OUD/uninstall \
            -i \
            -a \
            -I "admin" \
            -j ${jPW} \
            -X \
            -h ${localHost} \
            --no-prompt \
            --noPropertiesFile \
            >> ${logdir}/proxy-deinstall-${now}.log 2>&1
         rc=$?
         set +x
      fi

      if [ -e "${oudmwdir}/${proxyprefix}${pnum}/OUD/uninstall" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${proxyprefix}${pnum}/OUD/bin/stop-ds >> ${logdir}/proxy-deinstall-${now}.log 2>&1
         rc=$?
         rm -fr ${oudmwdir}/${proxyprefix}${pnum}
         rc=$?
         set +x
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.deinstall.proxy
}

###############################################################################
# Apply custom batch configuration file if one exists
###############################################################################
apply_custom_batch() {
   if [ -e  "${batchfile}" ]
   then
      let steps++
      echo "Step: ${steps} - Apply custom batch configuration to OUD proxy instance (${proxyprefix}${pnum})" | tee -a  ${logdir}/proxy-setup-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dcfg} \
         --batchFilePath ${batchfile} \
         --hostName ${localHost} \
         --port ${adminPort} \
         --bindDN "${bDN}" \
         --bindPasswordFile "${jPW}" \
         --trustAll \
         --no-prompt \
         --noPropertiesFile \
         >> ${logdir}/proxy-setup-${now}.log 2>&1
      rc=$?
      set +x
   fi
}

###############################################################################
# Stop OUD Proxy Instance
###############################################################################
stop_proxy() {
   if [ -z "${pnum}" ];then pnum=0;fi

   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d ${proxyprefix}[1-9]* 2> /dev/null|sed -e "s/${proxyprefix}//g")
      for node in ${nodes}
      do
         let steps++
         echo -e "Step: ${steps} - Stop OUD proxy instance (${proxyprefix}${node})\c" | tee -a  ${logdir}/proxy-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${proxyprefix}${node}/OUD/bin/stop-ds >> ${logdir}/oud-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      done
   else
      if [ -e "${oudmwdir}/${proxyprefix}${pnum}/OUD/bin/stop-ds" ]
      then
         let steps++
         echo -e "Step: ${steps} - Stop OUD proxy instance (${proxyprefix}${pnum})\c" | tee -a  ${logdir}/proxy-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${proxyprefix}${pnum}/OUD/bin/stop-ds >> ${logdir}/oud-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.proxy.stop
}

###############################################################################
# Start OUD Proxy Instance
###############################################################################
start_proxy() {
   if [ -z "${pnum}" ];then pnum=0;fi

   if [ ${pnum} -eq 0 ]
   then
      nodes=$(cd ${oudmwdir} 2> /dev/null;ls -d ${proxyprefix}[1-9]* 2> /dev/null|sed -e "s/${proxyprefix}//g")
      for node in ${nodes}
      do
         let steps++
         echo -e "Step: ${steps} - Start OUD proxy instance (${proxyprefix}${node})\c" | tee -a  ${logdir}/proxy-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${proxyprefix}${node}/OUD/bin/start-ds >> ${logdir}/oud-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      done
   else
      if [ -e "${oudmwdir}/${proxyprefix}${pnum}/OUD/bin/start-ds" ]
      then
         let steps++
         echo -e "Step: ${steps} - Start OUD proxy instance (${proxyprefix}${pnum})\c" | tee -a  ${logdir}/proxy-ctl-${now}.log
         if [ "${dbg}" == 'true' ];then set -x;fi
         ${oudmwdir}/${proxyprefix}${pnum}/OUD/bin/start-ds >> ${logdir}/oud-ctl-${now}.log 2>&1
         rc=$?
         echo
         set +x
      fi
   fi
   echo ${steps} > ${cfgdir}/.steps.proxy.start
}

###############################################################################
# Upgrade OUD Proxy Instance
###############################################################################
upgrade_proxy() {
   let steps++
   echo -e "Step: ${steps} - Upgrade OUD proxy instance ${proxyprefix}${pnum}\c" | tee -a  ${logdir}/proxy-ctl-${now}.log
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${oudmwdir}/${proxyprefix}${pnum}/OUD/bin/start-ds --upgrade >> ${logdir}/proxy-ctl-${now}.log 2>&1
   rc=$?
   set +x
   echo
}

###############################################################################
# Setup OUD proxy instance
###############################################################################
setup_proxy() {
   # Install OUD
   rm ${cfgdir}/.steps.install 2> /dev/null
   ${curdir}/manage_install.sh install oud --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag}
   if [ -e "${cfgdir}/.steps.install" ];then steps=$(cat ${cfgdir}/.steps.install);fi

   # Setup pnum to 1 if no OUD instances exist
   if [ -z "${pnum}" ];then pnum=0;fi
   if [ ${pnum} -eq 0 ]
   then
      cd "${oudmwdir}" 2> /dev/null
      cnum=$(ls -1d ${proxyprefix}[1-9]* 2> /dev/null|sed -e "s/${proxyprefix}//g"|tail -1)
      if [ -n "${cnum}" ];then pnum=${cnum};fi
      let pnum++;
   fi

   # Check node state
   anyNodeDown='false'
   nodes=$(echo ${nodes}|sed -e "s/,/ /g")
   for node in ${nodes}
   do
      node="${node}:"
      nHost=$(echo ${node}|cut -d':' -f1)
      myLdapPort=$(echo ${node}|cut -d':' -f2)
      myLdapsPort=$(echo ${node}|cut -d':' -f3)
      if [ -n "${myLdapPort}" ];then nodeLdapPort=${myLdapPort};fi
      if [ -n "${myLdapsPort}" ];then nodeLdapsPort=${myLdapsPort};fi
      if [ -z "${myLdapPort}" ];then nodeLdapPort=1389;fi
      if [ -z "${myLdapsPort}" ];then nodeLdapsPort=1636;fi

      ckAdmin=$(test_port ${supplierHost} ${snum}444)
      ckLDAP=$(test_port ${supplierHost} ${snum}389)
      ckLDAPS=$(test_port ${supplierHost} ${snum}636)
      ckDown=$(echo ${ckLDAP} ${ckLDAPS}|grep DOWN)
      if [ -n "${ckDown}" ]
      then
         echo "Error: Node ${nHost}:${nodeLdapPort}:${nodeLdapsPort} appears to be down."
         echo "Verify the directory server is up on host ${nHost} and that host ${nHost}'s host-based firewall allows ports:"
         echo '   firewall-cmd --permanent --zone=public --add-port=${nodeLdapPort}/tcp'
         echo '   firewall-cmd --permanent --zone=public --add-port=${nodeLdapsPort}/tcp'
         echo '   firewall-cmd --reload'
         anyNodeDown='true'
      fi
   done

   if [ "${anyNodeDown}" == 'true' ];then exit 1;fi 

   # Generate batch configuration files
   gen_proxy_batch_files

   # Check inputs
   if [ -e  "${oudmwdir}/${proxyprefix}${pnum}/OUD/config/config.ldif" ]
   then
      true
   else
      # Make sure cert exists
      ${curdir}/manage_certs.sh gencert -h ${localHost} --step ${steps}

      let steps++
      echo -e "Step: ${steps} - Setup OUD proxy instance (${proxyprefix}${pnum}).\c" | tee -a  ${logdir}/proxy-setup-${now}.log
      if [ "${disableRest}" == 'true' ]
      then
         restOptions=" --httpAdminConnectorPort disabled --httpPort disabled --httpsPort disabled "
      else
         restOptions="--httpAdminConnectorPort ${httpsAdminPort} --httpPort disabled --httpsPort ${httpsPort}"
      fi

      if [ "${ktype}" == 'jks' ] && [ -e "${kstore}" ] && [ -e "${kpin}" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         export INSTANCE_NAME="${proxyprefix}${pnum}"
         ${oudmwdir}/oud/oud-proxy-setup \
            --cli \
            --instancePath "${oudmwdir}/${proxyprefix}${pnum}/OUD" \
            ${integration} \
            --rootUserDN "${bDN}" \
            --rootUserPasswordFile "${jPW}" \
            --adminConnectorPort ${adminPort} \
            --ldapPort ${ldapPort} \
            --ldapsPort ${ldapsPort} \
            ${restOptions} \
            --enableStartTLS \
            --useJavaKeystore "${kstore}" \
            --keyStorePasswordFile "${kpin}" \
            --certNickname server-cert \
            >> ${logdir}/proxy-setup-${now}.log 2>&1
         rc=$?
         set +x
         echo -e ".\c"
      elif [ "${ktype}" == 'p12' ] && [ -e "${kstore}" ] && [ -e "${kpin}" ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         export INSTANCE_NAME="${proxyprefix}${pnum}"
         ${oudmwdir}/oud/oud-proxy-setup \
            --cli \
            --instancePath "${oudmwdir}/${proxyprefix}${pnum}/OUD" \
            ${integration} \
            --rootUserDN "${bDN}" \
            --rootUserPasswordFile "${jPW}" \
            --adminConnectorPort ${adminPort} \
            --ldapPort ${ldapPort} \
            --ldapsPort ${ldapsPort} \
            ${restOptions} \
            --enableStartTLS \
            --usePkcs12keyStore "${kstore}" \
            --keyStorePasswordFile "${kpin}" \
            --certNickname server-cert \
            >> ${logdir}/proxy-setup-${now}.log 2>&1
         rc=$?
         set +x
         echo -e ".\c"
      elif [ "${ktype}" == 'none' ]
      then
         if [ "${dbg}" == 'true' ];then set -x;fi
         export INSTANCE_NAME="${proxyprefix}${pnum}"
         ${oudmwdir}/oud/oud-proxy-setup \
            --cli \
            --instancePath "${oudmwdir}/${proxyprefix}${pnum}/OUD" \
            ${integration} \
            --rootUserDN "${bDN}" \
            --rootUserPasswordFile "${jPW}" \
            --adminConnectorPort ${adminPort} \
            --ldapPort ${ldapPort} \
            --ldapsPort ${ldapsPort} \
            ${restOptions} \
            --enableStartTLS \
            --generateSelfSignedCertificate \
            --certNickname server-cert \
            >> ${logdir}/proxy-setup-${now}.log 2>&1
         rc=$?
         set +x
         echo -e ".\c"
      else
         if [ -e "${kstore}" ]
         then
            true
         else
            echo -e "\nError: Key store (${kstore}) does not exist. "
         fi
         if [ -e "${kpin}" ]
         then
            true
         else
            echo -e "\nError: Key store pin (${kpin}) does not exist. "
         fi
         case ${ktype} in
            'none') true;;
             'jks') true;;
             'p12') true;;
                 *) echo;showUsage "Invalid keystore type (${ktype})";;
         esac
      fi
      echo '.done'
   fi

#   let steps++
#   echo "Step: ${steps} - Copy JDBC driver to instance in case we might need it" | tee -a  ${logdir}/load-jdbc-${now}.log
#   if [ "${dbg}" == 'true' ];then set -x;fi
#   cp ${oudmwdir}/oracle_common/modules/oracle.jdbc/ojdbc8.jar ${oudmwdir}/${INSTANCE_NAME}/OUD/lib
#   rc=$?
#   set +x

   # Load custom Schema
   if [ -e "${schemaFile}" ]
   then
      let steps++
      echo "Step: ${steps} - Load custom schema LDIF file" | tee -a  ${logdir}/load-schema-${now}.log
      if [ -e "${schemaFile}" ]
      then
         ${lmod} -Z -X -p ${adminPort} -h ${localHost} -D "${bDN}" -j "${jPW}" -c -f "${schemaFile}" >> ${logdir}/load-schema-${now}.log 2>&1
         rc=$?
      fi
      set +x
   fi

   # Apply proxy batch configuration
   if [ -e  ${cfgdir}/proxy-${now}.batch ]
   then
      let steps++
      echo -e "Step: ${steps} - Apply LB configuration to OUD Proxy instance.\c" | tee -a  ${logdir}/proxy-setup-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dcfg} \
         --batchFilePath ${cfgdir}/proxy-${now}.batch \
         --hostName ${localHost} \
         --port ${adminPort} \
         --bindDN "${bDN}" \
         --bindPasswordFile "${jPW}" \
         --trustAll \
         --no-prompt \
         --noPropertiesFile \
         >> ${logdir}/proxy-setup-${now}.log 2>&1
      rc=$?
      set +x
      echo '.done'
   fi

   # Apply custom batch configuration file if one exists
   if [ -e  "${batchfile}" ]
   then
      let steps++
      echo -e "Step: ${steps} - Apply custom batch configuration to OUD Proxy instance.\c" | tee -a  ${logdir}/proxy-setup-${now}.log
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${dcfg} \
         --batchFilePath ${batchfile} \
         --hostName ${localHost} \
         --port ${adminPort} \
         --bindDN "${bDN}" \
         --bindPasswordFile "${jPW}" \
         --trustAll \
         --no-prompt \
         --noPropertiesFile \
         >> ${logdir}/proxy-setup-${now}.log 2>&1
      rc=$?
      set +x
      echo '.done'
   fi
}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
       'setup') setup_proxy;;
        'stop') stop_proxy;;
       'start') start_proxy;;
     'upgrade') upgrade_proxy;;
       'apply') apply_custom_batch;;
   'deinstall') deinstall_proxy;;
             *) showUsage;;
esac
