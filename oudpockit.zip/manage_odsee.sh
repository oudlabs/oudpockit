#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd} [setup|deinstall|start|stop|rstatus|mod] [options]

SYNOPSIS
     Setup first ODSEE Instance
        ${cmd} setup --suffix <suffix> [other optons]

     Setup second and following ODSEE Instance on other hosts
        ${cmd} setup --suffix <suffix> --supplier <host:ldap_port> [optons]

     Start ODSEE instance
        ${cmd} start [ --pnum <n> ]
        Default: Start all ODSEE instances

     Stop ODSEE instance
        ${cmd} stop [ --pnum <n> ]
        Default: Stop all ODSEE instances

     Deinstall ODSEE Instance
        ${cmd} deinstall --pnum <n> [optons]

     Show ODSEE replication status
        ${cmd} rstatus --pnum <n> [optons]

     Apply some modifications
        ${cmd} mod --pnum <n> -N <num_users> [optons]
EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            pnum) pnum="$1";shift;;
            supplier) odseeSupplier="$1";shift;;
            suffix) suffix="$1";shift;;
            domain) domain="$1";shift;;
            ktype) ktype="$1";shift;;
            kstore) kstore="$1";shift;;
            kpin) kpin="$1";shift;;
            batch) batchFile="$1";shift;;
            schema) schemaFile="$1";shift;;
            data) dataFile="$1";shift;;
            be) backend="$1";shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            n) templateName="$1";shift;;
            H) showUsage;;
            S) suffix="$1";;
            c) myClients="$1";;
            t) myThreads="$1";;
            M) myM="$1";;
            m) mym="$1";;
            N) numUsers="$1";shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set default variables
###############################################################################
if [ -n "${odseeSupplier}" ]
then
   supplierHost=$(echo "${odseeSupplier}:"|cut -d':' -f1)
   supplierH=$(echo "${supplierHost}."|cut -d. -f1)
   supplierPort=$(echo "${odseeSupplier}:"|cut -d':' -f2)
fi
replid=$(( RANDOM % 65534 ))
if [ -z "${ktype}" ];then ktype='p12';fi
#if [ "${ktype}" == 'jks' ];then kstore="${cfgdir}/${oudprefix}${pnum}.jks";kpin="${cfgdir}/${oudprefix}${pnum}.pin";fi
#if [ "${ktype}" == 'p12' ];then kstore="${cfgdir}/${localHost}.p12";kpin="${cfgdir}/${localHost}.pin";fi
if [ "${ktype}" == 'jks' ];then kstore="${certdir}/${localHost}/${localHost}.jks";kpin="${certdir}/${localHost}/${localHost}.pin";fi
if [ "${ktype}" == 'p12' ];then kstore="${certdir}/${localHost}/${localHost}.p12";kpin="${certdir}/${localHost}/${localHost}.pin";fi


if [ -n "${templateName}" ] && [ -z "${schemaFile}" ];then schemaFile="${cfgdir}/${templateName}.schema";fi
if [ -n "${templateName}" ] && [ -z "${dataFile}" ];then dataFile="${cfgdir}/${templateName}.ldif";fi
if [ -n "${templateName}" ] && [ -z "${batchFile}" ];then batchFile="${cfgdir}/${templateName}.batch";fi

steps=0

###############################################################################
# Stop ODSEE
###############################################################################
stop_odsee() {
   if [ -z "${pnum}" ];then pnum=0;fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ ${pnum} -eq 0 ]
   then
      readarray -t instances < <(ls -1dt ${curdir}/dsee7/var/ds[1-9]* 2> /dev/null|sed -e "s/ /SSPPAACCEE/g")
      if [ -n "${instances[*]}" ]
      then
         for (( i=0; i< ${#instances[*]}; i++ ))
         do
            inst=$(echo ${instances[${i}]}|sed -e "s/SSPPAACCEE/ /g")
            instnum=$(echo ${instances[${i}]}|sed -e "s/^.*var\/ds//g")
            let steps++
            echo "Step: ${steps} - Stop ODSEE (ds${instnum})"
            ${curdir}/dsee7/bin/dsadm stop ${inst} >> ${logdir}/ds${instnum}-setup-${now}.log 2>&1
            rc=$?
         done
      fi
   else
      if [ -e "${curdir}/dsee7/var/ds${pnum}" ]
      then
         let steps++
         echo "Step: ${steps} - Stop ODSEE (ds${pnum})"
         ${curdir}/dsee7/bin/dsadm stop ${curdir}/dsee7/var/ds${pnum} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
         rc=$?
      fi
   fi
   set +x
}

###############################################################################
# Start ODSEE
###############################################################################
start_odsee() {
   if [ -z "${pnum}" ];then pnum=0;fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ ${pnum} -eq 0 ]
   then
      readarray -t instances < <(ls -1dt ${curdir}/dsee7/var/ds[1-9]* 2> /dev/null|sed -e "s/ /SSPPAACCEE/g")
      if [ -n "${instances[*]}" ]
      then
         for (( i=0; i< ${#instances[*]}; i++ ))
         do
            inst=$(echo ${instances[${i}]}|sed -e "s/SSPPAACCEE/ /g")
            instnum=$(echo ${instances[${i}]}|sed -e "s/^.*var\/ds//g")
            let steps++
            echo "Step: ${steps} - Start ODSEE (ds${instnum})"
            ${curdir}/dsee7/bin/dsadm start ${inst} >> ${logdir}/ds${instnum}-setup-${now}.log 2>&1
            rc=$?
         done
      fi
   else
      if [ -e "${curdir}/dsee7/var/ds${pnum}" ]
      then
         let steps++
         echo "Step: ${steps} - Start ODSEE (ds${pnum})"
         ${curdir}/dsee7/bin/dsadm start ${curdir}/dsee7/var/ds${pnum} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
         rc=$?
      fi
   fi
   set +x
}

###############################################################################
# Check requisites
###############################################################################
check_requisites() {
   if [ "${templateName}" != 'inetorg' ]
   then
      if [ -e "${schemaFile}" ] 
      then
         true
      else
         echo "ERROR: The custom schema file does not exist:"
         echo "   ${schemaFile}"
         echo "   You may can generate with for inetorg template name:"
         echo "   ${curdir}/manage_data.sh genall -n ${templateName} -N 100000 --rm"
         exit 1
      fi
   fi

   if [ -e "${dataFile}" ]
   then
      true
   else
      echo "ERROR: The custom schema file does not exist:"
      echo "   ${dataFile}"
      echo "   You may can generate with for inetorg template name:"
      echo "   ${curdir}/manage_data.sh genall -n ${templateName} -N 100000 --rm"
      exit 1
   fi

   # Lookup OS
   lookupos

   if [ "${os}" == 'Linux' ] && [ "${olv}" == '7' ]
   then
      ck4pkgs=$(rpm -q ksh unzip libzip libzip.i686 libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel compat-db47 compat-libcap1.x86_64 compat-libstdc++-33.x86_64 compat-libstdc++-33.i686 libstdc++.i686 compat-libcap1 compat-libstdc++-33|grep "not installed")

      if [ -n "${ck4pkgs}" ]
      then
         echo "ERROR: Make sure that that all of the following requisite packagesare installed"
         echo "   ksh unzip libzip libzip.i686 libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel compat-db47 compat-libcap1.x86_64 compat-libstdc++-33.x86_64 compat-libstdc++-33.i686 libstdc++.i686 compat-libcap1 compat-libstdc++-33"
         exit 1
      fi
   elif [ "${os}" == 'Linux' ] && [ "${olv}" == '8' ]
   then

      ck4pkgs=$(rpm -q ksh unzip libzip libzip libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel|grep "not installed")
      if [ -n "${ck4pkgs}" ]
      then
         echo "ERROR: Make sure that that all of the following requisite packagesare installed"
         echo "   ksh unzip libzip libzip libgcc.i686 glibc-devel.i686 gcc gcc-c++ perl bc elfutils-libelf-devel glibc-devel libaio-devel libstdc++-devel libstdc++-devel libaio-devel sysstat binutils unixODBC unixODBC-devel"
         exit 1
      fi
   fi

   # Optional packages
   # rsync snapper psmisc net-tools lsof xauth libXrender libXtst perl-CPAN  perl-JSON-PP krb5-server krb5-server-ldap krb5-workstation 
}


###############################################################################
# Extract and install ODSEE software
###############################################################################
install_odsee() {
   # Check requisites
   check_requisites

   if [ -e "${curdir}/dsee7/bin/dsadm" ]
   then
      true
   else
      if [ -e "{swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip" ]
      then
         true
      else
         let steps++
         echo "Step: ${steps} - Extract ODSEE 11g (V35071-01.zip)"
         mkdir -p "${swdir}/odsee" 2> /dev/null
         cd "${swdir}/odsee"
         unzip -oq "${bitsdir}/V35071-01.zip"
         rc=$?
         if [ "${rc}" != 0 ]
         then
            echo "ERROR: Extraction of V35071-01.zip failed"
            exit 1
         fi
      fi

      if [ -e "${swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip" ]
      then
         let steps++
         echo "Step: ${steps} - Install ODSEE 11g"
         cd ${curdir}
         unzip -oq "${swdir}/odsee/ODSEE_ZIP_Distribution/sun-dsee7.zip"
         rc=$?
         if [ "${rc}" != 0 ]
         then
            echo "ERROR: Extraction of sun-dsee7.zip failed"
            exit 1
         fi
      fi
   fi

   # Extract and install ODSEE patches
   cd "${bitsdir}"
   patches=$(ls -1 p*_111170_Linux-x86-64.zip 2> /dev/null|sed -e "s/^p//g" -e "s/_111170_Linux-x86-64.zip//g")
   for patch in ${patches}
   do
      # Extract patch
      if [ -d "${swdir}/odsee/${patch}" ]
      then
         true
      else
         mkdir -p "${swdir}/odsee/${patch}" 2> /dev/null
         cd "${swdir}/odsee/${patch}"
         unzip -oq "${bitsdir}/p${patch}_111170_Linux-x86-64.zip"
         rc=$?
         tar -zxf dsee*.tar.gz 2> /dev/null
         rc=$?
      fi

      # Install patch
      if [ -e "${curdir}/dsee7/patch.${patch}" ]
      then
         true
      else
         let steps++
         echo "Step: ${steps} - Install patch ${patch}"
         unzip -oq "${swdir}/odsee/${patch}/sun-dsee7.zip"
         rc=$?
         if [ "${rc}" == 0 ]
         then
            touch "${curdir}/dsee7/patch.${patch}"
         else
            echo "ERROR: Failed to install patch ${patch}"
            exit 1
         fi
      fi
   done
}

###############################################################################
# Setup ODSEE
###############################################################################
setup_odsee() {
   # Make sure ODSEE is installed
   install_odsee

   # Check to see if alredy setup
   if [ -d "${curdir}/dsee7/var/ds${pnum}" ]
   then
      echo "ERROR: ODSEE instance ds${pnum} is already setup"
      exit 1
   fi

   # Setup DSEE instance
   let steps++
   echo "Step: ${steps} - Create ODSEE instance (ds${pnum})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/dsadm create -w "${jPW}" -p ${pnum}393 -P ${pnum}640 ${curdir}/dsee7/var/ds${pnum} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?;set +x


   # Make sure cert exists
   ${curdir}/manage_certs.sh gencert -h ${localHost} ${dbgFlag}

   # Load cert
   let steps++
   echo "Step: ${steps} - Load certificate (ds${pnum})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/dsadm import-cert -i -W ${jPW} -I ${jPW} ${curdir}/dsee7/var/ds${pnum} ${certdir}/${localHost}/${localHost}.p12 >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?;set +x

   let steps++
   echo "Step: ${steps} - Load certificate chain (ds${pnum})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/dsadm import-cert -i -W ${jPW} -I ${jPW} ${curdir}/dsee7/var/ds${pnum} ${certdir}/truststore.p12 >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?;set +x

   let steps++
   echo "Step: ${steps} - Start ODSEE instance (ds${pnum})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/dsadm start ${curdir}/dsee7/var/ds${pnum} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?

   # Configure DSEE
   ${curdir}/dsee7/bin/dsconf set-server-prop -i -e -c -w "${jPW}" -h ${localHost} -p ${pnum}393 ssl-rsa-cert-name:server-cert >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?;set +x

   let steps++
   echo "Step: ${steps} - Create suffix (ds${pnum})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/dsconf create-suffix -i -e -c -w "${jPW}" -h ${localHost} -p ${pnum}393 ${suffix} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?;set +x

   let steps++
   echo "Step: ${steps} - Enable replication (ds${pnum})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/dsconf enable-repl -i -e -c -w "${jPW}" -h ${localHost} -p ${pnum}393 --repl-id ${replid} master "${suffix}" >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?
   ${curdir}/dsee7/bin/dsconf set-server-prop -i -e -c -w "${jPW}" -h ${localHost} -p ${pnum}393 def-repl-manager-pwd-file:"${jPW}" >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?;set +x

   # Load custom schema (ds${pnum})                                         
   if [ -s "${schemaFile}" ]
   then
      let steps++
      echo "Step: ${steps} - Load custom schema (ds${pnum})"
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${oudmwdir}/oud/bin/ldapmodify -h ${localHost} -p ${pnum}393 -D 'cn=Directory Manager' -j "${jPW}" -ac -f ${schemaFile} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
      rc=$?;set +x
   fi

   # Restart ODSEE DS instance (ds${pnum})                                  
   let steps++
   echo "Step: ${steps} - Restart ODSEE (ds${pnum})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/dsadm stop ${curdir}/dsee7/var/ds${pnum} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?
   ${curdir}/dsee7/bin/dsadm start ${curdir}/dsee7/var/ds${pnum} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?;set +x

   # If supplier provided, add replication agreements
   if [ -n "${supplierHost}" ] && [ -n "${supplierPort}" ]
   then
      # Setup replication agreements
      let steps++
      echo "Step: ${steps} - Setup replication agreements between ds${pnum} and supplier instance (${supplierH}:${supplierPort})"
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/dsee7/bin/dsconf create-repl-agmt -i -e -c -w "${jPW}" -h "${supplierHost}" -p ${supplierPort} "${suffix}" ${localHost}:${pnum}393 >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
      rc=$?

      ${curdir}/dsee7/bin/dsconf accord-repl-agmt -i -e -c -w "${jPW}" -h "${supplierHost}" -p ${supplierPort} "${suffix}" ${localHost}:${pnum}393 >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
      rc=$?

      ${curdir}/dsee7/bin/dsconf create-repl-agmt -i -e -c -w "${jPW}" -h "${localHost}" -p ${pnum}393 "${suffix}" ${supplierHost}:${supplierPort} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
      rc=$?

      ${curdir}/dsee7/bin/dsconf accord-repl-agmt -i -e -c -w "${jPW}" -h "${localHost}" -p ${pnum}393 "${suffix}" ${supplierHost}:${supplierPort} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
      rc=$?;set +x

      let steps++
      echo "Step: ${steps} - Initialize ds${pnum} from supplier instance (${supplierH}:${supplierPort})"
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/dsee7/bin/dsconf init-repl-dest -i -e -c -w "${jPW}" -h "${supplierHost}" -p ${supplierPort} "${suffix}" ${localHost}:${pnum}393 >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
      rc=$?;set +x
   elif [ -z "${supplierHost}" ] && [ -z "${supplierPort}" ]
   then
      # Import data into DSEE instance
      let steps++
      echo "Step: ${steps} - Import data into (ds${pnum})"
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${curdir}/dsee7/bin/dsconf import -i -e -c -w "${jPW}" -h ${localHost} -p ${pnum}393 -i "${dataFile}" "${suffix}" >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
      rc=$?;set +x
   fi

   # Ensure that PWP is at DS6 compat mode
   let steps++
   echo "Step: ${steps} - Set password policy to DS6-mode"

   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/dsconf pwd-compat -i -e -c -w "${jPW}" -h "${localHost}" -p ${pnum}393 to-DS6-migration-mode >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?

   ${curdir}/dsee7/bin/dsconf pwd-compat -i -e -c -w "${jPW}" -h "${localHost}" -p ${pnum}393 to-DS6-mode >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
   rc=$?;set +x
}

###############################################################################
# Deinstall ODSEE
###############################################################################
deinstall_odsee() {
   if [ -z "${pnum}" ];then pnum=0;fi

   if [ "${dbg}" == 'true' ];then set -x;fi
   if [ ${pnum} -eq 0 ]
   then
      readarray -t instances < <(ls -1dt ${curdir}/dsee7/var/ds[1-9]* 2> /dev/null|sed -e "s/ /SSPPAACCEE/g")
      if [ -n "${instances[*]}" ]
      then
         for (( i=0; i< ${#instances[*]}; i++ ))
         do
            inst=$(echo ${instances[${i}]}|sed -e "s/SSPPAACCEE/ /g")
            instnum=$(echo ${instances[${i}]}|sed -e "s/^.*var\/ds//g")
            let steps++
            echo "Step: ${steps} - Delete ODSEE (ds${instnum})"
            ${curdir}/dsee7/bin/dsadm delete ${inst} >> ${logdir}/ds${instnum}-setup-${now}.log 2>&1
            rc=$?
         done
      fi
   else
      if [ -e "${curdir}/dsee7/var/ds${pnum}" ]
      then
         let steps++
         echo "Step: ${steps} - Delete ODSEE (ds${pnum})"
         ${curdir}/dsee7/bin/dsadm delete ${curdir}/dsee7/var/ds${pnum} >> ${logdir}/ds${pnum}-setup-${now}.log 2>&1
         rc=$?
      fi
   fi
   set +x
}

###############################################################################
# Show ODSEE Replication Status
###############################################################################
show_rstatus() {
   let steps++
   echo "Step: ${steps} - Delete ODSEE (ds${pnum})"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/dsee7/bin/insync -s "${bDN}:${bPW}@${localHost}:${pnum}393"
   set +x
}

###############################################################################
# Show ODSEE Replication Status
###############################################################################
apply_mods() {
   let steps++
   echo "Step: ${steps} - Apply modifications (ds${pnum})"
   if [ -z "${myClients}" ];then clients=1;fi
   if [ -z "${myThreads}" ];then threads=1;fi
   if [ -z "${myM}" ];then M=1;fi
   if [ -z "${mym}" ];then m=5;fi
   if [ "${dbg}" == 'true' ];then set -x;fi
   #${curdir}/manage_load.sh modrate -p ${pnum}393 -c ${clients} -t ${threads} -M ${M} -m ${m} -N ${numUsers} ${dbgFlag}
   #set +x
   firstUser=$(head -1 "${cfgdir}/${templateName}.rdn")
   ${lmod} -Z -X -p ${pnum}393 -h ${localHost} -D "${bDN}" -j "${jPW}" >> ${logdir}/load-schema-${now}.log 2>&1 <<EOF
dn: ${firstUser}
changeType: modify
replace: description
description: test
EOF

}

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
          'setup') setup_odsee;;
           'stop') stop_odsee;;
          'start') start_odsee;;
      'deinstall') deinstall_odsee;;
        'install') install_odsee;;
        'rstatus') show_rstatus;;
            'mod') apply_mods;;
                *) showUsage;;
esac
