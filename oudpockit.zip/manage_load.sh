#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Usage
###############################################################################
showUsage() {
   msg="$1"
   if [ -n "${msg}" ];then echo -e "Error: ${msg}\n";fi

cat <<EOF
NAME
     ${cmd}

SYNOPSIS
     ${cmd} [ searchrate | bsearchrate | authrate | modrate ] [options]

DESCRIPTION
     Sample script to generate load against directory server

OPTIONS
     Setup Options

         --host <host>           OUD host
                                 Default: localhost 
         --ldap <port>           OUD LDAP port number
                                 Default: ${ldapPort}

         --ldaps <port>          OUD Secure LDAPS port number
                                 Default: ${ldapsPort}

         --suffix <suffix>       Base suffix
                                 Default: ${suffix}

         --ubase <base>          User branch from base suffix
                                 Default: ou=People

         --rdn <rdn>             RDN attribute
                                 Default: uid

         -N <number>             Number of users to span
                                 Default: 1000

         --firstnum <number>     First number of user span
                                 Default: 10000

         --lastnum <number>      Last number of user span
                                 Default: 10999

         --clients <number>      Number of clients
                                 Default: 3

         --threads <number>      Number of clients
                                 Default: 1

         --M <number>            Number of operations per second
                                 Default: 100

         --m <number>            Total number of operations
                                 Default: 10000

         --jh <dir>              JAVA_HOME directory if not already specified in env

         --swdir <dir>           Directory of the extracted software

         --fmwi <file>           Fusion Middleware Infrastructure jar file
                                 Default: ${curdir}/fmw_12.2.1.4.0_infrastructure_generic.jar

         --fmwo <file>           Fusion Middleware OUD jar file
                                 Default: ${curdir}/fmw_12.2.1.4.0_oud_generic.jar

EOF

   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
            swdir) swdir="$1";shift;;
            bitsdir) bitsdir="$1";shift;;
            host) host="$1";shift;;
            https) restPort="$1";shift;;
            ldap) myLdapPort="$1";shift;;
            ldaps) myLdapsPort="$1";shift;;
            firstnum) myFirstNum="$1";shift;;
            lastnum) myLastNum="$1";shift;;
            suffix) suffix="$1";shift;;
            ubase) ubase="$1";shift;;
            rdn) rdn="$1";shift;;
            jh) export JAVA_HOME="$1";PATH="$JAVA_HOME:$PATH";shift;;
            fmwi) fmwi="$1";shift;;
            fmwo) fmwo="$1";shift;;
            nosudo) sudoFlag=' --nosudo';;
            14c) export fmwVersion='14c';export fmwFlag="--${fmwVersion}";;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            h) host="$1";shift;;
            p) myLdapPort="$1";shift;;
            D) bDN="$1";;
            j) jPW="$1";;
            S) suffix="$1";;
            c) clients="$1";;
            t) threads="$1";;
            M) M="$1";;
            m) m="$1";;
            N) numUsers="$1";shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Validate inputs and set defaults
###############################################################################
if [ -z "${host}" ];then host="${localHost}";fi
magnitude=$((${numUsers}*10))
firstNum=$((${magnitude}))
lastNum=$((${magnitude}+${numUsers}-1))
if [ -n "${myFirstNum}" ];then firstNum=${myFirstNum}";fi
if [ -n "${myLastNum}" ];then firstNum=${myLastNum}";fi
if [ -n "${myLdapPort}" ] && [ -n "${myLdapsPort}" ]
then
   echo "Error: Only LDAP or LDAPS ports can be provided but not both"
   exit 1
fi

if [ -n "${myLdapPort}" ];then port=${myLdapPort};sslOpts='';fi
if [ -n "${myLdapsPort}" ];then port=${myLdapsPort};sslOpts=' -Z -X ';fi

if [ -z "${myLdapPort}" ] && [ -z "${myLdapsPort}" ];then port=${ldapPort};sslOpts='';fi


###############################################################################
# Extract software
###############################################################################
if [ -e  "${searchrate}" ]
then
   true
else
   cd "${swdir}"
   if [ -e  "${searchrate}" ]
   then
      unzip -q "${swdir}/perftools.zip"
   else
      if [ -e  "${swdir}/perftools.zip" ];then true; else curl -s -L -o ${swdir}/perftools.zip http://www.oracle.com/technetwork/middleware/id-mgmt/learnmore/ldapperftools-1973807.zip;fi
      unzip -q "${swdir}/perftools.zip"
   fi
fi

if [ -e  "${searchrate}" ]
then
   true
else
   showUsage "Perftools not installed"
fi

run_searchrate() {
   ckLDAP=$(test_port ${host} ${port})
   if [ -z "${ckLDAP}" ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${searchrate} -f ${sslOpts} -h ${host}:${port} -D "${bDN}" -j "${jPW}" \
         -g "rand(${firstNum},${lastNum})" \
         -s sub -c ${clients} -t ${threads} -M ${M} -m ${m} \
         -b "${rdn}=user%s,${ubase},${suffix}" '(objectClass=*)'
      rc=$?
      set +x
   fi
}

run_bsearchrate() {
   ckLDAP=$(test_port ${host} ${port})
   if [ -z "${ckLDAP}" ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${searchrate} -f ${sslOpts} -h ${host}:${port} -D "${bDN}" -j "${jPW}" \
         -g "rand(${firstNum},${lastNum})" \
         -s sub -c ${clients} -t ${threads} -M ${M} -m ${m} \
         -b "${suffix}" "(${rdn}=user%s)"
      rc=$?
      set +x
   fi
}

run_authrate() {
   ckLDAP=$(test_port ${host} ${port})
   if [ -z "${ckLDAP}" ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${authrate} -f ${sslOpts} -h ${host}:${port} \
         -g "rand(${firstNum},${lastNum})" \
         -D "${rdn}=user%s,${ubase},${suffix}" -j "${jPW}" \
         -s sub -c ${clients} -M ${M} -m ${m} 
      rc=$?
      set +x
   fi
}

run_modrate() {
   ckLDAP=$(test_port ${host} ${port})
   if [ -z "${ckLDAP}" ]
   then
      if [ "${dbg}" == 'true' ];then set -x;fi
      ${modrate} -f ${sslOpts} -h ${host}:${port} \
         -D "${bDN}" -j "${jPW}" \
         -g "rand(${firstNum},${lastNum})" -g "randstr(20)" \
         -b "${rdn}=user%1\$s,${ubase},${suffix}" \
         -c ${clients} -t ${threads} -M ${M} -m ${m} \
         "description:%2\$s"
      rc=$?
      set +x
   fi
}


# Install OUD
rm ${cfgdir}/.steps.install 2> /dev/null
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_install.sh install oud --jh "$JAVA_HOME" --bitsdir "${bitsdir}" ${dbgFlag} ${sudoFlag} ${fmwFlag} --step ${steps}
set +x
if [ -e "${cfgdir}/.steps.install" ];then steps=$(cat ${cfgdir}/.steps.install);fi

###############################################################################
# Process subcommand
###############################################################################
case ${subcmd} in
     'searchrate') run_searchrate;;
    'bsearchrate') run_bsearchrate;;
       'authrate') run_authrate;;
        'modrate') run_modrate;;
                *) showUsage;;
esac
