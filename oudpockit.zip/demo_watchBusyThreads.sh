#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

##############################################################################
# Watch busy threads script
##############################################################################

INST_NAME="$1"

if [ -z "${INST_NAME}" ];then echo "Usage: ${0} <instance_name>";exit 1;fi

setfmwenv
if [ -z "${JAVA_HOME}" ];then echo "Error: Must set JAVA_HOME to JDK 1.8 or later";exit 1;fi

printf "%-16s%-10s%-60s\n" "Date/Time" "CPU" "Which Thread"
while true
do
   pid=$(ps -ef|grep \/${INST_NAME}\/|grep config.ldif|grep -v grep|awk '{ print $2 }')
   if [ "${pid}" ]
   then
      dec=$(echo ${pid}|xargs -n1 top -b -H -d 1 -n 1 -p|grep -v java|head -9|tail -1|awk '{ print $1 " " $9 }')
      hex=$(echo "obase=16; ${dec}"|awk '{ print $1 " " $2 }' | bc)
      cpu=$(echo ${dec}|awk '{ print $2 }')
      jstack=$(${JAVA_HOME}/bin/jstack ${pid} 2>&1|egrep -v "^$|Full thread dump Java HotSpot")
      thread=$(echo "${jstack}"|grep -i "nid=0x${hex}")
      threadDump=$(echo "${jstack}"|sed -e "s/^/BBEEGGIINN/g"|tr -d '[\n\r]'|sed -e "s/BBEEGGIINN\"/BEGINBLOCK/g" -e "s/^.*nid=0x${hex}//g" -e 's/BEGINBLOCK.*$/BEGINBLOCK/' -e "s/BEGINBLOCK//g" -e 's/BBEEGGIINN/\n   /g'|egrep -v "^$|JAVA_TOOL_OPTIONS:")
      printf "%-16s%-10s%-60s\n" "${now}" "${cpu}" "${thread}"
      echo "${threadDump}"
   else
      echo "Error: No running OUD instances found"
   fi
   sleep 1
done
