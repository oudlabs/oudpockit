#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Show Usage
###############################################################################
showUsage() {
   echo "Usage: ${cmd} [--ktype (none | jks | p12) ]"
   echo "Default is none"
   echo "   none = Self-signed certificate in JKS provider"
   echo "   jks  = CA-signed certificate in JKS provider"
   echo "   p12  = CA-signed certificate in PKCS12 provider"
   exit 1
}

###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            ktype) ktype=$1;shift;;
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

###############################################################################
# Set provider store variables
###############################################################################
if [ -z "${ktype}" ];then ktype='none';fi
case ${ktype} in
     'none') kstore="${oudmwdir}/oud1/OUD/config/keystore"
             tstore="${oudmwdir}/oud1/OUD/config/truststore"
             provider="JKS"
             signer="self"
             ;;
      'jks') kstore="${oudmwdir}/oud1/OUD/config/keystore"
             tstore="${oudmwdir}/oud1/OUD/config/truststore"
             provider="JKS"
             signer="CA"
             ;;
      'p12') kstore="${oudmwdir}/oud1/OUD/config/keystore.p12"
             tstore="${oudmwdir}/oud1/OUD/config/truststore.p12"
             provider="PKCS12"
             signer="CA"
             ;;
          *) showUsage;;
esac

###############################################################################
# Share requisite expectations"
###############################################################################
echo -e "\nThis demonstration shows how to replace oud1 server ${provider} provider's"
echo -e "${signer}-signed certificate with CA signed certificate."

###############################################################################
# Check for OUD1
###############################################################################
if [ -e "${oudmwdir}/oud1" ]
then
   echo "No OUD instances should exist when running this demo. Exiting"
   exit 1
fi

###############################################################################
# Generate data
###############################################################################
if [ -e "${cfgdir}/inetorg.ldif" ]
then
   true
else
   echo -e "\nDEMO --> Generate data for the OUD topology"
   ${curdir}/manage_data.sh genall -n inetorg -N 1000 --rm
fi


###############################################################################
# Setup 2 replicated OUD instances
###############################################################################
if [ -e "${oudmwdir}/oud1" ]
then
   true
else
   echo -e "\nDEMO --> Setup oud1 with ${signer}-signed certificate"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oud.sh setup --pnum 1 -n inetorg --noroles --notune --ktype ${ktype}
   set +x
fi

if [ -e "${oudmwdir}/oud2" ]
then
   true
else
   echo -e "\nDEMO --> Setup oud2 with ${signer}-signed certificate"
   if [ "${dbg}" == 'true' ];then set -x;fi
   ${curdir}/manage_oud.sh setup --pnum 2 -n inetorg --noroles --notune --ktype ${ktype} --supplier ${localHost}:1444:1989
   set +x
fi

###############################################################################
# Show replication is working between the two OUD instances
###############################################################################
echo -e "\nDEMO --> Show replication between the two OUD instances"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh rstatus -z
set +x

###############################################################################
# Show existing oud1 certificate
###############################################################################
echo -e "\nDEMO --> Show oud1 server ${provider} cert"
if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -T -h ${localHost} -Z -p 1636 -D "${bDN}" -j "${jPW}" -b '' -s base objectClass=top <<EOF

EOF
set +x

###############################################################################
# Replace oud1 server JDK cert provider's ${signer}-signed cert with CA signed cert
###############################################################################
echo -e "\nDEMO --> Backup keystore and truststore"
if [ "${dbg}" == 'true' ];then set -x;fi
case ${ktype} in
   'none') cp ${kstore} ${kstore}.${now}
           cp ${tstore} ${tstore}.${now}
           ;;
    'jks') cp ${cfgdir}/certs/${localHost}/${localHost}.jks "${kstore}"
           cp ${cfgdir}/certs/CA/truststore "${tstore}"

           # Re-configure JKS provider to ${kstore}
           echo -e "\nDEMO --> Get pin value of oud1 server ${provider} provider keystore."
           if [ "${dbg}" == 'true' ];then set -x;fi
           export storepass=$(${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --advanced --no-prompt --showKeystorePassword get-key-manager-provider-prop --provider-name ${provider} --property key-store-pin|grep "^key-store-pin"|cut -d' ' -f3)
           rc=$?;set +x

           if [ -z "${storepass}" ]
           then
              echo "ERROR: Could not retrieve the keystore pin"
              exit 1
           fi

           echo -e "\nDEMO --> Re-configure oud1 JKS provider new ${provider} truststore"
           if [ "${dbg}" == 'true' ];then set -x;fi
           ${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --no-prompt set-trust-manager-provider-prop --provider-name JKS --set trust-store-file:"${tstore}" --set trust-store-pin:${storepass}
           rc=$?;set +x

           echo -e "\nDEMO --> Re-configure JKS provider use new ${provider} keystore"
           if [ "${dbg}" == 'true' ];then set -x;fi
           ${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --no-prompt set-key-manager-provider-prop --provider-name JKS --set key-store-file:"${kstore}" --set key-store-pin:${storepass}
           rc=$?;set +x

           echo -e "\nDEMO --> Restart oud1 to apply JKS provider changes"
           ${curdir}/manage_oud.sh stop --pnum 1 
           ${curdir}/manage_oud.sh start --pnum 1 
           ;;
    'p12') cp ${cfgdir}/certs/${localHost}/${localHost}.p12 "${kstore}"
           cp ${cfgdir}/certs/truststore.p12 "${tstore}"

           # Re-configure PKCS12 provider to ${kstore}
           echo -e "\nDEMO --> Get pin value of oud1 server ${provider} provider keystore."
           if [ "${dbg}" == 'true' ];then set -x;fi
           export storepass=$(${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --advanced --no-prompt --showKeystorePassword get-key-manager-provider-prop --provider-name ${provider} --property key-store-pin|grep "^key-store-pin"|cut -d' ' -f3)
           rc=$?;set +x

           if [ -z "${storepass}" ]
           then
              echo "ERROR: Could not retrieve the keystore pin"
              exit 1
           fi

           echo -e "\nDEMO --> Re-configure oud1 PKCS12 provider new ${provider} truststore"
           if [ "${dbg}" == 'true' ];then set -x;fi
           ${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --no-prompt set-trust-manager-provider-prop --provider-name PKCS12 --set trust-store-file:"${tstore}" --set trust-store-pin:${storepass}
           rc=$?;set +x

           echo -e "\nDEMO --> Re-configure PKCS12 provider use new ${provider} keystore"
           if [ "${dbg}" == 'true' ];then set -x;fi
           ${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --no-prompt set-key-manager-provider-prop --provider-name PKCS12 --set key-store-file:"${kstore}" --set key-store-pin:${storepass}
           rc=$?;set +x

           echo -e "\nDEMO --> Restart oud1 to apply PKCS12 provider changes"
           ${curdir}/manage_oud.sh stop --pnum 1 
           ${curdir}/manage_oud.sh start --pnum 1 
           ;;
esac
set +x

echo -e "\nDEMO --> Get pin value of oud1 server ${provider} keystore."
echo -e "           Note that keystore and truststore pin are the same by default."
if [ "${dbg}" == 'true' ];then set -x;fi
export storepass=$(${oudmwdir}/oud1/OUD/bin/dsconfig -h ${localHost} -X -p 1444 -D "${bDN}" -j "${jPW}" --advanced --no-prompt --showKeystorePassword get-key-manager-provider-prop --provider-name ${provider} --property key-store-pin|grep "^key-store-pin"|cut -d' ' -f3)
rc=$?;set +x

if [ -z "${storepass}" ]
then
   echo "ERROR: Could not retrieve the keystore pin"
   exit 1
fi

echo -e "\nDEMO --> Delete server-cert from keystore"
if [ "${dbg}" == 'true' ];then set -x;fi
${ktool} -delete -alias server-cert -keystore "${kstore}" -storepass ${storepass} -keypass ${storepass} -noprompt
rc=$?;set +x

echo -e "\nDEMO --> Generate new certificate"
if [ "${dbg}" == 'true' ];then set -x;fi
${ktool} -genkeypair -keystore "${kstore}" -storepass ${storepass} -keypass ${storepass} -alias server-cert -dname "cn=${localHost},${suffix}" -keysize 2048 -keyalg RSA -sigalg SHA256withRSA -validity 1440 -noprompt
rc=$?;set +x

echo -e "\nDEMO --> Request Certificate Signing Request (CSR)"
if [ "${dbg}" == 'true' ];then set -x;fi
${ktool} -certreq -storepass ${storepass} -keystore "${kstore}" -keypass ${storepass} -alias server-cert -file ${tmpdir}/certs/${localHost}.csr -noprompt
rc=$?;set +x

echo -e "\nDEMO --> Sign CSR and output to PEM file"
if [ "${dbg}" == 'true' ];then set -x;fi
${ktool} -gencert -storepass ${storepass} -keystore "${kstore}" -alias server-cert -ext BC=0  -rfc -infile ${tmpdir}/certs/${localHost}.csr -outfile ${tmpdir}/certs/${localHost}.pem -noprompt
rc=$?;set +x

echo -e "\nDEMO --> Import signed certificate into keystore"
if [ "${dbg}" == 'true' ];then set -x;fi
${ktool} -importcert -storepass ${storepass} -keystore "${kstore}" -alias server-cert -file ${tmpdir}/certs/${localHost}.pem -noprompt
rc=$?;set +x

echo -e "\nDEMO --> Import intermediate and root CA into keystore"
if [ "${dbg}" == 'true' ];then set -x;fi
${ktool} -importcert -trustcacerts -storepass ${storepass} -keystore "${kstore}" -alias intermediate-ca -file ${cfgdir}/certs/intermediate/certs/ica-cert.pem -noprompt
rc=$?
${ktool} -importcert -trustcacerts -storepass ${storepass} -keystore "${kstore}" -alias root-ca -file ${cfgdir}/certs/CA/certs/ca-cert.pem -noprompt
rc=$?;set +x

echo -e "\nDEMO --> Delete ${signer}-signed certificate from truststore"
if [ "${dbg}" == 'true' ];then set -x;fi
${ktool} -delete -alias server-cert -keystore "${tstore}" -storepass ${storepass} -keypass ${storepass} -noprompt
rc=$?;set +x

echo -e "\nDEMO --> Import intermediate and root CA into truststore"
if [ "${dbg}" == 'true' ];then set -x;fi
${ktool} -importcert -trustcacerts -storepass ${storepass} -keystore "${tstore}" -alias intermediate-ca -file ${cfgdir}/certs/intermediate/certs/ica-cert.pem -noprompt
rc=$?
${ktool} -importcert -trustcacerts -storepass ${storepass} -keystore "${tstore}" -alias root-ca -file ${cfgdir}/certs/CA/certs/ca-cert.pem -noprompt
rc=$?;set +x

echo -e "\nDEMO --> Restart OUD instance to apply cert changes"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_oud.sh stop --pnum 1 
${curdir}/manage_oud.sh start --pnum 1 
set +x

###############################################################################
# Show updated oud1 certificate
###############################################################################
echo -e "\nDEMO --> Confirm that server ${provider} cert change worked"
if [ "${dbg}" == 'true' ];then set -x;fi
${lsrch} -T -h ${localHost} -Z -p 1636 -D "${bDN}" -j "${jPW}" -b '' -s base objectClass=top <<EOF

EOF
set +x
