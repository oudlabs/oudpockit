#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# See if already setup
###############################################################################
if [ -e "${oudmwdir}/oud20/OUD/bin/start-ds" ]
then
   echo "ERROR: OUD is already setup for this purpose"
   exit 1
fi

###############################################################################
# Generate AD data
###############################################################################
echo "Generate Active Directory data"
${curdir}/manage_data.sh genall -N 10 -n ad --rm

###############################################################################
# Setup MSAD and OUD Instances
###############################################################################
echo "Setup OUD instantce to emulate Active Directory"
${curdir}/manage_oud.sh setup --pnum 20 --suffix 'dc=example,dc=com' -n ad --schema ${samples}/ad.schema --noroles

###############################################################################
# Show a few searches
###############################################################################
echo "Show a few searches"

set -x
${lsrch} -T -h ${localHost} -X -Z -p 20636 -D "cn=Administrator,cn=Users,${suffix}" -j "${jPW}" -b "${suffix}" -s sub uid=user1
rc=$?
