#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

##############################################################################
# Make sure clean slate
###############################################################################
if [ -d "${oudmwdir}/oud1" ]
then
   echo "ERROR: Please make sure no previous OUD instances exist before running this demo"
   exit 1
fi

###############################################################################
# Setup OUD instances and replication topology
###############################################################################
echo "DEMO --> Generate data for demo:"
if [ "${dbg}" == 'true' ];then set -x;fi
rm -f "${cfgdir}/my.tmpl" "${cfgdir}/my.ldif"
${curdir}/manage_data.sh genall --suffix "${suffix}" -N ${numUsers} ${dbgFlag}

echo "DEMO --> Setup OUD instance for demo:"
${curdir}/manage_oud.sh setup --pnum 1 --suffix "${suffix}" --schema ${curdir}/samples/my.schema --data ${cfgdir}/my.ldif ${dbgFlag}
#${curdir}/manage_oud.sh setup --pnum 2 --suffix "${suffix}" --supplier ${localHost}:${adminPort} ${dbgFlag}
set +x

###############################################################################
# Set JAVA_HOME if not already set
###############################################################################
if [ -z "${JAVA_HOME}" ];then export JAVA_HOME=$(ls -r1 ${swdir}/jdk1.8.0*/bin/java 2> /dev/null|head -1|sed -e "s/\/bin\/java//g");fi

echo "DEMO --> Show authrate before introductiong pass-through workflow element"
if [ "${dbg}" == 'true' ];then set -x;fi
${curdir}/manage_load.sh authrate -N ${numUsers} --suffix "${suffix}" ${dbgFlag}
set +x

echo "DEMO --> Add pass-through workflow element to update passwords"
if [ "${dbg}" == 'true' ];then set -x;fi
set -x
${dcfg} create-workflow-element \
          --element-name pta-wfe \
          --type pass-through-authentication \
          --set enabled:true \
          --set auth-provider-workflow-element:userRoot \
          --set user-provider-workflow-element:userRoot \
          --set save-password-on-successful-bind:true \
          --hostname ${localHost} \
          --port ${pnum}444 \
          --portProtocol LDAP \
          --trustAll \
          --bindDN "${bDN}" \
          --bindPasswordFile "${jPW}" \
          --no-prompt
rc=$?

${dcfg} set-workflow-prop \
          --workflow-name userRoot0 \
          --set workflow-element:pta-wfe \
          --hostname ${localHost} \
          --port ${pnum}444 \
          --portProtocol LDAP \
          --trustAll \
          --bindDN "${bDN}" \
          --bindPasswordFile "${jPW}" \
          --no-prompt
rc=$?
set +x

echo "DEMO --> Show authrate after introductiong pass-through workflow element"
${curdir}/manage_load.sh authrate -N ${numUsers} --suffix "${suffix}" ${dbgFlag}
