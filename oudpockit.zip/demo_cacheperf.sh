#!/bin/bash
cmd=$(basename $0)
curdir=$(dirname $0)
subcmd=$1
curdir=$(cd ${curdir}; pwd)
. ${curdir}/poc_vars
###############################################################################
# Copyright (c) 2019-2025 Oracle and/or its affiliates.
#
# The Oracle Unified Directory (OUD) Proof of Concept (POC) kit is intended to
# streamline OUD evaluations, proofs of concept and learning about OUD.
#
# The OUD POC Kit is NOT intended for production use though it has been used
# by some customers for that purpose. Note that you should remove the
# temporary password file (<kit_dir>/cfg/...pw) when not in use.
#
# The OUD POC Kit is open source and distributed under Universal Permissive
# License v1.0 as shown at https://oss.oracle.com/licenses/upl/.
###############################################################################

###############################################################################
# Retrieve cn=monitor data for db and entry caches and report performance
# dbCache for each backend
# entryCache for each entry Cache
###############################################################################
# Parse arguments
###############################################################################
while (($#)); do
    OPT=$1
    shift
    case $OPT in
        --*) case ${OPT:2} in
            help) showUsage;;
        esac;;
        -*) case ${OPT:1} in
            H) showUsage;;
            n) myTemplate=$1;shift;;
            z) dbg="true";dbgFlag=' -z ';;
        esac;;
    esac
done

if [ -n "${myTemplate}" ];then templateName=${myTemplate};else templateName='inetorg';fi

###############################################################################
# Usage
###############################################################################
if [ "${dbg}" == 'true' ];then set -x;fi

readarray -t metrics < <(${lsrch} -T -h ${localHost} -p 1444 -X -Z -D "${bDN}" -j "${jPW}" -s sub -b 'cn=monitor' '(|(entryCacheHitRatio=*)(EnvironmentNUpperINsFetch=*))' EnvironmentNUpperINsFetch EnvironmentNUpperINsFetchMiss EnvironmentNBINsFetch EnvironmentNBINsFetchMiss EnvironmentNBINsFetchMissRatio EnvironmentNLNsFetch EnvironmentNLNsFetchMiss entryCacheHitRatio currentEntryCacheCount|sed -e "s/ /${spcvar}/g" -e "s/	/${tabvar}/g" -e "s/$/|/g"|tr -d '[\n\r]'|sed -e "s/,cn=monitor//g" -e "s/dn:/\n/g")

printf "%-20s%-20s%-20s%-20s\n" "Backend" "LN Ratio" "BIN Ratio" "UBIN Ratio"
for (( x=0; x< ${#metrics[*]}; x++ ))
do
   object=$(echo "${metrics[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
   if [[ "${object}" == *Database\ Environment* ]]
   then
      be=$(echo ${object}|sed -e "s/^cn=//g" -e "s/ Database Environment//g" -e "s/|.*//g")

      lnfetch=$(echo ${object}|sed -e "s/^.*EnvironmentNLNsFetch: //g" -e "s/|.*//g")
      lnfetchmiss=$(echo ${object}|sed -e "s/^.*EnvironmentNLNsFetchMiss: //g" -e "s/|.*//g")

      binfetch=$(echo ${object}|sed -e "s/^.*EnvironmentNBINsFetch: //g" -e "s/|.*//g")
      binfetchmiss=$(echo ${object}|sed -e "s/^.*EnvironmentNBINsFetchMiss: //g" -e "s/|.*//g")
      binfetchmissratio=$(echo ${object}|sed -e "s/^.*EnvironmentNBINsFetchMissRatio: //g" -e "s/|.*//g")

      uinfetch=$(echo ${object}|sed -e "s/^.*EnvironmentNUpperINsFetch: //g" -e "s/|.*//g")
      uinfetchmiss=$(echo ${object}|sed -e "s/^.*EnvironmentNUpperINsFetchMiss: //g" -e "s/|.*//g")

      lnratio=$(echo ${lnfetch} ${lnfetchmiss}|awk '{ printf "%.0f", $1/$2*100 }' 2> /dev/null)
      if [ -z "${lnratio}" ];then lnratio=${lnfetch};fi
      binratio=$(echo ${binfetch} ${binfetchmiss}|awk '{ printf "%.0f", $1/$2*100 }' 2> /dev/null)
      if [ -z "${binratio}" ];then binratio=${binfetch};fi
      uinratio=$(echo ${uinfetch} ${uinfetchmiss}|awk '{ printf "%.0f", $1/$2*100 }' 2> /dev/null)
      if [ -z "${uinratio}" ];then uinratio=${uinfetch};fi

      printf "%-20s%-20s%-20s%-20s\n" "${be}" "${lnratio}" "${binratio}" "${uinratio}"
   fi
done

printf "\n%-20s%-20s%-20s\n" "EntryCache" "Entries" "Cache Ratio"
for (( x=0; x< ${#metrics[*]}; x++ ))
do
   object=$(echo "${metrics[${x}]}"|sed -e "s/${spcvar}/ /g" -e "s/${tabvar}/	/g")
   if [[ "${object}" == *Entry\ Cache* ]]
   then
      eCache=$(echo ${object}|sed -e "s/^.*cn=//g" -e "s/ Entry Cache//g" -e "s/Entry Caches/EntryCaches/g" -e "s/|.*//g")

      entries=$(echo ${object}|sed -e "s/^.*currentEntryCacheCount: //g" -e "s/|.*//g")
      if [ -z "${entries}" ];then entries=0;fi
 
      cacheratio=$(echo ${object}|sed -e "s/^.*entryCacheHitRatio: //g" -e "s/|.*//g")
      if [ -z "${cacheratio}" ];then cacheratio=0;fi

      printf "%-20s%-20s%-20s\n" "${eCache}" "${entries}" "${cacheratio}" 
   fi
done
